import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { paginationOptsValidator } from "convex/server";
import { getCurrentUser, getEffectiveUserId } from "./teamHelpers.ts";

export const createLabel = mutation({
  args: {
    cardId: v.id("cards"),
    labelData: v.object({
      cardName: v.string(),
      game: v.string(),
      set: v.optional(v.string()),
      cardNumber: v.optional(v.string()),
      condition: v.string(),
      grade: v.optional(v.string()),
      price: v.optional(v.number()),
      rarity: v.optional(v.string()),
      language: v.optional(v.string()),
      edition: v.optional(v.string()),
      notes: v.optional(v.string()),
    }),
    widthMm: v.optional(v.number()),
    heightMm: v.optional(v.number()),
    currency: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });

    const card = await ctx.db.get(args.cardId);
    if (!card || card.userId !== effectiveUserId) throw new ConvexError({ code: "FORBIDDEN", message: "Not your card" });

    const qrValue = `datcardvault://card/${args.cardId}`;
    return await ctx.db.insert("labels", {
      userId: effectiveUserId,
      cardId: args.cardId,
      labelData: args.labelData,
      widthMm: args.widthMm ?? 56,
      heightMm: args.heightMm ?? 35,
      currency: args.currency ?? user.currency ?? "GBP",
      qrValue,
      printed: false,
      printCount: 0,
    });
  },
});

export const updateLabel = mutation({
  args: {
    id: v.id("labels"),
    labelData: v.optional(v.object({
      cardName: v.string(),
      game: v.string(),
      set: v.optional(v.string()),
      cardNumber: v.optional(v.string()),
      condition: v.string(),
      grade: v.optional(v.string()),
      price: v.optional(v.number()),
      rarity: v.optional(v.string()),
      language: v.optional(v.string()),
      edition: v.optional(v.string()),
      notes: v.optional(v.string()),
    })),
    widthMm: v.optional(v.number()),
    heightMm: v.optional(v.number()),
    currency: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });

    const label = await ctx.db.get(args.id);
    if (!label || label.userId !== effectiveUserId) throw new ConvexError({ code: "FORBIDDEN", message: "Not your label" });

    const { id, ...rest } = args;
    await ctx.db.patch(id, rest);
  },
});

export const recordPrint = mutation({
  args: { id: v.id("labels"), copies: v.number() },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return;
    const label = await ctx.db.get(args.id);
    if (!label || label.userId !== effectiveUserId) return;
    await ctx.db.patch(args.id, {
      printed: true,
      printCount: (label.printCount ?? 0) + args.copies,
    });
  },
});

export const updateLabelByCardId = mutation({
  args: {
    cardId: v.id("cards"),
    labelData: v.object({
      cardName: v.string(),
      game: v.string(),
      set: v.optional(v.string()),
      cardNumber: v.optional(v.string()),
      condition: v.string(),
      grade: v.optional(v.string()),
      price: v.optional(v.number()),
      rarity: v.optional(v.string()),
      language: v.optional(v.string()),
      edition: v.optional(v.string()),
      notes: v.optional(v.string()),
    }),
  },
  handler: async (ctx, args) => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return;

    const label = await ctx.db
      .query("labels")
      .withIndex("by_card", (q) => q.eq("cardId", args.cardId))
      .first();
    if (!label || label.userId !== effectiveUserId) return;

    await ctx.db.patch(label._id, { labelData: args.labelData });
  },
});


export const patchLabelPrice = mutation({
  args: { cardId: v.id("cards"), price: v.number() },
  handler: async (ctx, args) => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return;
    const label = await ctx.db
      .query("labels")
      .withIndex("by_card", (q) => q.eq("cardId", args.cardId))
      .first();
    if (!label || label.userId !== effectiveUserId) return;
    await ctx.db.patch(label._id, {
      labelData: { ...label.labelData, price: args.price },
    });
  },
});

export const getLabels = query({
  args: { paginationOpts: paginationOptsValidator },
  handler: async (ctx, args) => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return { page: [], isDone: true, continueCursor: "" };
    return await ctx.db
      .query("labels")
      .withIndex("by_user", (q) => q.eq("userId", effectiveUserId))
      .order("desc")
      .paginate(args.paginationOpts);
  },
});

export const deleteLabel = mutation({
  args: { id: v.id("labels") },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });

    const label = await ctx.db.get(args.id);
    if (!label || label.userId !== effectiveUserId) throw new ConvexError({ code: "FORBIDDEN", message: "Not your label" });

    // Only allow deletion if the linked card is sold (archived)
    const card = await ctx.db.get(label.cardId);
    if (!card || !card.sold) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "You can only delete a label when its card has been sold and archived" });
    }

    await ctx.db.delete(args.id);
  },
});

export const checkCardHasLabel = query({
  args: { cardId: v.id("cards") },
  handler: async (ctx, args) => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return false;
    const label = await ctx.db
      .query("labels")
      .withIndex("by_card", (q) => q.eq("cardId", args.cardId))
      .first();
    return !!label;
  },
});

export const getLabelsWithCardStatus = query({
  args: { paginationOpts: paginationOptsValidator },
  handler: async (ctx, args) => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return { page: [], isDone: true, continueCursor: "" };
    const result = await ctx.db
      .query("labels")
      .withIndex("by_user", (q) => q.eq("userId", effectiveUserId))
      .order("desc")
      .paginate(args.paginationOpts);

    const page = await Promise.all(
      result.page.map(async (label) => {
        const card = await ctx.db.get(label.cardId);
        return { ...label, cardSold: card?.sold ?? false };
      })
    );
    return { ...result, page };
  },
});


