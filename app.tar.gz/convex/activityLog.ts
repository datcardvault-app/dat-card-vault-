import { internalMutation, query } from "./_generated/server";
import { v } from "convex/values";
import { paginationOptsValidator } from "convex/server";
import { getCurrentUser } from "./teamHelpers.ts";

/** Delete activity logs older than 90 days — run nightly */
export const pruneOldActivityLogs = internalMutation({
  args: {},
  handler: async (ctx): Promise<null> => {
    const cutoff = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString();
    const old = await ctx.db
      .query("activityLogs")
      .filter((q) => q.lt(q.field("at"), cutoff))
      .take(500);
    for (const row of old) await ctx.db.delete(row._id);
    return null;
  },
});

/** Write an audit log entry. Call from mutations/actions via ctx.runMutation. */
export const append = internalMutation({
  args: {
    userId: v.id("users"),
    action: v.string(),
    detail: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<null> => {
    await ctx.db.insert("activityLogs", {
      userId: args.userId,
      action: args.action,
      detail: args.detail,
      at: new Date().toISOString(),
    });
    return null;
  },
});

/** Paginated list of log entries for the current user, newest first. */
export const getMyLogs = query({
  args: { paginationOpts: paginationOptsValidator },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) return { page: [], isDone: true, continueCursor: "" };

    return await ctx.db
      .query("activityLogs")
      .withIndex("by_user_at", (q) => q.eq("userId", user._id))
      .order("desc")
      .paginate(args.paginationOpts);
  },
});

/** Recent entries for the dashboard activity feed — last N entries since a given ISO timestamp. */
export const getTodayFeed = query({
  args: { since: v.string(), limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) return [];
    return await ctx.db
      .query("activityLogs")
      .withIndex("by_user_at", (q) => q.eq("userId", user._id).gte("at", args.since))
      .order("desc")
      .take(args.limit ?? 20);
  },
});

/** Count of log entries in the last 24 hours — used for anomaly badge. */
export const recentCount = query({
  args: {},
  handler: async (ctx): Promise<number> => {
    const user = await getCurrentUser(ctx);
    if (!user) return 0;
    const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    const rows = await ctx.db
      .query("activityLogs")
      .withIndex("by_user_at", (q) => q.eq("userId", user._id).gte("at", since))
      .collect();
    return rows.length;
  },
});
