import { cronJobs } from "convex/server";
import { internal } from "./_generated/api";

const crons = cronJobs();

// Run daily at 3 AM UTC — delete accounts suspended for 35+ days
crons.daily(
  "auto delete suspended accounts",
  { hourUTC: 3, minuteUTC: 0 },
  internal.users.deleteExpiredSuspendedAccounts,
);

// Run nightly at 2 AM UTC — prune activity logs older than 90 days
crons.daily(
  "prune old activity logs",
  { hourUTC: 2, minuteUTC: 0 },
  internal.activityLog.pruneOldActivityLogs,
);

// Run nightly at 2:15 AM UTC — prune scan logs older than 30 days
crons.daily(
  "prune old scan logs",
  { hourUTC: 2, minuteUTC: 15 },
  internal.scans.pruneOldScanLogs,
);

export default crons;
