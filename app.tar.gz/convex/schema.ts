import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  users: defineTable({
    tokenIdentifier: v.string(),
    name: v.optional(v.string()),
    email: v.optional(v.string()),
    username: v.optional(v.string()),
    usernameLastChanged: v.optional(v.string()), // ISO 8601
    currency: v.optional(v.string()), // "GBP" | "USD"
    themeMode: v.optional(v.string()), // "dark" | "grey"
    suspended: v.optional(v.boolean()), // admin-set suspension
    suspendedAt: v.optional(v.string()), // ISO 8601 — set when suspended, cleared on unsuspend
    isGrantedAdmin: v.optional(v.boolean()), // granted by super admin
    isAffiliated: v.optional(v.boolean()), // affiliate/partner role
    isSupporter: v.optional(v.boolean()), // supporter role
    // Event mode
    eventActive: v.optional(v.boolean()),
    eventDays: v.optional(v.number()),
    eventStartDate: v.optional(v.string()),
    saleTarget: v.optional(v.number()), // money target in user's currency
    saleTargetSetAt: v.optional(v.string()), // ISO date string (YYYY-MM-DD) when target was last set
    // Label branding
    businessName: v.optional(v.string()),
    instagram: v.optional(v.string()),
    website: v.optional(v.string()),
    senderEmail: v.optional(v.string()),
    profileImageStorageId: v.optional(v.id("_storage")),
    logoStorageId: v.optional(v.id("_storage")),
    // Scan feedback
    scanSound: v.optional(v.boolean()),
    scanHaptics: v.optional(v.boolean()),
    scanSoundType: v.optional(v.string()),
    // Onboarding
    onboardingComplete: v.optional(v.boolean()),
    // Team mode
    teamId: v.optional(v.id("teams")),
    teamRole: v.optional(v.union(v.literal("owner"), v.literal("member"))),
  })
    .index("by_token", ["tokenIdentifier"])
    .index("by_username", ["username"]),

  teams: defineTable({
    ownerId: v.id("users"),
    joinCode: v.string(), // 6 uppercase alphanumeric
    name: v.optional(v.string()),
  })
    .index("by_owner", ["ownerId"])
    .index("by_join_code", ["joinCode"]),

  teamMembers: defineTable({
    teamId: v.id("teams"),
    userId: v.id("users"),
    role: v.union(v.literal("owner"), v.literal("member")),
    displayName: v.optional(v.string()),
  })
    .index("by_team", ["teamId"])
    .index("by_user", ["userId"]),

  presence: defineTable({
    userId: v.id("users"),
    teamId: v.id("teams"),
    lastSeen: v.number(), // Date.now() ms
    displayName: v.optional(v.string()),
  })
    .index("by_team", ["teamId"])
    .index("by_user", ["userId"]),

  // One document per calendar day per user
  dailyEarnings: defineTable({
    userId: v.id("users"),
    date: v.string(),          // "YYYY-MM-DD" UTC
    totalEarned: v.number(),   // sum of salePrice for cards sold on this day
    totalProfit: v.optional(v.number()), // sum of (salePrice - purchasePrice) where both known
    cardsSold: v.number(),
    topCard: v.optional(v.string()),
    topCardValue: v.optional(v.number()),
    deletedAt: v.optional(v.string()), // ISO 8601 — set when soft-deleted; row kept for PDF audit
  })
    .index("by_user", ["userId"])
    .index("by_user_date", ["userId", "date"]),

  cards: defineTable({
    userId: v.id("users"),
    name: v.string(),
    game: v.string(), // "Pokemon", "Magic", "Yu-Gi-Oh", "Other"
    set: v.optional(v.string()),
    cardNumber: v.optional(v.string()),
    condition: v.string(), // "Mint", "Near Mint", "Excellent", "Good", "Poor"
    grade: v.optional(v.string()), // "PSA 10", "BGS 9.5" etc
    purchasePrice: v.optional(v.number()),
    marketValue: v.optional(v.number()),
    salePrice: v.optional(v.number()),
    sold: v.boolean(),
    soldAt: v.optional(v.string()), // ISO 8601
    soldDate: v.optional(v.string()), // local YYYY-MM-DD used for earnings bucketing
    imageStorageId: v.optional(v.id("_storage")), // Front photo
    imageBackStorageId: v.optional(v.id("_storage")), // Back photo
    notes: v.optional(v.string()),
    rarity: v.optional(v.string()),
    language: v.optional(v.string()),
    edition: v.optional(v.string()),
  })
    .index("by_user", ["userId"])
    .index("by_user_sold", ["userId", "sold"])
    .index("by_sold_at", ["soldAt"]),

  labels: defineTable({
    userId: v.id("users"),
    cardId: v.id("cards"),
    labelData: v.object({
      cardName: v.string(),
      game: v.string(),
      set: v.optional(v.string()),
      cardNumber: v.optional(v.string()),
      condition: v.string(),
      grade: v.optional(v.string()),
      price: v.optional(v.number()),
      rarity: v.optional(v.string()),
      language: v.optional(v.string()),
      edition: v.optional(v.string()),
      notes: v.optional(v.string()),
    }),
    widthMm: v.optional(v.number()),
    heightMm: v.optional(v.number()),
    currency: v.optional(v.string()),
    qrValue: v.string(),
    printed: v.boolean(),
    printCount: v.optional(v.number()),
  })
    .index("by_user", ["userId"])
    .index("by_card", ["cardId"]),

  calendarNotes: defineTable({
    userId: v.id("users"),
    date: v.string(),   // "YYYY-MM-DD"
    note: v.string(),
  })
    .index("by_user", ["userId"])
    .index("by_user_date", ["userId", "date"]),

  scanLogs: defineTable({
    userId: v.id("users"),
    cardId: v.optional(v.id("cards")),
    labelId: v.optional(v.id("labels")),
    qrValue: v.string(),
    action: v.string(), // "scan", "sale_confirmed"
    scannedAt: v.string(), // ISO 8601
    notes: v.optional(v.string()),
  })
    .index("by_user", ["userId"])
    .index("by_scanned_at", ["scannedAt"]),

  // Security audit log — append-only record of sensitive account actions
  activityLogs: defineTable({
    userId: v.id("users"),
    action: v.string(),       // e.g. "settings_saved", "team_joined", "card_deleted"
    detail: v.optional(v.string()), // human-readable extra info
    ipHint: v.optional(v.string()), // not available server-side; reserved for future use
    at: v.string(),           // ISO 8601 UTC timestamp
  })
    .index("by_user", ["userId"])
    .index("by_user_at", ["userId", "at"]),

  // Team nudges — real-time "get to the table" alerts between team members
  nudges: defineTable({
    teamId: v.id("teams"),
    fromUserId: v.id("users"),
    fromName: v.string(),
    sentAt: v.number(), // Date.now() ms
  })
    .index("by_team", ["teamId"])
    .index("by_from_user", ["fromUserId"]),

  // Sealed TCG products (booster packs, boxes, ETBs etc.) identified by manufacturer barcode
  sealedProducts: defineTable({
    userId: v.id("users"),
    name: v.string(),
    game: v.string(),
    type: v.string(), // "Booster Pack" | "Booster Box" | "Elite Trainer Box" | "Tin" | "Bundle" | "Other"
    barcode: v.string(), // EAN-13 or UPC-A
    purchasePrice: v.optional(v.number()),
    sellPrice: v.optional(v.number()),
    quantity: v.number(),
    notes: v.optional(v.string()),
    imageStorageId: v.optional(v.id("_storage")),
    imageStorageIds: v.optional(v.array(v.id("_storage"))),
    soldAt: v.optional(v.string()), // ISO timestamp of most recent sale
    soldDate: v.optional(v.string()), // local YYYY-MM-DD used for earnings bucketing
    lastSalePrice: v.optional(v.number()), // sell price of most recent unit sold
  })
    .index("by_user", ["userId"])
    .index("by_barcode", ["barcode"]),

  // Buying deals logged from the dashboard % calculator
  buyingDeals: defineTable({
    userId: v.id("users"),
    date: v.string(),           // "YYYY-MM-DD" local
    cardPrice: v.number(),      // card's market value
    pct: v.number(),            // % offered to customer
    amountPaid: v.number(),     // cardPrice * pct / 100
    youKeep: v.number(),        // cardPrice - amountPaid
    cardCount: v.optional(v.number()), // how many cards in this deal
    note: v.optional(v.string()),
    at: v.string(),             // ISO 8601 UTC
    deletedAt: v.optional(v.string()), // ISO 8601 — soft-deleted; kept for PDF audit
  })
    .index("by_user", ["userId"])
    .index("by_user_date", ["userId", "date"]),

  // Snapshot of dailyEarnings taken before a rebuildEarnings — used for undo
  earningsSnapshots: defineTable({
    userId: v.id("users"),
    date: v.string(),
    totalEarned: v.number(),
    cardsSold: v.number(),
    topCard: v.optional(v.string()),
    topCardValue: v.optional(v.number()),
  })
    .index("by_user", ["userId"]),

  feedback: defineTable({
    userId: v.id("users"),
    name: v.optional(v.string()),
    type: v.union(v.literal("positive"), v.literal("negative")),
    message: v.string(),
    approved: v.optional(v.boolean()), // admin-approved for display
  })
    .index("by_type", ["type"])
    .index("by_user", ["userId"]),
});
