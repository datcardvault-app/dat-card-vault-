import { ConvexError, v } from "convex/values";
import { mutation, query, internalMutation } from "./_generated/server";
import { getCurrentUser, getEffectiveUserId } from "./teamHelpers.ts";

/** Delete scan logs older than 30 days — run nightly */
export const pruneOldScanLogs = internalMutation({
  args: {},
  handler: async (ctx): Promise<null> => {
    const cutoff = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
    const old = await ctx.db
      .query("scanLogs")
      .withIndex("by_scanned_at", (q) => q.lt("scannedAt", cutoff))
      .take(500);
    for (const row of old) await ctx.db.delete(row._id);
    return null;
  },
});

export const logScan = mutation({
  args: {
    qrValue: v.string(),
    action: v.string(),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });

    // Parse cardId from qrValue: datcardvault://card/<id>
    let cardId: string | undefined;
    let labelId: string | undefined;
    const match = args.qrValue.match(/datcardvault:\/\/card\/(.+)/);
    if (match) cardId = match[1];

    // Look up label for this card
    if (cardId) {
      const label = await ctx.db
        .query("labels")
        .withIndex("by_card", (q) => q.eq("cardId", cardId as string & { __tableName: "cards" }))
        .first();
      if (label) labelId = label._id;
    }

    return await ctx.db.insert("scanLogs", {
      userId: effectiveUserId,
      ...(cardId ? { cardId: cardId as string & { __tableName: "cards" } } : {}),
      ...(labelId ? { labelId: labelId as string & { __tableName: "labels" } } : {}),
      qrValue: args.qrValue,
      action: args.action,
      scannedAt: new Date().toISOString(),
      notes: args.notes,
    });
  },
});

export const getRecentScans = query({
  args: { sessionStart: v.optional(v.string()) },
  handler: async (ctx, args): Promise<{ id: string; cardName: string; qrValue: string; scannedAt: string; action: string }[]> => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return [];

    // Use explicit session start when provided; otherwise fall back to trading-day boundary (6am)
    let tradingDayStart: string;
    if (args.sessionStart) {
      tradingDayStart = args.sessionStart;
    } else {
      const now = new Date();
      const todayStart = new Date(now);
      todayStart.setHours(6, 0, 0, 0);
      if (now < todayStart) {
        todayStart.setDate(todayStart.getDate() - 1);
      }
      tradingDayStart = todayStart.toISOString();
    }

    const logs = await ctx.db
      .query("scanLogs")
      .withIndex("by_user", (q) => q.eq("userId", effectiveUserId))
      .order("desc")
      .take(200);

    // Only show scans from the current session start
    const sessionLogs = logs.filter((l) => l.scannedAt >= tradingDayStart).slice(0, 50);

    return await Promise.all(sessionLogs.map(async (log) => {
      let cardName = "Unknown Card";
      if (log.cardId) {
        const card = await ctx.db.get(log.cardId);
        if (card) cardName = card.name;
      }
      return { id: log._id, cardName, qrValue: log.qrValue, scannedAt: log.scannedAt, action: log.action };
    }));
  },
});

export const getMonthlySales = query({
  args: { year: v.number(), month: v.number() },
  handler: async (ctx, args) => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return [];

    const startDate = new Date(args.year, args.month - 1, 1).toISOString();
    const endDate = new Date(args.year, args.month, 1).toISOString();

    const cards = await ctx.db
      .query("cards")
      .withIndex("by_user_sold", (q) => q.eq("userId", effectiveUserId).eq("sold", true))
      .collect();

    return cards.filter(
      (c) => c.soldAt && c.soldAt >= startDate && c.soldAt < endDate
    );
  },
});
