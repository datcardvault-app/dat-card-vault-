import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser } from "./teamHelpers.ts";
import { internal } from "./_generated/api.js";

function generateCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

export const createTeam = mutation({
  args: { name: v.optional(v.string()) },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    // Already in a team?
    if (user.teamId) throw new ConvexError({ code: "CONFLICT", message: "You are already in a team. Leave it first." });

    // Generate unique join code
    let joinCode = generateCode();
    let attempts = 0;
    while (attempts < 10) {
      const existing = await ctx.db.query("teams").withIndex("by_join_code", (q) => q.eq("joinCode", joinCode)).first();
      if (!existing) break;
      joinCode = generateCode();
      attempts++;
    }

    const teamId = await ctx.db.insert("teams", {
      ownerId: user._id,
      joinCode,
      name: args.name,
    });

    // Add owner as member
    await ctx.db.insert("teamMembers", {
      teamId,
      userId: user._id,
      role: "owner",
      displayName: user.username ?? user.name ?? "Owner",
    });

    // Update user record
    await ctx.db.patch(user._id, { teamId, teamRole: "owner" });
    await ctx.scheduler.runAfter(0, internal.activityLog.append, {
      userId: user._id,
      action: "team_created",
      detail: args.name ? `Team "${args.name}" created` : "Team created",
    });
    return { teamId, joinCode };
  },
});

export const joinTeam = mutation({
  args: { joinCode: v.string() },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    if (user.teamId) throw new ConvexError({ code: "CONFLICT", message: "You are already in a team. Leave it first." });

    const code = args.joinCode.trim().toUpperCase();
    const team = await ctx.db.query("teams").withIndex("by_join_code", (q) => q.eq("joinCode", code)).first();
    if (!team) throw new ConvexError({ code: "NOT_FOUND", message: "No team found with that code." });

    // Check team size limit (max 2 members total including owner)
    const existingMembers = await ctx.db.query("teamMembers").withIndex("by_team", (q) => q.eq("teamId", team._id)).collect();
    if (existingMembers.length >= 2) throw new ConvexError({ code: "BAD_REQUEST", message: "Team is full (max 2 members)." });

    // Already a member?
    const already = existingMembers.find((m) => m.userId === user._id);
    if (already) throw new ConvexError({ code: "CONFLICT", message: "You are already in this team." });

    await ctx.db.insert("teamMembers", {
      teamId: team._id,
      userId: user._id,
      role: "member",
      displayName: user.username ?? user.name ?? "Member",
    });
    await ctx.db.patch(user._id, { teamId: team._id, teamRole: "member" });
    await ctx.scheduler.runAfter(0, internal.activityLog.append, {
      userId: user._id,
      action: "team_joined",
      detail: `Joined team with code ${code}`,
    });
    return { teamId: team._id };
  },
});

export const leaveTeam = mutation({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    if (!user.teamId) throw new ConvexError({ code: "BAD_REQUEST", message: "You are not in a team." });

    if (user.teamRole === "owner") {
      // Owner dissolves the team — remove all members and the team itself
      const members = await ctx.db.query("teamMembers").withIndex("by_team", (q) => q.eq("teamId", user.teamId!)).collect();
      for (const m of members) {
        await ctx.db.patch(m.userId, { teamId: undefined, teamRole: undefined });
        await ctx.db.delete(m._id);
      }
      // Remove presence rows
      const presenceRows = await ctx.db.query("presence").withIndex("by_team", (q) => q.eq("teamId", user.teamId!)).collect();
      for (const p of presenceRows) await ctx.db.delete(p._id);
      await ctx.db.delete(user.teamId);
      await ctx.scheduler.runAfter(0, internal.activityLog.append, {
        userId: user._id,
        action: "team_dissolved",
        detail: "Owner dissolved the team",
      });
    } else {
      // Member just leaves
      const memberRow = await ctx.db.query("teamMembers").withIndex("by_user", (q) => q.eq("userId", user._id)).first();
      if (memberRow) await ctx.db.delete(memberRow._id);
      const presenceRow = await ctx.db.query("presence").withIndex("by_user", (q) => q.eq("userId", user._id)).first();
      if (presenceRow) await ctx.db.delete(presenceRow._id);
      await ctx.db.patch(user._id, { teamId: undefined, teamRole: undefined });
      await ctx.scheduler.runAfter(0, internal.activityLog.append, {
        userId: user._id,
        action: "team_left",
        detail: "Left the team",
      });
    }
  },
});

export const removeMember = mutation({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    if (user.teamRole !== "owner") throw new ConvexError({ code: "FORBIDDEN", message: "Only the team owner can remove members." });
    if (args.userId === user._id) throw new ConvexError({ code: "BAD_REQUEST", message: "Cannot remove yourself." });

    const memberRow = await ctx.db.query("teamMembers").withIndex("by_user", (q) => q.eq("userId", args.userId)).first();
    if (!memberRow || memberRow.teamId !== user.teamId) throw new ConvexError({ code: "NOT_FOUND", message: "Member not found in your team." });
    await ctx.db.delete(memberRow._id);

    const presenceRow = await ctx.db.query("presence").withIndex("by_user", (q) => q.eq("userId", args.userId)).first();
    if (presenceRow) await ctx.db.delete(presenceRow._id);

    await ctx.db.patch(args.userId, { teamId: undefined, teamRole: undefined });
  },
});

export const regenerateCode = mutation({
  args: {},
  handler: async (ctx): Promise<string> => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    if (user.teamRole !== "owner" || !user.teamId) throw new ConvexError({ code: "FORBIDDEN", message: "Only the team owner can regenerate the code." });

    let joinCode = generateCode();
    let attempts = 0;
    while (attempts < 10) {
      const existing = await ctx.db.query("teams").withIndex("by_join_code", (q) => q.eq("joinCode", joinCode)).first();
      if (!existing) break;
      joinCode = generateCode();
      attempts++;
    }
    await ctx.db.patch(user.teamId, { joinCode });
    return joinCode;
  },
});

export const heartbeat = mutation({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user || !user.teamId) return;
    const existing = await ctx.db.query("presence").withIndex("by_user", (q) => q.eq("userId", user._id)).first();
    const displayName = user.username ?? user.name ?? "Unknown";
    if (existing) {
      await ctx.db.patch(existing._id, { lastSeen: Date.now(), displayName });
    } else {
      await ctx.db.insert("presence", { userId: user._id, teamId: user.teamId, lastSeen: Date.now(), displayName });
    }
  },
});

export const getMyTeam = query({
  args: {},
  handler: async (
    ctx,
  ): Promise<{
    team: { _id: string; joinCode: string; name?: string };
    members: { userId: string; role: "owner" | "member"; displayName?: string; lastSeen?: number; isOnline: boolean }[];
    myRole: "owner" | "member";
    myUserId: string;
  } | null> => {
    const user = await getCurrentUser(ctx);
    if (!user || !user.teamId) return null;

    const team = await ctx.db.get(user.teamId);
    if (!team) return null;

    const members = await ctx.db.query("teamMembers").withIndex("by_team", (q) => q.eq("teamId", user.teamId!)).collect();
    const presenceRows = await ctx.db.query("presence").withIndex("by_team", (q) => q.eq("teamId", user.teamId!)).collect();

    const now = Date.now();
    const ONLINE_THRESHOLD_MS = 60_000; // 60 seconds

    const membersWithPresence = members.map((m) => {
      const p = presenceRows.find((r) => r.userId === m.userId);
      const lastSeen = p?.lastSeen;
      return {
        userId: m.userId,
        role: m.role,
        displayName: p?.displayName ?? m.displayName,
        lastSeen,
        isOnline: lastSeen !== undefined && now - lastSeen < ONLINE_THRESHOLD_MS,
      };
    });

    return {
      team: { _id: team._id, joinCode: team.joinCode, name: team.name },
      members: membersWithPresence,
      myRole: user.teamRole ?? "member",
      myUserId: user._id,
    };
  },
});
