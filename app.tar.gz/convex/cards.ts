import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { paginationOptsValidator } from "convex/server";
import type { Id } from "./_generated/dataModel.d.ts";
import { getCurrentUser, getEffectiveUserId } from "./teamHelpers.ts";
import { upsertDailyEarnings, undoDailyEarnings } from "./earnings.ts";

export const addCard = mutation({
  args: {
    name: v.string(),
    game: v.string(),
    set: v.optional(v.string()),
    cardNumber: v.optional(v.string()),
    condition: v.string(),
    grade: v.optional(v.string()),
    purchasePrice: v.optional(v.number()),
    marketValue: v.optional(v.number()),
    imageStorageId: v.optional(v.id("_storage")),
    imageBackStorageId: v.optional(v.id("_storage")),
    notes: v.optional(v.string()),
    rarity: v.optional(v.string()),
    language: v.optional(v.string()),
    edition: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });

    // Enforce 1,500 active card limit — sold cards don't count toward the cap
    const activeCards = await ctx.db
      .query("cards")
      .withIndex("by_user_sold", (q) => q.eq("userId", effectiveUserId).eq("sold", false))
      .collect();
    if (activeCards.length >= 500) {
      throw new ConvexError({
        code: "BAD_REQUEST",
        message: "Vault full — you've reached the 1,500 card limit. Mark cards as sold or delete them to free up space.",
      });
    }

    return await ctx.db.insert("cards", {
      ...args,
      userId: effectiveUserId,
      sold: false,
    });
  },
});

export const updateCard = mutation({
  args: {
    id: v.id("cards"),
    name: v.optional(v.string()),
    game: v.optional(v.string()),
    set: v.optional(v.string()),
    cardNumber: v.optional(v.string()),
    condition: v.optional(v.string()),
    grade: v.optional(v.string()),
    purchasePrice: v.optional(v.number()),
    marketValue: v.optional(v.number()),
    salePrice: v.optional(v.number()),
    notes: v.optional(v.string()),
    rarity: v.optional(v.string()),
    language: v.optional(v.string()),
    edition: v.optional(v.string()),
    imageStorageId: v.optional(v.id("_storage")),
    imageBackStorageId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });
    const card = await ctx.db.get(args.id);
    if (!card || card.userId !== effectiveUserId) throw new ConvexError({ code: "FORBIDDEN", message: "Not your card" });
    const { id, ...rest } = args;
    await ctx.db.patch(id, rest);
  },
});

export const markSold = mutation({
  args: {
    id: v.id("cards"),
    salePrice: v.optional(v.number()),
    // Client passes its local YYYY-MM-DD so earnings are bucketed to the correct day
    localDate: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });
    const card = await ctx.db.get(args.id);
    if (!card || card.userId !== effectiveUserId) throw new ConvexError({ code: "FORBIDDEN", message: "Not your card" });
    const now = new Date().toISOString();
    // Prefer client-supplied local date so event date ranges always align
    const dateUtc = args.localDate ?? now.slice(0, 10);
    await ctx.db.patch(args.id, {
      sold: true,
      soldAt: now,
      soldDate: dateUtc,
      ...(args.salePrice !== undefined ? { salePrice: args.salePrice } : {}),
    });
    if (args.salePrice !== undefined && args.salePrice > 0) {
      await upsertDailyEarnings(ctx, effectiveUserId, args.salePrice, card.purchasePrice, card.name, dateUtc);
    }
  },
});

export const markBulkSold = mutation({
  args: {
    sales: v.array(v.object({
      id: v.id("cards"),
      salePrice: v.number(),
    })),
    localDate: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<void> => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });
    if (args.sales.length === 0) throw new ConvexError({ code: "BAD_REQUEST", message: "No cards to sell" });
    if (args.sales.length > 100) throw new ConvexError({ code: "BAD_REQUEST", message: "Max 100 cards per bulk sale" });
    const now = new Date().toISOString();
    const dateUtc = args.localDate ?? now.slice(0, 10);

    // Collect sale data for batch earnings update
    const earningsSales: { salePrice: number; purchasePrice?: number; cardName: string }[] = [];

    for (const sale of args.sales) {
      const card = await ctx.db.get(sale.id);
      if (!card || card.userId !== effectiveUserId) continue;
      await ctx.db.patch(sale.id, { sold: true, soldAt: now, soldDate: dateUtc, salePrice: sale.salePrice });
      earningsSales.push({
        salePrice: sale.salePrice,
        purchasePrice: card.purchasePrice,
        cardName: card.name,
      });
    }

    // Aggregate all sales and upsert earnings in a single transaction
    if (earningsSales.length > 0) {
      for (const s of earningsSales) {
        await upsertDailyEarnings(ctx, effectiveUserId, s.salePrice, s.purchasePrice, s.cardName, dateUtc);
      }
    }
  },
});

export const markUnsold = mutation({
  args: { id: v.id("cards") },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });
    const card = await ctx.db.get(args.id);
    if (!card || card.userId !== effectiveUserId) throw new ConvexError({ code: "FORBIDDEN", message: "Not your card" });
    const dateUtc = card.soldDate ?? (card.soldAt ? card.soldAt.slice(0, 10) : new Date().toISOString().slice(0, 10));
    const price = card.salePrice;
    const purchasePrice = card.purchasePrice;
    await ctx.db.patch(args.id, { sold: false, soldAt: undefined, salePrice: undefined });
    if (price !== undefined && price > 0) {
      await undoDailyEarnings(ctx, effectiveUserId, price, purchasePrice, dateUtc);
    }
  },
});

export const deleteCard = mutation({
  args: { id: v.id("cards") },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });
    const card = await ctx.db.get(args.id);
    if (!card || card.userId !== effectiveUserId) throw new ConvexError({ code: "FORBIDDEN", message: "Not your card" });
    // Delete any labels linked to this card
    const labels = await ctx.db
      .query("labels")
      .withIndex("by_card", (q) => q.eq("cardId", args.id))
      .collect();
    for (const label of labels) {
      await ctx.db.delete(label._id);
    }
    await ctx.db.delete(args.id);
  },
});

export const getCards = query({
  args: { paginationOpts: paginationOptsValidator, sold: v.optional(v.boolean()) },
  handler: async (ctx, args) => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return { page: [], isDone: true, continueCursor: "" };

    if (args.sold !== undefined) {
      return await ctx.db
        .query("cards")
        .withIndex("by_user_sold", (q) => q.eq("userId", effectiveUserId).eq("sold", args.sold!))
        .order("desc")
        .paginate(args.paginationOpts);
    }
    return await ctx.db
      .query("cards")
      .withIndex("by_user", (q) => q.eq("userId", effectiveUserId))
      .order("desc")
      .paginate(args.paginationOpts);
  },
});

export const getActiveCardCount = query({
  args: {},
  handler: async (ctx): Promise<{ active: number; limit: number }> => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return { active: 0, limit: 500 };
    const activeCards = await ctx.db
      .query("cards")
      .withIndex("by_user_sold", (q) => q.eq("userId", effectiveUserId).eq("sold", false))
      .collect();
    return { active: activeCards.length, limit: 500 };
  },
});

export const getRecentSold = query({
  args: { limit: v.optional(v.number()) },
  handler: async (ctx, args): Promise<Array<{
    type: "card" | "sealed";
    id: string;
    name: string;
    subtitle: string;
    salePrice?: number;
    profit?: number;
    soldAt: string;
  }>> => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return [];

    const n = args.limit ?? 5;

    // Recently sold cards
    const soldCards = await ctx.db
      .query("cards")
      .withIndex("by_user_sold", (q) => q.eq("userId", effectiveUserId).eq("sold", true))
      .order("desc")
      .take(n);

    // Recently sold sealed products (quantity === 0, has soldAt)
    const allSealed = await ctx.db
      .query("sealedProducts")
      .withIndex("by_user", (q) => q.eq("userId", effectiveUserId))
      .collect();
    const soldSealed = allSealed
      .filter(p => p.soldAt)
      .sort((a, b) => (b.soldAt ?? "").localeCompare(a.soldAt ?? ""))
      .slice(0, n);

    const cardRows = soldCards.map(c => ({
      type: "card" as const,
      id: c._id,
      name: c.name,
      subtitle: `${c.game}${c.condition ? ` • ${c.condition}` : ""}`,
      salePrice: c.salePrice,
      profit: c.salePrice !== undefined && c.purchasePrice !== undefined
        ? c.salePrice - c.purchasePrice
        : undefined,
      soldAt: c.soldAt ?? c._creationTime.toString(),
    }));

    const sealedRows = soldSealed.map(p => ({
      type: "sealed" as const,
      id: p._id,
      name: p.name,
      subtitle: `${p.game} • ${p.type}`,
      salePrice: p.sellPrice,
      profit: p.sellPrice !== undefined && p.purchasePrice !== undefined
        ? p.sellPrice - p.purchasePrice
        : undefined,
      soldAt: p.soldAt!,
    }));

    return [...cardRows, ...sealedRows]
      .sort((a, b) => b.soldAt.localeCompare(a.soldAt))
      .slice(0, n);
  },
});

export const getInventoryStats = query({
  args: {},
  handler: async (ctx) => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return { totalCards: 0, soldCards: 0, inventoryValue: 0, soldValue: 0 };

    const allCards = await ctx.db
      .query("cards")
      .withIndex("by_user", (q) => q.eq("userId", effectiveUserId))
      .collect();

    let inventoryValue = 0;
    let soldValue = 0;
    let soldCards = 0;
    let profit = 0;

    for (const card of allCards) {
      if (card.sold) {
        soldCards++;
        const sale = card.salePrice ?? card.marketValue ?? 0;
        soldValue += sale;
        profit += sale - (card.purchasePrice ?? 0);
      } else {
        inventoryValue += card.marketValue ?? card.purchasePrice ?? 0;
      }
    }

    return {
      totalCards: allCards.length - soldCards,
      soldCards,
      inventoryValue,
      soldValue,
      profit,
    };
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    return await ctx.storage.generateUploadUrl();
  },
});

export const getCardByQr = query({
  args: { qrValue: v.string() },
  handler: async (ctx, args) => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return null;
    // Support both formats: "datcardvault://card/<id>" and "dcv:<id>"
    const match =
      args.qrValue.match(/datcardvault:\/\/card\/(.+)/) ??
      args.qrValue.match(/^dcv:(.+)/);
    if (!match) return null;
    const cardId = match[1];
    const card = await ctx.db.get(cardId as Id<"cards">);
    if (!card || card.userId !== effectiveUserId) return null;
    return card;
  },
});

// Returns all unsold (for sale) cards — used for eBay CSV export
export const getForSaleCards = query({
  args: {},
  handler: async (ctx): Promise<Array<{
    _id: string;
    name: string;
    game: string;
    set?: string;
    cardNumber?: string;
    condition: string;
    grade?: string;
    marketValue?: number;
    rarity?: string;
    language?: string;
    edition?: string;
    notes?: string;
  }>> => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return [];
    return await ctx.db
      .query("cards")
      .withIndex("by_user_sold", (q) => q.eq("userId", effectiveUserId).eq("sold", false))
      .collect();
  },
});

export const getImageUrl = query({
  args: { storageId: v.id("_storage") },
  handler: async (ctx, args) => {
    return await ctx.storage.getUrl(args.storageId);
  },
});

export const findDuplicates = query({
  args: { name: v.string(), game: v.string() },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return [];
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", q => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) return [];

    const needle = args.name.trim().toLowerCase();
    if (!needle) return [];

    const cards = await ctx.db
      .query("cards")
      .withIndex("by_user_sold", q => q.eq("userId", user._id).eq("sold", false))
      .collect();

    return cards
      .filter(c => c.game === args.game && c.name.trim().toLowerCase() === needle)
      .map(c => ({
        _id: c._id,
        name: c.name,
        game: c.game,
        set: c.set,
        condition: c.condition,
        grade: c.grade,
        marketValue: c.marketValue,
      }));
  },
});
