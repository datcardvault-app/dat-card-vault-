import { ConvexError, v } from "convex/values";
import { mutation, query, internalMutation } from "./_generated/server";
import type { Id } from "./_generated/dataModel.d.ts";
import { internal } from "./_generated/api.js";

const BAD_WORDS = ["fuck", "shit", "ass", "bitch", "cunt", "dick", "pussy", "nigger", "nigga", "faggot", "retard", "whore", "slut"];

// Hardcoded admin email list — never stored in the database
const ADMIN_EMAILS = ["datcardvault@gmail.com", "av3ry1991@gmail.com", "datpikastore@gmail.com"];

// Only this email can grant/revoke admin to other accounts
const SUPER_ADMIN_EMAIL = "av3ry1991@gmail.com";

export function isAdmin(email: string | undefined, isGrantedAdmin?: boolean): boolean {
  if (isGrantedAdmin) return true;
  if (!email) return false;
  return ADMIN_EMAILS.includes(email.toLowerCase().trim());
}

function isSuperAdmin(email: string | undefined): boolean {
  if (!email) return false;
  return email.toLowerCase().trim() === SUPER_ADMIN_EMAIL;
}

function isTOSViolation(name: string): boolean {
  const lower = name.toLowerCase();
  return BAD_WORDS.some((w) => lower.includes(w));
}

export const updateCurrentUser = mutation({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "User not logged in" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (user !== null) {
      // Always ensure senderEmail is locked to the official DatCARDVault address
      if (user.senderEmail !== "datcardvault@gmail.com") {
        await ctx.db.patch(user._id, { senderEmail: "datcardvault@gmail.com" });
      }
      return user._id;
    }

    // Enforce 1 account per email
    if (identity.email) {
      const existingByEmail = await ctx.db
        .query("users")
        .filter((q) => q.eq(q.field("email"), identity.email))
        .first();
      if (existingByEmail) {
        throw new ConvexError({
          code: "CONFLICT",
          message: "An account with this email already exists. Only one account per email is allowed.",
        });
      }
    }

    return await ctx.db.insert("users", {
      name: identity.name,
      email: identity.email,
      tokenIdentifier: identity.tokenIdentifier,
      currency: "GBP",
      themeMode: "dark",
      senderEmail: "datcardvault@gmail.com", // locked to official address
    });
  },
});

export const getCurrentUser = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return null;
    return await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
  },
});

export const updateUsername = mutation({
  args: { username: v.string() },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });

    const username = args.username.trim();
    if (username.length < 3 || username.length > 30) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Username must be 3–30 characters" });
    }
    if (!/^[a-zA-Z0-9_ ]+$/.test(username)) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Only letters, numbers, spaces and underscores" });
    }
    if (isTOSViolation(username)) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Username violates our community guidelines" });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });

    // 14 day cooldown (admins are exempt)
    const userIsAdmin = isAdmin(user.email, user.isGrantedAdmin);
    if (!userIsAdmin && user.usernameLastChanged) {
      const last = new Date(user.usernameLastChanged).getTime();
      const now = Date.now();
      const daysDiff = (now - last) / (1000 * 60 * 60 * 24);
      if (daysDiff < 14) {
        const daysLeft = Math.ceil(14 - daysDiff);
        throw new ConvexError({ code: "CONFLICT", message: `You can change your username again in ${daysLeft} day${daysLeft === 1 ? "" : "s"}` });
      }
    }

    // Check uniqueness
    const existing = await ctx.db
      .query("users")
      .withIndex("by_username", (q) => q.eq("username", username))
      .unique();
    if (existing && existing._id !== user._id) {
      throw new ConvexError({ code: "CONFLICT", message: "Username already taken" });
    }

    await ctx.db.patch(user._id, {
      username,
      usernameLastChanged: new Date().toISOString(),
    });
    await ctx.scheduler.runAfter(0, internal.activityLog.append, {
      userId: user._id,
      action: "username_changed",
      detail: `Username changed to "${username}"`,
    });
    return true;
  },
});

/** Update the user's display name (supports spaces, TOS-checked) */
export const updateName = mutation({
  args: { name: v.string() },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });

    const name = args.name.trim();
    if (name.length < 2 || name.length > 40) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Name must be 2–40 characters" });
    }
    if (!/^[a-zA-Z0-9 '_\-.]+$/.test(name)) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Name can only contain letters, numbers, spaces, hyphens, apostrophes, and periods" });
    }
    if (isTOSViolation(name)) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Name violates our community guidelines" });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });

    await ctx.db.patch(user._id, { name });
    return true;
  },
});

export const updateSettings = mutation({
  args: {
    currency: v.optional(v.string()),
    themeMode: v.optional(v.string()),
    businessName: v.optional(v.string()),
    instagram: v.optional(v.string()),
    website: v.optional(v.string()),
    profileImageStorageId: v.optional(v.id("_storage")),
    logoStorageId: v.optional(v.id("_storage")),
    scanSound: v.optional(v.boolean()),
    scanHaptics: v.optional(v.boolean()),
    scanSoundType: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });

    // Delete old storage files if being replaced
    if (args.profileImageStorageId && user.profileImageStorageId && args.profileImageStorageId !== user.profileImageStorageId) {
      await ctx.storage.delete(user.profileImageStorageId);
    }
    if (args.logoStorageId && user.logoStorageId && args.logoStorageId !== user.logoStorageId) {
      await ctx.storage.delete(user.logoStorageId);
    }

    await ctx.db.patch(user._id, {
      ...(args.currency !== undefined ? { currency: args.currency } : {}),
      ...(args.themeMode !== undefined ? { themeMode: args.themeMode } : {}),
      ...(args.businessName !== undefined ? { businessName: args.businessName } : {}),
      ...(args.instagram !== undefined ? { instagram: args.instagram } : {}),
      ...(args.website !== undefined ? { website: args.website } : {}),
      ...(args.profileImageStorageId !== undefined ? { profileImageStorageId: args.profileImageStorageId } : {}),
      ...(args.logoStorageId !== undefined ? { logoStorageId: args.logoStorageId } : {}),
      ...(args.scanSound !== undefined ? { scanSound: args.scanSound } : {}),
      ...(args.scanHaptics !== undefined ? { scanHaptics: args.scanHaptics } : {}),
      ...(args.scanSoundType !== undefined ? { scanSoundType: args.scanSoundType } : {}),
    });
    const changed: string[] = [];
    if (args.currency !== undefined) changed.push(`currency → ${args.currency}`);
    if (args.themeMode !== undefined) changed.push(`theme → ${args.themeMode}`);
    if (args.businessName !== undefined) changed.push("label branding saved");
    if (args.profileImageStorageId !== undefined) changed.push("profile photo updated");
    if (args.logoStorageId !== undefined) changed.push("business logo updated");
    if (changed.length > 0) {
      await ctx.scheduler.runAfter(0, internal.activityLog.append, {
        userId: user._id,
        action: "settings_saved",
        detail: changed.join(", "),
      });
    }
  },
});

export const saveSenderEmail = mutation({
  args: { senderEmail: v.string() },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });
    await ctx.db.patch(user._id, { senderEmail: args.senderEmail.trim() });
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    return await ctx.storage.generateUploadUrl();
  },
});

export const getCurrentUserWithImages = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return null;
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) return null;
    const profileImageUrl = user.profileImageStorageId
      ? await ctx.storage.getUrl(user.profileImageStorageId as Id<"_storage">)
      : null;
    const logoUrl = user.logoStorageId
      ? await ctx.storage.getUrl(user.logoStorageId as Id<"_storage">)
      : null;
    return { ...user, profileImageUrl, logoUrl };
  },
});

export const deleteAccount = mutation({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });
    // Schedule cascading deletion of all associated data
    await ctx.scheduler.runAfter(0, internal.users.purgeUserData, { userId: user._id });
    await ctx.db.delete(user._id);
  },
});

/** Purge all data associated with a user — called after account deletion */
export const purgeUserData = internalMutation({
  args: { userId: v.id("users") },
  handler: async (ctx, { userId }): Promise<null> => {
    // Cards
    const cards = await ctx.db.query("cards").withIndex("by_user", (q) => q.eq("userId", userId)).collect();
    for (const r of cards) await ctx.db.delete(r._id);

    // Labels
    const labels = await ctx.db.query("labels").withIndex("by_user", (q) => q.eq("userId", userId)).collect();
    for (const r of labels) await ctx.db.delete(r._id);

    // Activity logs
    const activityLogs = await ctx.db.query("activityLogs").withIndex("by_user", (q) => q.eq("userId", userId)).collect();
    for (const r of activityLogs) await ctx.db.delete(r._id);

    // Scan logs
    const scanLogs = await ctx.db.query("scanLogs").withIndex("by_user", (q) => q.eq("userId", userId)).collect();
    for (const r of scanLogs) await ctx.db.delete(r._id);

    // Daily earnings
    const dailyEarnings = await ctx.db.query("dailyEarnings").withIndex("by_user", (q) => q.eq("userId", userId)).collect();
    for (const r of dailyEarnings) await ctx.db.delete(r._id);

    // Earnings snapshots
    const earningsSnapshots = await ctx.db.query("earningsSnapshots").withIndex("by_user", (q) => q.eq("userId", userId)).collect();
    for (const r of earningsSnapshots) await ctx.db.delete(r._id);

    // Calendar notes
    const calendarNotes = await ctx.db.query("calendarNotes").withIndex("by_user", (q) => q.eq("userId", userId)).collect();
    for (const r of calendarNotes) await ctx.db.delete(r._id);

    // Buying deals
    const buyingDeals = await ctx.db.query("buyingDeals").withIndex("by_user", (q) => q.eq("userId", userId)).collect();
    for (const r of buyingDeals) await ctx.db.delete(r._id);

    // Nudges sent by this user
    const nudges = await ctx.db.query("nudges").withIndex("by_from_user", (q) => q.eq("fromUserId", userId)).collect();
    for (const r of nudges) await ctx.db.delete(r._id);

    // Sealed products
    const sealedProducts = await ctx.db.query("sealedProducts").withIndex("by_user", (q) => q.eq("userId", userId)).collect();
    for (const r of sealedProducts) await ctx.db.delete(r._id);

    // Team memberships
    const memberships = await ctx.db.query("teamMembers").withIndex("by_user", (q) => q.eq("userId", userId)).collect();
    for (const r of memberships) await ctx.db.delete(r._id);

    // Presence records
    const presenceRows = await ctx.db.query("presence").withIndex("by_user", (q) => q.eq("userId", userId)).collect();
    for (const r of presenceRows) await ctx.db.delete(r._id);

    return null;
  },
});

export const completeOnboarding = mutation({
  args: {
    currency: v.string(),
    businessName: v.optional(v.string()),
    instagram: v.optional(v.string()),
    website: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });
    const patch: Record<string, unknown> = { onboardingComplete: true, currency: args.currency };
    if (args.businessName !== undefined) patch.businessName = args.businessName;
    if (args.instagram !== undefined) patch.instagram = args.instagram;
    if (args.website !== undefined) patch.website = args.website;
    await ctx.db.patch(user._id, patch);
  },
});

export const setSaleTarget = mutation({
  args: { target: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });
    // When setting a new target, record today's date so progress counts from now
    // When clearing (target === undefined), also clear the start date
    const now = new Date();
    const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
    await ctx.db.patch(user._id, {
      saleTarget: args.target,
      saleTargetSetAt: args.target !== undefined ? todayStr : undefined,
    });
  },
});

// ---------- Admin ----------

export const isAdminUser = query({
  args: {},
  handler: async (ctx): Promise<boolean> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return false;
    // Check hardcoded list first, then DB-granted
    if (isAdmin(identity.email)) return true;
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    return user?.isGrantedAdmin === true;
  },
});

export const isSuperAdminUser = query({
  args: {},
  handler: async (ctx): Promise<boolean> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return false;
    return isSuperAdmin(identity.email);
  },
});

export const adminGetAllUsers = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const callerUser = await ctx.db.query("users").withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
    if (!isAdmin(identity.email, callerUser?.isGrantedAdmin)) throw new ConvexError({ code: "FORBIDDEN", message: "Admin only" });
    const users = await ctx.db.query("users").collect();
    return await Promise.all(users.map(async u => {
      const cards = await ctx.db.query("cards").withIndex("by_user", (q) => q.eq("userId", u._id)).collect();
      const labels = await ctx.db.query("labels").withIndex("by_user", (q) => q.eq("userId", u._id)).collect();
      return {
        _id: u._id,
        _creationTime: u._creationTime,
        name: u.name,
        email: u.email,
        username: u.username,
        teamId: u.teamId,
        teamRole: u.teamRole,
        suspended: u.suspended ?? false,
        suspendedAt: u.suspendedAt,
        isGrantedAdmin: u.isGrantedAdmin ?? false,
        isHardcodedAdmin: ADMIN_EMAILS.includes((u.email ?? "").toLowerCase().trim()),
        isAffiliated: u.isAffiliated ?? false,
        isSupporter: u.isSupporter ?? false,
        cardCount: cards.length,
        soldCount: cards.filter(c => c.sold).length,
        labelCount: labels.length,
        printJobs: labels.reduce((sum, l) => sum + (l.printCount ?? (l.printed ? 1 : 0)), 0),
      };
    }));
  },
});

export const adminGetStats = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const callerUser = await ctx.db.query("users").withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
    if (!isAdmin(identity.email, callerUser?.isGrantedAdmin)) throw new ConvexError({ code: "FORBIDDEN", message: "Admin only" });
    const users = await ctx.db.query("users").collect();
    const cards = await ctx.db.query("cards").collect();
    const labels = await ctx.db.query("labels").collect();
    const soldCards = cards.filter(c => c.sold);
    const totalPrintJobs = labels.reduce((sum, l) => sum + (l.printCount ?? (l.printed ? 1 : 0)), 0);
    return {
      totalUsers: users.length,
      totalCards: cards.length,
      totalSold: soldCards.length,
      totalLabels: labels.length,
      totalPrintJobs,
    };
  },
});

export const adminSuspendUser = mutation({
  args: { userId: v.id("users"), suspended: v.boolean() },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const callerUser = await ctx.db.query("users").withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
    if (!isAdmin(identity.email, callerUser?.isGrantedAdmin)) throw new ConvexError({ code: "FORBIDDEN", message: "Admin only" });
    const target = await ctx.db.get(args.userId);
    if (!target) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });
    if (isSuperAdmin(target.email) || target.isGrantedAdmin) throw new ConvexError({ code: "FORBIDDEN", message: "Sorry, you can't suspend an admin. Remove their admin role first." });
    await ctx.db.patch(args.userId, {
      suspended: args.suspended,
      suspendedAt: args.suspended ? new Date().toISOString() : undefined,
    });
  },
});

export const adminDeleteUser = mutation({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const callerUser = await ctx.db.query("users").withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
    if (!isAdmin(identity.email, callerUser?.isGrantedAdmin)) throw new ConvexError({ code: "FORBIDDEN", message: "Admin only" });
    const target = await ctx.db.get(args.userId);
    if (!target) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });
    if (isAdmin(target.email)) throw new ConvexError({ code: "FORBIDDEN", message: "Cannot delete another admin" });
    await ctx.db.delete(args.userId);
  },
});

export const adminGrantAdmin = mutation({
  args: { userId: v.id("users"), grant: v.boolean() },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    if (!isSuperAdmin(identity.email)) throw new ConvexError({ code: "FORBIDDEN", message: "Super admin only" });
    const target = await ctx.db.get(args.userId);
    if (!target) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });
    if (isAdmin(target.email)) throw new ConvexError({ code: "FORBIDDEN", message: "Cannot modify a hardcoded admin" });
    await ctx.db.patch(args.userId, { isGrantedAdmin: args.grant });
  },
});

// Runs daily — deletes accounts that have been suspended for 35+ days
export const deleteExpiredSuspendedAccounts = internalMutation({
  args: {},
  handler: async (ctx) => {
    const cutoff = new Date(Date.now() - 35 * 24 * 60 * 60 * 1000).toISOString();
    const suspended = await ctx.db
      .query("users")
      .filter((q) => q.eq(q.field("suspended"), true))
      .collect();
    for (const user of suspended) {
      if (user.suspendedAt && user.suspendedAt <= cutoff) {
        await ctx.db.delete(user._id);
      }
    }
  },
});

export const adminHealthCheck = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const callerUser = await ctx.db.query("users").withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
    if (!isAdmin(identity.email, callerUser?.isGrantedAdmin)) throw new ConvexError({ code: "FORBIDDEN", message: "Admin only" });

    const users = await ctx.db.query("users").collect();
    const cards = await ctx.db.query("cards").collect();
    const labels = await ctx.db.query("labels").collect();

    // Active users (created or changed username within last 7 days)
    const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
    const activeUsers = users.filter(u => u._creationTime > sevenDaysAgo || (u.usernameLastChanged && new Date(u.usernameLastChanged).getTime() > sevenDaysAgo)).length;

    // Suspended users
    const suspendedUsers = users.filter(u => u.suspended).length;

    // Cards without labels
    const labelledCardIds = new Set(labels.map(l => l.cardId));
    const cardsWithoutLabels = cards.filter(c => !c.sold && !labelledCardIds.has(c._id)).length;

    // Orphaned labels (label exists but card was deleted)
    const cardIds = new Set(cards.map(c => c._id));
    const orphanedLabels = labels.filter(l => !cardIds.has(l.cardId)).length;

    // Users without username set
    const usersNoUsername = users.filter(u => !u.username).length;

    // Users without branding
    const usersNoBranding = users.filter(u => !u.businessName).length;

    const checks = [
      { label: "Database", status: "healthy" as const, detail: `${users.length} users, ${cards.length} cards, ${labels.length} labels` },
      { label: "Active Users (7d)", status: activeUsers > 0 ? "healthy" as const : "warning" as const, detail: `${activeUsers} active` },
      { label: "Suspended Accounts", status: suspendedUsers === 0 ? "healthy" as const : "warning" as const, detail: `${suspendedUsers} suspended` },
      { label: "Cards Without Labels", status: cardsWithoutLabels === 0 ? "healthy" as const : "info" as const, detail: `${cardsWithoutLabels} unlabelled` },
      { label: "Orphaned Labels", status: orphanedLabels === 0 ? "healthy" as const : "warning" as const, detail: `${orphanedLabels} orphaned` },
      { label: "Users Without Username", status: usersNoUsername === 0 ? "healthy" as const : "info" as const, detail: `${usersNoUsername} unset` },
      { label: "Users Without Branding", status: usersNoBranding === 0 ? "healthy" as const : "info" as const, detail: `${usersNoBranding} unset` },
    ];

    const overallStatus = checks.some(c => c.status === "warning") ? "warning" : "healthy";
    return { checks, overallStatus, timestamp: new Date().toISOString() };
  },
});

export const adminSetAffiliated = mutation({
  args: { userId: v.id("users"), value: v.boolean() },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const callerUser = await ctx.db.query("users").withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
    if (!isAdmin(identity.email, callerUser?.isGrantedAdmin)) throw new ConvexError({ code: "FORBIDDEN", message: "Admin only" });
    const target = await ctx.db.get(args.userId);
    if (!target) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });
    await ctx.db.patch(args.userId, { isAffiliated: args.value });
  },
});

export const adminSetSupporter = mutation({
  args: { userId: v.id("users"), value: v.boolean() },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const callerUser = await ctx.db.query("users").withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
    if (!isAdmin(identity.email, callerUser?.isGrantedAdmin)) throw new ConvexError({ code: "FORBIDDEN", message: "Admin only" });
    const target = await ctx.db.get(args.userId);
    if (!target) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });
    await ctx.db.patch(args.userId, { isSupporter: args.value });
  },
});

// Internal: grant Supporter role by email (called from PayPal IPN webhook)
export const grantSupporterByEmail = internalMutation({
  args: { email: v.string() },
  handler: async (ctx, args) => {
    const emailLower = args.email.toLowerCase().trim();
    // Find user whose stored email matches the PayPal donor email
    const allUsers = await ctx.db.query("users").collect();
    const match = allUsers.find(
      (u) => u.email && u.email.toLowerCase().trim() === emailLower
    );
    if (!match) return; // donor not registered in app — silently skip
    if (!match.isSupporter) {
      await ctx.db.patch(match._id, { isSupporter: true });
    }
  },
});
