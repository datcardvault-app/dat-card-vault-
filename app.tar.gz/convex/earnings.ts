import { ConvexError, v } from "convex/values";
import { internalMutation, mutation, query } from "./_generated/server";
import { getCurrentUser, getEffectiveUserId } from "./teamHelpers.ts";
import { internal } from "./_generated/api.js";
import type { MutationCtx } from "./_generated/server.d.ts";
import type { Id } from "./_generated/dataModel.d.ts";

/** Shared upsert helper — call directly inside a mutation for instant reactivity */
export async function upsertDailyEarnings(
  ctx: MutationCtx,
  userId: Id<"users">,
  salePrice: number,
  purchasePrice: number | undefined,
  cardName: string,
  dateUtc: string,
) {
  const profit = purchasePrice !== undefined ? salePrice - purchasePrice : undefined;
  const found = await ctx.db
    .query("dailyEarnings")
    .withIndex("by_user_date", (q) => q.eq("userId", userId).eq("date", dateUtc))
    .unique();

  if (found) {
    if (found.deletedAt) {
      // Row was soft-deleted — revive it with fresh data from this sale
      await ctx.db.patch(found._id, {
        deletedAt: undefined,
        totalEarned: salePrice,
        cardsSold: 1,
        totalProfit: profit,
        topCard: cardName,
        topCardValue: salePrice,
      });
    } else {
      // Active row — accumulate
      const isTopCard = salePrice > (found.topCardValue ?? 0);
      const newProfit = profit !== undefined
        ? (found.totalProfit ?? 0) + profit
        : found.totalProfit;
      await ctx.db.patch(found._id, {
        totalEarned: found.totalEarned + salePrice,
        cardsSold: found.cardsSold + 1,
        ...(newProfit !== undefined ? { totalProfit: newProfit } : {}),
        ...(isTopCard ? { topCard: cardName, topCardValue: salePrice } : {}),
      });
    }
  } else {
    await ctx.db.insert("dailyEarnings", {
      userId,
      date: dateUtc,
      totalEarned: salePrice,
      cardsSold: 1,
      ...(profit !== undefined ? { totalProfit: profit } : {}),
      topCard: cardName,
      topCardValue: salePrice,
    });
  }
}

/** Shared undo helper — call directly inside a mutation for instant reactivity */
export async function undoDailyEarnings(
  ctx: MutationCtx,
  userId: Id<"users">,
  salePrice: number,
  purchasePrice: number | undefined,
  dateUtc: string,
) {
  const found = await ctx.db
    .query("dailyEarnings")
    .withIndex("by_user_date", (q) => q.eq("userId", userId).eq("date", dateUtc))
    .unique();
  // Skip if missing or soft-deleted — row is already invisible to queries
  if (!found || found.deletedAt) return;
  const profit = purchasePrice !== undefined ? salePrice - purchasePrice : undefined;
  const newTotal = Math.max(0, found.totalEarned - salePrice);
  const newCount = Math.max(0, found.cardsSold - 1);
  const newProfit = profit !== undefined && found.totalProfit !== undefined
    ? found.totalProfit - profit
    : found.totalProfit;
  await ctx.db.patch(found._id, {
    totalEarned: newTotal,
    cardsSold: newCount,
    ...(newProfit !== undefined ? { totalProfit: newProfit } : {}),
  });
}

/** Called whenever a card is marked sold — upserts today's daily earnings row */
export const recordSale = internalMutation({
  args: {
    userId: v.id("users"),
    salePrice: v.number(),
    purchasePrice: v.optional(v.number()),
    cardName: v.string(),
    dateUtc: v.string(), // "YYYY-MM-DD"
  },
  handler: async (ctx, args) => {
    await upsertDailyEarnings(ctx, args.userId, args.salePrice, args.purchasePrice, args.cardName, args.dateUtc);
  },
});

/** Batch version — records multiple sales in a single transaction to avoid OCC retries */
export const recordBulkSales = internalMutation({
  args: {
    userId: v.id("users"),
    sales: v.array(v.object({
      salePrice: v.number(),
      purchasePrice: v.optional(v.number()),
      cardName: v.string(),
    })),
    dateUtc: v.string(),
  },
  handler: async (ctx, args) => {
    if (args.sales.length === 0) return;

    // Aggregate totals for the batch
    let totalSalePrice = 0;
    let totalProfit: number | undefined = undefined;
    let topCardName = args.sales[0].cardName;
    let topCardValue = args.sales[0].salePrice;

    for (const sale of args.sales) {
      totalSalePrice += sale.salePrice;
      if (sale.purchasePrice !== undefined) {
        totalProfit = (totalProfit ?? 0) + (sale.salePrice - sale.purchasePrice);
      }
      if (sale.salePrice > topCardValue) {
        topCardValue = sale.salePrice;
        topCardName = sale.cardName;
      }
    }

    const found = await ctx.db
      .query("dailyEarnings")
      .withIndex("by_user_date", (q) => q.eq("userId", args.userId).eq("date", args.dateUtc))
      .unique();

    if (found) {
      if (found.deletedAt) {
        // Soft-deleted row — revive with fresh bulk totals
        await ctx.db.patch(found._id, {
          deletedAt: undefined,
          totalEarned: totalSalePrice,
          cardsSold: args.sales.length,
          ...(totalProfit !== undefined ? { totalProfit } : {}),
          topCard: topCardName,
          topCardValue,
        });
      } else {
        const isTopCard = topCardValue > (found.topCardValue ?? 0);
        const newProfit = totalProfit !== undefined
          ? (found.totalProfit ?? 0) + totalProfit
          : found.totalProfit;
        await ctx.db.patch(found._id, {
          totalEarned: found.totalEarned + totalSalePrice,
          cardsSold: found.cardsSold + args.sales.length,
          ...(newProfit !== undefined ? { totalProfit: newProfit } : {}),
          ...(isTopCard ? { topCard: topCardName, topCardValue } : {}),
        });
      }
    } else {
      await ctx.db.insert("dailyEarnings", {
        userId: args.userId,
        date: args.dateUtc,
        totalEarned: totalSalePrice,
        cardsSold: args.sales.length,
        ...(totalProfit !== undefined ? { totalProfit: totalProfit } : {}),
        topCard: topCardName,
        topCardValue,
      });
    }
  },
});

/** Undo a sale — subtract from the daily earnings row */
export const undoSale = internalMutation({
  args: {
    userId: v.id("users"),
    salePrice: v.number(),
    purchasePrice: v.optional(v.number()),
    dateUtc: v.string(),
  },
  handler: async (ctx, args) => {
    const existing = await ctx.db
      .query("dailyEarnings")
      .withIndex("by_user_date", (q) => q.eq("userId", args.userId).eq("date", args.dateUtc))
      .unique();
    if (!existing) return;
    const newTotal = Math.max(0, existing.totalEarned - args.salePrice);
    const newCount = Math.max(0, existing.cardsSold - 1);
    const profit = args.purchasePrice !== undefined ? args.salePrice - args.purchasePrice : undefined;
    const newProfit = profit !== undefined && existing.totalProfit !== undefined
      ? existing.totalProfit - profit
      : existing.totalProfit;
    await ctx.db.patch(existing._id, {
      totalEarned: newTotal,
      cardsSold: newCount,
      ...(newProfit !== undefined ? { totalProfit: newProfit } : {}),
    });
  },
});

/** Get today's earnings for all team members — for the live teammate panel */
export const getTeamTodayEarnings = query({
  args: { dateUtc: v.string() },
  handler: async (ctx, args): Promise<{ userId: string; displayName: string; totalEarned: number; cardsSold: number }[]> => {
    const user = await getCurrentUser(ctx);
    if (!user || !user.teamId) return [];
    const members = await ctx.db
      .query("teamMembers")
      .withIndex("by_team", (q) => q.eq("teamId", user.teamId!))
      .collect();
    const results = await Promise.all(members.map(async (m) => {
      const row = await ctx.db
        .query("dailyEarnings")
        .withIndex("by_user_date", (q) => q.eq("userId", m.userId).eq("date", args.dateUtc))
        .unique();
      return {
        userId: m.userId,
        displayName: m.displayName ?? "Teammate",
        totalEarned: row && !row.deletedAt ? row.totalEarned : 0,
        cardsSold: row && !row.deletedAt ? row.cardsSold : 0,
      };
    }));
    return results;
  },
});

/** Get today's earnings */
export const getTodayEarnings = query({
  args: { dateUtc: v.string() },
  handler: async (ctx, args) => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return null;
    const row = await ctx.db
      .query("dailyEarnings")
      .withIndex("by_user_date", (q) => q.eq("userId", effectiveUserId).eq("date", args.dateUtc))
      .unique();
    // Don't surface soft-deleted today row
    if (row?.deletedAt) return null;
    return row;
  },
});

/** Get earnings for an event spanning startDate → endDate (inclusive) */
export const getEventEarnings = query({
  args: { startDate: v.string(), endDate: v.string() },
  handler: async (ctx, args): Promise<{ totalEarned: number; cardsSold: number; days: { date: string; totalEarned: number; cardsSold: number; topCard?: string; topCardValue?: number }[] }> => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return { totalEarned: 0, cardsSold: 0, days: [] };

    const rows = await ctx.db
      .query("dailyEarnings")
      .withIndex("by_user", (q) => q.eq("userId", effectiveUserId))
      .collect();

    const inRange = rows.filter(r => !r.deletedAt && r.date >= args.startDate && r.date <= args.endDate);
    return {
      totalEarned: inRange.reduce((s, r) => s + r.totalEarned, 0),
      cardsSold: inRange.reduce((s, r) => s + r.cardsSold, 0),
      days: inRange.sort((a, b) => a.date.localeCompare(b.date)).map(r => ({
        date: r.date,
        totalEarned: r.totalEarned,
        cardsSold: r.cardsSold,
        topCard: r.topCard,
        topCardValue: r.topCardValue,
      })),
    };
  },
});

/** Get all daily earnings rows for display (most recent first) — excludes soft-deleted */
export const getAllDailyEarnings = query({
  args: {},
  handler: async (ctx) => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return [];
    const rows = await ctx.db
      .query("dailyEarnings")
      .withIndex("by_user", (q) => q.eq("userId", effectiveUserId))
      .collect();
    return rows.filter(r => !r.deletedAt).sort((a, b) => b.date.localeCompare(a.date));
  },
});

/** Get earnings for the last 7 calendar days (today + 6 previous) for the dashboard chart */
export const getWeekEarnings = query({
  args: { dates: v.array(v.string()) }, // 7 "YYYY-MM-DD" strings, oldest first
  handler: async (ctx, args) => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return [];
    const rows = await ctx.db
      .query("dailyEarnings")
      .withIndex("by_user", (q) => q.eq("userId", effectiveUserId))
      .collect();
    const byDate: Record<string, { totalEarned: number; cardsSold: number }> = {};
    for (const r of rows) {
      if (!r.deletedAt) byDate[r.date] = { totalEarned: r.totalEarned, cardsSold: r.cardsSold };
    }
    return args.dates.map(d => ({
      date: d,
      totalEarned: byDate[d]?.totalEarned ?? 0,
      cardsSold: byDate[d]?.cardsSold ?? 0,
    }));
  },
});

/** Get ALL daily earnings rows including soft-deleted — for PDF export only */
export const getAllDailyEarningsForExport = query({
  args: {},
  handler: async (ctx) => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return [];
    const rows = await ctx.db
      .query("dailyEarnings")
      .withIndex("by_user", (q) => q.eq("userId", effectiveUserId))
      .collect();
    return rows.sort((a, b) => b.date.localeCompare(a.date));
  },
});

/** Rebuild all daily earnings from scratch from sold cards — fixes any missing data */
export const rebuildEarnings = mutation({
  args: {},
  handler: async (ctx): Promise<{ rebuilt: number; snapshotCount: number }> => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });

    // ── Snapshot existing rows so the user can undo ──────────────────
    const existing = await ctx.db
      .query("dailyEarnings")
      .withIndex("by_user", (q) => q.eq("userId", effectiveUserId))
      .collect();

    // Delete any previous snapshot for this user first
    const oldSnaps = await ctx.db
      .query("earningsSnapshots")
      .withIndex("by_user", (q) => q.eq("userId", effectiveUserId))
      .collect();
    for (const s of oldSnaps) await ctx.db.delete(s._id);

    // Save new snapshot (one row per existing dailyEarnings row)
    for (const row of existing) {
      await ctx.db.insert("earningsSnapshots", {
        userId: effectiveUserId,
        date: row.date,
        totalEarned: row.totalEarned,
        cardsSold: row.cardsSold,
        topCard: row.topCard,
        topCardValue: row.topCardValue,
      });
    }
    const snapshotCount = existing.length;

    // ── Delete existing daily earnings ──────────────────────────────
    for (const row of existing) await ctx.db.delete(row._id);

    // ── Re-derive from sold cards ────────────────────────────────────
    const soldCards = await ctx.db
      .query("cards")
      .withIndex("by_user_sold", (q) => q.eq("userId", effectiveUserId).eq("sold", true))
      .collect();

    const byDate = new Map<string, { totalEarned: number; totalProfit: number | undefined; cardsSold: number; topCard: string; topCardValue: number }>();
    for (const card of soldCards) {
      if (!card.salePrice || card.salePrice <= 0) continue;
      // Prefer soldDate (local business day) — fall back to soldAt UTC date for old cards
      const dateKey = card.soldDate ?? (card.soldAt ? card.soldAt.slice(0, 10) : new Date().toISOString().slice(0, 10));
      const cardProfit = card.purchasePrice !== undefined ? card.salePrice - card.purchasePrice : undefined;
      const cur = byDate.get(dateKey);
      if (cur) {
        cur.totalEarned += card.salePrice;
        cur.cardsSold   += 1;
        if (cardProfit !== undefined) {
          cur.totalProfit = (cur.totalProfit ?? 0) + cardProfit;
        }
        if (card.salePrice > cur.topCardValue) { cur.topCard = card.name; cur.topCardValue = card.salePrice; }
      } else {
        byDate.set(dateKey, { totalEarned: card.salePrice, totalProfit: cardProfit, cardsSold: 1, topCard: card.name, topCardValue: card.salePrice });
      }
    }

    for (const [date, data] of byDate.entries()) {
      await ctx.db.insert("dailyEarnings", { userId: effectiveUserId, date, ...data });
    }

    await ctx.scheduler.runAfter(0, internal.activityLog.append, {
      userId: user._id,
      action: "earnings_recalculated",
      detail: `Rebuilt ${byDate.size} day(s) of earnings`,
    });

    return { rebuilt: byDate.size, snapshotCount };
  },
});

/** Restore the last pre-recalculate snapshot */
export const restoreEarnings = mutation({
  args: {},
  handler: async (ctx): Promise<{ restored: number }> => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });

    const snapshots = await ctx.db
      .query("earningsSnapshots")
      .withIndex("by_user", (q) => q.eq("userId", effectiveUserId))
      .collect();

    if (snapshots.length === 0) {
      throw new ConvexError({ code: "NOT_FOUND", message: "No snapshot to restore" });
    }

    // Delete current daily earnings
    const current = await ctx.db
      .query("dailyEarnings")
      .withIndex("by_user", (q) => q.eq("userId", effectiveUserId))
      .collect();
    for (const row of current) await ctx.db.delete(row._id);

    // Re-insert from snapshot
    for (const snap of snapshots) {
      await ctx.db.insert("dailyEarnings", {
        userId: effectiveUserId,
        date: snap.date,
        totalEarned: snap.totalEarned,
        cardsSold: snap.cardsSold,
        topCard: snap.topCard,
        topCardValue: snap.topCardValue,
      });
    }

    // Clear the snapshot so it can't be restored twice
    for (const snap of snapshots) await ctx.db.delete(snap._id);

    await ctx.scheduler.runAfter(0, internal.activityLog.append, {
      userId: user._id,
      action: "earnings_restored",
      detail: `Earnings restored from snapshot (${snapshots.length} days)`,
    });

    return { restored: snapshots.length };
  },
});

/** Whether a restorable snapshot exists for the current user */
export const hasEarningsSnapshot = query({
  args: {},
  handler: async (ctx): Promise<boolean> => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return false;
    const snap = await ctx.db
      .query("earningsSnapshots")
      .withIndex("by_user", (q) => q.eq("userId", effectiveUserId))
      .first();
    return snap !== null;
  },
});

/** Start or update event mode */
export const setEventMode = mutation({
  args: {
    active: v.boolean(),
    days: v.optional(v.number()),
    startDate: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });
    await ctx.db.patch(effectiveUserId, {
      eventActive: args.active,
      eventDays: args.days,
      eventStartDate: args.startDate,
    });
  },
});

/** Delete a single daily earnings row by date (soft-delete — kept for PDF audit) */
export const deleteDailyEarning = mutation({
  args: { date: v.string() },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });
    const row = await ctx.db
      .query("dailyEarnings")
      .withIndex("by_user_date", (q) => q.eq("userId", effectiveUserId).eq("date", args.date))
      .unique();
    if (!row) throw new ConvexError({ code: "NOT_FOUND", message: "Earnings row not found" });
    // Soft-delete: stamp deletedAt so the PDF can still include it
    await ctx.db.patch(row._id, { deletedAt: new Date().toISOString() });
    await ctx.scheduler.runAfter(0, internal.activityLog.append, {
      userId: user._id,
      action: "earnings_deleted",
      detail: `Deleted earnings for ${args.date}`,
    });
  },
});


export const getSoldCardsForExport = query({
  args: {},
  handler: async (ctx) => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return [];
    const cards = await ctx.db
      .query("cards")
      .withIndex("by_user_sold", (q) => q.eq("userId", effectiveUserId).eq("sold", true))
      .collect();
    return cards
      .filter(c => c.soldAt)
      .map(c => ({
        name: c.name,
        game: c.game,
        salePrice: c.salePrice ?? 0,
        soldAt: c.soldAt!,
        date: c.soldAt!.slice(0, 10),
      }))
      .sort((a, b) => b.soldAt.localeCompare(a.soldAt));
  },
});

/** Sum earnings across all daily rows from fromDate onwards (for the Target Tracker) */
export const getTargetProgress = query({
  args: { fromDate: v.string() },
  handler: async (ctx, args): Promise<{ totalEarned: number; cardsSold: number }> => {
    const effectiveUserId = await getEffectiveUserId(ctx);
    if (!effectiveUserId) return { totalEarned: 0, cardsSold: 0 };

    const rows = await ctx.db
      .query("dailyEarnings")
      .withIndex("by_user_date", (q) => q.eq("userId", effectiveUserId).gte("date", args.fromDate))
      .collect();

    const active = rows.filter(r => !r.deletedAt);
    return {
      totalEarned: active.reduce((sum, r) => sum + (r.totalEarned ?? 0), 0),
      cardsSold:   active.reduce((sum, r) => sum + (r.cardsSold  ?? 0), 0),
    };
  },
});
