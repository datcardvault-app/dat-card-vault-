import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { ConvexError } from "convex/values";
import type { QueryCtx, MutationCtx } from "./_generated/server";

const MAX_NOTES_PER_DAY = 5;

async function requireUser(ctx: QueryCtx | MutationCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
  const user = await ctx.db.query("users").withIndex("by_token", q => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
  if (!user) throw new ConvexError({ message: "User not found", code: "NOT_FOUND" });
  return user;
}

export const getMonthNotes = query({
  args: { year: v.number(), month: v.number() },
  handler: async (ctx, args): Promise<Array<{ _id: string; date: string; note: string }>> => {
    const user = await requireUser(ctx);
    const prefix = `${args.year}-${String(args.month).padStart(2, "0")}`;
    const all = await ctx.db
      .query("calendarNotes")
      .withIndex("by_user", q => q.eq("userId", user._id))
      .collect();
    return all
      .filter(n => n.date.startsWith(prefix))
      .map(n => ({ _id: n._id, date: n.date, note: n.note }));
  },
});

export const addNote = mutation({
  args: { date: v.string(), note: v.string() },
  handler: async (ctx, args): Promise<void> => {
    if (args.note.trim() === "") return;
    const user = await requireUser(ctx);
    const existing = await ctx.db
      .query("calendarNotes")
      .withIndex("by_user_date", q => q.eq("userId", user._id).eq("date", args.date))
      .collect();
    if (existing.length >= MAX_NOTES_PER_DAY) {
      throw new ConvexError({ message: `Max ${MAX_NOTES_PER_DAY} notes per day`, code: "BAD_REQUEST" });
    }
    await ctx.db.insert("calendarNotes", { userId: user._id, date: args.date, note: args.note.trim() });
  },
});

export const updateNote = mutation({
  args: { noteId: v.id("calendarNotes"), note: v.string() },
  handler: async (ctx, args): Promise<void> => {
    if (args.note.trim() === "") return;
    const user = await requireUser(ctx);
    const existing = await ctx.db.get(args.noteId);
    if (!existing || existing.userId !== user._id) {
      throw new ConvexError({ message: "Note not found", code: "NOT_FOUND" });
    }
    await ctx.db.patch(args.noteId, { note: args.note.trim() });
  },
});

export const deleteNote = mutation({
  args: { noteId: v.id("calendarNotes") },
  handler: async (ctx, args): Promise<void> => {
    const user = await requireUser(ctx);
    const existing = await ctx.db.get(args.noteId);
    if (!existing || existing.userId !== user._id) {
      throw new ConvexError({ message: "Note not found", code: "NOT_FOUND" });
    }
    await ctx.db.delete(args.noteId);
  },
});

/** Get all calendar notes — for PDF export */
export const getAllNotesForExport = query({
  args: {},
  handler: async (ctx): Promise<Array<{ date: string; note: string }>> => {
    const user = await requireUser(ctx);
    const all = await ctx.db
      .query("calendarNotes")
      .withIndex("by_user", q => q.eq("userId", user._id))
      .collect();
    return all
      .map(n => ({ date: n.date, note: n.note }))
      .sort((a, b) => a.date.localeCompare(b.date));
  },
});

// Keep upsertNote for backwards compatibility (used by old delete flow)
export const upsertNote = mutation({
  args: { date: v.string(), note: v.string() },
  handler: async (ctx, args): Promise<void> => {
    const user = await requireUser(ctx);
    const existing = await ctx.db
      .query("calendarNotes")
      .withIndex("by_user_date", q => q.eq("userId", user._id).eq("date", args.date))
      .collect();
    if (args.note.trim() === "") {
      // Delete all notes for this day
      for (const n of existing) await ctx.db.delete(n._id);
      return;
    }
    if (existing.length > 0) {
      await ctx.db.patch(existing[0]._id, { note: args.note });
    } else {
      await ctx.db.insert("calendarNotes", { userId: user._id, date: args.date, note: args.note });
    }
  },
});
