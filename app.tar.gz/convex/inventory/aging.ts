import { query } from "../_generated/server";
import { v } from "convex/values";

export type AgingBucket = "0-7" | "8-14" | "15-30" | "31-60" | "61-90" | "90+";

type AgingCard = {
  _id: string;
  name: string;
  game: string;
  set?: string;
  condition: string;
  grade?: string;
  purchasePrice?: number;
  marketValue?: number;
  daysInInventory: number;
  bucket: AgingBucket;
  addedAtMs: number;
};

type AgingSealed = {
  _id: string;
  name: string;
  game: string;
  type: string;
  quantity: number;
  purchasePrice?: number;
  sellPrice?: number;
  daysInInventory: number;
  bucket: AgingBucket;
  addedAtMs: number;
};

function getBucket(days: number): AgingBucket {
  if (days <= 7)  return "0-7";
  if (days <= 14) return "8-14";
  if (days <= 30) return "15-30";
  if (days <= 60) return "31-60";
  if (days <= 90) return "61-90";
  return "90+";
}

export const getAgingCards = query({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const now = Date.now();
    const cards = await ctx.db
      .query("cards")
      .withIndex("by_user_sold", (q) => q.eq("userId", args.userId).eq("sold", false))
      .collect();

    const result: AgingCard[] = cards.map((c) => {
      const days = Math.floor((now - c._creationTime) / (1000 * 60 * 60 * 24));
      return {
        _id: c._id,
        name: c.name,
        game: c.game,
        set: c.set,
        condition: c.condition,
        grade: c.grade,
        purchasePrice: c.purchasePrice,
        marketValue: c.marketValue,
        daysInInventory: days,
        bucket: getBucket(days),
        addedAtMs: c._creationTime,
      };
    });

    // Sort by daysInInventory descending (oldest first)
    return result.sort((a, b) => b.daysInInventory - a.daysInInventory);
  },
});

export const getAgingSealed = query({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const now = Date.now();
    const products = await ctx.db
      .query("sealedProducts")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .collect();

    // Only show products that still have stock
    const result: AgingSealed[] = products
      .filter((p) => p.quantity > 0)
      .map((p) => {
        const days = Math.floor((now - p._creationTime) / (1000 * 60 * 60 * 24));
        return {
          _id: p._id,
          name: p.name,
          game: p.game,
          type: p.type,
          quantity: p.quantity,
          purchasePrice: p.purchasePrice,
          sellPrice: p.sellPrice,
          daysInInventory: days,
          bucket: getBucket(days),
          addedAtMs: p._creationTime,
        };
      });

    return result.sort((a, b) => b.daysInInventory - a.daysInInventory);
  },
});
