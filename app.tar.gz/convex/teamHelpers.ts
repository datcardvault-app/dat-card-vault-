import type { QueryCtx, MutationCtx } from "./_generated/server";
import type { Id } from "./_generated/dataModel.d.ts";

/**
 * Returns the effective data-owner userId.
 * If the current user is a team member, returns the team owner's userId.
 * Otherwise returns their own userId.
 */
export async function getEffectiveUserId(
  ctx: QueryCtx | MutationCtx,
): Promise<Id<"users"> | null> {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) return null;
  const user = await ctx.db
    .query("users")
    .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();
  if (!user) return null;

  if (user.teamId && user.teamRole === "member") {
    // Find the owner's userId from the teamMembers table
    const ownerMember = await ctx.db
      .query("teamMembers")
      .withIndex("by_team", (q) => q.eq("teamId", user.teamId!))
      .filter((q) => q.eq(q.field("role"), "owner"))
      .first();
    if (ownerMember) return ownerMember.userId;
  }
  return user._id;
}

/**
 * Returns the current user document, or null if not authenticated.
 */
export async function getCurrentUser(ctx: QueryCtx | MutationCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) return null;
  return await ctx.db
    .query("users")
    .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();
}
