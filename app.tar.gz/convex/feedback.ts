import { mutation, query } from "./_generated/server";
import { v, ConvexError } from "convex/values";
import { isAdmin } from "./users";

export const submitFeedback = mutation({
  args: {
    type: v.union(v.literal("positive"), v.literal("negative")),
    message: v.string(),
    name: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "User not found" });
    await ctx.db.insert("feedback", {
      userId: user._id,
      type: args.type,
      message: args.message.trim(),
      name: args.name?.trim() || user.username || user.name,
      approved: false,
    });
  },
});

export const getApprovedPositive = query({
  args: {},
  handler: async (ctx) => {
    const rows = await ctx.db
      .query("feedback")
      .withIndex("by_type", (q) => q.eq("type", "positive"))
      .order("desc")
      .collect();
    return rows
      .filter((r) => r.approved === true)
      .slice(0, 5)
      .map((r) => ({ _id: r._id, message: r.message, name: r.name }));
  },
});

// Admin: get all feedback
export const adminGetAllFeedback = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const callerUser = await ctx.db.query("users").withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
    if (!isAdmin(identity.email, callerUser?.isGrantedAdmin)) throw new ConvexError({ code: "FORBIDDEN", message: "Admin only" });
    const rows = await ctx.db.query("feedback").collect();
    const sorted = rows.sort((a, b) => b._creationTime - a._creationTime);
    // Attach user email
    const withEmail = await Promise.all(
      sorted.map(async (row) => {
        const user = await ctx.db.get(row.userId);
        return { ...row, email: user?.email ?? null };
      })
    );
    return withEmail;
  },
});

// Admin: approve/unapprove a positive review
export const adminApproveFeedback = mutation({
  args: { feedbackId: v.id("feedback"), approved: v.boolean() },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const callerUser = await ctx.db.query("users").withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
    if (!isAdmin(identity.email, callerUser?.isGrantedAdmin)) throw new ConvexError({ code: "FORBIDDEN", message: "Admin only" });
    const row = await ctx.db.get(args.feedbackId);
    if (!row) throw new ConvexError({ code: "NOT_FOUND", message: "Feedback not found" });
    await ctx.db.patch(args.feedbackId, { approved: args.approved });
  },
});

// Admin: delete feedback
export const adminDeleteFeedback = mutation({
  args: { feedbackId: v.id("feedback") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const callerUser = await ctx.db.query("users").withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
    if (!isAdmin(identity.email, callerUser?.isGrantedAdmin)) throw new ConvexError({ code: "FORBIDDEN", message: "Admin only" });
    await ctx.db.delete(args.feedbackId);
  },
});
