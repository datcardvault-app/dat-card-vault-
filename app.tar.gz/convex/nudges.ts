import { ConvexError } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser } from "./teamHelpers.ts";

// Cooldown: max 2 nudges per minute per user
const NUDGE_LIMIT  = 2;
const NUDGE_WINDOW = 60_000; // 1 minute in ms

export const sendNudge = mutation({
  args: {},
  handler: async (ctx): Promise<void> => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    if (!user.teamId) throw new ConvexError({ code: "BAD_REQUEST", message: "You are not in a team." });

    const now = Date.now();
    const windowStart = now - NUDGE_WINDOW;

    const recent = await ctx.db
      .query("nudges")
      .withIndex("by_from_user", (q) => q.eq("fromUserId", user._id))
      .collect();

    const recentCount = recent.filter((n) => n.sentAt >= windowStart).length;
    if (recentCount >= NUDGE_LIMIT) {
      throw new ConvexError({
        code: "BAD_REQUEST",
        message: `Nudge cooldown — max ${NUDGE_LIMIT} per minute. Try again shortly!`,
      });
    }

    const fromName = user.username ?? user.name ?? "Your teammate";

    await ctx.db.insert("nudges", {
      teamId: user.teamId,
      fromUserId: user._id,
      fromName,
      sentAt: now,
    });

    // Auto-clean nudges older than 10 minutes
    const stale = recent.filter((n) => n.sentAt < now - 600_000);
    for (const n of stale) await ctx.db.delete(n._id);
  },
});

// Returns the latest nudge from someone else on the team
export const getLatestNudge = query({
  args: {},
  handler: async (ctx): Promise<{
    _id: string;
    fromName: string;
    sentAt: number;
  } | null> => {
    const user = await getCurrentUser(ctx);
    if (!user?.teamId) return null;

    const nudges = await ctx.db
      .query("nudges")
      .withIndex("by_team", (q) => q.eq("teamId", user.teamId!))
      .order("desc")
      .take(10);

    const latest = nudges.find((n) => n.fromUserId !== user._id);
    if (!latest) return null;

    return { _id: latest._id, fromName: latest.fromName, sentAt: latest.sentAt };
  },
});

// Returns how many nudges the current user has sent in the last minute
// so the UI can show remaining nudges / disable the button.
export const myCooldownInfo = query({
  args: {},
  handler: async (ctx): Promise<{ used: number; limit: number; resetsAt: number | null }> => {
    const user = await getCurrentUser(ctx);
    if (!user?.teamId) return { used: 0, limit: NUDGE_LIMIT, resetsAt: null };

    const windowStart = Date.now() - NUDGE_WINDOW;
    const recent = await ctx.db
      .query("nudges")
      .withIndex("by_from_user", (q) => q.eq("fromUserId", user._id))
      .collect();

    const inWindow = recent.filter((n) => n.sentAt >= windowStart);
    const oldest   = inWindow.length > 0
      ? Math.min(...inWindow.map((n) => n.sentAt))
      : null;
    const resetsAt = oldest ? oldest + NUDGE_WINDOW : null;

    return { used: inWindow.length, limit: NUDGE_LIMIT, resetsAt };
  },
});
