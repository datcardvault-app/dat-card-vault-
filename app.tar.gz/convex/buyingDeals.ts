import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getCurrentUser } from "./teamHelpers.ts";

/** Log a buying deal accepted from the dashboard calculator */
export const logDeal = mutation({
  args: {
    date: v.string(),       // "YYYY-MM-DD" local
    cardPrice: v.number(),
    pct: v.number(),
    amountPaid: v.number(),
    youKeep: v.number(),
    cardCount: v.optional(v.number()),
    note: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    await ctx.db.insert("buyingDeals", {
      userId: user._id,
      date: args.date,
      cardPrice: args.cardPrice,
      pct: args.pct,
      amountPaid: args.amountPaid,
      youKeep: args.youKeep,
      cardCount: args.cardCount,
      note: args.note,
      at: new Date().toISOString(),
    });
  },
});

/** Delete a buying deal by id (soft-delete — kept for PDF audit) */
export const deleteDeal = mutation({
  args: { id: v.id("buyingDeals") },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not logged in" });
    const deal = await ctx.db.get(args.id);
    if (!deal || deal.userId !== user._id) throw new ConvexError({ code: "FORBIDDEN", message: "Not your deal" });
    await ctx.db.patch(args.id, { deletedAt: new Date().toISOString() });
  },
});

/** Get all buying deals for today (excludes soft-deleted) */
export const getTodayDeals = query({
  args: { date: v.string() },
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) return [];
    const deals = await ctx.db
      .query("buyingDeals")
      .withIndex("by_user_date", (q) => q.eq("userId", user._id).eq("date", args.date))
      .order("desc")
      .collect();
    return deals.filter(d => !d.deletedAt);
  },
});

/** Get buying deal totals for a set of dates — for the dashboard week chart */
export const getWeekDeals = query({
  args: { dates: v.array(v.string()) }, // 7 "YYYY-MM-DD" strings, oldest first
  handler: async (ctx, args) => {
    const user = await getCurrentUser(ctx);
    if (!user) return [];
    const deals = await ctx.db
      .query("buyingDeals")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .collect();
    const active = deals.filter(d => !d.deletedAt);
    const byDate: Record<string, { amountPaid: number; count: number }> = {};
    for (const d of active) {
      if (!byDate[d.date]) byDate[d.date] = { amountPaid: 0, count: 0 };
      byDate[d.date].amountPaid += d.amountPaid;
      byDate[d.date].count += 1;
    }
    return args.dates.map(d => ({
      date: d,
      amountPaid: byDate[d]?.amountPaid ?? 0,
      count: byDate[d]?.count ?? 0,
    }));
  },
});

/** Get all buying deals (most recent first, excludes soft-deleted) */
export const getAllDeals = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) return [];
    const deals = await ctx.db
      .query("buyingDeals")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .collect();
    return deals.filter(d => !d.deletedAt).sort((a, b) => b.at.localeCompare(a.at));
  },
});

/** Get ALL buying deals including soft-deleted — for PDF export only */
export const getAllDealsForExport = query({
  args: {},
  handler: async (ctx) => {
    const user = await getCurrentUser(ctx);
    if (!user) return [];
    const deals = await ctx.db
      .query("buyingDeals")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .collect();
    return deals.sort((a, b) => b.at.localeCompare(a.at));
  },
});
