import { httpRouter } from "convex/server";
import { httpAction } from "./_generated/server";
import { internal } from "./_generated/api.js";

const http = httpRouter();

/**
 * PayPal IPN (Instant Payment Notification) webhook.
 *
 * PayPal POST-encodes payment data to this URL. We echo it back to PayPal
 * with "cmd=_notify-validate" to verify authenticity, then grant the
 * Supporter role to the matching app user.
 *
 * Set this URL in your PayPal donate button / profile:
 *   https://<deployment>.convex.site/paypal-ipn
 */
http.route({
  path: "/paypal-ipn",
  method: "POST",
  handler: httpAction(async (ctx, request) => {
    const rawBody = await request.text();

    // Verify with PayPal
    const verifyRes = await fetch("https://ipnpb.paypal.com/cgi-bin/webscr", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: `cmd=_notify-validate&${rawBody}`,
    });
    const verifyText = await verifyRes.text();

    if (verifyText !== "VERIFIED") {
      // Invalid IPN — could be a test or spoofed. Still return 200 so PayPal
      // stops retrying, but don't process it.
      return new Response(null, { status: 200 });
    }

    // Parse the IPN fields
    const params = new URLSearchParams(rawBody);
    const paymentStatus = params.get("payment_status");
    const txnType = params.get("txn_type");
    const payerEmail = params.get("payer_email");

    // Only process completed donations (not refunds, pending, etc.)
    const isCompletedDonation =
      paymentStatus === "Completed" &&
      (txnType === "send_money" || txnType === "web_accept" || txnType === null || txnType === "");

    if (isCompletedDonation && payerEmail) {
      await ctx.runMutation(internal.users.grantSupporterByEmail, {
        email: payerEmail,
      });
    }

    return new Response(null, { status: 200 });
  }),
});

export default http;
