import { mutation, query } from "./_generated/server";
import { v, ConvexError } from "convex/values";
import type { MutationCtx, QueryCtx } from "./_generated/server";
import { undoDailyEarnings } from "./earnings.ts";

async function requireUser(ctx: QueryCtx | MutationCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
  const user = await ctx.db
    .query("users")
    .withIndex("by_token", q => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();
  if (!user) throw new ConvexError({ message: "User not found", code: "NOT_FOUND" });
  return user;
}

export const listSealedProducts = query({
  args: {},
  handler: async (ctx) => {
    const user = await requireUser(ctx);
    return ctx.db
      .query("sealedProducts")
      .withIndex("by_user", q => q.eq("userId", user._id))
      .order("desc")
      .collect();
  },
});

export const getByBarcode = query({
  args: { barcode: v.string() },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const results = await ctx.db
      .query("sealedProducts")
      .withIndex("by_barcode", q => q.eq("barcode", args.barcode))
      .collect();
    // Return only the current user's product
    return results.find(p => p.userId === user._id) ?? null;
  },
});

export const addSealedProduct = mutation({
  args: {
    name: v.string(),
    game: v.string(),
    type: v.string(),
    barcode: v.string(),
    purchasePrice: v.optional(v.number()),
    sellPrice: v.optional(v.number()),
    quantity: v.number(),
    notes: v.optional(v.string()),
    imageStorageId: v.optional(v.id("_storage")),
    imageStorageIds: v.optional(v.array(v.id("_storage"))),
  },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const existing = await ctx.db
      .query("sealedProducts")
      .withIndex("by_user", q => q.eq("userId", user._id))
      .collect();
    if (existing.length >= 500) {
      throw new ConvexError({ message: "Sealed product limit reached (500). Remove items to add more.", code: "BAD_REQUEST" });
    }
    return ctx.db.insert("sealedProducts", { ...args, userId: user._id });
  },
});

export const updateSealedProduct = mutation({
  args: {
    id: v.id("sealedProducts"),
    name: v.optional(v.string()),
    game: v.optional(v.string()),
    type: v.optional(v.string()),
    barcode: v.optional(v.string()),
    purchasePrice: v.optional(v.number()),
    sellPrice: v.optional(v.number()),
    quantity: v.optional(v.number()),
    notes: v.optional(v.string()),
    imageStorageId: v.optional(v.id("_storage")),
    imageStorageIds: v.optional(v.array(v.id("_storage"))),
  },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const product = await ctx.db.get(args.id);
    if (!product || product.userId !== user._id)
      throw new ConvexError({ message: "Product not found", code: "NOT_FOUND" });
    const { id, ...fields } = args;
    // Remove undefined values
    const patch = Object.fromEntries(Object.entries(fields).filter(([, v]) => v !== undefined));
    await ctx.db.patch(id, patch);
  },
});

export const deleteSealedProduct = mutation({
  args: { id: v.id("sealedProducts") },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const product = await ctx.db.get(args.id);
    if (!product || product.userId !== user._id)
      throw new ConvexError({ message: "Product not found", code: "NOT_FOUND" });
    await ctx.db.delete(args.id);
  },
});

export const sellOne = mutation({
  args: {
    id: v.id("sealedProducts"),
    salePrice: v.number(),
    localDate: v.string(),
  },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const product = await ctx.db.get(args.id);
    if (!product || product.userId !== user._id)
      throw new ConvexError({ message: "Product not found", code: "NOT_FOUND" });
    if (product.quantity < 1)
      throw new ConvexError({ message: "No stock remaining", code: "BAD_REQUEST" });

    // Decrement quantity and record sale timestamp
    await ctx.db.patch(args.id, { quantity: product.quantity - 1, soldAt: new Date().toISOString(), soldDate: args.localDate, lastSalePrice: args.salePrice });

    // Log to daily earnings
    const existing = await ctx.db
      .query("dailyEarnings")
      .withIndex("by_user_date", q => q.eq("userId", user._id).eq("date", args.localDate))
      .unique();

    const profit = product.purchasePrice !== undefined
      ? args.salePrice - product.purchasePrice
      : undefined;

    if (existing) {
      await ctx.db.patch(existing._id, {
        totalEarned: existing.totalEarned + args.salePrice,
        totalProfit: profit !== undefined
          ? (existing.totalProfit ?? 0) + profit
          : existing.totalProfit,
        cardsSold: existing.cardsSold + 1,
      });
    } else {
      await ctx.db.insert("dailyEarnings", {
        userId: user._id,
        date: args.localDate,
        totalEarned: args.salePrice,
        totalProfit: profit,
        cardsSold: 1,
        topCard: product.name,
        topCardValue: args.salePrice,
      });
    }
  },
});

export const restockProduct = mutation({
  args: { id: v.id("sealedProducts"), quantity: v.number() },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const product = await ctx.db.get(args.id);
    if (!product || product.userId !== user._id)
      throw new ConvexError({ message: "Product not found", code: "NOT_FOUND" });

    // Reverse the last sale's earnings when restocking a sold-out product
    if (product.quantity === 0 && product.lastSalePrice !== undefined && product.soldDate) {
      await undoDailyEarnings(ctx, user._id, product.lastSalePrice, product.purchasePrice, product.soldDate);
    }

    await ctx.db.patch(args.id, { quantity: args.quantity, soldAt: undefined, soldDate: undefined, lastSalePrice: undefined });
  },
});

export const getSealedStats = query({
  args: {},
  handler: async (ctx) => {
    const user = await requireUser(ctx);
    const products = await ctx.db
      .query("sealedProducts")
      .withIndex("by_user", q => q.eq("userId", user._id))
      .collect();

    let inventoryValue = 0;
    let soldOutValue = 0;
    let activeProducts = 0;
    let soldOutProducts = 0;

    for (const p of products) {
      if (p.quantity > 0) {
        activeProducts++;
        inventoryValue += (p.sellPrice ?? p.purchasePrice ?? 0) * p.quantity;
      } else {
        soldOutProducts++;
        soldOutValue += p.sellPrice ?? p.purchasePrice ?? 0;
      }
    }

    return { activeProducts, soldOutProducts, inventoryValue, soldOutValue };
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    await requireUser(ctx);
    return ctx.storage.generateUploadUrl();
  },
});

export const getImageUrls = query({
  args: { storageIds: v.array(v.id("_storage")) },
  handler: async (ctx, args): Promise<(string | null)[]> => {
    await requireUser(ctx);
    return Promise.all(args.storageIds.map(id => ctx.storage.getUrl(id)));
  },
});
