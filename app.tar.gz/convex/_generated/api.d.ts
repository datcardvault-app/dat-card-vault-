/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as activityLog from "../activityLog.js";
import type * as buyingDeals from "../buyingDeals.js";
import type * as calendarNotes from "../calendarNotes.js";
import type * as cards from "../cards.js";
import type * as crons from "../crons.js";
import type * as earnings from "../earnings.js";
import type * as emails from "../emails.js";
import type * as feedback from "../feedback.js";
import type * as http from "../http.js";
import type * as inventory_aging from "../inventory/aging.js";
import type * as labels from "../labels.js";
import type * as nudges from "../nudges.js";
import type * as scans from "../scans.js";
import type * as sealedProducts from "../sealedProducts.js";
import type * as teamHelpers from "../teamHelpers.js";
import type * as teams from "../teams.js";
import type * as users from "../users.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  activityLog: typeof activityLog;
  buyingDeals: typeof buyingDeals;
  calendarNotes: typeof calendarNotes;
  cards: typeof cards;
  crons: typeof crons;
  earnings: typeof earnings;
  emails: typeof emails;
  feedback: typeof feedback;
  http: typeof http;
  "inventory/aging": typeof inventory_aging;
  labels: typeof labels;
  nudges: typeof nudges;
  scans: typeof scans;
  sealedProducts: typeof sealedProducts;
  teamHelpers: typeof teamHelpers;
  teams: typeof teams;
  users: typeof users;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
