import { useCallback, useRef } from "react";

export type SoundType = "beep" | "chime" | "cash";

/**
 * Plays a confirmation sound using the Web Audio API and/or triggers vibration.
 * Three sound styles:
 *   beep  — short 880 Hz sine tone (~80ms)
 *   chime — two ascending tones (600 Hz → 900 Hz, ~200ms total)
 *   cash  — register-style double beep (1200 Hz + 800 Hz, ~180ms total)
 */
export function useScanFeedback(sound: boolean, haptics: boolean, soundType: SoundType = "beep") {
  const audioCtxRef = useRef<AudioContext | null>(null);

  const getCtx = () => {
    if (!audioCtxRef.current || audioCtxRef.current.state === "closed") {
      audioCtxRef.current = new AudioContext();
    }
    return audioCtxRef.current;
  };

  const playBeep = (ctx: AudioContext) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.type = "sine";
    osc.frequency.setValueAtTime(880, ctx.currentTime);
    gain.gain.setValueAtTime(0.25, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.08);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.08);
  };

  const playChime = (ctx: AudioContext) => {
    // Two ascending tones
    [[600, 0, 0.1], [900, 0.1, 0.12]].forEach(([freq, start, dur]) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, ctx.currentTime + start);
      gain.gain.setValueAtTime(0.2, ctx.currentTime + start);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + start + dur);
      osc.start(ctx.currentTime + start);
      osc.stop(ctx.currentTime + start + dur);
    });
  };

  const playCash = (ctx: AudioContext) => {
    // Register-style: high blip then lower blip
    [[1200, 0, 0.06], [800, 0.09, 0.08]].forEach(([freq, start, dur]) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = "square";
      osc.frequency.setValueAtTime(freq, ctx.currentTime + start);
      gain.gain.setValueAtTime(0.15, ctx.currentTime + start);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + start + dur);
      osc.start(ctx.currentTime + start);
      osc.stop(ctx.currentTime + start + dur);
    });
  };

  const trigger = useCallback(() => {
    if (haptics && "vibrate" in navigator) {
      navigator.vibrate(80);
    }
    if (sound) {
      try {
        const ctx = getCtx();
        if (soundType === "chime") playChime(ctx);
        else if (soundType === "cash") playCash(ctx);
        else playBeep(ctx);
      } catch {
        // AudioContext unavailable
      }
    }
  }, [sound, haptics, soundType]);

  return { trigger };
}
