import { useRef } from "react";
import { useQuery } from "convex/react";
import type { FunctionReference, OptionalRestArgs } from "convex/server";

type SkipToken = "skip";
type UseQueryArgs<Query extends FunctionReference<"query">> =
  | OptionalRestArgs<Query>
  | [SkipToken];

type UseQueryResult<Query extends FunctionReference<"query">> = ReturnType<
  typeof useQuery<Query>
>;

/**
 * Works exactly like useQuery but holds onto the last non-undefined result
 * during a WebSocket reconnect (e.g. after the phone screen wakes up).
 * This prevents the UI from flashing to skeleton/loading state on reconnect.
 */
export function useStableQuery<Query extends FunctionReference<"query">>(
  query: Query,
  ...args: UseQueryArgs<Query>
): UseQueryResult<Query> {
  // Cast needed because convex overloads useQuery with a separate "skip" signature
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const result = (useQuery as any)(query, ...args) as UseQueryResult<Query>;
  const stored = useRef<UseQueryResult<Query>>(undefined as UseQueryResult<Query>);
  if (result !== undefined) {
    stored.current = result;
  }
  return stored.current;
}
