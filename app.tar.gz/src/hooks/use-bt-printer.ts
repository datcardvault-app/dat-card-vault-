/**
 * Bluetooth thermal printer hook — MarkLife D100 + compatible printers.
 *
 * Protocol based on reverse-engineering of the official MarkLife Web Kit
 * (gitlab.com/marklife/marklife-label-printer-web-kit) and the print_master_ble
 * Flutter package documentation.
 *
 * BLE topology:
 *   Service  0xFF00 → Write char  0xFF02 (commands + image data)
 *                   → Notify char 0xFF03 (credit-based flow control)
 * Fallback service UUIDs for macOS / iOS / older firmware also supported.
 *
 * Flow control:
 *   Printer sends [0x01, N] notifications on 0xFF03 granting N credits.
 *   Client sends one 90-byte chunk per credit, then waits for more.
 *   If 0xFF03 is unavailable, a timed fallback is used (50ms between chunks).
 *
 * Image encoding: ESC/POS GS v 0 raster (1-bit, big-end, standard 203 DPI).
 */
import { useState, useEffect, useCallback, useRef } from "react";

// ─── Web Bluetooth type declarations ─────────────────────────────────────────
declare global {
  interface Navigator {
    bluetooth?: {
      requestDevice: (opts: BtRequestOptions) => Promise<BtDevice>;
    };
  }
  interface BtRequestOptions {
    filters?: Array<{ services?: string[]; name?: string; namePrefix?: string }>;
    acceptAllDevices?: boolean;
    optionalServices?: string[];
  }
  interface BtDevice {
    name?: string;
    gatt?: BtGATT;
  }
  interface BtGATT {
    connected: boolean;
    connect: () => Promise<BtGATT>;
    disconnect: () => void;
    getPrimaryService: (uuid: string) => Promise<BtService>;
  }
  interface BtService {
    getCharacteristic: (uuid: string) => Promise<BtChar>;
  }
  interface BtCharacteristicProperties {
    write: boolean;
    writeWithoutResponse: boolean;
    notify: boolean;
  }
  interface BtChar {
    properties: BtCharacteristicProperties;
    writeValue: (data: BufferSource) => Promise<void>;
    writeValueWithoutResponse: (data: BufferSource) => Promise<void>;
    startNotifications: () => Promise<BtChar>;
    addEventListener: (event: string, handler: (e: Event) => void) => void;
    removeEventListener: (event: string, handler: (e: Event) => void) => void;
    value?: DataView;
  }
  // These are type aliases only — the actual Web Bluetooth types extend BtChar/BtService/BtGATT/BtDevice
  type BluetoothRemoteGATTCharacteristic = BtChar;
  type BluetoothRemoteGATTService = BtService;
  type BluetoothRemoteGATTServer = BtGATT;
  type BluetoothDevice = BtDevice;
}

// ─── Known service UUIDs (priority order) ───────────────────────────────────
// Primary: MarkLife / Phomemo / Vretti / Aibecy — Zhuhai Quin protocol
const SVC_FF00 = "0000ff00-0000-1000-8000-00805f9b34fb";
// Niimbot B1/B1 Pro/B21/D11 and newer — primary NIIMBOT proprietary protocol
// (also advertised as macOS/iOS alt UUID by some older Zhuhai Quin chips)
const SVC_E781 = "e7810a71-73ae-499d-8c15-faa9aef0c3f2";
// MUNBYN ITP01/ITP900/ITP90/ITPP047 — FFF0 profile
const SVC_FFF0 = "0000fff0-0000-1000-8000-00805f9b34fb";
// SPP-over-BLE (many brands including iDPRT, Polono, some Zebra BLE models)
const SVC_4953 = "49535343-fe7d-4ae5-8fa9-9fafd205e455";
// Swiftint PM260 / similar Chinese BLE thermal printers — AE30 protocol
const SVC_AE30 = "0000ae30-0000-1000-8000-00805f9b34fb";
// Generic ESC/POS BLE dongle / Bixolon / Star Micronics SM-L series
const SVC_18F0 = "000018f0-0000-1000-8000-00805f9b34fb";
// Brother P-touch Cube / PT-P910BT — uses 0xFEBE service
const SVC_FEBE = "0000febe-0000-1000-8000-00805f9b34fb";
// Zebra ZQ620/ZQ630 BLE (link-OS)
const SVC_38EB = "38eb4a80-c570-11e3-9507-0002a5d5c51b";

const ALL_SERVICES = [SVC_FF00, SVC_E781, SVC_FFF0, SVC_4953, SVC_AE30, SVC_18F0, SVC_FEBE, SVC_38EB];

// Characteristic UUIDs per service
const CHAR_MAP: Record<string, { write: string; flow?: string }> = {
  [SVC_FF00]: {
    write: "0000ff02-0000-1000-8000-00805f9b34fb",
    flow:  "0000ff03-0000-1000-8000-00805f9b34fb",
  },
  // Niimbot B1/B21/D11 etc — proprietary protocol, same write+notify char
  [SVC_E781]: {
    write: "bef8d6c9-9c21-4c9e-b632-bd58c1009f9f",
    flow:  "bef8d6c9-9c21-4c9e-b632-bd58c1009f9f", // same char, used for notify
  },
  // MUNBYN ITP-series FFF0/FFF2
  [SVC_FFF0]: { write: "0000fff2-0000-1000-8000-00805f9b34fb" },
  // SPP-over-BLE (iDPRT, Polono, some Zebra)
  [SVC_4953]: { write: "49535343-8841-43f4-a8d4-ecbe34729bb3" },
  // Swiftint PM260 / AE30 protocol — AE01 write, AE02 notify
  [SVC_AE30]: {
    write: "0000ae01-0000-1000-8000-00805f9b34fb",
    flow:  "0000ae02-0000-1000-8000-00805f9b34fb",
  },
  // Generic ESC/POS BLE / Bixolon / Star SM-L
  [SVC_18F0]: { write: "00002af1-0000-1000-8000-00805f9b34fb" },
  // Brother P-touch Cube
  [SVC_FEBE]: { write: "0000febd-0000-1000-8000-00805f9b34fb" },
  // Zebra Link-OS BLE
  [SVC_38EB]: { write: "38eb4a82-c570-11e3-9507-0002a5d5c51b" },
};

// ─── Types ────────────────────────────────────────────────────────────────────
export type CalibrationSettings = {
  offsetXmm: number;
  offsetYmm: number;
  scaleX: number;
  scaleY: number;
  widthMm: number;
  heightMm: number;
  copies: number;
  /** 0–255: darkness level. Higher = darker (more pixels print). Default 128. */
  darkness: number;
  /** Extra ESC/POS feed lines after each label. Default 2. */
  feedLines: number;
  /** Whether to draw the dotted cut-guide border around the label. Default true. */
  showBorder: boolean;
};

export const DEFAULT_CALIBRATION: CalibrationSettings = {
  offsetXmm: 0,
  offsetYmm: 0,
  scaleX: 1.0,
  scaleY: 1.0,
  widthMm: 52,
  heightMm: 32,
  copies: 1,
  darkness: 128,
  feedLines: 0,
  showBorder: true,
};

type CachedPrinter = {
  writeChar: BtChar;
  useWithoutResponse: boolean;
  flowChar: BtChar | null;
  serviceUuid: string;
  /** True when connected to a Niimbot printer (SVC_E781 — proprietary protocol) */
  isNiimbot: boolean;
};

// ─── Hook ─────────────────────────────────────────────────────────────────────
export function useBtPrinter() {
  const [device, setDevice]       = useState<BtDevice | null>(null);
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(false);

  // Cached GATT chars resolved on first print (avoids re-probing every call)
  const cachedRef = useRef<CachedPrinter | null>(null);
  const printAbortRef = useRef(false); // set to true to stop between chunks

  // Credit counter for flow-control writes
  const creditsRef = useRef<number>(0);

  const [cal, setCal] = useState<CalibrationSettings>(() => {
    try {
      const s = localStorage.getItem("dcv_printer_cal");
      return s ? { ...DEFAULT_CALIBRATION, ...(JSON.parse(s) as Partial<CalibrationSettings>) } : DEFAULT_CALIBRATION;
    } catch { return DEFAULT_CALIBRATION; }
  });

  const isAvailable =
    typeof navigator !== "undefined" &&
    "bluetooth" in navigator &&
    !!navigator.bluetooth;

  // Detect iOS — Apple blocks Web Bluetooth on all iOS browsers (WebKit restriction)
  const isIOS =
    typeof navigator !== "undefined" &&
    /iphone|ipad|ipod/i.test(navigator.userAgent);

  useEffect(() => {
    localStorage.setItem("dcv_printer_cal", JSON.stringify(cal));
  }, [cal]);

  // ── Connect ────────────────────────────────────────────────────────────────
  const connect = useCallback(async (): Promise<boolean> => {
    if (!isAvailable) return false;
    setConnecting(true);
    try {
      const dev = await navigator.bluetooth!.requestDevice({
        acceptAllDevices: true,
        optionalServices: ALL_SERVICES,
      });
      if (!dev.gatt) return false;
      await dev.gatt.connect();
      setDevice(dev);
      setConnected(true);
      cachedRef.current = null;
      creditsRef.current = 0;
      return true;
    } catch (e) {
      if ((e as Error).name !== "NotFoundError") throw e;
      return false;
    } finally {
      setConnecting(false);
    }
  }, [isAvailable]);

  // ── Disconnect ────────────────────────────────────────────────────────────
  const disconnect = useCallback(() => {
    device?.gatt?.disconnect();
    setDevice(null);
    setConnected(false);
    cachedRef.current = null;
    creditsRef.current = 0;
  }, [device]);

  // ── Clear cache (force re-probe on next print without disconnecting) ───────
  const clearCache = useCallback(() => {
    cachedRef.current = null;
    creditsRef.current = 0;
  }, []);

  // ── Resolve write + flow-control characteristics (once per connection) ─────
  const resolveChars = useCallback(async (): Promise<CachedPrinter> => {
    if (!device?.gatt) throw new Error("Not connected");

    for (const svcUuid of ALL_SERVICES) {
      // Wait between service attempts — prevents overlapping GATT ops
      await delay(100);

      let svc: BtService;
      try { svc = await device.gatt.getPrimaryService(svcUuid); }
      catch { continue; }

      await delay(50);
      const charUuids = CHAR_MAP[svcUuid];
      if (!charUuids) continue;

      let writeChar: BtChar;
      try { writeChar = await svc.getCharacteristic(charUuids.write); }
      catch { continue; }

      // Only proceed if this char supports some form of write
      const canWrite = writeChar.properties.write || writeChar.properties.writeWithoutResponse;
      if (!canWrite) continue;

      const useWithoutResponse = writeChar.properties.writeWithoutResponse;

      // Try to subscribe to flow-control notifications (0xFF03)
      let flowChar: BtChar | null = null;
      if (charUuids.flow) {
        await delay(50);
        try {
          flowChar = await svc.getCharacteristic(charUuids.flow);
          await flowChar.startNotifications();

          // Listen for credit grants: printer sends [0x01, N]
          const onNotify = (e: Event) => {
            const target = e.target as unknown as BtChar;
            const value = target.value;
            if (!value || value.byteLength < 2) return;
            if (value.getUint8(0) === 0x01) {
              creditsRef.current += value.getUint8(1);
            }
          };
          flowChar.addEventListener("characteristicvaluechanged", onNotify);
        } catch {
          flowChar = null; // flow control unavailable — use timed fallback
        }
      }

      return { writeChar, useWithoutResponse, flowChar, serviceUuid: svcUuid, isNiimbot: svcUuid === SVC_E781 };
    }

    throw new Error(
      "Printer not recognised. Make sure it is turned on, in range, and paired, then tap Clear Cache and try again.",
    );
  }, [device]);

  // ── Send raw bytes ─────────────────────────────────────────────────────────
  const sendBytes = useCallback(async (data: Uint8Array): Promise<void> => {
    if (!device?.gatt) throw new Error("Not connected");

    if (!cachedRef.current) {
      cachedRef.current = await resolveChars();
    }

    const { writeChar, useWithoutResponse, flowChar, serviceUuid, isNiimbot } = cachedRef.current;

    // Mobile BLE stacks (Android Chrome) have a hard limit on how fast
    // writeValueWithoutResponse can be called — exceed it and you get
    // "GATT operation already in progress". Use smaller chunks + write-with-
    // response when available, which serialises naturally and never overflows.
    const isMobile = /android|iphone|ipad|ipod/i.test(navigator.userAgent);

    // AE30 printers (Swiftint PM260 etc) have smaller buffers — use 20-byte chunks
    const isAE30 = serviceUuid === SVC_AE30;

    // Niimbot packets are pre-framed so pass them through whole (up to MTU = 512)
    // Use 512-byte chunks to avoid splitting a packet across two BLE writes
    const isNiimbotMode = isNiimbot;

    // Prefer writeValue (acknowledged) for reliability. Only use
    // writeValueWithoutResponse if writeValue is genuinely unavailable.
    const useAck = writeChar.properties.write;

    // Chunk size: AE30 always 20 bytes for reliability, otherwise
    // 20 bytes on mobile (safe below any MTU), 90 bytes on desktop
    // with flow-control, 50 bytes otherwise.
    const CHUNK = isNiimbotMode ? 512 : isAE30 ? 20 : flowChar ? 90 : isMobile ? 20 : 50;

    const chunks: Uint8Array[] = [];
    for (let offset = 0; offset < data.length; offset += CHUNK) {
      chunks.push(data.slice(offset, offset + CHUNK));
    }

    const writeChunk = async (c: Uint8Array): Promise<void> => {
      const buf = c.buffer.slice(c.byteOffset, c.byteOffset + c.byteLength) as ArrayBuffer;
      // Retry up to 4 times on GATT-busy errors (common on Android)
      for (let attempt = 0; attempt < 4; attempt++) {
        try {
          if (useAck) {
            await writeChar.writeValue(buf);
          } else if (useWithoutResponse) {
            await writeChar.writeValueWithoutResponse(buf);
          } else {
            await writeChar.writeValue(buf);
          }
          return;
        } catch (err) {
          const msg = (err as Error).message ?? "";
          const isGattBusy =
            msg.includes("already in progress") ||
            msg.includes("GATT operation") ||
            msg.includes("NetworkError");
          if (!isGattBusy || attempt === 3) throw err;
          // Back off: 50 / 100 / 200 ms
          await delay(50 * Math.pow(2, attempt));
        }
      }
    };

    if (flowChar) {
      // ── Credit-based flow control ────────────────────────────────────────
      // Seed initial credits if printer hasn't sent any yet
      // AE30 printers (PM260) may need more generous seeding
      if (creditsRef.current === 0) creditsRef.current = isAE30 ? 8 : 4;

      for (const chunk of chunks) {
        if (printAbortRef.current) throw new Error("Print stopped by user.");
        // Wait until the printer grants a credit
        let waited = 0;
        const timeout = isAE30 ? 10000 : 5000;
        while (creditsRef.current <= 0) {
          await delay(isAE30 ? 30 : 20);
          waited += isAE30 ? 30 : 20;
          if (printAbortRef.current) throw new Error("Print stopped by user.");
          if (waited > timeout) throw new Error("Printer stopped responding (flow control timeout).");
        }
        creditsRef.current--;
        await writeChunk(chunk);
        // AE30 needs a small pause between chunks even with flow control
        if (isAE30) await delay(10);
      }
    } else {
      // ── Timed fallback (no flow control) ────────────────────────────────
      // writeValue serialises itself; writeValueWithoutResponse needs a pause.
      // AE30 printers need more time between chunks
      const betweenMs = isAE30 ? 40 : useAck ? 0 : isMobile ? 30 : 15;
      for (let i = 0; i < chunks.length; i++) {
        if (printAbortRef.current) throw new Error("Print stopped by user.");
        await writeChunk(chunks[i]);
        if (betweenMs > 0 && i < chunks.length - 1) await delay(betweenMs);
      }
    }
  }, [device, resolveChars]);

  // ── Send a single Niimbot framed packet ──────────────────────────────────
  // Packet format: 55 55 <cmd> <len> <data...> <xor_checksum> AA AA
  const sendNiimbotPacket = useCallback(async (cmd: number, data: number[]): Promise<void> => {
    const len = data.length;
    const buf = new Uint8Array(4 + len + 3); // head(2) + cmd + len + data + chk + tail(2)
    buf[0] = 0x55;
    buf[1] = 0x55;
    buf[2] = cmd;
    buf[3] = len;
    let chk = cmd ^ len;
    for (let i = 0; i < data.length; i++) {
      buf[4 + i] = data[i];
      chk ^= data[i];
    }
    buf[4 + len] = chk;
    buf[4 + len + 1] = 0xAA;
    buf[4 + len + 2] = 0xAA;
    await sendBytes(buf);
  }, [sendBytes]);

  // ── Print a canvas via Niimbot proprietary protocol (B1/B21/D11 etc) ─────
  const printLabelNiimbot = useCallback(async (
    canvas: HTMLCanvasElement,
    copies: number,
  ): Promise<void> => {
    const PRINT_DPI = 203;
    const MM_PER_INCH = 25.4;

    const offsetXpx = Math.round((cal.offsetXmm / MM_PER_INCH) * PRINT_DPI);
    const offsetYpx = Math.round((cal.offsetYmm / MM_PER_INCH) * PRINT_DPI);

    const srcW = canvas.width;
    const srcH = canvas.height;
    const dstW = Math.max(1, srcW + Math.abs(offsetXpx));
    const dstH = Math.max(1, srcH + Math.abs(offsetYpx));

    const drawX = offsetXpx >= 0 ? offsetXpx : 0;
    const drawY = offsetYpx >= 0 ? offsetYpx : 0;
    const srcX  = offsetXpx < 0 ? Math.abs(offsetXpx) : 0;
    const srcY  = offsetYpx < 0 ? Math.abs(offsetYpx) : 0;
    const srcDrawW = srcW - srcX;
    const srcDrawH = srcH - srcY;

    const padded = document.createElement("canvas");
    padded.width  = dstW;
    padded.height = dstH;
    const pctx = padded.getContext("2d")!;
    pctx.fillStyle = "#ffffff";
    pctx.fillRect(0, 0, dstW, dstH);
    if (srcDrawW > 0 && srcDrawH > 0) {
      pctx.drawImage(canvas, srcX, srcY, srcDrawW, srcDrawH, drawX, drawY, srcDrawW, srcDrawH);
    }

    const imageData = pctx.getImageData(0, 0, dstW, dstH);
    const pixels    = imageData.data;

    // Floyd–Steinberg 1-bit dither
    const err = new Float32Array(dstW * dstH);
    for (let i = 0; i < dstW * dstH; i++) {
      const p = i * 4;
      err[i] = (pixels[p] * 77 + pixels[p + 1] * 151 + pixels[p + 2] * 28) >> 8;
    }

    const bytesPerRow = Math.ceil(dstW / 8);
    const raster = new Uint8Array(bytesPerRow * dstH);
    for (let y = 0; y < dstH; y++) {
      for (let x = 0; x < dstW; x++) {
        const idx   = y * dstW + x;
        const old   = err[idx];
        const pixel = old < cal.darkness ? 0 : 255;
        const diff  = old - pixel;
        if (pixel === 0) {
          raster[y * bytesPerRow + (x >> 3)] |= (0x80 >> (x & 7));
        }
        if (x + 1 < dstW)               err[idx + 1]          += diff * 7 / 16;
        if (y + 1 < dstH) {
          if (x > 0)                     err[idx + dstW - 1]   += diff * 3 / 16;
                                         err[idx + dstW]        += diff * 5 / 16;
          if (x + 1 < dstW)             err[idx + dstW + 1]   += diff * 1 / 16;
        }
      }
    }

    // Total pages = copies * 1 page
    const totalPages = copies;

    // PrintStart (0x01) — 7-byte B1 variant
    // 55 55 01 07 00 <totalPagesHi> <totalPagesLo> 00 00 00 00 00 <chk> AA AA
    const tsHi = (totalPages >> 8) & 0xFF;
    const tsLo = totalPages & 0xFF;
    await sendNiimbotPacket(0x01, [0x00, tsHi, tsLo, 0x00, 0x00, 0x00, 0x00]);
    await delay(100);

    for (let copy = 0; copy < copies; copy++) {
      if (printAbortRef.current) throw new Error("Print stopped by user.");

      // SetDensity (0x21): darkness 1–5 mapped from cal.darkness 0–255
      const density = Math.max(1, Math.min(5, Math.round((cal.darkness / 255) * 4) + 1));
      await sendNiimbotPacket(0x21, [density]);
      await delay(30);

      // SetLabelType (0x23): 1 = standard gap label
      await sendNiimbotPacket(0x23, [0x01]);
      await delay(30);

      // SetPageSize (0x13) — 6-byte variant: rowCount(2) + colCount(2) + copies(2)
      const rowHi  = (dstH >> 8) & 0xFF;
      const rowLo  = dstH & 0xFF;
      const colHi  = (dstW >> 8) & 0xFF;
      const colLo  = dstW & 0xFF;
      await sendNiimbotPacket(0x13, [rowHi, rowLo, colHi, colLo, 0x00, 0x01]);
      await delay(30);

      // PrintQuantity (0x15): always 1 per PageStart/PageEnd block
      await sendNiimbotPacket(0x15, [0x00, 0x01]);
      await delay(30);

      // PageStart (0x03)
      await sendNiimbotPacket(0x03, [0x01]);
      await delay(30);

      // Send image rows
      for (let y = 0; y < dstH; y++) {
        if (printAbortRef.current) throw new Error("Print stopped by user.");

        const rowStart = y * bytesPerRow;
        const rowBytes = Array.from(raster.subarray(rowStart, rowStart + bytesPerRow));

        // Count black bits for the black-pixel-count field (total mode, little-endian 3 bytes)
        let blackBits = 0;
        for (const b of rowBytes) {
          let v = b;
          while (v) { blackBits += v & 1; v >>= 1; }
        }

        // Check if row is all white — use PrintEmptyRow (0x84) for efficiency
        if (blackBits === 0) {
          // Count consecutive empty rows for run-length
          let runLen = 1;
          while (y + runLen < dstH && runLen < 255) {
            const nStart = (y + runLen) * bytesPerRow;
            let allWhite = true;
            for (let b = 0; b < bytesPerRow; b++) {
              if (raster[nStart + b] !== 0) { allWhite = false; break; }
            }
            if (!allWhite) break;
            runLen++;
          }
          const yHi = (y >> 8) & 0xFF;
          const yLo = y & 0xFF;
          await sendNiimbotPacket(0x84, [yHi, yLo, runLen]);
          y += runLen - 1; // loop will y++ at top
        } else {
          // PrintBitmapRow (0x85): rowNum(2) + blackPixelCount(3, total mode) + repeatCount(1) + data
          const yHi = (y >> 8) & 0xFF;
          const yLo = y & 0xFF;
          const bpHi = (blackBits >> 8) & 0xFF;
          const bpLo = blackBits & 0xFF;
          const rowData = [yHi, yLo, 0x00, bpHi, bpLo, 0x01, ...rowBytes];
          await sendNiimbotPacket(0x85, rowData);
        }

        await delay(2); // small inter-row gap to avoid overwhelming BLE
      }

      // PageEnd (0xE3)
      await sendNiimbotPacket(0xE3, [0x01]);
      await delay(50);
    }

    // PrintEnd (0xF3)
    await sendNiimbotPacket(0xF3, [0x01]);
    await delay(50);
  }, [sendBytes, sendNiimbotPacket, cal]);

  // ── Print a canvas — routes to Niimbot or ESC/POS depending on connected printer
  const printLabelCanvas = useCallback(async (
    canvas: HTMLCanvasElement,
    copies: number,
  ): Promise<void> => {
    // Resolve printer type before choosing path
    if (!cachedRef.current) {
      cachedRef.current = await resolveChars();
    }
    if (cachedRef.current.isNiimbot) {
      return printLabelNiimbot(canvas, copies);
    }

    const PRINT_DPI = 203;
    const MM_PER_INCH = 25.4;

    const offsetXpx = Math.round((cal.offsetXmm / MM_PER_INCH) * PRINT_DPI);
    const offsetYpx = Math.round((cal.offsetYmm / MM_PER_INCH) * PRINT_DPI);

    const srcW = canvas.width;
    const srcH = canvas.height;

    const dstW = Math.max(1, srcW + Math.abs(offsetXpx));
    const dstH = Math.max(1, srcH + Math.abs(offsetYpx));

    const drawX = offsetXpx >= 0 ? offsetXpx : 0;
    const drawY = offsetYpx >= 0 ? offsetYpx : 0;
    const srcX  = offsetXpx < 0 ? Math.abs(offsetXpx) : 0;
    const srcY  = offsetYpx < 0 ? Math.abs(offsetYpx) : 0;
    const srcDrawW = srcW - srcX;
    const srcDrawH = srcH - srcY;

    const padded = document.createElement("canvas");
    padded.width  = dstW;
    padded.height = dstH;
    const pctx = padded.getContext("2d")!;
    pctx.fillStyle = "#ffffff";
    pctx.fillRect(0, 0, dstW, dstH);
    if (srcDrawW > 0 && srcDrawH > 0) {
      pctx.drawImage(canvas, srcX, srcY, srcDrawW, srcDrawH, drawX, drawY, srcDrawW, srcDrawH);
    }

    const imageData = pctx.getImageData(0, 0, dstW, dstH);
    const pixels    = imageData.data;

    // ── 1-bit raster with Floyd–Steinberg dithering ──────────────────────
    const err = new Float32Array(dstW * dstH);
    for (let i = 0; i < dstW * dstH; i++) {
      const p = i * 4;
      err[i] = (pixels[p] * 77 + pixels[p + 1] * 151 + pixels[p + 2] * 28) >> 8;
    }

    const bytesPerRow = Math.ceil(dstW / 8);
    const raster = new Uint8Array(bytesPerRow * dstH);

    for (let y = 0; y < dstH; y++) {
      for (let x = 0; x < dstW; x++) {
        const idx   = y * dstW + x;
        const old   = err[idx];
        const pixel = old < cal.darkness ? 0 : 255;
        const diff  = old - pixel;
        if (pixel === 0) {
          raster[y * bytesPerRow + (x >> 3)] |= (0x80 >> (x & 7));
        }
        if (x + 1 < dstW)               err[idx + 1]          += diff * 7 / 16;
        if (y + 1 < dstH) {
          if (x > 0)                     err[idx + dstW - 1]   += diff * 3 / 16;
                                         err[idx + dstW]        += diff * 5 / 16;
          if (x + 1 < dstW)             err[idx + dstW + 1]   += diff * 1 / 16;
        }
      }
    }

    // ── ESC/POS command packet ───────────────────────────────────────────
    const m  = 0;
    const xL = bytesPerRow & 0xFF;
    const xH = (bytesPerRow >> 8) & 0xFF;
    const yL = dstH & 0xFF;
    const yH = (dstH >> 8) & 0xFF;

    const INIT   = [0x1B, 0x40];
    const HEADER = [0x1D, 0x76, 0x30, m, xL, xH, yL, yH];
    const FEED   = cal.feedLines > 0 ? [0x1B, 0x64, Math.max(0, Math.min(255, Math.round(cal.feedLines)))] : [];
    const CUT    = [0x1D, 0x56, 0x01]; // partial cut, no extra feed
    const perCopy = HEADER.length + raster.length + FEED.length + CUT.length;
    const total   = INIT.length + perCopy * copies;
    const cmds    = new Uint8Array(total);

    let pos = 0;
    for (const b of INIT) cmds[pos++] = b;
    for (let c = 0; c < copies; c++) {
      for (const b of HEADER) cmds[pos++] = b;
      cmds.set(raster, pos); pos += raster.length;
      for (const b of FEED) cmds[pos++] = b;
      for (const b of CUT)  cmds[pos++] = b;
    }

    await sendBytes(cmds);
  }, [sendBytes, cal, resolveChars, printLabelNiimbot]);

  /**
   * Build a raster chunk for one canvas (no INIT, no CUT) — used for batching.
   * Returns the raw ESC/POS bytes for HEADER + raster + FEED + CUT.
   */
  const buildLabelChunk = useCallback((
    canvas: HTMLCanvasElement,
  ): Uint8Array => {
    const PRINT_DPI = 203;
    const MM_PER_INCH = 25.4;

    const offsetXpx = Math.round((cal.offsetXmm / MM_PER_INCH) * PRINT_DPI);
    const offsetYpx = Math.round((cal.offsetYmm / MM_PER_INCH) * PRINT_DPI);

    const srcW = canvas.width;
    const srcH = canvas.height;
    const dstW = Math.max(1, srcW + Math.abs(offsetXpx));
    const dstH = Math.max(1, srcH + Math.abs(offsetYpx));

    const drawX = offsetXpx >= 0 ? offsetXpx : 0;
    const drawY = offsetYpx >= 0 ? offsetYpx : 0;
    const srcX  = offsetXpx < 0 ? Math.abs(offsetXpx) : 0;
    const srcY  = offsetYpx < 0 ? Math.abs(offsetYpx) : 0;
    const srcDrawW = srcW - srcX;
    const srcDrawH = srcH - srcY;

    const padded = document.createElement("canvas");
    padded.width  = dstW;
    padded.height = dstH;
    const pctx = padded.getContext("2d")!;
    pctx.fillStyle = "#ffffff";
    pctx.fillRect(0, 0, dstW, dstH);
    if (srcDrawW > 0 && srcDrawH > 0) {
      pctx.drawImage(canvas, srcX, srcY, srcDrawW, srcDrawH, drawX, drawY, srcDrawW, srcDrawH);
    }

    const imageData = pctx.getImageData(0, 0, dstW, dstH);
    const pixels    = imageData.data;

    const err = new Float32Array(dstW * dstH);
    for (let i = 0; i < dstW * dstH; i++) {
      const p = i * 4;
      err[i] = (pixels[p] * 77 + pixels[p + 1] * 151 + pixels[p + 2] * 28) >> 8;
    }

    const bytesPerRow = Math.ceil(dstW / 8);
    const raster = new Uint8Array(bytesPerRow * dstH);

    for (let y = 0; y < dstH; y++) {
      for (let x = 0; x < dstW; x++) {
        const idx   = y * dstW + x;
        const old   = err[idx];
        const pixel = old < cal.darkness ? 0 : 255;
        const diff  = old - pixel;
        if (pixel === 0) {
          raster[y * bytesPerRow + (x >> 3)] |= (0x80 >> (x & 7));
        }
        if (x + 1 < dstW)               err[idx + 1]          += diff * 7 / 16;
        if (y + 1 < dstH) {
          if (x > 0)                     err[idx + dstW - 1]   += diff * 3 / 16;
                                         err[idx + dstW]        += diff * 5 / 16;
          if (x + 1 < dstW)             err[idx + dstW + 1]   += diff * 1 / 16;
        }
      }
    }

    const m  = 0;
    const xL = bytesPerRow & 0xFF;
    const xH = (bytesPerRow >> 8) & 0xFF;
    const yL = dstH & 0xFF;
    const yH = (dstH >> 8) & 0xFF;

    const HEADER = [0x1D, 0x76, 0x30, m, xL, xH, yL, yH];
    const FEED   = cal.feedLines > 0 ? [0x1B, 0x64, Math.max(0, Math.min(255, Math.round(cal.feedLines)))] : [];
    const CUT    = [0x1D, 0x56, 0x01]; // partial cut, no extra feed

    const chunk = new Uint8Array(HEADER.length + raster.length + FEED.length + CUT.length);
    let pos = 0;
    for (const b of HEADER) chunk[pos++] = b;
    chunk.set(raster, pos); pos += raster.length;
    for (const b of FEED) chunk[pos++] = b;
    for (const b of CUT)  chunk[pos++] = b;
    return chunk;
  }, [cal]);

  /**
   * Print multiple label canvases as a single ESC/POS job — one INIT, all labels
   * back-to-back with FEED+CUT between each. Labels stack continuously on the roll
   * exactly like repeated test prints with no printer reset between them.
   */
  const printLabelCanvasBatch = useCallback(async (
    canvases: HTMLCanvasElement[],
    copies: number,
  ): Promise<void> => {
    // Niimbot: send each label as a separate print job (protocol doesn't batch)
    if (!cachedRef.current) {
      cachedRef.current = await resolveChars();
    }
    if (cachedRef.current.isNiimbot) {
      for (const canvas of canvases) {
        await printLabelNiimbot(canvas, copies);
      }
      return;
    }

    const INIT = [0x1B, 0x40];
    const chunks: Uint8Array[] = [];
    for (const canvas of canvases) {
      const chunk = buildLabelChunk(canvas);
      for (let c = 0; c < copies; c++) chunks.push(chunk);
    }
    const total = INIT.length + chunks.reduce((s, c) => s + c.length, 0);
    const cmds = new Uint8Array(total);
    let pos = 0;
    for (const b of INIT) cmds[pos++] = b;
    for (const chunk of chunks) { cmds.set(chunk, pos); pos += chunk.length; }
    await sendBytes(cmds);
  }, [sendBytes, buildLabelChunk, resolveChars, printLabelNiimbot]);

  // ── Calibration helpers ───────────────────────────────────────────────────
  const updateCal = useCallback((key: keyof CalibrationSettings, val: number | boolean) => {
    setCal(prev => ({ ...prev, [key]: val }));
  }, []);

  const resetCal = useCallback(() => { setCal(DEFAULT_CALIBRATION); }, []);

  const saveCal = useCallback(() => {
    try {
      localStorage.setItem("dcv_printer_cal", JSON.stringify(cal));
    } catch { /* ignore */ }
  }, [cal]);

  const stopPrint = useCallback(() => {
    printAbortRef.current = true;
    // Auto-reset after 2s so next print can start normally
    setTimeout(() => { printAbortRef.current = false; }, 2000);
  }, []);

  return {
    device,
    connected,
    connecting,
    isAvailable,
    isIOS,
    cal,
    updateCal,
    resetCal,
    saveCal,
    connect,
    disconnect,
    clearCache,
    sendBytes,
    printLabelCanvas,
    printLabelCanvasBatch,
    stopPrint,
  };
}

// ── Helpers ────────────────────────────────────────────────────────────────
function delay(ms: number): Promise<void> {
  return new Promise<void>(r => setTimeout(r, ms));
}
