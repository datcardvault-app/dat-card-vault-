/**
 * BtPrinterContext — wraps useBtPrinter in a React context so the Bluetooth
 * connection survives page navigation. Mount BtPrinterProvider once near the
 * app root; call useBtPrinterContext() anywhere to access the shared instance.
 */
import React, { createContext, useContext } from "react";
import { useBtPrinter } from "./use-bt-printer.ts";

type BtPrinterContextValue = ReturnType<typeof useBtPrinter>;

const BtPrinterContext = createContext<BtPrinterContextValue | null>(null);

export function BtPrinterProvider({ children }: { children: React.ReactNode }) {
  const printer = useBtPrinter();
  return (
    <BtPrinterContext.Provider value={printer}>
      {children}
    </BtPrinterContext.Provider>
  );
}

export function useBtPrinterContext(): BtPrinterContextValue {
  const ctx = useContext(BtPrinterContext);
  if (!ctx) throw new Error("useBtPrinterContext must be used inside BtPrinterProvider");
  return ctx;
}
