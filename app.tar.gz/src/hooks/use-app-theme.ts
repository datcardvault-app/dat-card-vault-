import { useQuery } from "convex/react";
import { useEffect } from "react";
import { api } from "@/convex/_generated/api.js";
import { useTheme } from "next-themes";

const THEME_STORAGE_KEY = "dcv_theme";

function applyTheme(mode: string, setTheme: (t: string) => void) {
  const html = document.documentElement;
  html.classList.remove("dark", "grey", "light");
  if (mode === "grey") {
    html.classList.add("grey");
    setTheme("light");
  } else if (mode === "light") {
    setTheme("light");
  } else {
    html.classList.add("dark");
    setTheme("dark");
  }
}

export function useAppTheme() {
  const { setTheme } = useTheme();
  const user = useQuery(api.users.getCurrentUser, {});

  // Apply cached theme immediately (no flash)
  useEffect(() => {
    try {
      const cached = localStorage.getItem(THEME_STORAGE_KEY) ?? "dark";
      applyTheme(cached, setTheme);
    } catch { /* ignore */ }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Sync from DB once user loads (handles theme changes from another device)
  useEffect(() => {
    if (!user) return;
    const mode = user.themeMode ?? "dark";
    const current = localStorage.getItem(THEME_STORAGE_KEY);
    // Only re-apply if the theme has actually changed — avoids flash on every reactive update
    if (current === mode) return;
    try { localStorage.setItem(THEME_STORAGE_KEY, mode); } catch { /* ignore */ }
    applyTheme(mode, setTheme);
  // user?.themeMode ensures we only re-run when the theme value itself changes, not on every user update
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.themeMode]);
}
