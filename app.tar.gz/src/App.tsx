import { BrowserRouter, Route, Routes } from "react-router-dom";
import { DefaultProviders } from "./components/providers/default.tsx";
import AuthCallback from "./pages/auth/Callback.tsx";
import AppLayout from "./pages/AppLayout.tsx";
import NotFound from "./pages/NotFound.tsx";
import { useState } from "react";

import { useServiceWorker } from "@/hooks/use-service-worker.ts";
import { AppUpdateBanner } from "@/components/app-update-banner.tsx";
import { CookieConsentBanner } from "@/components/cookie-consent-banner.tsx";

export default function App() {
  const { updateAvailable } = useServiceWorker();
  const [dismissed, setDismissed] = useState(false);

  return (
    <DefaultProviders>
      <BrowserRouter>
        <Routes>
          <Route path="/auth/callback" element={<AuthCallback />} />
          <Route path="/terms" element={<DeferredTerms />} />
          <Route path="/privacy" element={<DeferredPrivacy />} />
          <Route element={<AppLayout />}>
            <Route path="/" element={<DeferredIndex />} />
            <Route path="/inventory" element={<DeferredInventory />} />
            <Route path="/labels" element={<DeferredLabels />} />
            <Route path="/labels/new" element={<DeferredLabelNew />} />
            <Route path="/labels/:id/edit" element={<DeferredLabelEdit />} />
            <Route path="/scan" element={<DeferredScan />} />
            <Route path="/calendar" element={<DeferredCalendar />} />
            <Route path="/earnings" element={<DeferredEarnings />} />
            <Route path="/settings" element={<DeferredSettings />} />
            <Route path="/how-to" element={<DeferredHowTo />} />
            <Route path="/printer" element={<DeferredPrinter />} />
            <Route path="/support" element={<DeferredSupport />} />
            <Route path="/feedback" element={<DeferredFeedback />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
      <AppUpdateBanner visible={updateAvailable && !dismissed} onDismiss={() => setDismissed(true)} />
      <CookieConsentBanner />
    </DefaultProviders>
  );
}

// Lazy loaded pages
import { lazy, Suspense } from "react";
import { Spinner } from "@/components/ui/spinner.tsx";

const LoadingFallback = () => (
  <div className="flex-1 flex items-center justify-center">
    <Spinner className="text-primary" />
  </div>
);

const IndexPage = lazy(() => import("./pages/Index.tsx"));
const InventoryPage = lazy(() => import("./pages/inventory/page.tsx"));
const LabelsPage = lazy(() => import("./pages/labels/page.tsx"));
const LabelNewPage = lazy(() => import("./pages/labels/new/page.tsx"));
const LabelEditPage = lazy(() => import("./pages/labels/edit/page.tsx"));
const ScanPage = lazy(() => import("./pages/scan/page.tsx"));
const CalendarPage = lazy(() => import("./pages/calendar/page.tsx"));
const EarningsPage = lazy(() => import("./pages/earnings/page.tsx"));
const SettingsPage = lazy(() => import("./pages/settings/page.tsx"));
const HowToPage = lazy(() => import("./pages/how-to/page.tsx"));
const PrinterPage = lazy(() => import("./pages/printer/page.tsx"));
const TermsPage = lazy(() => import("./pages/terms/page.tsx"));
const PrivacyPage = lazy(() => import("./pages/privacy/page.tsx"));
const SupportPage = lazy(() => import("./pages/support/page.tsx"));
const FeedbackPage = lazy(() => import("./pages/feedback/page.tsx"));

function DeferredIndex() { return <Suspense fallback={<LoadingFallback />}><IndexPage /></Suspense>; }
function DeferredInventory() { return <Suspense fallback={<LoadingFallback />}><InventoryPage /></Suspense>; }
function DeferredLabels() { return <Suspense fallback={<LoadingFallback />}><LabelsPage /></Suspense>; }
function DeferredLabelNew() { return <Suspense fallback={<LoadingFallback />}><LabelNewPage /></Suspense>; }
function DeferredLabelEdit() { return <Suspense fallback={<LoadingFallback />}><LabelEditPage /></Suspense>; }
function DeferredScan() { return <Suspense fallback={<LoadingFallback />}><ScanPage /></Suspense>; }
function DeferredCalendar() { return <Suspense fallback={<LoadingFallback />}><CalendarPage /></Suspense>; }
function DeferredEarnings() { return <Suspense fallback={<LoadingFallback />}><EarningsPage /></Suspense>; }
function DeferredSettings() { return <Suspense fallback={<LoadingFallback />}><SettingsPage /></Suspense>; }
function DeferredHowTo() { return <Suspense fallback={<LoadingFallback />}><HowToPage /></Suspense>; }
function DeferredPrinter() { return <Suspense fallback={<LoadingFallback />}><PrinterPage /></Suspense>; }
function DeferredTerms() { return <Suspense fallback={<LoadingFallback />}><TermsPage /></Suspense>; }
function DeferredPrivacy() { return <Suspense fallback={<LoadingFallback />}><PrivacyPage /></Suspense>; }
function DeferredSupport() { return <Suspense fallback={<LoadingFallback />}><SupportPage /></Suspense>; }
function DeferredFeedback() { return <Suspense fallback={<LoadingFallback />}><FeedbackPage /></Suspense>; }
