import { motion, AnimatePresence } from "motion/react";
import { RefreshCw, X, Sparkles } from "lucide-react";

interface AppUpdateBannerProps {
  visible: boolean;
  onDismiss: () => void;
}

export function AppUpdateBanner({ visible, onDismiss }: AppUpdateBannerProps) {
  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: 16, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 16, scale: 0.96 }}
          transition={{ type: "spring", stiffness: 380, damping: 30 }}
          className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[9990] w-[calc(100%-2rem)] max-w-[320px]"
        >
          <div className="flex items-start gap-3 rounded-2xl border border-primary/30 bg-[oklch(0.14_0.03_25/0.97)] backdrop-blur-md shadow-2xl px-4 py-3">
            {/* icon */}
            <div className="shrink-0 mt-0.5 w-8 h-8 rounded-full bg-primary/15 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-primary" />
            </div>

            {/* text */}
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-white leading-tight">New version available</p>
              <p className="text-[10px] text-white/60 mt-0.5 leading-tight">Refresh to get the latest DatCARDVault update.</p>
              <button
                onClick={() => window.location.reload()}
                className="mt-2 flex items-center gap-1.5 text-[10px] font-bold text-primary hover:text-primary/80 transition-colors cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" />
                Refresh now
              </button>
            </div>

            {/* dismiss */}
            <button
              onClick={onDismiss}
              className="shrink-0 p-0.5 rounded-lg text-white/40 hover:text-white/70 transition-colors cursor-pointer"
              aria-label="Dismiss"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
