import { CircleCheckIcon, OctagonXIcon, TriangleAlertIcon, InfoIcon, Loader2Icon } from "lucide-react";
import { useTheme } from "next-themes";
import { Toaster as Sonner, type ToasterProps } from "sonner";

const Toaster = ({ ...props }: ToasterProps) => {
  const { theme = "system" } = useTheme();

  return (
    <Sonner
      theme={theme as ToasterProps["theme"]}
      className="toaster group"
      position="bottom-center"
      gap={8}
      toastOptions={{
        unstyled: true,
        classNames: {
          toast: [
            "flex items-center gap-2.5",
            "w-fit max-w-[90vw] mx-auto",
            "px-4 py-2.5",
            "rounded-full",
            "text-sm font-semibold leading-snug",
            "shadow-lg",
            "backdrop-blur-md",
            "border",
            // base (normal)
            "bg-[oklch(0.15_0_0/0.92)] text-white border-white/10",
          ].join(" "),
          success: [
            "bg-[oklch(0.22_0.07_145/0.95)] text-[oklch(0.88_0.14_145)] border-[oklch(0.4_0.14_145/0.4)]",
          ].join(" "),
          error: [
            "bg-[oklch(0.22_0.09_25/0.95)] text-[oklch(0.88_0.14_25)] border-[oklch(0.5_0.18_25/0.4)]",
          ].join(" "),
          warning: [
            "bg-[oklch(0.22_0.07_60/0.95)] text-[oklch(0.88_0.14_60)] border-[oklch(0.5_0.14_60/0.4)]",
          ].join(" "),
          info: [
            "bg-[oklch(0.22_0.06_240/0.95)] text-[oklch(0.88_0.1_240)] border-[oklch(0.5_0.1_240/0.4)]",
          ].join(" "),
          icon: "shrink-0 size-4",
          title: "font-semibold",
          description: "text-xs opacity-75 mt-0.5",
          actionButton: "text-xs font-bold underline ml-2 opacity-80 hover:opacity-100 cursor-pointer",
          cancelButton: "text-xs opacity-60 ml-2 cursor-pointer",
        },
      }}
      icons={{
        success: <CircleCheckIcon className="size-4" />,
        info: <InfoIcon className="size-4" />,
        warning: <TriangleAlertIcon className="size-4" />,
        error: <OctagonXIcon className="size-4" />,
        loading: <Loader2Icon className="size-4 animate-spin" />,
      }}
      {...props}
    />
  );
};

export { Toaster };
