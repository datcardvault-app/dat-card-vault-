/**
 * Persistent top-of-screen presence bar shown whenever the user is in a team.
 * Shows all members with green/grey online dots. Fires a heartbeat every 20s.
 */
import { useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Users } from "lucide-react";

function initials(name: string | undefined): string {
  if (!name) return "?";
  return name
    .split(/[\s_]+/)
    .map(w => w[0]?.toUpperCase() ?? "")
    .slice(0, 2)
    .join("");
}

const COLOURS = [
  "bg-red-600", "bg-blue-600", "bg-emerald-600",
  "bg-violet-600", "bg-amber-600", "bg-pink-600",
];

export default function TeamPresenceBar() {
  const teamData = useQuery(api.teams.getMyTeam, {});
  const heartbeat = useMutation(api.teams.heartbeat);

  // Fire heartbeat every 20s while in a team, but pause when the page is hidden
  // (screen dimmed / backgrounded) to prevent write-triggered UI flicker
  useEffect(() => {
    if (!teamData) return;
    void heartbeat({});

    let id: ReturnType<typeof setInterval> | null = null;

    const start = () => {
      if (id !== null) return;
      id = setInterval(() => void heartbeat({}), 20_000);
    };

    const stop = () => {
      if (id === null) return;
      clearInterval(id);
      id = null;
    };

    const onVisibility = () => {
      if (document.hidden) {
        stop();
      } else {
        void heartbeat({});
        start();
      }
    };

    if (!document.hidden) start();
    document.addEventListener("visibilitychange", onVisibility);

    return () => {
      stop();
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [!!teamData, heartbeat]);

  if (!teamData) return null;

  const { members } = teamData;
  const onlineCount = members.filter(m => m.isOnline).length;

  return (
    <div className="w-full bg-primary/10 border-b border-primary/20 px-4 py-1.5 flex items-center gap-3">
      <div className="flex items-center gap-1.5 shrink-0">
        <Users className="h-3.5 w-3.5 text-primary" />
        <span className="text-xs font-bold text-primary hidden sm:block">Team Mode</span>
        <span className="text-xs text-muted-foreground hidden sm:block">·</span>
        <span className="text-xs text-muted-foreground hidden sm:block">{onlineCount}/{members.length} online</span>
      </div>

      <div className="flex items-center gap-1.5 flex-1 min-w-0">
        {members.map((m, i) => (
          <div key={m.userId} className="flex items-center gap-1" title={`${m.displayName ?? "Unknown"} — ${m.isOnline ? "online" : "offline"}`}>
            {/* Avatar circle */}
            <div className={`relative w-6 h-6 rounded-full flex items-center justify-center text-white text-[9px] font-black shrink-0 ${COLOURS[i % COLOURS.length]}`}>
              {initials(m.displayName)}
              {/* Online dot */}
              <span className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-background ${m.isOnline ? "bg-profit" : "bg-muted-foreground/40"}`} />
            </div>
            <span className="text-xs text-muted-foreground truncate max-w-[60px] hidden sm:block">
              {m.displayName ?? "Unknown"}
              {m.role === "owner" && <span className="text-primary ml-0.5">★</span>}
            </span>
          </div>
        ))}
      </div>

      {/* Mobile: just show count */}
      <span className="text-xs text-muted-foreground sm:hidden">{onlineCount}/{members.length}</span>
    </div>
  );
}
