/**
 * NudgeAlert — shows "YOU'RE NEEDED AT THE TABLE!" when a teammate sends a nudge.
 * Dismissed by tapping the button or auto-closes after 6s.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { useQuery } from "convex/react";
import { Authenticated } from "convex/react";
import { motion, AnimatePresence } from "motion/react";
import { api } from "@/convex/_generated/api.js";

/**
 * Shared AudioContext — created AND unlocked inside the first user gesture so
 * that mobile browsers (iOS Safari in particular) allow programmatic playback
 * later (e.g. when a nudge arrives).
 *
 * iOS Safari requires:
 *   1. AudioContext is created inside a user-gesture handler, OR
 *   2. AudioContext.resume() is called inside a user-gesture handler AND a
 *      silent buffer is played to fully initialise the audio graph.
 *
 * We do both: create the context inside the gesture, then play a silent buffer
 * to warm up the audio pipeline.
 */
let sharedCtx: AudioContext | null = null;

function getAudioCtx(): AudioContext | null {
  if (sharedCtx && sharedCtx.state !== "closed") return sharedCtx;
  try {
    sharedCtx = new AudioContext();
    return sharedCtx;
  } catch {
    return null;
  }
}

/** Play a zero-length silent buffer to fully unlock the audio pipeline on iOS. */
function playSilentBuffer(ctx: AudioContext) {
  const buf = ctx.createBuffer(1, 1, 22050);
  const src = ctx.createBufferSource();
  src.buffer = buf;
  src.connect(ctx.destination);
  src.start(0);
}

// Unlock on the very first user interaction (touch, click, keydown).
// Must happen inside the gesture handler to satisfy mobile autoplay policy.
if (typeof window !== "undefined") {
  const events = ["touchstart", "touchend", "click", "keydown"] as const;
  const handler = () => {
    // Create (or reuse) the context inside the gesture
    const ctx = getAudioCtx();
    if (ctx) {
      if (ctx.state === "suspended") {
        // resume() returns a Promise — we play the silent buffer after it resolves
        ctx.resume().then(() => playSilentBuffer(ctx)).catch(() => {});
      } else {
        playSilentBuffer(ctx);
      }
    }
    events.forEach((e) => document.removeEventListener(e, handler, true));
  };
  events.forEach((e) => document.addEventListener(e, handler, { capture: true, once: false }));
}

/** Plays a repeating alarm tone using the pre-unlocked AudioContext. Returns a stop function. */
function playAlarm(): () => void {
  const ctx = getAudioCtx();
  if (!ctx) return () => {};

  // If still suspended (e.g. the unlock gesture hasn't fired yet), resume and
  // then schedule the beeps asynchronously so the audio graph is ready.
  if (ctx.state === "suspended") {
    let cancelled = false;
    const stopFn = { current: () => {} };
    ctx.resume().then(() => {
      if (!cancelled) stopFn.current = scheduleBeeps(ctx);
    }).catch(() => {});
    return () => { cancelled = true; stopFn.current(); };
  }

  return scheduleBeeps(ctx);
}

/** Creates and starts the oscillators. Called once the AudioContext is running. */
function scheduleBeeps(ctx: AudioContext): () => void {
  try {
    const gain = ctx.createGain();
    gain.gain.value = 0.7;
    gain.connect(ctx.destination);

    let stopped = false;
    const oscillators: OscillatorNode[] = [];

    // 3 beats tuned for phone speakers: mid-range frequencies with punchy
    // attack and quick decay — similar to an Android/iOS notification tone.
    // High freqs (>1kHz) sound thin on phone speakers; 440–700Hz sits better.
    const freqs = [440, 554, 659]; // A4 → C#5 → E5 (A major chord, ascending)
    for (let i = 0; i < 3; i++) {
      const osc = ctx.createOscillator();
      osc.type = "sine";
      osc.frequency.value = freqs[i];

      const beepGain = ctx.createGain();
      const start = i * 0.14;
      beepGain.gain.setValueAtTime(0.001, ctx.currentTime + start);
      beepGain.gain.linearRampToValueAtTime(1.0, ctx.currentTime + start + 0.015); // fast attack
      beepGain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + start + 0.28); // natural decay
      osc.connect(beepGain);
      beepGain.connect(gain);

      osc.start(ctx.currentTime + start);
      osc.stop(ctx.currentTime + start + 0.28);
      oscillators.push(osc);
    }

    return () => {
      if (stopped) return;
      stopped = true;
      oscillators.forEach((o) => { try { o.stop(); } catch { /* already stopped */ } });
      gain.disconnect();
    };
  } catch {
    return () => {};
  }
}

function NudgeAlertInner() {
  const latestNudge  = useQuery(api.nudges.getLatestNudge, {});

  const mountedAt    = useRef(Date.now());
  const shownNudgeId = useRef<string | null>(null);

  const [visible,    setVisible]    = useState(false);
  const [nudgerName, setNudgerName] = useState("");
  const [gotIt,      setGotIt]      = useState(false);

  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const stopAlarm = useRef<(() => void) | null>(null);

  useEffect(() => {
    if (!latestNudge) return;
    if (latestNudge._id === shownNudgeId.current) return;
    if (latestNudge.sentAt < mountedAt.current) {
      shownNudgeId.current = latestNudge._id;
      return;
    }
    shownNudgeId.current = latestNudge._id;
    setNudgerName(latestNudge.fromName);
    setVisible(true);

    // Play alarm sound
    stopAlarm.current = playAlarm();

    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setVisible(false), 6_000);
    return () => { if (timer.current) clearTimeout(timer.current); };
  }, [latestNudge]);

  const dismiss = useCallback(() => {
    setVisible(false);
    if (timer.current) clearTimeout(timer.current);
    if (stopAlarm.current) { stopAlarm.current(); stopAlarm.current = null; }
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          key="nudge-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/70 backdrop-blur-sm cursor-pointer"
          onClick={dismiss}
        >
          <motion.div
            initial={{ scale: 0.7, y: 40 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.85, y: 20, opacity: 0 }}
            transition={{ type: "spring", damping: 18, stiffness: 280 }}
            onClick={(e) => e.stopPropagation()}
            className="relative mx-4 max-w-sm w-full"
          >
            <motion.div
              className="absolute inset-0 rounded-2xl bg-primary/30"
              animate={{ scale: [1, 1.06, 1], opacity: [0.6, 1, 0.6] }}
              transition={{ duration: 1.2, repeat: Infinity, ease: "easeInOut" }}
            />
            <div className="relative bg-background border-2 border-primary rounded-2xl overflow-hidden shadow-2xl">
              <div className="bg-primary px-5 py-3 flex items-center gap-3">
                <motion.span
                  className="text-2xl"
                  animate={{ rotate: [-15, 15, -15, 15, 0] }}
                  transition={{ duration: 0.5, repeat: 3, ease: "easeInOut" }}
                >🔔</motion.span>
                <span className="text-primary-foreground font-black text-sm tracking-widest uppercase">Team Nudge</span>
              </div>
              <div className="px-6 pt-5 pb-4 text-center space-y-2">
                <motion.p
                  className="text-3xl font-black tracking-widest text-foreground uppercase leading-tight"
                  animate={{ scale: [1, 1.03, 1] }}
                  transition={{ duration: 0.8, repeat: Infinity, ease: "easeInOut" }}
                >
                  YOU&apos;RE NEEDED<br />AT THE TABLE!
                </motion.p>
                <p className="text-sm text-muted-foreground font-medium">
                  from <span className="text-primary font-bold">{nudgerName}</span>
                </p>
              </div>
              <div className="px-5 pb-5">
                <button
                  onClick={() => {
                    setGotIt(true);
                    setTimeout(() => { setGotIt(false); dismiss(); }, 400);
                  }}
                  className={`w-full py-2.5 rounded-xl text-sm font-semibold transition-colors cursor-pointer
                    ${gotIt
                      ? "bg-profit text-white"
                      : "bg-secondary text-muted-foreground hover:bg-secondary/80"
                    }`}
                >
                  Got it — on my way!
                </button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export default function NudgeAlert() {
  return (
    <Authenticated>
      <NudgeAlertInner />
    </Authenticated>
  );
}
