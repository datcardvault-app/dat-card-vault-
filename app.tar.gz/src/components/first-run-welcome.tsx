import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Input } from "@/components/ui/input.tsx";
import { CheckCircle2, Package, Tag, ScanLine, ChevronRight, X, Store } from "lucide-react";
import { useNavigate } from "react-router-dom";

type Step = 1 | 2 | 3 | 4;

const CURRENCIES = [
  { value: "GBP", label: "£ GBP — British Pound" },
  { value: "USD", label: "$ USD — US Dollar" },
  { value: "EUR", label: "€ EUR — Euro" },
  { value: "CAD", label: "$ CAD — Canadian Dollar" },
  { value: "AUD", label: "$ AUD — Australian Dollar" },
  { value: "JPY", label: "¥ JPY — Japanese Yen" },
];

interface Props {
  onComplete: () => void;
}

export default function FirstRunWelcome({ onComplete }: Props) {
  const [step, setStep] = useState<Step>(1);
  const [currency, setCurrency] = useState("GBP");
  const [businessName, setBusinessName] = useState("");
  const [instagram, setInstagram] = useState("");
  const [website, setWebsite] = useState("");
  const [saving, setSaving] = useState(false);
  const completeOnboarding = useMutation(api.users.completeOnboarding);
  const navigate = useNavigate();

  const getOnboardingArgs = () => ({
    currency,
    businessName: businessName.trim() || undefined,
    instagram: instagram.trim() || undefined,
    website: website.trim() || undefined,
  });

  const handleFinish = async () => {
    setSaving(true);
    try {
      await completeOnboarding(getOnboardingArgs());
      onComplete();
    } catch {
      onComplete(); // dismiss anyway
    } finally {
      setSaving(false);
    }
  };

  const handleDismiss = async () => {
    setSaving(true);
    try {
      await completeOnboarding(getOnboardingArgs());
    } catch { /* ignore */ } finally {
      setSaving(false);
      onComplete();
    }
  };

  const handleGoToInventory = async () => {
    setSaving(true);
    try { await completeOnboarding(getOnboardingArgs()); } catch { /* ignore */ } finally { setSaving(false); }
    onComplete();
    navigate("/inventory");
  };

  const handleGoToLabels = async () => {
    setSaving(true);
    try { await completeOnboarding(getOnboardingArgs()); } catch { /* ignore */ } finally { setSaving(false); }
    onComplete();
    navigate("/labels");
  };

  return (
    <div className="fixed inset-0 z-[9999] flex items-start justify-center p-4 overflow-y-auto">
      {/* Backdrop */}
      <motion.div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      />

      {/* Card */}
      <motion.div
        className="relative z-10 w-full max-w-sm my-auto bg-background border border-border rounded-2xl shadow-2xl"
        initial={{ opacity: 0, scale: 0.92, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ type: "spring", damping: 24, stiffness: 260 }}
      >
        {/* Top stripe */}
        <div className="h-1 w-full rounded-t-2xl" />

        {/* Header */}
        <div className="px-6 pt-5 pb-4 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src="https://hercules-cdn.com/file_3dzmLjTtZEhTAwTQYzz2XFce"
              alt="DatCardVault"
              className="h-9 w-9 object-contain"
              style={{ filter: "brightness(1.45) saturate(1.2)" }}
            />
            <div>
              <p className="font-sans font-black tracking-[0.1em] leading-none text-sm">
                Dat<span className="text-primary">CARD</span>Vault™
              </p>
              <p className="text-[10px] text-muted-foreground font-bold tracking-widest uppercase leading-none mt-0.5">
                Setup Guide
              </p>
            </div>
          </div>
          <button
            onClick={handleDismiss}
            className="w-7 h-7 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors cursor-pointer"
            aria-label="Dismiss"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Progress dots */}
        <div className="flex items-center justify-center gap-2 pt-4 pb-1">
          {([1, 2, 3, 4] as Step[]).map((s) => (
            <div
              key={s}
              className={`rounded-full transition-all duration-300 ${
                s === step
                  ? "w-6 h-2 bg-primary"
                  : s < step
                    ? "w-2 h-2 bg-primary/50"
                    : "w-2 h-2 bg-muted"
              }`}
            />
          ))}
        </div>

        {/* Step content */}
        <div className="px-6 py-4 min-h-[180px] flex flex-col">
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="flex-1 flex flex-col gap-4"
              >
                <div>
                  <p className="text-xs font-black uppercase tracking-widest text-primary mb-1">Step 1 of 4</p>
                  <h2 className="text-lg font-black leading-tight">Welcome to the Vault!</h2>
                  <p className="text-sm text-muted-foreground mt-1 leading-relaxed">
                    Let's get you set up in 4 quick steps. First — pick your currency.
                  </p>
                </div>
                <div className="space-y-1.5">
                  <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Currency</p>
                  <Select value={currency} onValueChange={setCurrency}>
                    <SelectTrigger className="h-11">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent position="popper" className="z-[10000]">
                      {CURRENCIES.map((c) => (
                        <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-[11px] text-muted-foreground/70">
                    Used for pricing, earnings, and the buyer calculator. You can change this later in Settings.
                  </p>
                </div>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="flex-1 flex flex-col gap-4"
              >
                <div>
                  <p className="text-xs font-black uppercase tracking-widest text-primary mb-1">Step 2 of 4</p>
                  <h2 className="text-lg font-black leading-tight">Label Branding</h2>
                  <p className="text-sm text-muted-foreground mt-1 leading-relaxed">
                    Set up your business details — these appear on every printed QR label.
                  </p>
                </div>
                <div className="space-y-3">
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Business Name</p>
                    <Input
                      placeholder="Your Store Name"
                      value={businessName}
                      onChange={(e) => setBusinessName(e.target.value)}
                      className="h-10"
                    />
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Instagram</p>
                    <Input
                      placeholder="yourstoreig"
                      value={instagram}
                      onChange={(e) => setInstagram(e.target.value)}
                      className="h-10"
                    />
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Website</p>
                    <Input
                      placeholder="yourstore.com"
                      value={website}
                      onChange={(e) => setWebsite(e.target.value)}
                      className="h-10"
                    />
                  </div>
                  <p className="text-[11px] text-muted-foreground/70">
                    You can skip this and set it up later in Settings → Label Branding.
                  </p>
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="flex-1 flex flex-col gap-4"
              >
                <div>
                  <p className="text-xs font-black uppercase tracking-widest text-primary mb-1">Step 3 of 4</p>
                  <h2 className="text-lg font-black leading-tight">Add Your First Card</h2>
                  <p className="text-sm text-muted-foreground mt-1 leading-relaxed">
                    Head to Inventory to add cards to your vault — track condition, value, and more.
                  </p>
                </div>
                <div className="rounded-xl border border-border bg-secondary/40 p-4 space-y-3">
                  {[
                    "Tap the + button or use the dashboard quick-add",
                    "Fill in the card name, game & condition",
                    "Add a purchase price to track profit later",
                  ].map((tip, i) => (
                    <div key={i} className="flex items-start gap-2.5">
                      <div className="w-5 h-5 rounded-full bg-primary/15 flex items-center justify-center shrink-0 mt-0.5">
                        <span className="text-[9px] font-black text-primary">{i + 1}</span>
                      </div>
                      <p className="text-sm text-foreground/90 leading-snug">{tip}</p>
                    </div>
                  ))}
                </div>
                <Button
                  variant="secondary"
                  className="gap-2 w-full"
                  onClick={handleGoToInventory}
                >
                  <Package className="h-4 w-4" />
                  Go to Inventory Now
                </Button>
              </motion.div>
            )}

            {step === 4 && (
              <motion.div
                key="step4"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="flex-1 flex flex-col gap-4"
              >
                <div>
                  <p className="text-xs font-black uppercase tracking-widest text-primary mb-1">Step 4 of 4</p>
                  <h2 className="text-lg font-black leading-tight">Print Your First Label</h2>
                  <p className="text-sm text-muted-foreground mt-1 leading-relaxed">
                    Labels make selling at shows a breeze — price tags with QR codes for lightning-fast checkout.
                  </p>
                </div>
                <div className="rounded-xl border border-primary/20 bg-primary/5 p-4 space-y-3">
                  {[
                    { icon: Tag, text: "Create a label from any card in Inventory" },
                    { icon: ScanLine, text: "Scan the QR code at your table to sell instantly" },
                    { icon: CheckCircle2, text: "Card auto-marks as Sold — earnings tracked!" },
                  ].map(({ icon: Icon, text }, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                        <Icon className="h-3.5 w-3.5 text-primary" />
                      </div>
                      <p className="text-sm text-foreground/90 leading-snug">{text}</p>
                    </div>
                  ))}
                </div>
                <Button
                  variant="secondary"
                  className="gap-2 w-full"
                  onClick={handleGoToLabels}
                >
                  <Tag className="h-4 w-4" />
                  Go to Labels Now
                </Button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Footer buttons */}
        <div className="px-6 pb-6 flex items-center justify-between gap-3">
          {step > 1 ? (
            <Button variant="ghost" size="sm" onClick={() => setStep((s) => (s - 1) as Step)} className="text-muted-foreground">
              Back
            </Button>
          ) : (
            <div />
          )}

          {step < 4 ? (
            <Button className="gap-2 font-bold" onClick={() => setStep((s) => (s + 1) as Step)}>
              Next
              <ChevronRight className="h-4 w-4" />
            </Button>
          ) : (
            <Button className="gap-2 font-bold" onClick={handleFinish} disabled={saving}>
              {saving ? "Saving…" : "Let's Go!"}
              <CheckCircle2 className="h-4 w-4" />
            </Button>
          )}
        </div>
      </motion.div>
    </div>
  );
}
