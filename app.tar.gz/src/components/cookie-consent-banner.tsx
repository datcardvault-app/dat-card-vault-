import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Cookie, X } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";

const CONSENT_KEY = "dcv_cookie_consent";

export type CookieConsent = "accepted" | "declined" | null;

export function getCookieConsent(): CookieConsent {
  try {
    const val = localStorage.getItem(CONSENT_KEY);
    if (val === "accepted" || val === "declined") return val;
  } catch { /* ignore */ }
  return null;
}

export function setCookieConsent(value: "accepted" | "declined") {
  try {
    localStorage.setItem(CONSENT_KEY, value);
  } catch { /* ignore */ }
}

export function CookieConsentBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Show banner only if the user hasn't already chosen
    if (getCookieConsent() === null) {
      // Small delay so it doesn't flash immediately on load
      const t = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(t);
    }
  }, []);

  const handleAccept = () => {
    setCookieConsent("accepted");
    setVisible(false);
  };

  const handleDecline = () => {
    setCookieConsent("declined");
    setVisible(false);
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: 32 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 32 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="fixed bottom-4 left-4 right-4 z-[200] md:left-auto md:right-6 md:max-w-sm"
        >
          <div className="rounded-2xl border border-border bg-card shadow-xl p-4 space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                <Cookie className="w-4 h-4 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-foreground">Cookie Notice</p>
                <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                  DatCARDVault uses essential cookies for authentication and functionality. No analytics or advertising cookies are used.
                </p>
              </div>
              <button
                onClick={handleDecline}
                className="p-1 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors cursor-pointer shrink-0"
                aria-label="Decline and close"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="flex gap-2">
              <Button
                size="sm"
                className="flex-1 text-xs h-8"
                onClick={handleAccept}
              >
                Accept All
              </Button>
              <Button
                size="sm"
                variant="secondary"
                className="flex-1 text-xs h-8"
                onClick={handleDecline}
              >
                Essential Only
              </Button>
            </div>
            <p className="text-[10px] text-muted-foreground text-center leading-relaxed">
              See our{" "}
              <a href="/privacy" className="text-primary underline hover:no-underline">
                Privacy Policy
              </a>{" "}
              for full details. Essential cookies cannot be declined.
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
