import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { AlertTriangle, ChevronDown, ChevronUp } from "lucide-react";
import { formatCurrency } from "@/lib/utils.ts";
import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";

type Props = {
  name: string;
  game: string;
  currency: string;
};

export default function DuplicateWarning({ name, game, currency }: Props) {
  const [expanded, setExpanded] = useState(false);

  const duplicates = useQuery(
    api.cards.findDuplicates,
    name.trim().length >= 2 ? { name: name.trim(), game } : "skip"
  );

  if (!duplicates || duplicates.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: -4 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -4 }}
      className="rounded-xl border border-amber-500/30 bg-amber-500/8 overflow-hidden"
    >
      <button
        type="button"
        onClick={() => setExpanded(e => !e)}
        className="w-full flex items-center gap-2.5 px-3 py-2.5 cursor-pointer text-left"
      >
        <AlertTriangle className="h-4 w-4 text-amber-400 shrink-0" />
        <div className="flex-1 min-w-0">
          <p className="text-xs font-bold text-amber-400">
            Possible Duplicate — {duplicates.length} matching card{duplicates.length > 1 ? "s" : ""} already in vault
          </p>
          <p className="text-[10px] text-muted-foreground">You can still save — tap to {expanded ? "hide" : "review"}</p>
        </div>
        {expanded
          ? <ChevronUp className="h-3.5 w-3.5 text-amber-400 shrink-0" />
          : <ChevronDown className="h-3.5 w-3.5 text-amber-400 shrink-0" />
        }
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: "auto" }}
            exit={{ height: 0 }}
            className="overflow-hidden"
          >
            <div className="border-t border-amber-500/20 divide-y divide-amber-500/10">
              {duplicates.map(card => (
                <div key={card._id} className="px-3 py-2 flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-foreground truncate">{card.name}</p>
                    <p className="text-[10px] text-muted-foreground truncate">
                      {card.game}
                      {card.set ? ` · ${card.set}` : ""}
                      {" · "}{card.condition}
                      {card.grade ? ` · ${card.grade}` : ""}
                    </p>
                  </div>
                  {card.marketValue !== undefined && (
                    <span className="text-xs font-bold text-foreground shrink-0">
                      {formatCurrency(card.marketValue, currency)}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
