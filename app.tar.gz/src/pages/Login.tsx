import { motion } from "motion/react";
import { type ReactNode, useEffect, useRef, useState } from "react";
import { SignInButton } from "@/components/ui/signin.tsx";
import { useAuth } from "@/hooks/use-auth.ts";
import { useNavigate } from "react-router-dom";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import {
  Package, Tag, ScanLine, TrendingUp, Bluetooth, Wifi,
  Zap, ShieldCheck, QrCode, Archive, Calendar, Users,
  CheckCircle2, ArrowRight, Camera, Printer, ShoppingCart, WifiOff, Barcode, FileText, Star,
} from "lucide-react";

type BounceLogo = {
  id: number;
  size: number;
  rot: number;
  opacity: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  vrot: number;
  // Sine-wave drift for organic curvy paths
  phase: number;
  phaseSpeed: number;
  driftAmplitude: number;
};

function BouncingLogos() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [logos, setLogos] = useState<BounceLogo[]>([]);
  const logosRef = useRef<BounceLogo[]>([]);
  const rafRef = useRef<number>(0);
  const frameCount = useRef(0);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const W = el.offsetWidth;
    const H = el.offsetHeight;

    // Varied sizes for depth/parallax feel
    const configs = [
      { size: 240, opacity: 0.2 },
      { size: 160, opacity: 0.14 },
      { size: 200, opacity: 0.17 },
      { size: 140, opacity: 0.12 },
      { size: 180, opacity: 0.15 },
    ];

    const initial: BounceLogo[] = configs.map((c, i) => ({
      id: i,
      size: c.size,
      rot: Math.random() * 360,
      opacity: c.opacity,
      x: Math.random() * (W - c.size),
      y: Math.random() * (H - c.size),
      // Faster base speed for livelier movement
      vx: (Math.random() * 1.0 + 0.5) * (Math.random() < 0.5 ? 1 : -1),
      vy: (Math.random() * 1.0 + 0.5) * (Math.random() < 0.5 ? 1 : -1),
      vrot: (Math.random() * 0.4 + 0.15) * (Math.random() < 0.5 ? 1 : -1),
      // Each logo drifts on a unique sine wave for curvy, organic paths
      phase: Math.random() * Math.PI * 2,
      phaseSpeed: 0.01 + Math.random() * 0.015,
      driftAmplitude: 0.3 + Math.random() * 0.5,
    }));

    logosRef.current = initial;
    setLogos([...initial]);

    const tick = () => {
      frameCount.current += 1;
      const W2 = el.offsetWidth;
      const H2 = el.offsetHeight;
      logosRef.current = logosRef.current.map(l => {
        let { x, y, vx, vy, rot, vrot, size, phase, phaseSpeed, driftAmplitude } = l;

        // Advance sine phase for organic drift
        phase += phaseSpeed;

        // Apply velocity + perpendicular sine drift for curved paths
        const angle = Math.atan2(vy, vx);
        const driftX = Math.cos(angle + Math.PI / 2) * Math.sin(phase) * driftAmplitude;
        const driftY = Math.sin(angle + Math.PI / 2) * Math.sin(phase) * driftAmplitude;

        x += vx + driftX;
        y += vy + driftY;
        rot += vrot;

        // Bounce with slight speed variation for natural feel
        if (x <= 0) { x = 0; vx = Math.abs(vx) * (0.9 + Math.random() * 0.2); }
        if (x >= W2 - size) { x = W2 - size; vx = -Math.abs(vx) * (0.9 + Math.random() * 0.2); }
        if (y <= 0) { y = 0; vy = Math.abs(vy) * (0.9 + Math.random() * 0.2); }
        if (y >= H2 - size) { y = H2 - size; vy = -Math.abs(vy) * (0.9 + Math.random() * 0.2); }

        // Clamp speed so they don't get too fast or too slow over time
        const speed = Math.sqrt(vx * vx + vy * vy);
        if (speed > 1.8) { vx *= 1.8 / speed; vy *= 1.8 / speed; }
        if (speed < 0.4) { vx *= 0.4 / speed; vy *= 0.4 / speed; }

        return { ...l, x, y, vx, vy, rot, phase };
      });
      // Render every 2nd frame (~30fps) for smoother visual
      if (frameCount.current % 2 === 0) {
        setLogos([...logosRef.current]);
      }
      rafRef.current = requestAnimationFrame(tick);
    };

    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, []);

  return (
    <div ref={containerRef} className="fixed inset-0 overflow-hidden pointer-events-none select-none">
      {logos.map(l => (
        <img
          key={l.id}
          src="https://hercules-cdn.com/file_ucfyG5vLgm6brElkxbRiu0Ji"
          alt=""
          aria-hidden="true"
          style={{
            position: "absolute",
            left: l.x,
            top: l.y,
            width: l.size,
            height: l.size,
            opacity: l.opacity,
            transform: `translate3d(0,0,0) rotate(${l.rot}deg)`,
            objectFit: "contain",
            pointerEvents: "none",
          }}
        />
      ))}
    </div>
  );
}

const FEATURES = [
  {
    icon: Package,
    title: "500 Cards + 500 Sealed Product",
    desc: "Catalogue cards with photos, condition, grade, and pricing — plus track booster packs, ETBs, tins, and boxes with barcode scanning.",
    color: "text-purple-400",
    bg: "bg-purple-500/10 border-purple-500/20",
  },
  {
    icon: QrCode,
    title: "QR Price Labels & Barcode Scanning",
    desc: "Custom print templates with QR labels for cards. Scan any barcode to sell sealed product instantly.",
    color: "text-amber-500",
    bg: "bg-amber-600/10 border-amber-600/20",
  },
  {
    icon: ScanLine,
    title: "Scan & Sell",
    desc: "Scan labels to pull up cards, mark sold, and email receipts.",
    color: "text-primary",
    bg: "bg-primary/10 border-primary/20",
  },
  {
    icon: TrendingUp,
    title: "Earnings Tracking",
    desc: "Automatic daily logging for total sales, profits, and top buys.",
    color: "text-profit",
    bg: "bg-profit/10 border-profit/20",
  },
  {
    icon: Zap,
    title: "Event Mode",
    desc: "Seamless multi-day tracking with zero at 6am resets.",
    color: "text-orange-400",
    bg: "bg-orange-500/10 border-orange-500/20",
  },
  {
    icon: Bluetooth,
    title: "Bluetooth/WiFi Printing",
    desc: "Print labels directly from the app using compatible Bluetooth or WiFi thermal printers.",
    color: "text-blue-400",
    bg: "bg-blue-500/10 border-blue-500/20",
  },
  {
    icon: Archive,
    title: "Sold Archive",
    desc: "Auto-archives sold stock to free up new vault space instantly.",
    color: "text-gray-400",
    bg: "bg-secondary border-border",
  },
  {
    icon: Calendar,
    title: "Sales Calendar",
    desc: "Track monthly revenue and log show notes day-by-day.",
    color: "text-cyan-400",
    bg: "bg-cyan-500/10 border-cyan-500/20",
  },
];

function SignInLink() {
  const { signinRedirect } = useAuth();
  return (
    <button
      onClick={() => signinRedirect()}
      className="text-primary underline underline-offset-2 font-semibold cursor-pointer hover:text-primary/80 transition-colors"
    >
      Sign in
    </button>
  );
}

function WorkflowStep({ icon, number, title, desc, color, bg }: {
  icon: ReactNode;
  number: number;
  title: string;
  desc: string;
  color: string;
  bg: string;
}) {
  return (
    <div className="rounded-xl border border-white/20 bg-white/[0.04] p-3 flex flex-col items-center text-center gap-2.5 h-full">
      <div className={`w-11 h-11 rounded-2xl ${bg} flex items-center justify-center shrink-0 shadow-lg`}>
        {icon}
      </div>
      <div>
        <p className={`text-[11px] font-black ${color} leading-tight tracking-wide`}>{number}. {title}</p>
        <p className="text-[9px] text-white/50 leading-snug mt-1">{desc}</p>
      </div>
    </div>
  );
}

function StaticTagline() {
  return (
    <p className="font-black tracking-[0.1em] text-primary uppercase" style={{ fontSize: "clamp(0.65rem, 3.5vw, 1.125rem)" }}>
      BUILT FOR THE TCG GRIND. EVERY SHOW. EVERY EVENT. EVERY CONVENTION.
    </p>
  );
}

export default function LoginPage() {
  const navigate = useNavigate();
  const liveFeedback = useQuery(api.feedback.getApprovedPositive, {});

  const STATIC_TESTIMONIALS = [
    { quote: "Absolutely game changer at shows. Scan, sell, done. No more spreadsheets.", name: "J.M., Pokémon vendor" },
    { quote: "The QR label system saves me hours every weekend. Couldn't run my table without it.", name: "D.T., TCG trader" },
    { quote: "Event Mode is incredible — tracks every day of a multi-day show perfectly.", name: "R.K., card show regular" },
  ];

  const testimonials = (liveFeedback && liveFeedback.length > 0)
    ? liveFeedback.map(f => ({ quote: f.message, name: f.name ?? "DatCARDVault user" }))
    : STATIC_TESTIMONIALS;

  return (
    <div className="min-h-screen bg-black flex flex-col items-center p-6 pb-8 relative overflow-x-hidden overflow-y-auto">
      {/* Black overlay */}
      <div className="absolute inset-0 pointer-events-none bg-black/40" />
      {/* Bouncing watermark logos — disabled on iOS for performance */}
      {!/iphone|ipad|ipod/i.test(navigator.userAgent) && <BouncingLogos />}

      {/* RGB watercolour background */}
      <div className="absolute inset-0 pointer-events-none select-none overflow-hidden">
        {/* Base layer — ambient colour shifts */}
        <motion.div
          className="absolute inset-0 will-change-[background]"
          animate={{
            background: [
              "radial-gradient(ellipse 120% 100% at 30% 20%, rgba(255,0,40,0.45) 0%, transparent 50%), radial-gradient(ellipse 100% 120% at 75% 80%, rgba(0,80,255,0.4) 0%, transparent 50%), radial-gradient(ellipse 80% 80% at 50% 50%, rgba(120,0,200,0.25) 0%, transparent 60%)",
              "radial-gradient(ellipse 120% 100% at 70% 80%, rgba(0,180,255,0.45) 0%, transparent 50%), radial-gradient(ellipse 100% 120% at 20% 30%, rgba(255,0,180,0.4) 0%, transparent 50%), radial-gradient(ellipse 80% 80% at 60% 40%, rgba(255,100,0,0.25) 0%, transparent 60%)",
              "radial-gradient(ellipse 120% 100% at 80% 30%, rgba(180,0,255,0.45) 0%, transparent 50%), radial-gradient(ellipse 100% 120% at 30% 70%, rgba(0,255,120,0.35) 0%, transparent 50%), radial-gradient(ellipse 80% 80% at 40% 60%, rgba(255,0,60,0.25) 0%, transparent 60%)",
              "radial-gradient(ellipse 120% 100% at 20% 70%, rgba(255,60,0,0.45) 0%, transparent 50%), radial-gradient(ellipse 100% 120% at 80% 20%, rgba(0,100,255,0.4) 0%, transparent 50%), radial-gradient(ellipse 80% 80% at 50% 50%, rgba(200,0,255,0.25) 0%, transparent 60%)",
              "radial-gradient(ellipse 120% 100% at 30% 20%, rgba(255,0,40,0.45) 0%, transparent 50%), radial-gradient(ellipse 100% 120% at 75% 80%, rgba(0,80,255,0.4) 0%, transparent 50%), radial-gradient(ellipse 80% 80% at 50% 50%, rgba(120,0,200,0.25) 0%, transparent 60%)",
            ],
          }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
          style={{ filter: "blur(28px)" }}
        />
        {/* Blob 1 — hot pink/red */}
        <motion.div
          animate={{ x: [0, 80, 20, -40, 0], y: [0, -40, -80, -20, 0] }}
          transition={{ duration: 14, repeat: Infinity, ease: "easeInOut" }}
          className="absolute -top-16 -left-16 w-[320px] h-[320px] rounded-full will-change-transform"
          style={{ background: "radial-gradient(circle, rgba(255,20,80,0.65) 0%, rgba(255,0,120,0.3) 40%, transparent 70%)", filter: "blur(28px)" }}
        />
        {/* Blob 2 — electric blue */}
        <motion.div
          animate={{ x: [0, -70, -20, 50, 0], y: [0, 60, 30, -20, 0] }}
          transition={{ duration: 16, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          className="absolute -top-10 -right-10 w-[300px] h-[300px] rounded-full will-change-transform"
          style={{ background: "radial-gradient(circle, rgba(0,120,255,0.65) 0%, rgba(0,80,255,0.3) 40%, transparent 70%)", filter: "blur(28px)" }}
        />
        {/* Blob 3 — purple/violet */}
        <motion.div
          animate={{ x: [0, 50, -60, 20, 0], y: [0, -50, 30, 60, 0] }}
          transition={{ duration: 18, repeat: Infinity, ease: "easeInOut", delay: 3 }}
          className="absolute bottom-[10%] left-[20%] w-[280px] h-[280px] rounded-full will-change-transform"
          style={{ background: "radial-gradient(circle, rgba(160,0,255,0.55) 0%, rgba(100,0,200,0.25) 40%, transparent 70%)", filter: "blur(28px)" }}
        />
        {/* Blob 4 — cyan/teal */}
        <motion.div
          animate={{ x: [0, -40, 30, -60, 0], y: [0, -30, -60, 20, 0] }}
          transition={{ duration: 20, repeat: Infinity, ease: "easeInOut", delay: 5 }}
          className="absolute bottom-[5%] right-[10%] w-[240px] h-[240px] rounded-full will-change-transform"
          style={{ background: "radial-gradient(circle, rgba(0,220,200,0.5) 0%, rgba(0,180,255,0.2) 40%, transparent 70%)", filter: "blur(28px)" }}
        />
      </div>

      <div className="relative z-10 w-full max-w-lg flex flex-col items-center gap-6 pt-6">

        {/* ── Hero ── */}
        <div className="flex flex-col items-center text-center gap-6 w-full">
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.05, type: "spring", stiffness: 180, damping: 16 }}
            className="relative m-6"
          >
            {/* Red glow behind logo — separate div so iOS Safari doesn't blank the img */}
            <div
              className="absolute inset-0 rounded-full"
              style={{ background: "radial-gradient(circle, rgba(204,0,0,0.7) 0%, transparent 70%)" }}
            />
            <img
              src="https://hercules-cdn.com/file_SQDBfg4Krhk4mBS3EVwxZEs6"
              alt="DatCardVault"
              className="relative w-52 h-52 object-contain"
            />
            <span className="absolute top-1 right-1 text-[9px] font-bold text-white/60 leading-none">™</span>
            {/* Inner ring with dot */}
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 14, ease: "linear" }}
              className="absolute rounded-full border border-dashed border-primary/40"
              style={{ inset: -14 }}
            >
              {/* 0° (12 o'clock) */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-primary/80 shadow-[0_0_6px_rgba(204,0,0,0.6)]" />
            </motion.div>
            {/* Outer ring counter-rotating with dots */}
            <motion.div
              animate={{ rotate: -360 }}
              transition={{ repeat: Infinity, duration: 22, ease: "linear" }}
              className="absolute rounded-full border border-dashed border-primary/25"
              style={{ inset: -28 }}
            >
              {/* 90° (3 o'clock) */}
              <div className="absolute top-1/2 right-0 translate-x-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-primary/50 shadow-[0_0_5px_rgba(204,0,0,0.4)]" />
              {/* 270° (9 o'clock) */}
              <div className="absolute top-1/2 left-0 -translate-x-1/2 -translate-y-1/2 w-1 h-1 rounded-full bg-primary/30" />
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="w-full rounded-3xl border border-white/40 p-4 space-y-3"
            style={{ background: "rgba(0,0,0,0.7)" }}
          >
            {/* "For vendors" badge */}
            <div className="flex justify-center">
              <span className="text-[10px] font-black tracking-[0.2em] uppercase px-3 py-1 rounded-full bg-primary/20 border border-primary/40 text-primary">
                For TCG Vendors &amp; Card Show Sellers
              </span>
            </div>
            <h1 className="text-[clamp(1.75rem,8vw,3rem)] font-sans font-black tracking-widest leading-none text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)] text-center">
              Dat<span className="text-primary">CARD</span>Vault<sup className="text-[10px] font-normal text-white/50 align-super ml-0.5">™</sup>
            </h1>
            {/* Benefit headline */}
            <p className="text-lg font-black text-white leading-snug">
              Run your entire card stall<br /><span className="text-primary">from your phone.</span>
            </p>
            <p className="text-sm text-white/75 max-w-xs mx-auto leading-relaxed">
              Inventory · QR Labels · Barcode Scanning · Earnings — all in one place. Built for the table, not the office.
            </p>
            <StaticTagline />
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35 }}
            className="w-full space-y-2"
          >
            <SignInButton className="w-full h-13 text-base font-black gap-2" signInText="GET STARTED — IT'S FREE">
            </SignInButton>
            <div className="flex flex-col items-center gap-1.5 drop-shadow-[0_1px_4px_rgba(0,0,0,0.8)]">
              <span className="text-[11px] text-white/50">Already have an account? <SignInLink /></span>
              <motion.div
                className="flex items-center justify-center gap-2 w-full"
                animate={{ scale: [1, 1.04, 1] }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut" as const,
                }}
              >
                <CheckCircle2 className="w-7 h-7 text-profit shrink-0" />
                <span className="text-xl font-black text-profit">Early Access Available Now</span>
              </motion.div>
            </div>
          </motion.div>

          {/* Social proof */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.42 }}
            className="w-full rounded-2xl border border-white/60 p-4 space-y-3"
            style={{ background: "rgba(0,0,0,0.5)", backdropFilter: "blur(16px)" }}
          >
            <div className="flex items-center justify-center gap-1.5">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              ))}
              <span className="text-[11px] font-bold text-white/70 ml-1">Loved by vendors</span>
            </div>
            <div className="space-y-2.5">
              {testimonials.map(({ quote, name }, i) => (
                <div key={i} className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2.5">
                  <p className="text-[11px] text-white/75 leading-relaxed italic">{`"${quote}"`}</p>
                  <p className="text-[10px] font-bold text-primary mt-1">{name}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* ── From Card To Cash workflow ── */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.45 }}
          className="w-full rounded-2xl border border-white/60 overflow-hidden"
          style={{ background: "rgba(0,0,0,0.75)", backdropFilter: "blur(24px)", boxShadow: "0 0 0 1px rgba(255,255,255,0.15), 0 0 24px rgba(255,255,255,0.05)" }}
        >
          {/* Title */}
          <div className="text-center px-6 pt-6 pb-4 border-b border-white/10">
            <h2 className="text-xl sm:text-2xl font-black tracking-wider text-white uppercase">
              From <span className="text-primary">CARDS</span> to Cash — Your Complete <span className="text-primary">Workflow</span>
            </h2>
            <p className="text-[10px] text-white/40 tracking-wide mt-1">The real reason why vendors choose us everytime — Everything in your palm.</p>
          </div>

          {/* Steps grid — 2 columns of 4 rows + full-width final step */}
          <div className="px-4 py-4 space-y-1.5">
            {/* Row 1 */}
            <div className="grid grid-cols-[1fr_auto_1fr] items-stretch gap-1.5">
              <WorkflowStep
                icon={<Camera className="w-5 h-5 text-blue-400" />}
                number={1}
                title="Photo & Details"
                desc="Take a photo and add card details in seconds."
                color="text-blue-400"
                bg="bg-blue-500/20 border border-blue-500/30"
              />
              <div className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center self-center">
                <ArrowRight className="w-3 h-3 text-white/60" />
              </div>
              <WorkflowStep
                icon={<Package className="w-5 h-5 text-purple-400" />}
                number={2}
                title="Add to Vault"
                desc="Store your card safely in your digital vault."
                color="text-purple-400"
                bg="bg-purple-500/20 border border-purple-500/30"
              />
            </div>
            {/* Row 2 */}
            <div className="grid grid-cols-[1fr_auto_1fr] items-stretch gap-1.5">
              <WorkflowStep
                icon={<Tag className="w-5 h-5 text-amber-500" />}
                number={3}
                title="Auto Label"
                desc="Generate a label with pricing and details."
                color="text-amber-500"
                bg="bg-amber-500/20 border border-amber-500/30"
              />
              <div className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center self-center">
                <ArrowRight className="w-3 h-3 text-white/60" />
              </div>
              <WorkflowStep
                icon={<Printer className="w-5 h-5 text-blue-400" />}
                number={4}
                title="Print QR Labels"
                desc="Print labels with your Bluetooth or WiFi printer."
                color="text-blue-400"
                bg="bg-blue-500/20 border border-blue-500/30"
              />
            </div>
            {/* Row 3 */}
            <div className="grid grid-cols-[1fr_auto_1fr] items-stretch gap-1.5">
              <WorkflowStep
                icon={<ScanLine className="w-5 h-5 text-primary" />}
                number={5}
                title="Scan QR & Sell"
                desc="Scan a card's QR label to instantly pull it up and sell."
                color="text-primary"
                bg="bg-primary/20 border border-primary/30"
              />
              <div className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center self-center">
                <ArrowRight className="w-3 h-3 text-white/60" />
              </div>
              <WorkflowStep
                icon={<Barcode className="w-5 h-5 text-blue-300" />}
                number={6}
                title="Scan Barcode"
                desc="Or scan a sealed product barcode — same scanner, auto-detected."
                color="text-blue-300"
                bg="bg-blue-400/20 border border-blue-400/30"
              />
            </div>
            {/* Row 4 */}
            <div className="grid grid-cols-[1fr_auto_1fr] items-stretch gap-1.5">
              <WorkflowStep
                icon={<ShoppingCart className="w-5 h-5 text-orange-400" />}
                number={7}
                title="Bulk Sale"
                desc="Sell multiple cards quickly in bulk."
                color="text-orange-400"
                bg="bg-orange-500/20 border border-orange-500/30"
              />
              <div className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center self-center">
                <ArrowRight className="w-3 h-3 text-white/60" />
              </div>
              <WorkflowStep
                icon={<TrendingUp className="w-5 h-5 text-profit" />}
                number={8}
                title="Earnings Logged"
                desc="All sales logged and earnings tracked automatically."
                color="text-profit"
                bg="bg-profit/20 border border-profit/30"
              />
            </div>
          </div>
        </motion.div>

        {/* ── Feature grid ── */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.55 }}
          className="w-full space-y-3"
        >
          <div className="flex items-center gap-2">
            <div className="h-px flex-1 bg-white/20" />
            <p className="text-[9px] font-black tracking-[0.3em] text-white/80 uppercase drop-shadow-[0_1px_4px_rgba(0,0,0,0.9)]">Everything Inside</p>
            <div className="h-px flex-1 bg-white/20" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            {FEATURES.map(({ icon: Icon, title, desc, color, bg }, i) => (
              <motion.div
                key={title}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 + i * 0.05 }}
                className={`flex flex-col gap-2 p-4 rounded-2xl border border-white/40`}
                style={{ background: "rgba(0,0,0,0.6)", backdropFilter: "blur(16px)" }}
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ background: "rgba(255,255,255,0.08)" }}>
                    <Icon className={`w-4 h-4 ${color}`} />
                  </div>
                  <p className="text-xs font-bold text-white leading-snug">{title}</p>
                </div>
                <p className="text-[11px] text-white/65 leading-relaxed">{desc}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* ── Bottom CTA ── */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
          className="w-full space-y-3"
        >
          <div className="flex items-center gap-2">
            <div className="h-px flex-1 bg-white/20" />
            <p className="text-[9px] font-black tracking-[0.3em] text-white/80 uppercase drop-shadow-[0_1px_4px_rgba(0,0,0,0.9)]">Exclusive Features</p>
            <div className="h-px flex-1 bg-white/20" />
          </div>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.85 }}
            className="w-full rounded-2xl border border-blue-500/40 p-4 flex items-start gap-3"
            style={{ background: "rgba(0,20,60,0.7)", backdropFilter: "blur(20px)" }}
          >
            <div className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0 bg-blue-500/15 border border-blue-500/30">
              <Users className="w-5 h-5 text-blue-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-white leading-snug">Team Mode — New</p>
              <p className="text-[11px] text-white/65 mt-0.5 leading-relaxed">Running a stall with a partner? Share your vault in real time — live presence, instant nudge alerts, and a shared selling flow.<br /><span className="text-blue-300 font-semibold">Two people. One vault. Zero chaos.</span></p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
            className="w-full rounded-2xl border border-profit/40 p-4 flex items-start gap-3"
            style={{ background: "rgba(0,30,10,0.7)", backdropFilter: "blur(20px)" }}
          >
            <div className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0 bg-profit/15 border border-profit/30">
              <Zap className="w-5 h-5 text-profit" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-white leading-snug">Event Mode — New</p>
              <p className="text-[11px] text-white/65 mt-0.5 leading-relaxed">Heading to a card show? Activate Event Mode for seamless multi-day tracking — sales reset at 6am each morning so each day starts fresh, while your total earnings keep rolling.<br /><span className="text-profit font-semibold">Built for the weekend grind.</span></p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.95 }}
            className="w-full rounded-2xl border border-amber-500/40 p-4 flex items-start gap-3"
            style={{ background: "rgba(30,18,0,0.7)", backdropFilter: "blur(20px)" }}
          >
            <div className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0 bg-amber-500/15 border border-amber-500/30">
              <QrCode className="w-5 h-5 text-amber-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-white leading-snug">QR Code & Barcode Scanning — New</p>
              <p className="text-[11px] text-white/65 mt-0.5 leading-relaxed">
                Every card gets its own unique QR code label — scan it at point of sale to instantly pull up the card, confirm the price, and mark it sold.<br />
                Selling sealed product too? The same scanner auto-detects product barcodes (EAN-13/UPC-A) on boxes, ETBs, and packs — no mode switching needed. Stock updates and the sale logs to Earnings instantly.<br />
                <span className="text-amber-300 font-semibold">Works offline at shows and syncs automatically when back online.</span>
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.0 }}
            className="w-full rounded-2xl border border-purple-500/40 p-4 flex items-start gap-3"
            style={{ background: "rgba(20,0,40,0.7)", backdropFilter: "blur(20px)" }}
          >
            <div className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0 bg-purple-500/15 border border-purple-500/30">
              <ScanLine className="w-5 h-5 text-purple-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-white leading-snug">Bulk QR & Barcode Scanning — New</p>
              <p className="text-[11px] text-white/65 mt-0.5 leading-relaxed">
                Scan card after card without stopping — each scan instantly logs to your recent scans list.<br />
                When a customer wants multiple items, tap <span className="text-white font-semibold">Bulk Sale</span> to scan QR labels <span className="text-white font-semibold">and</span> product barcodes together in one basket — mix cards and sealed products, set each price individually, pick cash or card, confirm the whole sale in one tap, and send a combined receipt.<br />
                <span className="text-purple-300 font-semibold">No fumbling. No delays. Built for busy show tables.</span>
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.05 }}
            className="w-full rounded-2xl border border-pink-500/40 p-4 flex items-start gap-3"
            style={{ background: "rgba(60,0,30,0.7)", backdropFilter: "blur(20px)" }}
          >
            <div className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0 bg-pink-500/15 border border-pink-500/30">
              <FileText className="w-5 h-5 text-pink-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-white leading-snug">eBay CSV Import — New</p>
              <p className="text-[11px] text-white/65 mt-0.5 leading-relaxed">
                Got existing eBay sold listings or a spreadsheet of cards? Import them in one go — no manual entry needed.<br />
                Upload your eBay Seller Hub orders CSV directly, or use the Standard format for any spreadsheet. The importer maps <span className="text-white font-bold">Item Title → name, Sold For → price, Custom Label → set, Item Condition → condition</span> automatically. Each card gets its own QR label instantly.<br />
                <span className="text-pink-300 font-semibold">Bulk-add your entire back catalogue in minutes.</span>
              </p>
            </div>
          </motion.div>

          <div className="flex items-center gap-3">
            <div className="h-px flex-1 bg-white/20" />
            <p className="text-[9px] font-black tracking-[0.3em] text-white/80 drop-shadow-[0_1px_4px_rgba(0,0,0,0.9)]">iOS WiFi PRINTING</p>
            <div className="h-px flex-1 bg-white/20" />
          </div>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.1 }}
            className="w-full rounded-2xl border border-blue-400/40 p-4 flex items-start gap-3"
            style={{ background: "rgba(0,20,50,0.7)", backdropFilter: "blur(20px)" }}
          >
            <div className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0 bg-blue-500/15 border border-blue-500/30">
              <Wifi className="w-5 h-5 text-blue-400" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <p className="text-sm font-bold text-white leading-snug">Apple iOS Printing</p>
                <span className="text-[8px] font-black bg-blue-500/30 border border-blue-400/40 text-blue-300 px-1.5 py-0.5 rounded-full uppercase tracking-wide whitespace-nowrap">WiFi Available</span>
              </div>
              <p className="text-[11px] text-white/65 leading-relaxed">
                Web Bluetooth isn&apos;t available on iOS (Apple blocks it), but <span className="text-white font-bold">WiFi Printing</span> works natively on iPhone &amp; iPad — tap the blue WiFi button on the Labels page to print to any WiFi printer on your network. You can also use <span className="text-white font-semibold">Save Label Image</span> to export high-res PNGs and print via the <span className="text-white font-semibold">MarkLife</span> app.<br /><span className="text-blue-300 font-semibold">For direct Bluetooth printing, use Android or Chrome on desktop.</span>
              </p>
            </div>
          </motion.div>

          <div className="rounded-2xl border border-red-700/60 p-4 text-center space-y-3"
            style={{ background: "rgba(153,0,0,0.45)", backdropFilter: "blur(20px)" }}>
            <p className="text-base font-black tracking-wide text-white">Ready to sell smarter at your next show?</p>
            <p className="text-xs text-white/70">Join vendors already running their TCG business from their pocket — no regrets.</p>
            <SignInButton className="w-full h-11 font-bold gap-2" signInText="START FOR FREE">
            </SignInButton>
          </div>

          {/* Footer */}
          <div className="w-full space-y-3 pt-2 pb-4">
            <p className="text-[10px] text-white/50 text-center tracking-widest uppercase drop-shadow-[0_1px_4px_rgba(0,0,0,0.9)]">
              Dat<span className="text-primary font-bold">CARD</span>Vault · Scan · Store · Label
            </p>
            <p className="text-[10px] font-bold flex items-center justify-center gap-1 text-profit drop-shadow-[0_1px_4px_rgba(0,0,0,0.9)]">
              <ShieldCheck className="w-3 h-3 shrink-0" />
              Secure & Protected
            </p>
            <div className="flex items-center justify-center gap-3 text-center drop-shadow-[0_1px_4px_rgba(0,0,0,0.9)]">
              <button
                onClick={() => navigate("/privacy")}
                className="text-[10px] text-white/50 hover:text-white/80 transition-colors underline underline-offset-2 cursor-pointer"
              >
                Privacy Policy
              </button>
              <span className="text-white/20">·</span>
              <button
                onClick={() => navigate("/terms")}
                className="text-[10px] text-white/50 hover:text-white/80 transition-colors underline underline-offset-2 cursor-pointer"
              >
                Terms & Conditions
              </button>
            </div>
            <p className="text-[10px] text-white/35 text-center tracking-widest drop-shadow-[0_1px_4px_rgba(0,0,0,0.9)]">
              © {new Date().getFullYear()} Dat<span className="font-bold">CARD</span>Vault™ All rights reserved.
            </p>
          </div>
        </motion.div>

      </div>
    </div>
  );
}
