// Redirect to labels page
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
export default function LabelNewPage() {
  const navigate = useNavigate();
  useEffect(() => { navigate("/inventory"); }, [navigate]);
  return null;
}
