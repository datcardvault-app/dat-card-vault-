// Redirect to labels page
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
export default function LabelEditPage() {
  const navigate = useNavigate();
  useEffect(() => { navigate("/labels"); }, [navigate]);
  return null;
}
