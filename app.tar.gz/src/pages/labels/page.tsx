import { useState, useEffect, useRef, useCallback } from "react";
import { usePaginatedQuery, useMutation, useQuery } from "convex/react";
import { motion, AnimatePresence } from "motion/react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import {
  Tag, Pencil, Printer, ChevronDown, QrCode, Minus, Plus, X,
  Bluetooth, BluetoothConnected, BluetoothOff, AlertCircle, Trash2,
  Download, Share2, Smartphone, Wifi,
} from "lucide-react";
import QRCode from "qrcode";
import { formatCurrency } from "@/lib/utils.ts";
import { useNavigate } from "react-router-dom";
import { useBtPrinterContext } from "@/hooks/use-bt-printer-context.tsx";


const LABEL_SIZES = [
  { label: "50×30mm", w: 50, h: 30 },
  { label: "52×32mm", w: 52, h: 32 },
  { label: "57×33mm", w: 57, h: 33 },
  { label: "62×29mm", w: 62, h: 29 },
  { label: "Custom", w: 0, h: 0 },
];

// Pre-designed label templates — each sets the visual style
export type LabelTemplate = {
  id: string;
  name: string;
  description: string;
  style: "standard" | "graded" | "minimal";
  accent: string; // hex for price/accent colour
};

export const LABEL_TEMPLATES: LabelTemplate[] = [
  {
    id: "standard",
    name: "Standard",
    description: "QR left, full info right. Best all-rounder.",
    style: "standard",
    accent: "#cc0000",
  },
  {
    id: "graded",
    name: "Graded Card",
    description: "Highlights grade prominently alongside QR.",
    style: "graded",
    accent: "#b8860b",
  },
  {
    id: "minimal",
    name: "Minimal",
    description: "Name + price only. Clean and simple.",
    style: "minimal",
    accent: "#333333",
  },
];

const PX_PER_MM = 3.7795;
const PRINT_DPI   = 300;
const MM_PER_INCH = 25.4;

// Sheet constants — 100×150mm at 203 DPI
const SHEET_DPI   = 203;
const SHEET_W_MM  = 100;
const SHEET_H_MM  = 150;

// Fixed label size
const LABEL_W_MM  = 56;
const LABEL_H_MM  = 35;

/**
 * Pack an arbitrary list of label canvases (different labels) onto sheets.
 * Labels are placed left-to-right, top-to-bottom, one after the other.
 */
function packMixedLabelsOntoSheets(labelCanvases: HTMLCanvasElement[]): HTMLCanvasElement[] {
  const sheetW = Math.round((SHEET_W_MM / MM_PER_INCH) * SHEET_DPI);
  const sheetH = Math.round((SHEET_H_MM / MM_PER_INCH) * SHEET_DPI);
  const lblW   = Math.round((LABEL_W_MM / MM_PER_INCH) * SHEET_DPI);
  const lblH   = Math.round((LABEL_H_MM / MM_PER_INCH) * SHEET_DPI);

  const cols = Math.floor(sheetW / lblW);  // 2
  const rows = Math.floor(sheetH / lblH);  // 6
  const perSheet = cols * rows;            // 12

  const sheets: HTMLCanvasElement[] = [];
  let idx = 0;

  while (idx < labelCanvases.length) {
    const canvas = document.createElement("canvas");
    canvas.width  = sheetW;
    canvas.height = sheetH;
    const ctx = canvas.getContext("2d")!;
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, sheetW, sheetH);

    const onThisSheet = Math.min(labelCanvases.length - idx, perSheet);
    for (let i = 0; i < onThisSheet; i++) {
      const col = i % cols;
      const row = Math.floor(i / cols);
      ctx.drawImage(labelCanvases[idx + i], col * lblW, row * lblH, lblW, lblH);

      // Dotted cut guides between labels
      ctx.strokeStyle = "#000000";
      ctx.lineWidth   = 1;
      ctx.setLineDash([4, 4]);
      if (col < cols - 1) {
        const x = col * lblW + lblW;
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, sheetH); ctx.stroke();
      }
      if (row < rows - 1) {
        const y = row * lblH + lblH;
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(sheetW, y); ctx.stroke();
      }
      ctx.setLineDash([]);
    }

    sheets.push(canvas);
    idx += onThisSheet;
  }

  return sheets;
}

type LabelData = {
  _id: Id<"labels">;
  cardId: Id<"cards">;
  labelData: {
    cardName: string;
    game: string;
    set?: string;
    cardNumber?: string;
    condition: string;
    grade?: string;
    price?: number;
    rarity?: string;
    language?: string;
    edition?: string;
    notes?: string;
  };
  widthMm?: number;
  heightMm?: number;
  currency?: string;
  qrValue: string;
  printed: boolean;
  printCount?: number;
};

type Branding = { businessName?: string; instagram?: string; website?: string };

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
  ctx.fill();
}

/** Render a label to an offscreen canvas at printer DPI and return it */
async function renderLabelToCanvas(
  label: LabelData,
  currency: string,
  cal: { widthMm: number; heightMm: number; scaleX: number; scaleY: number; showBorder?: boolean },
  template: LabelTemplate = LABEL_TEMPLATES[0],
  branding: Branding = {}
): Promise<HTMLCanvasElement> {
  // Render at 203 DPI using the printer's calibrated label dimensions — exactly
  // the same way the test print is built, so output matches perfectly on the roll.
  const LABEL_DPI = 203;
  const wMm = cal.widthMm;
  const hMm = cal.heightMm;
  const wPx = Math.round((wMm / MM_PER_INCH) * LABEL_DPI * cal.scaleX);
  const hPx = Math.round((hMm / MM_PER_INCH) * LABEL_DPI * cal.scaleY);

  const canvas = document.createElement("canvas");
  canvas.width  = wPx;
  canvas.height = hPx;
  const ctx = canvas.getContext("2d")!;

  // ── Pure white background ──────────────────────────────────
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, wPx, hPx);

  // ── Dotted cut-guide border — dashed so user knows where to cut ──────
  const scale  = hPx / 122;           // reference height 122 px at 203 dpi 32mm
  const BORDER = Math.max(2, Math.round(2 * scale));
  if (cal.showBorder !== false) {
    ctx.strokeStyle = "#000000";
    ctx.lineWidth   = BORDER;
    // Dash pattern: 6px on, 4px off — clearly visible on thermal print
    const dashLen = Math.max(4, Math.round(5 * scale));
    const gapLen  = Math.max(3, Math.round(3.5 * scale));
    ctx.setLineDash([dashLen, gapLen]);
    ctx.strokeRect(BORDER / 2, BORDER / 2, wPx - BORDER, hPx - BORDER);
    ctx.setLineDash([]);
  }

  ctx.textBaseline = "top";
  // Padding is inside the border
  const PAD   = Math.round(5 * scale);
  // Light, clean font stack — no Arial Black, uses thin/regular weights for clarity
  const FONT  = `"Helvetica Neue", Helvetica, Arial, sans-serif`;

  // Helper: truncate text to maxW pixels
  const trunc = (text: string, maxW: number) => truncateText(ctx, text, maxW);

  // Helper: shrink font size until text fits within maxW, returns the font size used
  function fitFontSize(text: string, baseFontSize: number, minFontSize: number, maxW: number, weight = "700"): number {
    let fs = baseFontSize;
    while (fs > minFontSize) {
      ctx.font = `${weight} ${fs}px ${FONT}`;
      if (ctx.measureText(text).width <= maxW) return fs;
      fs -= 1;
    }
    return minFontSize;
  }

  // Simple fill-only text — no stroke, no bold double-pass
  function drawText(text: string, x: number, y: number) {
    ctx.fillText(text, x, y);
  }

  // ── Font sizes — scaled for thermal legibility at 56×35mm ─
  const NAME_FS   = Math.round(17   * scale);   // card name — primary, big
  const NAME2_FS  = Math.round(13.5 * scale);   // card name line 2
  const GAME_FS   = Math.round(9    * scale);   // game / set
  const COND_FS   = Math.round(9.5  * scale);   // condition text
  const META_FS   = Math.round(7.5  * scale);   // small meta (rarity, lang)
  const PRICE_FS  = Math.round(18   * scale);   // price
  const BRAND_FS  = Math.round(5.5  * scale);   // branding instagram/website
  const CHIP_FS   = Math.round(5.5  * scale);   // "VENDOR QR" chip text
  const SM_GAP    = Math.round(2    * scale);   // small gap
  const MED_GAP   = Math.round(3    * scale);   // medium gap

  // ── Watermark dimensions — computed up-front so zones can reserve it ──
  const WM_FS     = Math.round(4.2 * scale);
  const WM_TEXT   = "Generated By: DatCARDVault";
  // Total height the watermark strip needs (text height + gap to border)
  const WM_ZONE_H = WM_FS + Math.round(4 * scale);

  // ─── MINIMAL ──────────────────────────────────────────────────────
  if (template.style === "minimal") {
    // Slightly larger QR on minimal
    const qrSize = Math.round(hPx * 0.60);
    const qrUrl = await QRCode.toDataURL(label.qrValue, {
      width: qrSize, margin: 1, errorCorrectionLevel: "H",
      color: { dark: "#000000", light: "#ffffff" },
    });
    const qrY = Math.round((hPx - qrSize) / 2);
    ctx.drawImage(await loadImage(qrUrl), PAD, qrY, qrSize, qrSize);

    // "VENDOR ONLY" — small text centred above QR on minimal
    const vendorMinFs = Math.round(4 * scale);
    ctx.font = `700 ${vendorMinFs}px ${FONT}`;
    ctx.fillStyle = "#000000";
    ctx.textAlign = "center";
    const voX = PAD + Math.round(qrSize / 2);
    const voY = qrY - SM_GAP - vendorMinFs;
    ctx.fillText("VENDOR ONLY", voX, voY);
    ctx.textAlign = "left";

    // Business name under QR on minimal
    if (branding.businessName) {
      const bnFs = Math.round(5 * scale);
      ctx.font = `700 ${bnFs}px ${FONT}`;
      ctx.fillStyle = "#000000";
      ctx.textAlign = "center";
      const bnX = PAD + Math.round(qrSize / 2);
      const bnY = qrY + qrSize + SM_GAP + bnFs;
      ctx.fillText(trunc(branding.businessName, qrSize), bnX, bnY);
      ctx.textAlign = "left";
    }

    const tx = PAD + qrSize + MED_GAP;
    const tw = wPx - tx - PAD;
    let ry = PAD + SM_GAP;

    // Name — auto-scale to fit
    ctx.fillStyle = "#000000";
    const nameFs = fitFontSize(label.labelData.cardName, NAME_FS, Math.round(NAME_FS * 0.55), tw);
    ctx.font = `700 ${nameFs}px ${FONT}`;
    if (ctx.measureText(label.labelData.cardName).width <= tw) {
      drawText(label.labelData.cardName, tx, ry);
      ry += nameFs + SM_GAP;
    } else {
      const words = label.labelData.cardName.split(" ");
      let best = 1;
      for (let i = 1; i < words.length; i++) {
        if (ctx.measureText(words.slice(0, i).join(" ")).width <= tw &&
            ctx.measureText(words.slice(i).join(" ")).width <= tw) best = i;
      }
      drawText(trunc(words.slice(0, best).join(" "), tw), tx, ry); ry += nameFs + 1;
      const name2Fs = Math.round(nameFs * 0.8);
      ctx.font = `700 ${name2Fs}px ${FONT}`;
      drawText(trunc(words.slice(best).join(" "), tw), tx, ry); ry += name2Fs + SM_GAP;
    }

    // Condition
    ctx.font = `700 ${COND_FS}px ${FONT}`;
    ctx.fillStyle = "#000000";
    drawText(trunc(label.labelData.condition, tw), tx, ry);
    ry += COND_FS + SM_GAP;

    // Set / Set Number
    if (label.labelData.set || label.labelData.cardNumber) {
      const setLine = [label.labelData.set, label.labelData.cardNumber ?? ""].filter(Boolean).join(" ");
      ctx.font = `700 ${META_FS}px ${FONT}`;
      ctx.fillStyle = "#000000";
      drawText(trunc(setLine, tw), tx, ry);
    }

    // Price — auto-scale to fit, sits above the watermark zone
    if (label.labelData.price !== undefined) {
      const priceText = formatCurrency(label.labelData.price, label.currency ?? currency);
      const priceFs = fitFontSize(priceText, PRICE_FS, Math.round(PRICE_FS * 0.5), tw);
      const py = hPx - BORDER - WM_ZONE_H - priceFs - SM_GAP;
      ctx.font = `700 ${priceFs}px ${FONT}`;
      ctx.fillStyle = "#000000";
      drawText(priceText, tx, py);
    }
    // Watermark — bottom-right, own dedicated strip above border
    ctx.font = `700 ${WM_FS}px ${FONT}`;
    ctx.fillStyle = "#000000";
    const wmW0 = ctx.measureText(WM_TEXT).width;
    ctx.fillText(WM_TEXT, wPx - wmW0 - PAD - BORDER, hPx - BORDER - WM_ZONE_H + Math.round(1.5 * scale));
    return canvas;
  }

  // ─── NON-MINIMAL: LEFT COLUMN LAYOUT ──────────────────────────────

  // Branding lines below QR
  type BrandLine = { text: string; fs: number; bold: boolean };
  const brandLines: BrandLine[] = [];
  if (branding.businessName) brandLines.push({ text: branding.businessName, fs: Math.round(5.5 * scale), bold: false });
  if (branding.instagram)    brandLines.push({ text: `@${branding.instagram.replace(/^@/, "")}`, fs: BRAND_FS, bold: false });
  if (branding.website)      brandLines.push({ text: branding.website.replace(/^https?:\/\//, ""), fs: Math.round(4.5 * scale), bold: false });

  // "QR FOR VENDOR USE ONLY" — small plain text centred above QR on all labels
  const VENDOR_FS = Math.round(4.5 * scale);   // small, unobtrusive
  ctx.font = `700 ${VENDOR_FS}px ${FONT}`;
  const chipPadX = Math.round(4.5 * scale);
  const chipPadY = Math.round(2.5 * scale);
  const chipW = Math.min(
    Math.round(ctx.measureText("QR FOR VENDOR USE ONLY").width) + chipPadX * 2,
    Math.round(hPx * 0.65),
  );
  const chipH = VENDOR_FS + chipPadY * 2;

  const belowH = brandLines.length > 0
    ? brandLines.reduce((s, l) => s + l.fs + SM_GAP, SM_GAP)
    : 0;
  const aboveH = chipH + SM_GAP;
  // QR gets as much space as possible between chip above and branding below
  const availQr = hPx - (PAD + BORDER) * 2 - aboveH - belowH - SM_GAP;
  const qrSize  = Math.max(
    Math.round(hPx * 0.38),
    Math.min(availQr, Math.round(hPx * 0.56)),
  );

  const blockH = aboveH + qrSize + (belowH > 0 ? belowH : 0);
  const blockY = Math.max(PAD + BORDER, Math.round((hPx - blockH) / 2));
  const qrDrawY = blockY + aboveH;
  const leftCX  = PAD + BORDER + Math.round(qrSize / 2);

  // Draw QR — black modules on white background
  const qrUrl = await QRCode.toDataURL(label.qrValue, {
    width: qrSize, margin: 1, errorCorrectionLevel: "H",
    color: { dark: "#000000", light: "#ffffff" },
  });
  ctx.drawImage(await loadImage(qrUrl), PAD + BORDER, qrDrawY, qrSize, qrSize);

  // "QR FOR VENDOR USE ONLY" — small plain text, no background box, centred above QR
  const chipX = PAD + BORDER + Math.round((qrSize - chipW) / 2);
  ctx.fillStyle = "#000000";
  ctx.font = `700 ${VENDOR_FS}px ${FONT}`;
  ctx.textAlign = "center";
  drawText("QR FOR VENDOR USE ONLY", chipX + Math.round(chipW / 2), blockY + chipPadY);

  // Branding lines below QR — centred on left column
  if (brandLines.length > 0) {
    let by = qrDrawY + qrSize + SM_GAP;
    ctx.fillStyle = "#000000";
    for (const line of brandLines) {
      ctx.font = `700 ${line.fs}px ${FONT}`;
      ctx.textAlign = "center";
      drawText(trunc(line.text, qrSize), leftCX, by);
      by += line.fs + SM_GAP;
    }
  }
  ctx.textAlign = "left";

  // ── Column divider ─────────────────────────────────────────
  const COL_GAP = Math.round(8 * scale);  // tighter gap: more space for text
  const divX    = PAD + BORDER + qrSize + Math.round(COL_GAP / 2);
  ctx.strokeStyle = "#000000";
  ctx.lineWidth   = Math.max(2, Math.round(1.2 * scale));
  ctx.beginPath();
  ctx.moveTo(divX, PAD + BORDER + 2);
  ctx.lineTo(divX, hPx - PAD - BORDER - 2);
  ctx.stroke();

  // ─── RIGHT COLUMN GEOMETRY ────────────────────────────────────────
  const tx = PAD + BORDER + qrSize + COL_GAP;
  const tw = wPx - tx - PAD - BORDER;

  // Pre-calc name height
  ctx.font = `700 ${NAME_FS}px ${FONT}`;
  const nameOneLine = ctx.measureText(label.labelData.cardName).width <= tw;
  const nameH = nameOneLine
    ? NAME_FS + SM_GAP
    : NAME_FS + 1 + NAME2_FS + SM_GAP;

  // Game row height
  const gameRowH = GAME_FS + SM_GAP + Math.max(2, Math.round(1.5 * scale)) + SM_GAP;

  // Price zone from bottom — price sits ABOVE the watermark strip
  // bottom of label: BORDER | WM_ZONE_H | SM_GAP | PRICE_FS | ruleH | priceZoneTop ...
  const ruleH        = Math.max(3, Math.round(2.5 * scale));
  const priceZoneH   = WM_ZONE_H + SM_GAP + PRICE_FS + ruleH + SM_GAP;
  const priceZoneTop = hPx - priceZoneH - BORDER;

  // Condition chip height
  ctx.font = `600 ${COND_FS}px ${FONT}`;
  const condChipH = Math.round(COND_FS * 1.9) + SM_GAP;

  const metaLineH   = META_FS + SM_GAP;
  let y = PAD + BORDER + SM_GAP;

  const topAfterHeader = y + nameH + gameRowH;
  const middleAvail    = priceZoneTop - PAD - topAfterHeader - condChipH;
  const maxMeta        = Math.max(0, Math.floor(middleAvail / metaLineH));

  // ─── RIGHT COLUMN DRAW HELPERS ────────────────────────────────────

  function drawName(name: string) {
    ctx.fillStyle = "#000000";
    const nameFs = fitFontSize(name, NAME_FS, Math.round(NAME_FS * 0.55), tw);
    ctx.font = `700 ${nameFs}px ${FONT}`;
    if (ctx.measureText(name).width <= tw) {
      drawText(name, tx, y);
      y += nameFs + SM_GAP;
    } else {
      const words = name.split(" ");
      let best = 1;
      for (let i = 1; i < words.length; i++) {
        if (ctx.measureText(words.slice(0, i).join(" ")).width <= tw &&
            ctx.measureText(words.slice(i).join(" ")).width <= tw) best = i;
      }
      drawText(trunc(words.slice(0, best).join(" "), tw), tx, y); y += nameFs + 1;
      const name2Fs = Math.round(nameFs * 0.8);
      ctx.font = `700 ${name2Fs}px ${FONT}`;
      drawText(trunc(words.slice(best).join(" "), tw), tx, y); y += name2Fs + SM_GAP;
    }
  }

  function drawGame(game: string) {
    ctx.font = `700 ${GAME_FS}px ${FONT}`;
    ctx.fillStyle = "#000000";
    drawText(trunc(game, tw), tx, y);
    y += GAME_FS + SM_GAP;
    // Separator rule below game
    const rW = Math.max(1, Math.round(1 * scale));
    ctx.fillStyle = "#000000";
    ctx.fillRect(tx, y, tw, rW);
    y += rW + SM_GAP;
  }

  function drawCondition(condition: string) {
    const pH  = Math.round(COND_FS * 1.9);
    const topPad = Math.round(COND_FS * 0.35);
    ctx.font = `700 ${COND_FS}px ${FONT}`;
    ctx.fillStyle = "#000000";
    drawText(trunc(condition, tw), tx, y + topPad);
    y += pH + SM_GAP;
  }

  let metaDrawn = 0;
  function drawMeta(text: string) {
    if (metaDrawn >= maxMeta) return;
    ctx.font = `700 ${META_FS}px ${FONT}`;
    ctx.fillStyle = "#000000";
    drawText(trunc(text, tw), tx, y);
    y += META_FS + SM_GAP;
    metaDrawn++;
  }

  function drawPrice(price: number, curr: string) {
    const ruleY = priceZoneTop;
    ctx.fillStyle = "#000000";
    ctx.fillRect(tx, ruleY, Math.round(tw * 0.65), Math.max(1, Math.round(1 * scale)));
    const py = ruleY + Math.max(1, Math.round(1 * scale)) + SM_GAP;
    const priceText = formatCurrency(price, curr);
    const priceFs = fitFontSize(priceText, PRICE_FS, Math.round(PRICE_FS * 0.5), tw);
    ctx.font = `700 ${priceFs}px ${FONT}`;
    ctx.fillStyle = "#000000";
    drawText(priceText, tx, py);
  }

  // ─── TEMPLATE RENDER ──────────────────────────────────────────────

  if (template.style === "graded") {
    drawName(label.labelData.cardName);
    drawGame(label.labelData.game);
    if (label.labelData.grade) {
      const baseBFs = Math.round(10 * scale);
      const gradeText = label.labelData.grade;
      const bFs = fitFontSize(gradeText, baseBFs, Math.round(baseBFs * 0.6), tw);
      ctx.font   = `700 ${bFs}px ${FONT}`;
      ctx.fillStyle = "#000000";
      drawText(gradeText, tx, y);
      y += Math.round(bFs * 1.75) + SM_GAP;
    }
    drawCondition(label.labelData.condition);
    if (label.labelData.price !== undefined) drawPrice(label.labelData.price, label.currency ?? currency);

  } else {
    // Standard
    drawName(label.labelData.cardName);
    drawGame(label.labelData.game);
    // Always show set + set number on standard
    if (label.labelData.set || label.labelData.cardNumber) {
      const setLine = [label.labelData.set, label.labelData.cardNumber ?? ""].filter(Boolean).join(" ");
      ctx.font = `700 ${META_FS}px ${FONT}`;
      ctx.fillStyle = "#000000";
      drawText(trunc(setLine, tw), tx, y);
      y += META_FS + SM_GAP;
    }
    drawCondition(label.labelData.condition);
    if (label.labelData.rarity)   drawMeta(label.labelData.rarity);
    if (label.labelData.language) drawMeta(label.labelData.language);
    if (label.labelData.price !== undefined) drawPrice(label.labelData.price, label.currency ?? currency);
  }

  // ── Watermark — bottom-right, in its own reserved strip ─────
  ctx.font      = `700 ${WM_FS}px ${FONT}`;
  ctx.fillStyle = "#000000";
  const wmW    = ctx.measureText(WM_TEXT).width;
  const wmY    = hPx - BORDER - WM_ZONE_H + Math.round(1.5 * scale);
  ctx.fillText(WM_TEXT, wPx - wmW - PAD - BORDER, wmY);

  return canvas;
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

function truncateText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string {
  if (ctx.measureText(text).width <= maxWidth) return text;
  let t = text;
  while (t.length > 1 && ctx.measureText(t + "…").width > maxWidth) t = t.slice(0, -1);
  return t + "…";
}

export default function LabelsPage() {
  const navigate = useNavigate();
  const user = useQuery(api.users.getCurrentUser, {});
  const currency = user?.currency ?? "GBP";
  const branding: Branding = {
    businessName: user?.businessName,
    instagram: user?.instagram,
    website: user?.website,
  };

  const { results: labels, status, loadMore } = usePaginatedQuery(
    api.labels.getLabelsWithCardStatus, {}, { initialNumItems: 20 }
  );

  const updateLabel = useMutation(api.labels.updateLabel);
  const recordPrint = useMutation(api.labels.recordPrint);
  const deleteLabelMut = useMutation(api.labels.deleteLabel);

  const bt = useBtPrinterContext();

  const [selected, setSelected] = useState<Set<Id<"labels">>>(new Set());
  const [activeTemplate, setActiveTemplate] = useState<LabelTemplate>(LABEL_TEMPLATES[0]);
  const [editLabel, setEditLabel] = useState<LabelData | null>(null);
  const [savedEdit, setSavedEdit] = useState(false);
  const [editForm, setEditForm] = useState<{
    cardName: string; game: string; set: string; condition: string;
    grade: string; price: string; rarity: string; language: string;
    widthMm: number; heightMm: number; customW: string; customH: string;
  } | null>(null);
  const [sizeMode, setSizeMode] = useState<string>("24mm × 42mm (Default)");
  const [printCopies, setPrintCopies] = useState(1);
  const [showPrintDialog, setShowPrintDialog] = useState(false);
  const [printMinimized, setPrintMinimized] = useState(false);
  const [printingLabels, setPrintingLabels] = useState<LabelData[]>([]);
  const abortRef = useRef(false);
  const [printing, setPrinting] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<Id<"labels"> | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [qrDataUrls, setQrDataUrls] = useState<Record<string, string>>({});
  const templatePreviewRef = useRef<HTMLCanvasElement>(null);

  const previewCanvasRef = useRef<HTMLCanvasElement>(null);

  // Generate QR preview thumbnails
  useEffect(() => {
    if (!labels) return;
    const toGenerate = labels.filter(l => !qrDataUrls[l._id]);
    if (!toGenerate.length) return;
    toGenerate.forEach(async (label) => {
      try {
        const url = await QRCode.toDataURL(label.qrValue, { width: 200, margin: 0, color: { dark: "#000000", light: "#ffffff" } });
        setQrDataUrls(prev => ({ ...prev, [label._id]: url }));
      } catch { /* ignore */ }
    });
  }, [labels]);

  // Render template preview — uses the first selected label's real data, or sample data if none selected
  useEffect(() => {
    // Find the first selected label (in list order) if any
    const firstSelectedId = labels
      ? [...selected].find(id => labels.some(l => l._id === id))
      : undefined;
    const firstSelected = firstSelectedId
      ? (labels?.find(l => l._id === firstSelectedId) as LabelData | undefined)
      : undefined;

    const previewLabel: LabelData = firstSelected ?? {
      _id: "sample" as Id<"labels">,
      cardId: "sample" as Id<"cards">,
      labelData: {
        cardName: "Charizard VMAX",
        game: "Pokémon",
        set: "Darkness Ablaze",
        cardNumber: "020",
        condition: "Mint",
        grade: activeTemplate.style === "graded" ? "PSA 10" : undefined,
        price: 74.99,
        rarity: "Rare Holo",
        language: "English",
      },
      widthMm: LABEL_W_MM,
      heightMm: LABEL_H_MM,
      currency,
      qrValue: "dcv:sample-card-preview",
      printed: false,
    };

    // Use saved branding or fall back to sample values so the preview always shows branding
    const previewBranding: Branding = {
      businessName: branding.businessName || "Your Store Name",
      instagram: branding.instagram || "yourstoreig",
      website: branding.website || "yourstore.com",
    };
    renderLabelToCanvas(previewLabel, currency, bt.cal, activeTemplate, previewBranding).then(src => {
      const dst = templatePreviewRef.current;
      if (!dst) return;
      dst.width = src.width;
      dst.height = src.height;
      dst.getContext("2d")!.drawImage(src, 0, 0);
    }).catch(() => { /* ignore */ });
  }, [activeTemplate, currency, bt.cal, branding.businessName, branding.instagram, branding.website, user, selected, labels]);


  useEffect(() => {
    if (!showPrintDialog || !previewCanvasRef.current) return;
    const effectiveLabels: LabelData[] = printingLabels;
    if (!effectiveLabels.length) return;
    (async () => {
      try {
        const labelCanvases = await Promise.all(
          effectiveLabels.map(l => renderLabelToCanvas(l, currency, bt.cal, activeTemplate, branding))
        );
        const source = labelCanvases[0];
        const dst = previewCanvasRef.current;
        if (!dst) return;
        // Render at 2× for crisp HD preview on retina/high-DPI screens
        const dpr = Math.max(window.devicePixelRatio ?? 1, 2);
        dst.width  = source.width  * dpr;
        dst.height = source.height * dpr;
        const dctx = dst.getContext("2d")!;
        dctx.imageSmoothingEnabled = true;
        dctx.imageSmoothingQuality = "high";
        dctx.scale(dpr, dpr);
        dctx.drawImage(source, 0, 0, source.width, source.height);
      } catch { /* ignore */ }
    })();
  }, [showPrintDialog, printingLabels, currency, bt.cal, activeTemplate, branding]);

  const toggleSelect = (id: Id<"labels">) => {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) { next.delete(id); } else { next.add(id); }
      return next;
    });
  };

  const openEdit = (label: LabelData) => {
    setEditLabel(label);
    const w = label.widthMm ?? 52;
    const h = label.heightMm ?? 32;
    const preset = LABEL_SIZES.find(s => s.w === w && s.h === h);
    setSizeMode(preset?.label ?? "Custom");
    setEditForm({
      cardName: label.labelData.cardName,
      game: label.labelData.game,
      set: label.labelData.set ?? "",
      condition: label.labelData.condition,
      grade: label.labelData.grade ?? "",
      price: label.labelData.price?.toString() ?? "",
      rarity: label.labelData.rarity ?? "",
      language: label.labelData.language ?? "",
      widthMm: w, heightMm: h,
      customW: w.toString(), customH: h.toString(),
    });
  };

  const handleSaveEdit = async () => {
    if (!editLabel || !editForm) return;
    try {
      await updateLabel({
        id: editLabel._id,
        labelData: {
          cardName: editForm.cardName, game: editForm.game,
          set: editForm.set || undefined, condition: editForm.condition,
          grade: editForm.grade || undefined,
          price: editForm.price ? parseFloat(editForm.price) : undefined,
          rarity: editForm.rarity || undefined,
          language: editForm.language || undefined,
        },
        widthMm: editForm.widthMm, heightMm: editForm.heightMm, currency,
      });
      setSavedEdit(true);
      setTimeout(() => { setSavedEdit(false); setEditLabel(null); }, 400);
    } catch {
      // failed to update label
    }
  };

  const handleDeleteLabel = async () => {
    if (!deleteConfirmId) return;
    setDeleting(true);
    try {
      await deleteLabelMut({ id: deleteConfirmId });
      toast.success("Label deleted");
      setDeleteConfirmId(null);
    } catch (e) {
      if (e instanceof ConvexError) {
        const { message } = e.data as { message: string };
        toast.error(message);
      } else {
        toast.error("Failed to delete label");
      }
    } finally {
      setDeleting(false);
    }
  };

  const openPrintDialog = async (labelsArr: LabelData[]) => {
    setPrintingLabels(labelsArr);
    setPrintCopies(1);
    setPrintMinimized(false);
    setShowPrintDialog(true);
  };

  const handlePrintSelected = () => {
    const sel = labels?.filter(l => selected.has(l._id)) ?? [];
    if (!sel.length) return;
    handlePrintAction(sel as LabelData[]);
  };

  const executePrint = async () => {
    if (!bt.connected) return;
    if (!printingLabels.length) return;

    abortRef.current = false;
    setPrinting(true);
    try {
      const labelCanvases = await Promise.all(
        printingLabels.map(l => renderLabelToCanvas(l, currency, bt.cal, activeTemplate, branding))
      );

      // Send all labels in one ESC/POS job — single INIT, no printer reset between them.
      // Labels stack continuously on the roll, exactly like the test print.
      await bt.printLabelCanvasBatch(labelCanvases, printCopies);

      if (!abortRef.current) {
        await Promise.all(printingLabels.map(l => recordPrint({ id: l._id, copies: printCopies })));
        setShowPrintDialog(false);
        setSelected(new Set());
      }
    } catch {
      // print failed
    } finally {
      abortRef.current = false;
      setPrinting(false);
    }
  };

  const stopPrint = () => { abortRef.current = true; bt.stopPrint(); };

  // ── iOS Label Image Export ──────────────────────────────────────────────
  const [showIOSExport, setShowIOSExport] = useState(false);
  const [iosExportLabels, setIOSExportLabels] = useState<LabelData[]>([]);
  const [iosExporting, setIOSExporting] = useState(false);

  const openIOSExport = (labelsArr: LabelData[]) => {
    // Cap at 10 labels
    setIOSExportLabels(labelsArr.slice(0, 10));
    setShowIOSExport(true);
  };

  const executeIOSExport = async () => {
    if (!iosExportLabels.length) return;
    setIOSExporting(true);
    try {
      // Render all labels at 2x for high-res print quality
      const canvases = await Promise.all(
        iosExportLabels.map(l => renderLabelToCanvas(l, currency, bt.cal, activeTemplate, branding))
      );

      // Convert each canvas to a PNG blob
      const files: File[] = [];
      for (let i = 0; i < canvases.length; i++) {
        const blob = await new Promise<Blob>((resolve, reject) => {
          canvases[i].toBlob(b => b ? resolve(b) : reject(new Error("Canvas to blob failed")), "image/png");
        });
        const cardName = iosExportLabels[i].labelData.cardName.replace(/[^a-zA-Z0-9]/g, "_").slice(0, 30);
        files.push(new File([blob], `DatCARDVault_Label_${cardName}_${i + 1}.png`, { type: "image/png" }));
      }

      // Try Web Share API first (native iOS share sheet)
      if (typeof navigator !== "undefined" && navigator.share && navigator.canShare?.({ files })) {
        await navigator.share({
          title: `DatCARDVault Label${files.length > 1 ? "s" : ""}`,
          text: `${files.length} label image${files.length > 1 ? "s" : ""} — print via MarkLife Label app`,
          files,
        });
        toast.success(`${files.length} label${files.length > 1 ? "s" : ""} shared!`);
      } else {
        // Fallback: download each file
        for (const file of files) {
          const url = URL.createObjectURL(file);
          const a = document.createElement("a");
          a.href = url;
          a.download = file.name;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
        }
        toast.success(`${files.length} label${files.length > 1 ? "s" : ""} downloaded!`);
      }

      // Record prints
      await Promise.all(iosExportLabels.map(l => recordPrint({ id: l._id, copies: 1 })));
      setShowIOSExport(false);
      setSelected(new Set());
    } catch (e) {
      const msg = (e as Error).message ?? "";
      // User cancelled the share sheet — not an error
      if (!msg.includes("abort") && !msg.includes("cancel")) {
        toast.error("Export failed: " + msg);
      }
    } finally {
      setIOSExporting(false);
    }
  };

  // ── WiFi Print (browser print dialog) ──────────────────────────────────
  const [showWifiPrintDialog, setShowWifiPrintDialog] = useState(false);
  const [wifiPrintLabels, setWifiPrintLabels] = useState<LabelData[]>([]);
  const [wifiPrinting, setWifiPrinting] = useState(false);

  const openWifiPrint = (labelsArr: LabelData[]) => {
    setWifiPrintLabels(labelsArr.slice(0, 20));
    setShowWifiPrintDialog(true);
  };

  const executeWifiPrint = async () => {
    if (!wifiPrintLabels.length) return;
    setWifiPrinting(true);
    try {
      // Render all labels to canvas
      const canvases = await Promise.all(
        wifiPrintLabels.map(l => renderLabelToCanvas(l, currency, bt.cal, activeTemplate, branding))
      );

      // Convert canvases to data URLs
      const dataUrls = canvases.map(c => c.toDataURL("image/png"));

      // Open print window with label images
      const printWindow = window.open("", "_blank", "width=800,height=600");
      if (!printWindow) {
        toast.error("Popup blocked — please allow popups for this site");
        setWifiPrinting(false);
        return;
      }

      const labelW = wifiPrintLabels[0]?.widthMm ?? 52;
      const labelH = wifiPrintLabels[0]?.heightMm ?? 32;

      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>DatCARDVault - WiFi Print Labels</title>
          <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { background: #fff; font-family: system-ui, sans-serif; }
            @media screen {
              body { padding: 20px; }
              .print-header { text-align: center; margin-bottom: 20px; }
              .print-header h1 { font-size: 18px; color: #333; }
              .print-header p { font-size: 12px; color: #666; margin-top: 4px; }
              .print-hint { text-align: center; padding: 12px; background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 8px; margin-bottom: 20px; font-size: 12px; color: #0369a1; }
              .labels-grid { display: flex; flex-wrap: wrap; gap: 12px; justify-content: center; }
              .label-item { border: 1px solid #e5e7eb; border-radius: 4px; padding: 4px; }
              .label-item img { display: block; height: auto; }
            }
            @media print {
              .print-header, .print-hint { display: none !important; }
              .labels-grid { display: block; }
              .label-item { border: none; padding: 0; margin: 0; page-break-inside: avoid; margin-bottom: 2mm; }
              .label-item img { width: ${labelW}mm; height: ${labelH}mm; display: block; }
            }
          </style>
        </head>
        <body>
          <div class="print-header">
            <h1>DatCARDVault\u2122 Labels</h1>
            <p>${dataUrls.length} label${dataUrls.length > 1 ? "s" : ""} ready to print</p>
          </div>
          <div class="print-hint">
            Select your WiFi printer from the print dialog. For best results, set margins to "None" and scale to 100%.
          </div>
          <div class="labels-grid">
            ${dataUrls.map((url, i) => `<div class="label-item"><img src="${url}" alt="Label ${i + 1}" style="width:${labelW * 3}px;" /></div>`).join("")}
          </div>
          <script>
            window.onload = function() {
              setTimeout(function() { window.print(); }, 300);
              window.onafterprint = function() { window.close(); };
            };
          </script>
        </body>
        </html>
      `);
      printWindow.document.close();

      // Record prints
      await Promise.all(wifiPrintLabels.map(l => recordPrint({ id: l._id, copies: 1 })));
      toast.success(`${wifiPrintLabels.length} label${wifiPrintLabels.length > 1 ? "s" : ""} sent to WiFi print`);
      setShowWifiPrintDialog(false);
      setSelected(new Set());
    } catch (e) {
      const msg = (e as Error).message ?? "Unknown error";
      toast.error("WiFi print failed: " + msg);
    } finally {
      setWifiPrinting(false);
    }
  };

  // Route print action: iOS goes to export, everything else goes to BT print dialog
  const handlePrintAction = (labelsArr: LabelData[]) => {
    if (bt.isIOS) {
      openIOSExport(labelsArr);
    } else {
      openPrintDialog(labelsArr);
    }
  };

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between gap-2">
        <h1 className="text-3xl font-sans text-primary tracking-widest">Labels</h1>
        <div className="flex gap-2 shrink-0">
          {selected.size > 0 && (
            <>
              <Button onClick={() => openWifiPrint((labels?.filter(l => selected.has(l._id)) ?? []) as LabelData[])} variant="secondary" className="gap-1.5 h-9 px-3 text-sm">
                <Wifi className="h-4 w-4" />
                WiFi ({selected.size})
              </Button>
              <Button onClick={handlePrintSelected} className="gap-1.5 h-9 px-3 text-sm">
                {bt.isIOS ? <Download className="h-4 w-4" /> : <Printer className="h-4 w-4" />}
                {bt.isIOS ? `Export (${selected.size})` : `Print (${selected.size})`}
              </Button>
            </>
          )}
        </div>
      </div>

      {/* Template picker + live preview */}
      <div className="space-y-3">
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Label Template</p>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {LABEL_TEMPLATES.map(t => (
            <button
              key={t.id}
              onClick={() => setActiveTemplate(t)}
              className={`flex-shrink-0 flex flex-col gap-0.5 px-3 py-2 rounded-xl border text-left cursor-pointer transition-all ${
                activeTemplate.id === t.id
                  ? "border-primary bg-primary/10"
                  : "border-border bg-secondary hover:border-primary/40"
              }`}
            >
              <span className="text-xs font-bold whitespace-nowrap">{t.name}</span>
              <span className="text-[10px] text-muted-foreground max-w-[120px] leading-tight">{t.description}</span>
            </button>
          ))}
        </div>

        {/* Live canvas preview */}
        <div className="flex flex-col items-start gap-2 p-3 rounded-xl border border-border bg-secondary/50">
          <div className="flex items-center justify-between w-full">
            <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-widest">
              Preview — {activeTemplate.name}
            </span>
            {selected.size > 0 ? (
              <span className="text-[10px] text-primary font-semibold">
                {labels?.find(l => l._id === [...selected][0])?.labelData.cardName ?? "selected label"}
              </span>
            ) : (
              <span className="text-[10px] text-muted-foreground italic">sample data</span>
            )}
          </div>
          <div className="flex items-center justify-center w-full">
            <canvas
              ref={templatePreviewRef}
              className="rounded border border-border shadow-sm"
              style={{ maxWidth: "85%", height: "auto", imageRendering: "crisp-edges" }}
            />
          </div>
        </div>
      </div>

      {/* BT status banner — different UI for iOS vs Android/desktop */}
      {bt.isIOS ? (
        <div className="flex items-center justify-between gap-2 p-3 rounded-xl border border-blue-500/30 bg-blue-500/10">
          <div className="flex items-center gap-2 min-w-0">
            <Smartphone className="h-4 w-4 text-blue-400 shrink-0" />
            <div className="min-w-0">
              <span className="text-sm font-medium text-blue-400">iOS — Save Label Image</span>
              <p className="text-[10px] text-muted-foreground">Save labels as images, then print via MarkLife Label app</p>
            </div>
          </div>
          <span className="text-[10px] text-blue-400/70 font-medium shrink-0">Up to 10</span>
        </div>
      ) : (
        <div
          className={`flex items-center justify-between gap-2 p-3 rounded-xl border cursor-pointer transition-all ${
            bt.connected
              ? "bg-profit/10 border-profit/30"
              : "bg-secondary border-border hover:border-primary/40"
          }`}
          onClick={() => !bt.connected && navigate("/printer")}
        >
          <div className="flex items-center gap-2 min-w-0">
            {bt.connected
              ? <BluetoothConnected className="h-4 w-4 text-profit shrink-0" />
              : <BluetoothOff className="h-4 w-4 text-muted-foreground shrink-0" />}
            <span className="text-sm font-medium truncate">
              {bt.connected ? `Connected: ${bt.device?.name ?? "Bluetooth Printer"}` : "No Bluetooth printer connected"}
            </span>
          </div>
          {bt.connected ? (
            <Button variant="ghost" size="sm" className="text-xs gap-1 shrink-0" onClick={(e) => { e.stopPropagation(); bt.disconnect(); }}>
              <BluetoothOff className="h-3 w-3" /> Disconnect
            </Button>
          ) : (
            <span className="text-xs text-primary font-medium">Tap to connect →</span>
          )}
        </div>
      )}

      {/* Labels list */}
      {status === "LoadingFirstPage" ? (
        Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)
      ) : labels?.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <Tag className="h-12 w-12 mx-auto mb-3 opacity-30" />
          <p className="font-semibold">No labels yet</p>
          <p className="text-sm mt-1">Labels are auto-created when you add a card to inventory</p>
        </div>
      ) : (
        <div className="space-y-3">
          {labels?.map((label, i) => (
            <motion.div key={label._id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}>
              <Card
                className={`border-border cursor-pointer transition-all ${selected.has(label._id) ? "border-primary ring-1 ring-primary" : ""}`}
                onClick={() => toggleSelect(label._id)}
              >
                <CardContent className="p-3 sm:p-4">
                  <div className="flex items-start gap-3">
                    {/* QR thumbnail */}
                    <div className="w-14 h-14 sm:w-16 sm:h-16 bg-white rounded-lg overflow-hidden border border-border shrink-0 flex items-center justify-center">
                      {qrDataUrls[label._id]
                        ? <img src={qrDataUrls[label._id]} alt="QR" className="w-full h-full object-contain" />
                        : <QrCode className="h-7 w-7 text-muted-foreground" />}
                    </div>
                    {/* Info + actions */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <h3 className="font-bold text-sm truncate">{label.labelData.cardName}</h3>
                          <p className="text-xs text-muted-foreground truncate">{label.labelData.game}{label.labelData.set ? ` • ${label.labelData.set}` : ""}{label.labelData.cardNumber ? ` ${label.labelData.cardNumber}` : ""}</p>
                          <div className="flex flex-wrap gap-x-2 mt-1">
                            <span className="text-xs text-muted-foreground">{label.labelData.condition}</span>
                            {label.labelData.grade && <span className="text-xs text-amber-500 font-semibold">{label.labelData.grade}</span>}
                            {label.labelData.price !== undefined && (
                              <span className="text-xs font-bold text-primary">{formatCurrency(label.labelData.price, label.currency ?? currency)}</span>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            {label.widthMm ?? 52}×{label.heightMm ?? 32}mm
                            {label.printed ? ` · ×${label.printCount}` : ""}
                          </p>
                        </div>
                        {/* Action buttons — always right-aligned */}
                        <div className="flex gap-1 shrink-0">
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={e => { e.stopPropagation(); openEdit(label as LabelData); }}>
                            <Pencil className="h-3.5 w-3.5" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-400 hover:text-blue-300" onClick={e => { e.stopPropagation(); openWifiPrint([label as LabelData]); }} title="WiFi Print">
                            <Wifi className="h-3.5 w-3.5" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={e => { e.stopPropagation(); handlePrintAction([label as LabelData]); }}>
                            <Printer className="h-3.5 w-3.5" />
                          </Button>
                          {label.cardSold && (
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={e => { e.stopPropagation(); setDeleteConfirmId(label._id); }}>
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
          {status === "CanLoadMore" && (
            <Button variant="secondary" className="w-full gap-2" onClick={() => loadMore(20)}>
              <ChevronDown className="h-4 w-4" /> Load More
            </Button>
          )}
        </div>
      )}

      {/* Edit Label Dialog */}
      {editLabel && editForm && (
        <Dialog open={!!editLabel} onOpenChange={() => setEditLabel(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="font-sans text-primary">Edit Label</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <div className="space-y-1">
                <Label>Card Name</Label>
                <Input value={editForm.cardName} onChange={e => setEditForm(f => f ? { ...f, cardName: e.target.value } : f)} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>Condition</Label>
                  <Input value={editForm.condition} onChange={e => setEditForm(f => f ? { ...f, condition: e.target.value } : f)} />
                </div>
                <div className="space-y-1">
                  <Label>Grade</Label>
                  <Input value={editForm.grade} onChange={e => setEditForm(f => f ? { ...f, grade: e.target.value } : f)} />
                </div>
                <div className="space-y-1">
                  <Label>Price ({currency})</Label>
                  <Input type="number" value={editForm.price} onChange={e => setEditForm(f => f ? { ...f, price: e.target.value } : f)} />
                </div>
                <div className="space-y-1">
                  <Label>Rarity</Label>
                  <Input value={editForm.rarity} onChange={e => setEditForm(f => f ? { ...f, rarity: e.target.value } : f)} />
                </div>
              </div>
              <div className="space-y-1">
                <Label>Label Size</Label>
                <Select value={sizeMode} onValueChange={v => {
                  setSizeMode(v);
                  const preset = LABEL_SIZES.find(s => s.label === v);
                  if (preset && preset.w > 0) setEditForm(f => f ? { ...f, widthMm: preset.w, heightMm: preset.h } : f);
                }}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {LABEL_SIZES.map(s => <SelectItem key={s.label} value={s.label}>{s.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              {sizeMode === "Custom" && (
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label>Width (mm)</Label>
                    <Input type="number" value={editForm.customW} onChange={e => setEditForm(f => f ? { ...f, customW: e.target.value, widthMm: parseFloat(e.target.value) || 51 } : f)} />
                  </div>
                  <div className="space-y-1">
                    <Label>Height (mm)</Label>
                    <Input type="number" value={editForm.customH} onChange={e => setEditForm(f => f ? { ...f, customH: e.target.value, heightMm: parseFloat(e.target.value) || 28 } : f)} />
                  </div>
                </div>
              )}
            </div>
            <DialogFooter>
              <Button variant="secondary" onClick={() => setEditLabel(null)}>Cancel</Button>
              <Button onClick={handleSaveEdit} className={`transition-colors ${savedEdit ? "bg-profit hover:bg-profit text-white" : ""}`}>Save</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Delete Label Confirmation Dialog */}
      <Dialog open={!!deleteConfirmId} onOpenChange={o => { if (!o) setDeleteConfirmId(null); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive">
              <Trash2 className="h-4 w-4" /> Delete Label
            </DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Are you sure you want to delete this label? This cannot be undone.
          </p>
          <p className="text-xs text-muted-foreground leading-relaxed">
            If you unsell this card and move it back to inventory, you can regenerate a new label for it.
          </p>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setDeleteConfirmId(null)} disabled={deleting}>Cancel</Button>
            <Button variant="destructive" onClick={handleDeleteLabel} disabled={deleting}>
              {deleting ? "Deleting…" : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Print Panel — floating, minimizable */}
      {showPrintDialog && (
        <>
          {/* Minimized pill */}
          {printMinimized && (
            <div
              className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 px-4 py-2.5 rounded-full bg-background/80 backdrop-blur-md border border-border shadow-xl cursor-pointer"
              onClick={() => setPrintMinimized(false)}
            >
              {printing ? (
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse shrink-0" />
              ) : (
                <Printer className="h-3.5 w-3.5 text-primary shrink-0" />
              )}
              <span className="text-sm font-semibold whitespace-nowrap">
                {printing ? "Printing…" : "Print Ready"}
              </span>
              <span className="text-xs text-muted-foreground truncate max-w-[120px]">
                {printingLabels.length > 1 ? `${printingLabels.length} labels` : (printingLabels[0]?.labelData.cardName ?? "")}
              </span>
              <span className="text-xs text-primary font-bold ml-1">Tap to expand</span>
            </div>
          )}

          {/* Full panel */}
          {!printMinimized && (
            <div className="fixed inset-x-0 top-0 z-50 flex items-center justify-center p-4" style={{ bottom: "calc(96px + env(safe-area-inset-bottom, 0px))" }}>
              {/* Backdrop — full screen including nav area */}
              <div
                className="fixed inset-0 bg-black/60 backdrop-blur-sm"
                style={{ zIndex: -1 }}
                onClick={() => { if (!printing) setShowPrintDialog(false); }}
              />
              {/* On mobile: sit above the 64px nav bar + safe area */}
              <div
                className="relative w-full md:max-w-lg bg-background rounded-t-2xl md:rounded-2xl border border-border shadow-2xl flex flex-col"
                style={{
                  maxHeight: "calc(100dvh - 96px - env(safe-area-inset-bottom, 0px) - env(safe-area-inset-top, 0px))",
                }}
              >
                {/* Header */}
                <div className="flex items-center justify-between px-3 pt-3 pb-2 border-b border-border shrink-0">
                  <div className="flex items-center gap-1.5">
                    <Bluetooth className="h-3.5 w-3.5 text-primary" />
                    <span className="font-bold text-xs">Bluetooth Print</span>
                  </div>
                  <div className="flex items-center gap-1">
                    {!printing && (
                      <button
                        className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-secondary transition-colors cursor-pointer"
                        onClick={() => setPrintMinimized(true)}
                        title="Minimise"
                      >
                        <Minus className="h-3.5 w-3.5" />
                      </button>
                    )}
                    {!printing && (
                      <button
                        className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-secondary transition-colors cursor-pointer"
                        onClick={() => setShowPrintDialog(false)}
                      >
                        <X className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Scrollable body */}
                <div className="overflow-y-auto flex-1 space-y-2 p-3">
                  {/* Printer status */}
                  {bt.connected ? (
                    <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-profit/10 border border-profit/30">
                      <BluetoothConnected className="h-3.5 w-3.5 text-profit shrink-0" />
                      <span className="text-xs text-profit font-medium truncate">{bt.device?.name ?? "Bluetooth Printer"} — Ready</span>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-secondary border border-border">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="h-3.5 w-3.5 text-amber-500 shrink-0" />
                        <span className="text-xs font-medium">No printer connected</span>
                      </div>
                      <Button size="sm" className="gap-1 h-7 text-xs px-2" onClick={async () => {
                        try { await bt.connect(); } catch { /* connection failed */ }
                      }} disabled={bt.connecting}>
                        <Bluetooth className="h-3 w-3" />
                        {bt.connecting ? "Connecting…" : "Connect"}
                      </Button>
                    </div>
                  )}

                  {/* Label info */}
                  <div className="bg-secondary rounded-lg px-3 py-2 flex items-center gap-2">
                    <div className="min-w-0">
                      <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-semibold">Label</p>
                      <p className="text-xs font-semibold truncate">{printingLabels[0]?.labelData.cardName ?? "—"}</p>
                      {printingLabels.length > 1 && (
                        <p className="text-[10px] text-muted-foreground">{printingLabels.length} labels selected</p>
                      )}
                    </div>
                  </div>

                  {/* Quantity */}
                  <div className="flex items-center gap-3">
                    <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-widest shrink-0">Qty</p>
                    <div className="flex items-center bg-secondary rounded-lg overflow-hidden border border-border">
                      <button
                        className="w-8 h-8 flex items-center justify-center cursor-pointer hover:bg-primary/10 transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                        onClick={() => setPrintCopies(c => Math.max(1, c - 1))}
                        disabled={printCopies <= 1 || printing}
                      >
                        <Minus className="h-3 w-3" />
                      </button>
                      <span className="w-10 text-center font-black text-sm">{printCopies}</span>
                      <button
                        className="w-8 h-8 flex items-center justify-center cursor-pointer hover:bg-primary/10 transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                        onClick={() => setPrintCopies(c => Math.min(30, c + 1))}
                        disabled={printCopies >= 30 || printing}
                      >
                        <Plus className="h-3 w-3" />
                      </button>
                    </div>
                    <span className="text-xs text-muted-foreground">{printCopies} / 30</span>
                  </div>

                  {/* Label preview */}
                  <div className="space-y-1">
                    <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-widest">Preview</p>
                    <div className="bg-white rounded-lg flex justify-center items-center overflow-hidden" style={{ height: "110px" }}>
                      <canvas
                        ref={previewCanvasRef}
                        className="rounded shadow-sm"
                        style={{ maxWidth: "100%", maxHeight: "104px", width: "auto", height: "auto", imageRendering: "auto", display: "block" }}
                      />
                    </div>
                  </div>

                  {!bt.isAvailable && (
                    <div className="flex items-start gap-2 p-2 rounded-lg bg-amber-500/10 border border-amber-700/30 text-xs text-amber-500">
                      <AlertCircle className="h-3.5 w-3.5 shrink-0 mt-0.5" />
                      Chrome on Android/desktop only. Safari & Firefox not supported.
                    </div>
                  )}
                </div>

                {/* Footer */}
                <div className="flex gap-2 px-3 py-3 border-t border-border shrink-0">
                  {printing ? (
                    <>
                      <Button variant="destructive" size="sm" onClick={stopPrint} className="gap-1.5 flex-1">
                        Stop Printer
                      </Button>
                      <Button size="sm" disabled className="gap-1.5 flex-1">
                        <span className="animate-spin inline-block">⏳</span> Printing…
                      </Button>
                    </>
                  ) : (
                    <>
                      <Button variant="secondary" size="sm" onClick={() => setShowPrintDialog(false)} className="flex-1">Cancel</Button>
                      <Button size="sm" onClick={executePrint} disabled={!bt.connected} className="gap-1.5 flex-1">
                        <Printer className="h-3.5 w-3.5" /> Send to Printer
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* WiFi Print Dialog */}
      <Dialog open={showWifiPrintDialog} onOpenChange={o => { if (!wifiPrinting && !o) setShowWifiPrintDialog(false); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-blue-400">
              <Wifi className="h-4 w-4" /> WiFi Print
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="flex items-start gap-2 p-3 rounded-lg bg-blue-500/10 border border-blue-500/30">
              <Wifi className="h-4 w-4 text-blue-400 shrink-0 mt-0.5" />
              <div className="text-xs text-muted-foreground leading-relaxed">
                <p className="font-semibold text-blue-400 mb-1">Print via WiFi Printer</p>
                <p>This opens your device's print dialog where you can select any WiFi printer connected to your network. Works on Android, iOS, and desktop.</p>
              </div>
            </div>

            <div className="bg-secondary rounded-lg px-3 py-2 space-y-1">
              <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-semibold">
                {wifiPrintLabels.length} label{wifiPrintLabels.length > 1 ? "s" : ""} to print
              </p>
              {wifiPrintLabels.slice(0, 3).map(l => (
                <p key={l._id} className="text-xs font-semibold truncate">{l.labelData.cardName}</p>
              ))}
              {wifiPrintLabels.length > 3 && (
                <p className="text-[10px] text-muted-foreground">+{wifiPrintLabels.length - 3} more</p>
              )}
            </div>

            <div className="space-y-1.5">
              <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-widest">Tips</p>
              <ul className="text-xs text-muted-foreground space-y-1 list-disc list-inside">
                <li>Set margins to <span className="font-semibold text-foreground">None</span></li>
                <li>Set scale to <span className="font-semibold text-foreground">100%</span></li>
                <li>Make sure your printer is on the same WiFi network</li>
              </ul>
            </div>
          </div>
          <DialogFooter className="flex-col gap-2 sm:flex-col">
            <Button onClick={executeWifiPrint} disabled={wifiPrinting} className="w-full gap-2">
              {wifiPrinting ? (
                <><span className="animate-spin inline-block">⏳</span> Preparing…</>
              ) : (
                <><Wifi className="h-4 w-4" /> Print via WiFi</>
              )}
            </Button>
            <Button variant="secondary" onClick={() => setShowWifiPrintDialog(false)} disabled={wifiPrinting} className="w-full">
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* iOS Label Image Export Dialog */}
      <Dialog open={showIOSExport} onOpenChange={o => { if (!iosExporting && !o) setShowIOSExport(false); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-blue-400">
              <Smartphone className="h-4 w-4" /> Save Label Image{iosExportLabels.length > 1 ? "s" : ""}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="flex items-start gap-2 p-3 rounded-lg bg-blue-500/10 border border-blue-500/30">
              <AlertCircle className="h-4 w-4 text-blue-400 shrink-0 mt-0.5" />
              <div className="text-xs text-muted-foreground leading-relaxed">
                <p className="font-semibold text-blue-400 mb-1">Direct Bluetooth printing is not available on iOS</p>
                <p>Save your label{iosExportLabels.length > 1 ? "s" : ""} as high-resolution PNG image{iosExportLabels.length > 1 ? "s" : ""}, then open the MarkLife Label app and print from there.</p>
              </div>
            </div>

            <div className="bg-secondary rounded-lg px-3 py-2 space-y-1">
              <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-semibold">
                {iosExportLabels.length} label{iosExportLabels.length > 1 ? "s" : ""} to export
              </p>
              {iosExportLabels.slice(0, 3).map(l => (
                <p key={l._id} className="text-xs font-semibold truncate">{l.labelData.cardName}</p>
              ))}
              {iosExportLabels.length > 3 && (
                <p className="text-[10px] text-muted-foreground">+{iosExportLabels.length - 3} more</p>
              )}
            </div>

            <div className="space-y-1.5">
              <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-widest">How to print</p>
              <ol className="text-xs text-muted-foreground space-y-1 list-decimal list-inside">
                <li>Tap <span className="font-semibold text-foreground">Save Label Image</span> below</li>
                <li>Save to your Photos or share via AirDrop</li>
                <li>Open the <span className="font-semibold text-foreground">MarkLife Label</span> app</li>
                <li>Import the saved image and print</li>
              </ol>
            </div>
          </div>
          <DialogFooter className="flex-col gap-2 sm:flex-col">
            <Button onClick={executeIOSExport} disabled={iosExporting} className="w-full gap-2">
              {iosExporting ? (
                <><span className="animate-spin inline-block">⏳</span> Rendering…</>
              ) : (
                <><Share2 className="h-4 w-4" /> Save Label Image{iosExportLabels.length > 1 ? "s" : ""}</>
              )}
            </Button>
            <Button variant="secondary" onClick={() => setShowIOSExport(false)} disabled={iosExporting} className="w-full">
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
