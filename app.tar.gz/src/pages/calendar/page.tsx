import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { motion, AnimatePresence } from "motion/react";
import { api } from "@/convex/_generated/api.js";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog.tsx";
import { ChevronLeft, ChevronRight, TrendingUp, StickyNote, Save, Trash2, Pencil, X, Plus } from "lucide-react";
import { formatCurrency } from "@/lib/utils.ts";

function getDaysInMonth(year: number, month: number): number {
  return new Date(year, month, 0).getDate();
}
function getFirstDayOfMonth(year: number, month: number): number {
  return new Date(year, month - 1, 1).getDay();
}
function pad(n: number) { return String(n).padStart(2, "0"); }
function toDateStr(year: number, month: number, day: number) {
  return `${year}-${pad(month)}-${pad(day)}`;
}

export default function CalendarPage() {
  const today = new Date();
  const [year, setYear] = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth() + 1);

  // Which day is "selected" — shows preview box below calendar
  const [activeDay, setActiveDay] = useState<number | null>(null);

  // Editor dialog state
  const [editDay, setEditDay] = useState<number | null>(null);
  const [noteText, setNoteText] = useState("");
  const [saving, setSaving] = useState(false);
  const [savedNote, setSavedNote] = useState(false);

  const user = useQuery(api.users.getCurrentUser, {});
  const currency = user?.currency ?? "GBP";
  const sales = useQuery(api.scans.getMonthlySales, { year, month });
  const notes = useQuery(api.calendarNotes.getMonthNotes, { year, month });
  const upsertNote = useMutation(api.calendarNotes.upsertNote);

  const prev = () => {
    setActiveDay(null);
    if (month === 1) { setMonth(12); setYear(y => y - 1); }
    else setMonth(m => m - 1);
  };
  const next = () => {
    setActiveDay(null);
    if (month === 12) { setMonth(1); setYear(y => y + 1); }
    else setMonth(m => m + 1);
  };

  const salesByDay = new Map<number, number>();
  (sales ?? []).forEach(card => {
    if (!card.soldAt) return;
    const d = new Date(card.soldAt).getDate();
    salesByDay.set(d, (salesByDay.get(d) ?? 0) + (card.salePrice ?? card.marketValue ?? 0));
  });

  const notesByDay = new Map<number, string>();
  (notes ?? []).forEach(n => {
    const day = parseInt(n.date.split("-")[2], 10);
    notesByDay.set(day, n.note);
  });

  const totalEarnings = [...salesByDay.values()].reduce((a, b) => a + b, 0);
  const daysInMonth = getDaysInMonth(year, month);
  const firstDay = getFirstDayOfMonth(year, month);
  const monthName = new Date(year, month - 1).toLocaleString("en-GB", { month: "long" });

  const cells: (number | null)[] = [
    ...Array.from({ length: firstDay }, () => null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ];

  function openEditor(day: number) {
    setEditDay(day);
    setNoteText(notesByDay.get(day) ?? "");
  }

  async function saveNote() {
    if (editDay === null) return;
    setSaving(true);
    try {
      await upsertNote({ date: toDateStr(year, month, editDay), note: noteText });
      setSavedNote(true);
      setTimeout(() => { setSavedNote(false); setEditDay(null); }, 400);
    } catch {
      // failed to save note
    } finally {
      setSaving(false);
    }
  }

  async function deleteNote() {
    if (editDay === null) return;
    setSaving(true);
    try {
      await upsertNote({ date: toDateStr(year, month, editDay), note: "" });
      setEditDay(null);
      setActiveDay(null);
    } catch {
      // failed to remove note
    } finally {
      setSaving(false);
    }
  }

  const activeDateLabel = activeDay !== null
    ? new Date(year, month - 1, activeDay).toLocaleDateString("en-GB", {
        weekday: "long", day: "numeric", month: "long",
      })
    : "";
  const activeNote = activeDay !== null ? notesByDay.get(activeDay) : undefined;
  const editDateLabel = editDay !== null
    ? new Date(year, month - 1, editDay).toLocaleDateString("en-GB", {
        weekday: "long", day: "numeric", month: "long",
      })
    : "";

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto space-y-5">
      <h1 className="text-3xl font-sans text-primary tracking-widest">Calendar</h1>

      {/* Month total */}
      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/20">
              <TrendingUp className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Total Earnings – {monthName} {year}</p>
              <p className="text-2xl font-bold">{formatCurrency(totalEarnings, currency)}</p>
            </div>
          </div>
          <p className="text-xs text-muted-foreground">{(sales ?? []).length} card{(sales ?? []).length !== 1 ? "s" : ""} sold</p>
        </CardContent>
      </Card>

      {/* Nav */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" size="icon" onClick={prev}><ChevronLeft className="h-5 w-5" /></Button>
        <h2 className="text-lg font-bold">{monthName} {year}</h2>
        <Button variant="ghost" size="icon" onClick={next}><ChevronRight className="h-5 w-5" /></Button>
      </div>

      {/* Calendar grid */}
      <div className="grid grid-cols-7 gap-1">
        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(d => (
          <div key={d} className="text-[10px] sm:text-xs font-semibold text-muted-foreground text-center py-1">{d.slice(0, 2)}</div>
        ))}

        {cells.map((day, i) => {
          if (!day) return <div key={`empty-${i}`} />;
          const amount = salesByDay.get(day);
          const hasNote = notesByDay.has(day);
          const isToday = day === today.getDate() && month === today.getMonth() + 1 && year === today.getFullYear();
          const isActive = activeDay === day;

          return (
            <motion.button
              key={day}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: i * 0.006 }}
              onClick={() => setActiveDay(isActive ? null : day)}
              className={[
                "relative flex flex-col items-center justify-center p-1 text-center transition-all cursor-pointer",
                "rounded-lg border active:scale-95 touch-manipulation",
                "min-h-[40px] sm:min-h-[52px] md:min-h-[60px]",
                amount ? "bg-primary/15 border-primary/35" : "bg-card border-border/50",
                isActive ? "ring-2 ring-amber-500 border-amber-500/50" : "hover:border-primary/40 hover:bg-secondary/40",
                isToday ? "ring-1 ring-primary" : "",
              ].filter(Boolean).join(" ")}
            >
              <span className={`text-[11px] sm:text-xs font-bold leading-none ${isToday ? "text-primary" : "text-foreground"}`}>
                {day}
              </span>
              {amount !== undefined && (
                <span className="text-[7px] sm:text-[8px] text-primary font-bold mt-0.5 leading-none hidden sm:block">
                  {formatCurrency(amount, currency)}
                </span>
              )}
              {/* Yellow dot for notes */}
              {hasNote && (
                <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 rounded-full bg-amber-500" />
              )}
            </motion.button>
          );
        })}
      </div>

      {/* Legend */}
      <div className="flex items-center gap-4 text-xs text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-sm bg-primary/15 border border-primary/35 inline-block" />
          Sales day
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 inline-block" />
          Has note
        </span>
      </div>

      {/* ── Note preview box — shown below calendar when a day is selected ── */}
      <AnimatePresence mode="wait">
        {activeDay !== null && (
          <motion.div
            key={`preview-${activeDay}`}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            transition={{ duration: 0.18 }}
          >
            <Card className={`border-2 ${activeNote ? "border-amber-500/40 bg-amber-500/5" : "border-dashed border-border"}`}>
              <CardContent className="p-4">
                {/* Header row */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <StickyNote className={`h-4 w-4 ${activeNote ? "text-amber-500" : "text-muted-foreground"}`} />
                    <span className="text-sm font-bold">{activeDateLabel}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 gap-1 text-xs"
                      onClick={() => openEditor(activeDay)}
                    >
                      <Pencil className="h-3 w-3" />
                      {activeNote ? "Edit" : "Add Note"}
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-7 w-7 text-muted-foreground"
                      onClick={() => setActiveDay(null)}
                    >
                      <X className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>

                {/* Note content or empty state */}
                {activeNote ? (
                  <p className="text-sm text-foreground whitespace-pre-wrap leading-relaxed">
                    {activeNote}
                  </p>
                ) : (
                  <div className="flex flex-col items-center justify-center py-4 gap-2 text-center">
                    <p className="text-sm text-muted-foreground">No note for this day yet.</p>
                    <Button size="sm" variant="secondary" className="gap-1.5 text-xs" onClick={() => openEditor(activeDay)}>
                      <Plus className="h-3.5 w-3.5" />
                      Add a note
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Editor dialog ── */}
      <Dialog open={editDay !== null} onOpenChange={open => { if (!open) setEditDay(null); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <StickyNote className="h-4 w-4 text-amber-500" />
              {editDateLabel}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3 pt-1">
            <Textarea
              value={noteText}
              onChange={e => setNoteText(e.target.value)}
              placeholder="Add a note for this day…"
              className="min-h-[120px] resize-none"
              autoFocus
            />
            <div className="flex gap-2 justify-end">
              {notesByDay.has(editDay ?? -1) && (
                <Button
                  variant="ghost" size="sm"
                  className="text-red-400 hover:text-red-400 gap-1"
                  onClick={deleteNote}
                  disabled={saving}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Remove
                </Button>
              )}
              <Button variant="ghost" size="sm" onClick={() => setEditDay(null)} disabled={saving}>
                Cancel
              </Button>
              <Button size="sm" onClick={saveNote} disabled={saving} className={`gap-1 transition-colors ${savedNote ? "bg-profit hover:bg-profit text-white" : ""}`}>
                <Save className="h-3.5 w-3.5" />
                {saving ? "Saving…" : "Save Note"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
