import { useState } from "react";
import { useMutation, useQuery, useConvexAuth } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { motion } from "motion/react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { toast } from "sonner";
import { ConvexError } from "convex/values";
import { ThumbsUp, ThumbsDown, CheckCircle2, Trash2, CheckCheck } from "lucide-react";

export default function FeedbackPage() {
  const { isAuthenticated } = useConvexAuth();
  const isAdmin = useQuery(api.users.isAdminUser, isAuthenticated ? {} : "skip");

  const submitFeedback = useMutation(api.feedback.submitFeedback);
  const adminGetAll = useQuery(api.feedback.adminGetAllFeedback, isAuthenticated && isAdmin ? {} : "skip");
  const adminApprove = useMutation(api.feedback.adminApproveFeedback);
  const adminDelete = useMutation(api.feedback.adminDeleteFeedback);

  const [posName, setPosName] = useState("");
  const [posMsg, setPosMsg] = useState("");
  const [negName, setNegName] = useState("");
  const [negMsg, setNegMsg] = useState("");
  const [submittingPos, setSubmittingPos] = useState(false);
  const [submittingNeg, setSubmittingNeg] = useState(false);
  const [donePos, setDonePos] = useState(false);
  const [doneNeg, setDoneNeg] = useState(false);

  const handleSubmit = async (type: "positive" | "negative") => {
    const msg = type === "positive" ? posMsg : negMsg;
    const name = type === "positive" ? posName : negName;
    if (!msg.trim()) { toast.error("Please write something before submitting."); return; }
    if (type === "positive") setSubmittingPos(true); else setSubmittingNeg(true);
    try {
      await submitFeedback({ type, message: msg, name: name || undefined });
      toast.success(type === "positive" ? "Thanks for the kind words! 🎉" : "Thanks for your feedback — we appreciate it.");
      if (type === "positive") { setPosMsg(""); setPosName(""); setDonePos(true); }
      else { setNegMsg(""); setNegName(""); setDoneNeg(true); }
    } catch (e) {
      if (e instanceof ConvexError) toast.error((e.data as { message: string }).message);
      else toast.error("Failed to submit — please try again.");
    } finally {
      if (type === "positive") setSubmittingPos(false); else setSubmittingNeg(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 sm:py-8 space-y-5 sm:space-y-6 min-h-[calc(100dvh-8rem)] flex flex-col">
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
        <h1 className="text-2xl sm:text-3xl font-sans font-black text-primary tracking-widest">Feedback</h1>
        <p className="text-xs sm:text-sm text-muted-foreground mt-1">Share what you love or what we can improve — every message is read by the team.</p>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 flex-1">
        {/* Positive */}
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1, duration: 0.4 }}>
          <Card className="border-emerald-500/30 h-full">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2 text-emerald-400">
                <ThumbsUp className="h-4 w-4" /> What's working well?
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {donePos ? (
                <div className="flex flex-col items-center gap-3 py-6 text-center">
                  <CheckCircle2 className="w-10 h-10 text-emerald-400" />
                  <p className="text-sm font-semibold text-foreground">Thank you!</p>
                  <p className="text-xs text-muted-foreground">Your positive feedback has been received.</p>
                  <Button variant="secondary" size="sm" onClick={() => setDonePos(false)}>Submit another</Button>
                </div>
              ) : (
                <>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Your name <span className="text-muted-foreground">(optional)</span></Label>
                    <Input placeholder="e.g. J.M., Pokémon vendor" value={posName} onChange={e => setPosName(e.target.value)} maxLength={60} />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Your message</Label>
                    <Textarea
                      placeholder="Tell us what you love about DatCARDVault…"
                      value={posMsg}
                      onChange={e => setPosMsg(e.target.value)}
                      maxLength={300}
                      rows={4}
                    />
                    <p className="text-[10px] text-muted-foreground text-right">{posMsg.length}/300</p>
                  </div>
                  <Button
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                    onClick={() => handleSubmit("positive")}
                    disabled={submittingPos}
                  >
                    {submittingPos ? "Sending…" : "Submit Positive Feedback"}
                  </Button>
                  <p className="text-[10px] text-muted-foreground">Positive reviews may appear on the app's landing page after approval.</p>
                </>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Negative */}
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15, duration: 0.4 }}>
          <Card className="border-red-500/30 h-full">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2 text-red-400">
                <ThumbsDown className="h-4 w-4" /> What can we improve?
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {doneNeg ? (
                <div className="flex flex-col items-center gap-3 py-6 text-center">
                  <CheckCircle2 className="w-10 h-10 text-red-400" />
                  <p className="text-sm font-semibold text-foreground">Received!</p>
                  <p className="text-xs text-muted-foreground">We'll review your feedback and use it to improve.</p>
                  <Button variant="secondary" size="sm" onClick={() => setDoneNeg(false)}>Submit another</Button>
                </div>
              ) : (
                <>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Your name <span className="text-muted-foreground">(optional)</span></Label>
                    <Input placeholder="e.g. D.T., TCG trader" value={negName} onChange={e => setNegName(e.target.value)} maxLength={60} />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Your message</Label>
                    <Textarea
                      placeholder="What's frustrating, broken, or missing? Be honest…"
                      value={negMsg}
                      onChange={e => setNegMsg(e.target.value)}
                      maxLength={300}
                      rows={4}
                    />
                    <p className="text-[10px] text-muted-foreground text-right">{negMsg.length}/300</p>
                  </div>
                  <Button
                    className="w-full bg-red-600 hover:bg-red-700 text-white"
                    onClick={() => handleSubmit("negative")}
                    disabled={submittingNeg}
                  >
                    {submittingNeg ? "Sending…" : "Submit Improvement Feedback"}
                  </Button>
                  <p className="text-[10px] text-muted-foreground">This feedback is private and goes directly to the team.</p>
                </>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Admin panel */}
      {isAdmin && adminGetAll !== undefined && (
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2, duration: 0.4 }}>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <CheckCheck className="h-4 w-4 text-primary" /> Admin — All Feedback ({adminGetAll.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {adminGetAll.length === 0 && (
                <p className="text-xs text-muted-foreground text-center py-4">No feedback yet.</p>
              )}
              {adminGetAll.map(f => (
                <div
                  key={f._id}
                  className={`rounded-xl border p-3 space-y-1.5 ${
                    f.type === "positive"
                      ? "border-emerald-500/20 bg-emerald-500/5"
                      : "border-red-500/20 bg-red-500/5"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2 min-w-0">
                      {f.type === "positive"
                        ? <ThumbsUp className="h-3.5 w-3.5 text-emerald-400 shrink-0 mt-0.5" />
                        : <ThumbsDown className="h-3.5 w-3.5 text-red-400 shrink-0 mt-0.5" />
                      }
                      <div className="min-w-0 flex flex-col">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-xs font-semibold text-foreground truncate">{f.name ?? "Anonymous"}</span>
                          {f.type === "positive" && (
                            <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-full border shrink-0 ${
                              f.approved
                                ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                                : "bg-secondary text-muted-foreground border-border"
                            }`}>
                              {f.approved ? "APPROVED" : "PENDING"}
                            </span>
                          )}
                        </div>
                        {f.email && (
                          <span className="text-[10px] text-muted-foreground truncate">{f.email}</span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      {f.type === "positive" && (
                        <button
                          className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                            f.approved
                              ? "text-emerald-400 hover:bg-emerald-500/10"
                              : "text-muted-foreground hover:bg-emerald-500/10 hover:text-emerald-400"
                          }`}
                          title={f.approved ? "Unapprove" : "Approve for login page"}
                          onClick={async () => {
                            try {
                              await adminApprove({ feedbackId: f._id, approved: !f.approved });
                              toast.success(f.approved ? "Unapproved" : "Approved for login page");
                            } catch { toast.error("Failed"); }
                          }}
                        >
                          <CheckCircle2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                      <button
                        className="p-1.5 rounded-lg text-destructive hover:bg-destructive/10 transition-colors cursor-pointer"
                        title="Delete"
                        onClick={async () => {
                          try {
                            await adminDelete({ feedbackId: f._id });
                            toast.success("Deleted");
                          } catch { toast.error("Failed"); }
                        }}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed">{f.message}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
}
