import { useState, useRef } from "react";
import { useQuery, useMutation, useConvex } from "convex/react";
import { motion, AnimatePresence } from "motion/react";
import { api } from "@/convex/_generated/api.js";
import { formatCurrency, formatDate } from "@/lib/utils.ts";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { toast } from "sonner";
import {
  TrendingUp, CalendarDays, Tag, Trophy, Zap,
  ChevronDown, ChevronUp,
  ChevronLeft, ChevronRight, Calendar as CalendarIcon,
  StickyNote, X, Check, RefreshCw, FileDown,
  ShoppingBag, Trash2, Pencil, ArrowDownLeft,
} from "lucide-react";

function localDateStr(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function businessDayStr() {
  const now = new Date();
  if (now.getHours() < 6) {
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    return localDateStr(yesterday);
  }
  return localDateStr(now);
}

function addDays(dateStr: string, n: number) {
  const d = new Date(dateStr + "T12:00:00Z");
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

function formatDayDate(dateStr: string) {
  const d = new Date(dateStr + "T12:00:00Z");
  return d.toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short", year: "numeric" });
}

function getDaysInMonth(year: number, month: number): number {
  return new Date(year, month, 0).getDate();
}

function getFirstDayOfMonth(year: number, month: number): number {
  return new Date(year, month - 1, 1).getDay();
}

type Tab = "today" | "history" | "deals" | "calendar";

export default function EarningsPage() {
  const today = businessDayStr();
  const [activeTab, setActiveTab] = useState<Tab>("today");

  const user = useQuery(api.users.getCurrentUserWithImages, {});
  const currency = user?.currency ?? "GBP";
  // Only subscribe to tab-specific queries when that tab is active
  const allDays = useQuery(api.earnings.getAllDailyEarnings, activeTab === "history" ? {} : "skip");
  const allDeals = useQuery(api.buyingDeals.getAllDeals, activeTab === "deals" || activeTab === "calendar" ? {} : "skip");
  const todayEarnings = useQuery(api.earnings.getTodayEarnings, activeTab === "today" ? { dateUtc: businessDayStr() } : "skip");
  const todayDeals = useQuery(api.buyingDeals.getTodayDeals, activeTab === "today" ? { date: businessDayStr() } : "skip");
  const deleteDeal = useMutation(api.buyingDeals.deleteDeal);
  const deleteDailyEarning = useMutation(api.earnings.deleteDailyEarning);
  const setEventMode = useMutation(api.earnings.setEventMode);
  const rebuildEarnings = useMutation(api.earnings.rebuildEarnings);
  const [rebuilding, setRebuilding] = useState(false);
  const [generatingPdf, setGeneratingPdf] = useState(false);

  const convex = useConvex();

  async function handleRebuild() {
    setRebuilding(true);
    try { await rebuildEarnings({}); } catch (e) { toast.error("Rebuild failed: " + (e as Error).message); } finally { setRebuilding(false); }
  }
  const [expandedDay, setExpandedDay] = useState<string | null>(today);
  const [expandedDeal, setExpandedDeal] = useState<string | null>(null);
  const [showTotalPaidPopup, setShowTotalPaidPopup] = useState(false);
  const [showMarginHeldPopup, setShowMarginHeldPopup] = useState(false);

  async function handleDownloadPdf() {
    setGeneratingPdf(true);
    try {
      // Fetch export data on-demand — no need for live subscriptions for PDF generation
      const [allDaysForExport, allDealsForExport] = await Promise.all([
        convex.query(api.earnings.getAllDailyEarningsForExport, {}),
        convex.query(api.buyingDeals.getAllDealsForExport, {}),
      ]);
      if (!allDaysForExport || allDaysForExport.length === 0) {
        setGeneratingPdf(false);
        return;
      }
      const doc = new jsPDF();
      const pageW = doc.internal.pageSize.getWidth();
      const pageH = doc.internal.pageSize.getHeight();
      const now = new Date();
      const sym = currency === "GBP" ? "£" : currency === "EUR" ? "€" : "$";
      const BLACK:   [number,number,number] = [10, 10, 10];
      const RED:     [number,number,number] = [180, 0, 0];
      const WHITE:   [number,number,number] = [255, 255, 255];
      const GREY:    [number,number,number] = [80, 80, 80];
      const LTGREY:  [number,number,number] = [200, 200, 200];
      const DKGREY:  [number,number,number] = [40, 40, 40];
      const ORANGE:  [number,number,number] = [210, 100, 20];
      const GREEN:   [number,number,number] = [60, 140, 90];
      const BODYTEXT:[number,number,number] = [20, 20, 20];
      const ALTROW:  [number,number,number] = [248, 248, 248];
      const LINELIT: [number,number,number] = [220, 220, 220];

      // ── Determine UK tax year ─────────────────────────────────────────
      const currentYear = now.getFullYear();
      const currentMonth = now.getMonth();
      const currentDay = now.getDate();
      const taxYearStartYear = (currentMonth > 3 || (currentMonth === 3 && currentDay >= 6)) ? currentYear : currentYear - 1;
      const taxYearEndYear = taxYearStartYear + 1;
      const taxYearStart = `${taxYearStartYear}-04-06`;
      const taxYearEnd = `${taxYearEndYear}-04-05`;
      const taxYearLabel = `${taxYearStartYear}/${taxYearEndYear}`;

      // Filter data to current tax year
      const activeDays = allDaysForExport.filter(d => !d.deletedAt && d.date >= taxYearStart && d.date <= taxYearEnd);
      const deals = (allDealsForExport ?? []).filter(d => d.date >= taxYearStart && d.date <= taxYearEnd);
      const activeDeals = deals.filter(d => !d.deletedAt);

      // Monthly breakdown
      const taxMonths: { label: string; start: string; end: string }[] = [];
      for (let i = 0; i < 12; i++) {
        const monthIndex = (3 + i) % 12;
        const year = monthIndex >= 3 ? taxYearStartYear : taxYearEndYear;
        const daysInMonth = new Date(year, monthIndex + 1, 0).getDate();
        const startDay = i === 0 ? 6 : 1;
        const endDay = i === 11 ? 5 : daysInMonth;
        const startYear = i === 0 ? taxYearStartYear : year;
        const endYear = i === 11 ? taxYearEndYear : year;
        const monthStart = `${startYear}-${String(monthIndex + 1).padStart(2, "0")}-${String(startDay).padStart(2, "0")}`;
        const monthEnd = `${endYear}-${String(monthIndex + 1).padStart(2, "0")}-${String(endDay).padStart(2, "0")}`;
        const monthName = new Date(year, monthIndex, 15).toLocaleString(undefined, { month: "short" });
        taxMonths.push({ label: `${monthName} ${year}`, start: monthStart, end: monthEnd });
      }

      type MonthSummary = { label: string; revenue: number; profit: number; cardsSold: number; dealsPaid: number; dealsKept: number };
      const monthlyData: MonthSummary[] = taxMonths.map(m => {
        const mDays = activeDays.filter(d => d.date >= m.start && d.date <= m.end);
        const mDeals = activeDeals.filter(d => d.date >= m.start && d.date <= m.end);
        return {
          label: m.label,
          revenue: mDays.reduce((s, d) => s + d.totalEarned, 0),
          profit: mDays.reduce((s, d) => s + (d.totalProfit ?? 0), 0),
          cardsSold: mDays.reduce((s, d) => s + d.cardsSold, 0),
          dealsPaid: mDeals.reduce((s, d) => s + d.amountPaid, 0),
          dealsKept: mDeals.reduce((s, d) => s + d.youKeep, 0),
        };
      });

      const quarters = [
        { label: "Q1", months: monthlyData.slice(0, 3) },
        { label: "Q2", months: monthlyData.slice(3, 6) },
        { label: "Q3", months: monthlyData.slice(6, 9) },
        { label: "Q4", months: monthlyData.slice(9, 12) },
      ];

      // Totals
      const totalRevenue = activeDays.reduce((s, d) => s + d.totalEarned, 0);
      const totalSold = activeDays.reduce((s, d) => s + d.cardsSold, 0);
      const totalProfit = activeDays.reduce((s, d) => s + (d.totalProfit ?? 0), 0);
      const totalDealsPaid = activeDeals.reduce((s, d) => s + d.amountPaid, 0);
      const totalDealsKept = activeDeals.reduce((s, d) => s + d.youKeep, 0);
      const bestDay = activeDays.length > 0 ? activeDays.reduce((b, d) => d.totalEarned > b.totalEarned ? d : b, activeDays[0]) : null;

      // ── Logo ───────────────────────────────────────────────────────────
      let logoDataUrl: string | null = null;
      let logoMime = "image/png";
      if (user?.logoUrl) {
        try {
          const resp = await fetch(user.logoUrl);
          const blob = await resp.blob();
          logoMime = blob.type || "image/png";
          logoDataUrl = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          });
        } catch { /* no logo */ }
      }

      // ── Header (compact) ────────────────────────────────────────────
      const HEADER_H = 28;
      doc.setFillColor(...BLACK); doc.rect(0, 0, pageW, HEADER_H, "F");
      doc.setFillColor(...RED); doc.rect(0, 0, 3, HEADER_H, "F");
      doc.setTextColor(...WHITE); doc.setFont("helvetica", "bold"); doc.setFontSize(13);
      doc.text("Dat", 10, 11);
      const dw = doc.getTextWidth("Dat");
      doc.setTextColor(...RED); doc.text("CARD", 10 + dw, 11);
      const cw = doc.getTextWidth("CARD");
      doc.setTextColor(...WHITE); doc.text("Vault", 10 + dw + cw, 11);
      doc.setFontSize(9); doc.setFont("helvetica", "bold"); doc.setTextColor(...WHITE);
      doc.text(`UK TAX YEAR ${taxYearLabel}`, 10, 21);
      doc.setFontSize(6.5); doc.setFont("helvetica", "normal"); doc.setTextColor(...LTGREY);
      doc.text(`6 Apr ${taxYearStartYear} – 5 Apr ${taxYearEndYear}  |  Generated ${now.toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" })}`, 10, 26);
      if (logoDataUrl) {
        const ls = 14; const lx = pageW - ls - 6; const ly = 7;
        doc.addImage(logoDataUrl, logoMime.includes("png") ? "PNG" : "JPEG", lx, ly, ls, ls);
      }

      // ── Stat cards (2 compact rows) ─────────────────────────────────
      let y = HEADER_H + 5;
      const cardH = 14;
      const margin = 10;
      const gap = 3;
      const cols = 4;
      const cardW = (pageW - margin * 2 - gap * (cols - 1)) / cols;

      function drawMiniStat(x: number, yPos: number, label: string, value: string, color: [number,number,number]) {
        doc.setFillColor(...color); doc.roundedRect(x, yPos, cardW, cardH, 1.5, 1.5, "F");
        doc.setFont("helvetica", "bold"); doc.setFontSize(9); doc.setTextColor(...WHITE);
        doc.text(value, x + cardW / 2, yPos + 7, { align: "center" });
        doc.setFont("helvetica", "normal"); doc.setFontSize(5.5); doc.setTextColor(200, 200, 200);
        doc.text(label.toUpperCase(), x + cardW / 2, yPos + 12, { align: "center" });
      }

      const netPosition = totalProfit - totalDealsPaid;
      const row1 = [
        { label: "Revenue", value: `${sym}${totalRevenue.toFixed(2)}`, color: RED },
        { label: "Profit", value: `${sym}${totalProfit.toFixed(2)}`, color: totalProfit >= 0 ? GREEN : [140, 30, 30] as [number,number,number] },
        { label: "Cards Sold", value: String(totalSold), color: DKGREY },
        { label: "Trading Days", value: String(activeDays.length), color: DKGREY },
      ];
      const row2 = [
        { label: "Deals", value: String(activeDeals.length), color: DKGREY },
        { label: "Paid Out", value: `${sym}${totalDealsPaid.toFixed(2)}`, color: ORANGE },
        { label: "Margin Held", value: `${sym}${totalDealsKept.toFixed(2)}`, color: GREEN },
        { label: "Net Position", value: `${sym}${netPosition.toFixed(2)}`, color: netPosition >= 0 ? GREEN : [140, 30, 30] as [number,number,number] },
      ];

      row1.forEach((s, i) => drawMiniStat(margin + i * (cardW + gap), y, s.label, s.value, s.color));
      y += cardH + 3;
      row2.forEach((s, i) => drawMiniStat(margin + i * (cardW + gap), y, s.label, s.value, s.color));
      y += cardH + 5;

      // ── Best day (single line) ─────────────────────────────────────
      if (bestDay) {
        doc.setFillColor(20, 20, 20); doc.roundedRect(margin, y, pageW - margin * 2, 8, 1, 1, "F");
        doc.setFont("helvetica", "bold"); doc.setFontSize(6); doc.setTextColor(...RED);
        doc.text("BEST DAY", margin + 3, y + 5.5);
        doc.setTextColor(...WHITE); doc.setFont("helvetica", "normal"); doc.setFontSize(6);
        const bestText = `${formatDayDate(bestDay.date)} — ${sym}${bestDay.totalEarned.toFixed(2)} (${bestDay.cardsSold} cards)${bestDay.topCard ? `  |  Top: ${bestDay.topCard}` : ""}`;
        doc.text(bestText, margin + 26, y + 5.5);
        y += 11;
      }

      // ── Event mode (single line if active) ─────────────────────────
      if (eventActive && eventEarnings) {
        doc.setFillColor(20, 20, 20); doc.roundedRect(margin, y, pageW - margin * 2, 8, 1, 1, "F");
        doc.setFont("helvetica", "bold"); doc.setFontSize(6); doc.setTextColor(100, 200, 100);
        doc.text("EVENT", margin + 3, y + 5.5);
        doc.setTextColor(...WHITE); doc.setFont("helvetica", "normal"); doc.setFontSize(6);
        doc.text(`${eventDays}-day event: ${sym}${eventEarnings.totalEarned.toFixed(2)} revenue, ${eventEarnings.cardsSold} cards sold, ${daysLeft}d remaining`, margin + 22, y + 5.5);
        y += 11;
      }

      // ── Monthly breakdown ─────────────────────────────────────────
      doc.setFillColor(245, 245, 245); doc.roundedRect(margin, y, pageW - margin * 2, 7, 1, 1, "F");
      doc.setFont("helvetica", "bold"); doc.setFontSize(7); doc.setTextColor(...RED);
      doc.text("MONTHLY BREAKDOWN", margin + 3, y + 4.8);
      doc.setFont("helvetica", "normal"); doc.setFontSize(5.5); doc.setTextColor(...GREY);
      doc.text(`Apr ${taxYearStartYear} – Mar ${taxYearEndYear}`, pageW - margin - 3, y + 4.8, { align: "right" });
      y += 10;

      autoTable(doc, {
        startY: y,
        margin: { left: margin, right: margin },
        head: [["Month", `Revenue (${sym})`, `Profit (${sym})`, "Cards", `Paid Out (${sym})`, `Margin (${sym})`]],
        body: monthlyData.flatMap((m, i) => {
          const row = [
            m.label,
            m.revenue > 0 ? m.revenue.toFixed(2) : "—",
            m.profit !== 0 ? `${m.profit >= 0 ? "+" : ""}${m.profit.toFixed(2)}` : "—",
            m.cardsSold > 0 ? String(m.cardsSold) : "—",
            m.dealsPaid > 0 ? m.dealsPaid.toFixed(2) : "—",
            m.dealsKept > 0 ? m.dealsKept.toFixed(2) : "—",
          ];
          const rows: string[][] = [row];
          if ((i + 1) % 3 === 0) {
            const qIdx = Math.floor(i / 3);
            const q = quarters[qIdx];
            const qR = q.months.reduce((s, x) => s + x.revenue, 0);
            const qP = q.months.reduce((s, x) => s + x.profit, 0);
            const qS = q.months.reduce((s, x) => s + x.cardsSold, 0);
            const qD = q.months.reduce((s, x) => s + x.dealsPaid, 0);
            const qK = q.months.reduce((s, x) => s + x.dealsKept, 0);
            rows.push([
              `${q.label} Total`,
              qR > 0 ? qR.toFixed(2) : "—",
              qP !== 0 ? `${qP >= 0 ? "+" : ""}${qP.toFixed(2)}` : "—",
              qS > 0 ? String(qS) : "—",
              qD > 0 ? qD.toFixed(2) : "—",
              qK > 0 ? qK.toFixed(2) : "—",
            ]);
          }
          return rows;
        }),
        foot: [[
          `YEAR ${taxYearLabel}`,
          totalRevenue > 0 ? totalRevenue.toFixed(2) : "—",
          `${totalProfit >= 0 ? "+" : ""}${totalProfit.toFixed(2)}`,
          String(totalSold),
          totalDealsPaid > 0 ? totalDealsPaid.toFixed(2) : "—",
          totalDealsKept > 0 ? totalDealsKept.toFixed(2) : "—",
        ]],
        theme: "grid",
        headStyles: {
          fillColor: [25, 25, 25],
          textColor: [255, 255, 255],
          fontStyle: "bold",
          fontSize: 6,
          lineColor: [50, 50, 50],
          lineWidth: 0.2,
          cellPadding: { top: 2.5, bottom: 2.5, left: 2, right: 2 },
        },
        footStyles: {
          fillColor: RED,
          textColor: WHITE,
          fontStyle: "bold",
          fontSize: 6.5,
          lineColor: [150, 0, 0],
          lineWidth: 0.3,
          cellPadding: { top: 3, bottom: 3, left: 2, right: 2 },
        },
        bodyStyles: {
          fontSize: 6.5,
          textColor: BODYTEXT,
          lineColor: [235, 235, 235],
          lineWidth: 0.1,
          cellPadding: { top: 2, bottom: 2, left: 2, right: 2 },
        },
        alternateRowStyles: { fillColor: [250, 250, 250] },
        columnStyles: {
          0: { cellWidth: 28, fontStyle: "bold" },
          1: { halign: "right", cellWidth: 24 },
          2: { halign: "right", cellWidth: 24 },
          3: { halign: "center", cellWidth: 16 },
          4: { halign: "right", cellWidth: 24 },
          5: { halign: "right", cellWidth: 24 },
        },
        styles: { cellPadding: 2 },
        didParseCell: (data) => {
          if (data.section === "body") {
            const cellText = String(data.cell.raw ?? "");
            // Quarterly subtotal rows
            const rawRow = data.row.raw;
            const rowFirstCell = String(Array.isArray(rawRow) ? rawRow[0] : "");
            if (rowFirstCell.endsWith("Total")) {
              data.cell.styles.fillColor = [30, 30, 30];
              data.cell.styles.textColor = [255, 255, 255];
              data.cell.styles.fontStyle = "bold";
              data.cell.styles.fontSize = 6;
            }
            // Colour profit green/red
            if (data.column.index === 2 && !rowFirstCell.endsWith("Total")) {
              if (cellText.startsWith("+")) {
                data.cell.styles.textColor = GREEN;
              } else if (cellText.startsWith("-")) {
                data.cell.styles.textColor = [180, 40, 40];
              }
            }
            // Colour margin green
            if (data.column.index === 5 && cellText !== "—" && !rowFirstCell.endsWith("Total")) {
              data.cell.styles.textColor = GREEN;
            }
            // Colour stock orange
            if (data.column.index === 4 && cellText !== "—" && !rowFirstCell.endsWith("Total")) {
              data.cell.styles.textColor = ORANGE;
            }
            // Dim zero/dash cells
            if (cellText === "—") {
              data.cell.styles.textColor = [180, 180, 180];
            }
          }
          // Foot profit colour
          if (data.section === "foot" && data.column.index === 2) {
            if (totalProfit >= 0) {
              data.cell.styles.textColor = [200, 255, 200];
            } else {
              data.cell.styles.textColor = [255, 180, 180];
            }
          }
        },
      });

      // ── Footer ─────────────────────────────────────────────────────
      const totalPages = doc.getNumberOfPages();
      for (let i = 1; i <= totalPages; i++) {
        doc.setPage(i);
        doc.setFillColor(...BLACK); doc.rect(0, pageH - 10, pageW, 10, "F");
        doc.setFillColor(...RED); doc.rect(0, pageH - 10, 3, 10, "F");
        doc.setFont("helvetica", "bold"); doc.setFontSize(5.5); doc.setTextColor(...RED);
        doc.text("DatCARDVault", 7, pageH - 4);
        doc.setFont("helvetica", "normal"); doc.setTextColor(...GREY); doc.setFontSize(5);
        doc.text("For personal records only. Not professional tax advice.", pageW / 2, pageH - 4, { align: "center" });
        doc.text(`Page ${i}/${totalPages}`, pageW - margin, pageH - 4, { align: "right" });
      }

      doc.save(`datcardvault-tax-year-${taxYearLabel.replace("/", "-")}.pdf`);
    } catch (e) {
      console.error("PDF generation failed", e);
    } finally {
      setGeneratingPdf(false);
    }
  }

  // Event mode
  const eventActive = user?.eventActive ?? false;
  const eventDays = user?.eventDays ?? 3;
  const eventStartDate = user?.eventStartDate ?? today;
  const eventEndDate = eventActive ? addDays(eventStartDate, eventDays - 1) : today;
  const eventEarnings = useQuery(api.earnings.getEventEarnings, eventActive ? { startDate: eventStartDate, endDate: eventEndDate } : "skip");
  const [showEventSetup, setShowEventSetup] = useState(false);
  const [pickedDays, setPickedDays] = useState(3);
  const daysLeft = eventActive ? Math.max(0, Math.ceil((new Date(eventEndDate + "T23:59:59Z").getTime() - Date.now()) / 86400000)) : 0;
  async function startEvent() { await setEventMode({ active: true, days: pickedDays, startDate: today }); setShowEventSetup(false); }
  async function endEvent() { await setEventMode({ active: false }); }

  const sortedDays = allDays ?? [];

  // Calendar
  const todayDate = new Date();
  const [calYear, setCalYear] = useState(todayDate.getFullYear());
  const [calMonth, setCalMonth] = useState(todayDate.getMonth() + 1);
  const sales = useQuery(api.scans.getMonthlySales, activeTab === "calendar" ? { year: calYear, month: calMonth } : "skip");
  const monthNotes = useQuery(api.calendarNotes.getMonthNotes, activeTab === "calendar" ? { year: calYear, month: calMonth } : "skip");
  const addNoteMutation = useMutation(api.calendarNotes.addNote);
  const updateNoteMutation = useMutation(api.calendarNotes.updateNote);
  const deleteNoteMutation = useMutation(api.calendarNotes.deleteNote);
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  const [newNoteText, setNewNoteText] = useState("");
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [editingNoteText, setEditingNoteText] = useState("");
  const [savingNote, setSavingNote] = useState(false);
  const noteRef = useRef<HTMLTextAreaElement>(null);

  // Group notes by day number
  const notesByDay = new Map<number, Array<{ _id: string; note: string }>>();
  (monthNotes ?? []).forEach(n => {
    const day = parseInt(n.date.slice(8, 10), 10);
    const arr = notesByDay.get(day) ?? [];
    arr.push({ _id: n._id, note: n.note });
    notesByDay.set(day, arr);
  });

  function openDay(day: number) { setSelectedDay(day); setNewNoteText(""); setEditingNoteId(null); }
  function closeNote() { setSelectedDay(null); setNewNoteText(""); setEditingNoteId(null); setEditingNoteText(""); }

  async function addNote() {
    if (selectedDay === null || !newNoteText.trim()) return;
    const dateStr = `${calYear}-${String(calMonth).padStart(2, "0")}-${String(selectedDay).padStart(2, "0")}`;
    setSavingNote(true);
    try { await addNoteMutation({ date: dateStr, note: newNoteText }); setNewNoteText(""); } catch { /* failed */ } finally { setSavingNote(false); }
  }

  async function saveEditNote() {
    if (!editingNoteId || !editingNoteText.trim()) return;
    setSavingNote(true);
    try {
      await updateNoteMutation({ noteId: editingNoteId as Parameters<typeof updateNoteMutation>[0]["noteId"], note: editingNoteText });
      setEditingNoteId(null); setEditingNoteText("");
    } catch { /* failed */ } finally { setSavingNote(false); }
  }

  async function deleteNote(noteId: string) {
    setSavingNote(true);
    try { await deleteNoteMutation({ noteId: noteId as Parameters<typeof deleteNoteMutation>[0]["noteId"] }); } catch { /* failed */ } finally { setSavingNote(false); }
  }

  const prevMonth = () => { closeNote(); if (calMonth === 1) { setCalMonth(12); setCalYear(y => y - 1); } else setCalMonth(m => m - 1); };
  const nextMonth = () => { closeNote(); if (calMonth === 12) { setCalMonth(1); setCalYear(y => y + 1); } else setCalMonth(m => m + 1); };

  const salesByDay = new Map<number, number>();
  (sales ?? []).forEach(card => {
    if (!card.soldAt) return;
    const d = new Date(card.soldAt).getDate();
    salesByDay.set(d, (salesByDay.get(d) ?? 0) + (card.salePrice ?? card.marketValue ?? 0));
  });

  const totalEarnings = [...salesByDay.values()].reduce((a, b) => a + b, 0);
  const maxDayEarnings = salesByDay.size > 0 ? Math.max(...salesByDay.values()) : 0;

  const dealsByDate = new Map<string, number>();
  (allDeals ?? []).forEach(d => {
    dealsByDate.set(d.date, (dealsByDate.get(d.date) ?? 0) + 1);
  });

  const salesArr = sales ?? [];
  const salesByDayNum = new Map<number, typeof salesArr>();
  salesArr.forEach(card => {
    if (!card.soldAt) return;
    const dn = new Date(card.soldAt).getDate();
    const existing = salesByDayNum.get(dn);
    if (existing) { existing.push(card); } else { salesByDayNum.set(dn, [card]); }
  });

  const selectedDateStr = selectedDay !== null
    ? `${calYear}-${String(calMonth).padStart(2, "0")}-${String(selectedDay).padStart(2, "0")}`
    : "";
  const selectedDaySales = selectedDay !== null ? (salesByDayNum.get(selectedDay) ?? []) : [];
  const selectedDayDeals = (allDeals ?? []).filter(d => d.date === selectedDateStr);

  const daysInMonth = getDaysInMonth(calYear, calMonth);
  const firstDay = getFirstDayOfMonth(calYear, calMonth);
  const monthName = new Date(calYear, calMonth - 1).toLocaleString("en-GB", { month: "long" });
  const cells: (number | null)[] = [...Array.from({ length: firstDay }, () => null), ...Array.from({ length: daysInMonth }, (_, i) => i + 1)];

  // Deals summary
  const todayDealsTotalPaid = (todayDeals ?? []).reduce((s, d) => s + d.amountPaid, 0);
  const todayDealsCount = (todayDeals ?? []).length;

  const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
    { id: "today",   label: "Today",    icon: Zap },
    { id: "history", label: "Sales",    icon: TrendingUp },
    { id: "deals",   label: "Buys",     icon: ShoppingBag },
    { id: "calendar",label: "Calendar", icon: CalendarIcon },
  ];

  return (
    <div className="p-4 md:p-6 max-w-2xl mx-auto space-y-5">

      {/* ── Header ── */}
      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0">
          <h1 className="text-3xl font-sans text-primary tracking-widest">Earnings</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Sales log · resets at 6am</p>
        </div>
        <div className="flex items-center gap-1">
          <Button size="sm" variant="ghost" className="text-xs text-muted-foreground gap-1.5 shrink-0"
            onClick={handleDownloadPdf} disabled={generatingPdf}>
            <FileDown className="w-3.5 h-3.5 shrink-0" />
            <span className="hidden sm:inline">{generatingPdf ? "Generating…" : "Tax Year PDF"}</span>
            <span className="sm:hidden">{generatingPdf ? "…" : "PDF"}</span>
          </Button>
        </div>
      </div>

      {/* ── Event Mode ── */}
      <div className={`rounded-2xl border overflow-hidden ${eventActive ? "border-primary/60 bg-primary/8" : "border-border bg-secondary/50"}`}>
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            <Zap className={`w-4 h-4 ${eventActive ? "text-primary fill-primary" : "text-muted-foreground"}`} />
            <span className="font-bold text-sm">Event Mode</span>
            {eventActive && <span className="text-[10px] font-black tracking-widest px-2 py-0.5 rounded-full bg-primary text-primary-foreground">LIVE · {daysLeft}d left</span>}
          </div>
          {eventActive
            ? <Button size="sm" variant="ghost" className="text-xs text-destructive hover:text-destructive" onClick={endEvent}>End Event</Button>
            : <Button size="sm" variant="ghost" className="text-xs text-muted-foreground" onClick={() => setShowEventSetup(v => !v)}>{showEventSetup ? "Cancel" : "Start Event"}</Button>
          }
        </div>

        <AnimatePresence>
          {!eventActive && showEventSetup && (
            <div className="overflow-hidden border-t border-border">
              <div className="px-4 py-4 space-y-3">
                <p className="text-xs text-muted-foreground">How many days is your event?</p>
                <div className="flex gap-2 flex-wrap">
                  {[2,3,4,5].map(d => (
                    <button key={d} onClick={() => setPickedDays(d)}
                      className={`w-10 h-10 rounded-xl border font-bold text-sm cursor-pointer transition-all ${pickedDays === d ? "border-primary bg-primary text-primary-foreground" : "border-border bg-background hover:border-primary/50"}`}>
                      {d}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground">{pickedDays} days from today → {formatDayDate(addDays(today, pickedDays - 1))}</p>
                <Button size="sm" className="w-full" onClick={startEvent}><Zap className="w-3 h-3 mr-1.5" /> Start {pickedDays}-Day Event</Button>
              </div>
            </div>
          )}
        </AnimatePresence>

        {eventActive && eventEarnings && (
          <div className="border-t border-primary/20 px-4 py-3 space-y-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-xl bg-primary/10 border border-primary/20 p-3 text-center">
                <div className="text-xl sm:text-2xl font-black text-primary truncate">{formatCurrency(eventEarnings.totalEarned, currency)}</div>
                <div className="text-[10px] text-muted-foreground mt-0.5">Event Total</div>
              </div>
              <div className="rounded-xl bg-secondary border border-border p-3 text-center">
                <div className="text-xl sm:text-2xl font-black truncate">{eventEarnings.cardsSold}</div>
                <div className="text-[10px] text-muted-foreground mt-0.5">Cards Sold</div>
              </div>
            </div>
            {eventEarnings.days.length > 0 && (
              <div className="space-y-1">
                {eventEarnings.days.map((d, i) => (
                  <div key={d.date} className="flex items-center justify-between py-1.5 px-3 rounded-lg bg-background/60 text-sm">
                    <span className="text-[10px] font-black text-primary mr-2">Day {i + 1}</span>
                    <span className="text-xs text-muted-foreground flex-1">{formatDayDate(d.date)}</span>
                    <span className="font-bold">{formatCurrency(d.totalEarned, currency)}</span>
                    <span className="text-[10px] text-muted-foreground ml-2">×{d.cardsSold}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* ── Tabs ── */}
      <div className="grid grid-cols-4 gap-1 p-1 bg-secondary border border-border rounded-xl">
        {tabs.map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => setActiveTab(id)}
            className={`flex flex-col items-center justify-center gap-1 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${activeTab === id ? "bg-background text-foreground shadow-sm border border-border" : "text-muted-foreground hover:text-foreground"}`}>
            <Icon className="w-3.5 h-3.5" />
            {label}
          </button>
        ))}
      </div>

      {/* ══ TODAY TAB ══ */}
      {activeTab === "today" && (
        <div className="space-y-4">
          {todayEarnings === undefined ? (
            <div className="space-y-3"><Skeleton className="h-28 w-full rounded-2xl" /><Skeleton className="h-16 w-full rounded-2xl" /></div>
          ) : (
            <>
              {/* Revenue + cards sold */}
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-2xl border border-border bg-secondary/60 p-4 space-y-1">
                  <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Earned Today</p>
                  <p className="text-2xl sm:text-3xl font-black text-primary truncate">{formatCurrency(todayEarnings?.totalEarned ?? 0, currency)}</p>
                  <p className="text-xs text-muted-foreground">{new Date().toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short" })}</p>
                </div>
                <div className="rounded-2xl border border-border bg-secondary/60 p-4 space-y-1">
                  <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Cards Sold</p>
                  <p className="text-2xl sm:text-3xl font-black truncate">{todayEarnings?.cardsSold ?? 0}</p>
                  <p className="text-xs text-muted-foreground">today</p>
                </div>
              </div>

              {/* Profit */}
              {todayEarnings?.totalProfit !== undefined && (
                <div className={`rounded-2xl border p-4 flex items-center gap-3 ${todayEarnings.totalProfit >= 0 ? "border-profit/30 bg-profit/5" : "border-red-500/30 bg-red-500/5"}`}>
                  <TrendingUp className={`w-4 h-4 shrink-0 ${todayEarnings.totalProfit >= 0 ? "text-profit" : "text-red-400"}`} />
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Today's Profit</p>
                    <p className={`text-lg sm:text-xl font-black truncate ${todayEarnings.totalProfit >= 0 ? "text-profit" : "text-red-400"}`}>
                      {todayEarnings.totalProfit >= 0 ? "+" : ""}{formatCurrency(todayEarnings.totalProfit, currency)}
                    </p>
                  </div>
                </div>
              )}

              {/* Top card */}
              {todayEarnings?.topCard && (
                <div className="rounded-2xl border border-primary/30 bg-primary/5 p-4 flex items-center gap-3">
                  <Trophy className="w-4 h-4 text-primary shrink-0" />
                  <div className="min-w-0">
                    <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Top Sale Today</p>
                    <p className="text-sm font-bold truncate">{todayEarnings.topCard}</p>
                    {todayEarnings.topCardValue !== undefined && <p className="text-xs text-primary font-semibold">{formatCurrency(todayEarnings.topCardValue, currency)}</p>}
                  </div>
                </div>
              )}

              {/* Today's buying deals summary */}
              {todayDealsCount > 0 && (
                <div className="rounded-2xl border border-border bg-secondary/40 p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <ArrowDownLeft className="w-4 h-4 text-orange-400 shrink-0" />
                      <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Cards Bought Today</p>
                    </div>
                    <Badge variant="secondary" className="text-xs">{todayDealsCount} deal{todayDealsCount !== 1 ? "s" : ""}</Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="rounded-xl bg-background p-3 text-center">
                <p className="text-lg font-black text-orange-400 truncate">{formatCurrency(todayDealsTotalPaid, currency)}</p>
                      <p className="text-[9px] text-muted-foreground mt-0.5">Total Paid Out</p>
                    </div>
                    <div className="rounded-xl bg-background p-3 text-center">
                      <p className="text-lg font-black">{todayDealsCount}</p>
                      <p className="text-[9px] text-muted-foreground mt-0.5">Cards Acquired</p>
                    </div>
                  </div>
                  <button onClick={() => setActiveTab("deals")} className="mt-3 w-full text-xs text-primary font-semibold cursor-pointer hover:underline">View all buying deals →</button>
                </div>
              )}

              {/* Empty */}
              {(todayEarnings?.cardsSold ?? 0) === 0 && todayDealsCount === 0 && (
                <div className="rounded-2xl border border-border bg-secondary/40 p-8 text-center">
                  <Zap className="w-8 h-8 mx-auto mb-2 text-muted-foreground opacity-30" />
                  <p className="text-sm font-semibold text-muted-foreground">No activity today</p>
                  <p className="text-xs text-muted-foreground mt-1">Scan a card and mark it as sold to log a sale</p>
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* ══ SALES HISTORY TAB ══ */}
      {activeTab === "history" && (
        <div className="space-y-3">
          {allDays === undefined ? (
            Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 w-full rounded-xl" />)
          ) : sortedDays.length === 0 ? (
            <div className="rounded-2xl border border-border bg-secondary/40 p-8 text-center">
              <TrendingUp className="w-8 h-8 mx-auto mb-2 text-muted-foreground opacity-30" />
              <p className="text-sm text-muted-foreground">No sales logged yet</p>
            </div>
          ) : (
            sortedDays.map((day, idx) => {
              const isToday = day.date === today;
              const isOpen = expandedDay === day.date;
              const avgPerCard = day.cardsSold > 0 ? day.totalEarned / day.cardsSold : 0;
              return (
                <motion.div key={day.date} layout
                  className={`rounded-2xl border overflow-hidden cursor-pointer transition-colors ${isToday ? "border-primary/50 bg-primary/5" : "border-border bg-secondary/30 hover:bg-secondary/50"}`}
                  onClick={() => setExpandedDay(isOpen ? null : day.date)}>

                  {/* Collapsed body */}
                  <div className="px-4 py-3 space-y-2">
                    {/* Top line: date + today badge + chevron */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className={`w-6 h-6 rounded-md flex items-center justify-center shrink-0 ${isToday ? "bg-primary/20" : "bg-muted"}`}>
                          <CalendarDays className={`w-3.5 h-3.5 ${isToday ? "text-primary" : "text-muted-foreground"}`} />
                        </div>
                        <div>
                          <span className="text-[11px] text-muted-foreground font-medium">{formatDayDate(day.date)}</span>
                          <p className="text-[9px] text-muted-foreground/60 mt-0.5">
                            First sale: {new Date(day._creationTime).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}
                          </p>
                        </div>
                        {isToday && <span className="text-[9px] font-black tracking-widest px-1.5 py-0.5 rounded-full bg-primary text-primary-foreground">TODAY</span>}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-secondary border border-border text-muted-foreground">
                          Day {sortedDays.length - idx}
                        </span>
                        {isOpen ? <ChevronUp className="w-3.5 h-3.5 text-muted-foreground" /> : <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />}
                      </div>
                    </div>

                    {/* Main numbers row */}
                    <div className="grid grid-cols-3 gap-2">
                      <div className={`rounded-xl border p-2.5 text-center ${isToday ? "bg-primary/8 border-primary/20" : "bg-background/70 border-border/60"}`}>
                        <p className={`text-xs font-black truncate ${isToday ? "text-primary" : ""}`}>{formatCurrency(day.totalEarned, currency)}</p>
                        <p className="text-[9px] text-muted-foreground mt-0.5">Revenue</p>
                      </div>
                      <div className="rounded-xl bg-background/70 border border-border/60 p-2.5 text-center">
                        <p className="text-xs font-black truncate">{day.cardsSold}</p>
                        <p className="text-[9px] text-muted-foreground mt-0.5">Cards Sold</p>
                      </div>
                      <div className={`rounded-xl border p-2.5 text-center ${day.totalProfit !== undefined ? (day.totalProfit >= 0 ? "bg-profit/8 border-profit/20" : "bg-red-500/8 border-red-500/20") : "bg-background/70 border-border/60"}`}>
                        {day.totalProfit !== undefined ? (
                          <>
                            <p className={`text-xs font-black truncate ${day.totalProfit >= 0 ? "text-profit" : "text-red-400"}`}>
                              {day.totalProfit >= 0 ? "+" : ""}{formatCurrency(day.totalProfit, currency)}
                            </p>
                            <p className="text-[9px] text-muted-foreground mt-0.5">Profit</p>
                          </>
                        ) : (
                          <><p className="text-xs font-black text-muted-foreground/40">—</p><p className="text-[9px] text-muted-foreground mt-0.5">Profit</p></>
                        )}
                      </div>
                    </div>

                    {/* Pill summary row */}
                    <div className="flex items-center gap-2 flex-wrap">
                      {avgPerCard > 0 && (
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-secondary border border-border text-muted-foreground">
                          Avg {formatCurrency(avgPerCard, currency)} / card
                        </span>
                      )}
                      {day.topCard && (
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-500 truncate max-w-[160px]">
                          Top: {day.topCard}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Expanded detail */}
                  <AnimatePresence>
                    {isOpen && (
                      <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.18 }} className="overflow-hidden">
                        <div className="px-4 pb-4 pt-3 border-t border-border space-y-3">

                          {/* Breakdown */}
                          <div className="rounded-xl bg-background border border-border p-3 space-y-2">
                            <p className="text-[9px] text-muted-foreground uppercase tracking-widest font-bold">Day Breakdown</p>
                            <div className="space-y-1.5">
                              <div className="flex items-center justify-between text-xs">
                                <span className="text-muted-foreground">Cards sold</span>
                                <span className="font-bold">{day.cardsSold} card{day.cardsSold !== 1 ? "s" : ""}</span>
                              </div>
                              <div className="flex items-center justify-between text-xs">
                                <span className="text-muted-foreground">Total revenue</span>
                                <span className={`font-bold ${isToday ? "text-primary" : ""}`}>{formatCurrency(day.totalEarned, currency)}</span>
                              </div>
                              {avgPerCard > 0 && (
                                <div className="flex items-center justify-between text-xs">
                                  <span className="text-muted-foreground">Average per card</span>
                                  <span className="font-bold">{formatCurrency(avgPerCard, currency)}</span>
                                </div>
                              )}
                              {day.totalProfit !== undefined && (
                                <>
                                  <div className="h-px bg-border" />
                                  <div className="flex items-center justify-between text-xs">
                                    <span className="font-semibold">Net profit</span>
                                    <span className={`font-black ${day.totalProfit >= 0 ? "text-profit" : "text-red-400"}`}>
                                      {day.totalProfit >= 0 ? "+" : ""}{formatCurrency(day.totalProfit, currency)}
                                    </span>
                                  </div>
                                </>
                              )}
                            </div>
                          </div>

                          {day.topCard && (
                            <div className="flex items-center gap-2 rounded-xl bg-amber-500/5 border border-amber-500/20 px-3 py-2.5">
                              <Trophy className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                              <div className="min-w-0">
                                <p className="text-[9px] text-amber-500 uppercase tracking-widest font-bold mb-0.5">Top Sale</p>
                                <p className="text-xs font-bold truncate">{day.topCard}</p>
                                <p className="text-[10px] text-muted-foreground">{formatCurrency(day.topCardValue ?? 0, currency)}</p>
                              </div>
                            </div>
                          )}

                          <button
                            onClick={(e) => { e.stopPropagation(); deleteDailyEarning({ date: day.date }); }}
                            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold text-destructive hover:bg-destructive/10 transition-colors cursor-pointer border border-destructive/20"
                          >
                            <Trash2 className="w-3.5 h-3.5" /> Delete Day
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })
          )}
        </div>
      )}

      {/* ══ BUYING DEALS TAB ══ */}
      {activeTab === "deals" && (
        <div className="space-y-3">
          {/* Summary header */}
          {allDeals !== undefined && allDeals.length > 0 && (
            <div className="grid grid-cols-3 gap-2">
              <div className="rounded-xl border border-border bg-secondary/60 p-3 text-center">
                <p className="text-lg sm:text-xl font-black truncate">{allDeals.length}</p>
                <p className="text-[9px] text-muted-foreground mt-0.5">Total Deals</p>
              </div>
              <div className="rounded-xl border border-orange-500/20 bg-orange-500/5 p-3 text-center cursor-pointer transition-colors hover:bg-orange-500/10"
                onClick={(e) => { e.stopPropagation(); setShowTotalPaidPopup(v => !v); }}>
                <p className="text-lg sm:text-xl font-black text-orange-400 truncate">{formatCurrency(allDeals.reduce((s, d) => s + d.amountPaid, 0), currency)}</p>
                <p className="text-[9px] text-muted-foreground mt-0.5">Total Paid</p>
              </div>
              <div className="rounded-xl border border-profit/20 bg-profit/5 p-3 text-center cursor-pointer transition-colors hover:bg-profit/10"
                onClick={(e) => { e.stopPropagation(); setShowMarginHeldPopup(v => !v); }}>
                <p className="text-lg sm:text-xl font-black text-profit truncate">{formatCurrency(allDeals.reduce((s, d) => s + d.youKeep, 0), currency)}</p>
                <p className="text-[9px] text-muted-foreground mt-0.5">Margin Held</p>
              </div>
            </div>
          )}

          {/* Total Paid popup */}
          <AnimatePresence>
            {showTotalPaidPopup && allDeals && allDeals.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: -6, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -6, scale: 0.95 }}
                transition={{ duration: 0.15 }}
                className="rounded-xl border border-orange-500/30 bg-background shadow-lg p-4"
              >
                <div className="flex items-center justify-between mb-3">
                  <p className="text-[9px] text-muted-foreground uppercase tracking-widest font-bold">Total Paid Out</p>
                  <button onClick={(e) => { e.stopPropagation(); setShowTotalPaidPopup(false); }} className="w-7 h-7 rounded-lg bg-secondary flex items-center justify-center cursor-pointer hover:bg-secondary/80 transition-colors">
                    <X className="w-3.5 h-3.5 text-muted-foreground" />
                  </button>
                </div>
                <div className="rounded-lg bg-orange-500/5 border border-orange-500/20 p-3 text-center">
                  <p className="text-2xl font-black text-orange-400">{formatCurrency(allDeals.reduce((s, d) => s + d.amountPaid, 0), currency)}</p>
                  <p className="text-[9px] text-muted-foreground mt-1">Paid to sellers across {allDeals.length} deal{allDeals.length !== 1 ? "s" : ""}</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Margin Held popup */}
          <AnimatePresence>
            {showMarginHeldPopup && allDeals && allDeals.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: -6, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -6, scale: 0.95 }}
                transition={{ duration: 0.15 }}
                className="rounded-xl border border-profit/30 bg-background shadow-lg p-4"
              >
                <div className="flex items-center justify-between mb-3">
                  <p className="text-[9px] text-muted-foreground uppercase tracking-widest font-bold">Margin Held</p>
                  <button onClick={(e) => { e.stopPropagation(); setShowMarginHeldPopup(false); }} className="w-7 h-7 rounded-lg bg-secondary flex items-center justify-center cursor-pointer hover:bg-secondary/80 transition-colors">
                    <X className="w-3.5 h-3.5 text-muted-foreground" />
                  </button>
                </div>
                <div className="rounded-lg bg-profit/5 border border-profit/20 p-3 text-center">
                  <p className="text-2xl font-black text-profit">{formatCurrency(allDeals.reduce((s, d) => s + d.youKeep, 0), currency)}</p>
                  <p className="text-[9px] text-muted-foreground mt-1">Kept from {allDeals.length} deal{allDeals.length !== 1 ? "s" : ""}</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Deal list */}
          {allDeals === undefined ? (
            Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24 w-full rounded-xl" />)
          ) : allDeals.length === 0 ? (
            <div className="rounded-2xl border border-border bg-secondary/40 p-8 text-center">
              <ShoppingBag className="w-8 h-8 mx-auto mb-2 text-muted-foreground opacity-30" />
              <p className="text-sm font-semibold text-muted-foreground">No buying deals yet</p>
              <p className="text-xs text-muted-foreground mt-1">Use the Buyer Percentage Calculator on the Dashboard and tap Deal Accepted</p>
            </div>
          ) : (
            allDeals.map((deal, idx) => {
              const isOpen = expandedDeal === deal._id;
              const savingPct = Math.round(100 - deal.pct);
              return (
              <motion.div key={deal._id} layout initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
                className="rounded-2xl border border-border bg-secondary/30 overflow-hidden cursor-pointer transition-colors hover:bg-secondary/50"
                onClick={() => setExpandedDeal(isOpen ? null : deal._id)}>

                {/* Collapsed row */}
                <div className="px-4 py-3 space-y-2">
                  {/* Top line: date + deal # + chevron */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-md bg-orange-500/15 flex items-center justify-center shrink-0">
                        <ArrowDownLeft className="w-3.5 h-3.5 text-orange-400" />
                      </div>
                      <span className="text-[11px] text-muted-foreground font-medium">{formatDate(deal.at)}</span>
                      {deal.cardCount && deal.cardCount > 1 && (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-primary/10 text-primary">{deal.cardCount} cards</span>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-secondary border border-border text-muted-foreground">Deal #{allDeals.length - idx}</span>
                      {isOpen ? <ChevronUp className="w-3.5 h-3.5 text-muted-foreground" /> : <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />}
                    </div>
                  </div>

                  {/* Main numbers row */}
                  <div className="grid grid-cols-3 gap-2">
                    <div className="rounded-xl bg-background/70 border border-border/60 p-2.5 text-center">
                      <p className="text-xs font-black truncate">{formatCurrency(deal.cardPrice, currency)}</p>
                      <p className="text-[9px] text-muted-foreground mt-0.5">Card Value</p>
                    </div>
                    <div className="rounded-xl bg-orange-500/8 border border-orange-500/20 p-2.5 text-center">
                      <p className="text-xs font-black text-orange-400 truncate">{formatCurrency(deal.amountPaid, currency)}</p>
                      <p className="text-[9px] text-muted-foreground mt-0.5">You Paid</p>
                    </div>
                    <div className="rounded-xl bg-profit/8 border border-profit/20 p-2.5 text-center">
                      <p className="text-xs font-black text-profit truncate">{formatCurrency(deal.youKeep, currency)}</p>
                      <p className="text-[9px] text-muted-foreground mt-0.5">You Keep</p>
                    </div>
                  </div>

                  {/* Pill summary row */}
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-secondary border border-border text-muted-foreground">
                      Offered {deal.pct}% of value
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-profit/10 border border-profit/20 text-profit">
                      Saved {savingPct}%
                    </span>
                    {deal.note && (
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-500">
                        Note
                      </span>
                    )}
                  </div>
                </div>

                {/* Expanded detail */}
                <AnimatePresence>
                  {isOpen && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.18 }} className="overflow-hidden">
                      <div className="px-4 pb-4 pt-3 border-t border-border space-y-3">

                        {/* Breakdown explanation */}
                        <div className="rounded-xl bg-background border border-border p-3 space-y-2">
                          <p className="text-[9px] text-muted-foreground uppercase tracking-widest font-bold">Deal Breakdown</p>
                          <div className="space-y-1.5">
                            <div className="flex items-center justify-between text-xs">
                              <span className="text-muted-foreground">Seller's card value</span>
                              <span className="font-bold">{formatCurrency(deal.cardPrice, currency)}</span>
                            </div>
                            <div className="flex items-center justify-between text-xs">
                              <span className="text-muted-foreground">You offered ({deal.pct}%)</span>
                              <span className="font-bold text-orange-400">− {formatCurrency(deal.amountPaid, currency)}</span>
                            </div>
                            <div className="h-px bg-border" />
                            <div className="flex items-center justify-between text-xs">
                              <span className="font-semibold">Your margin / saving</span>
                              <span className="font-black text-profit">{formatCurrency(deal.youKeep, currency)} ({savingPct}%)</span>
                            </div>
                          </div>
                        </div>

                        {deal.note && (
                          <div className="rounded-xl bg-amber-500/5 border border-amber-500/20 p-3">
                            <p className="text-[9px] text-amber-500 uppercase tracking-widest font-bold mb-1">Note</p>
                            <p className="text-sm text-foreground whitespace-pre-wrap">{deal.note}</p>
                          </div>
                        )}
                        <button onClick={(e) => { e.stopPropagation(); deleteDeal({ id: deal._id }); }}
                          className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold text-destructive hover:bg-destructive/10 transition-colors cursor-pointer border border-destructive/20">
                          <Trash2 className="w-3.5 h-3.5" /> Delete Deal
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
              );
            })
          )}
        </div>
      )}

      {/* ══ CALENDAR TAB ══ */}
      {activeTab === "calendar" && (
        <div className="space-y-4">

          {/* Month nav + summary */}
          <div className="rounded-2xl border border-border bg-secondary/30 overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border">
              <Button variant="ghost" size="icon" className="h-8 w-8 rounded-xl" onClick={prevMonth}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <div className="text-center">
                <p className="text-base font-black tracking-wide">{monthName} {calYear}</p>
                {(sales ?? []).length > 0 && (
                  <p className="text-[10px] text-muted-foreground mt-0.5">{(sales ?? []).length} card{(sales ?? []).length !== 1 ? "s" : ""} sold</p>
                )}
              </div>
              <Button variant="ghost" size="icon" className="h-8 w-8 rounded-xl" onClick={nextMonth}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>

            {/* Month total strip */}
            {totalEarnings > 0 && (
              <div className="flex items-center justify-between px-4 py-2.5 bg-primary/5 border-b border-primary/10">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-3.5 h-3.5 text-primary" />
                  <span className="text-[11px] text-muted-foreground font-medium">Month Revenue</span>
                </div>
                <span className="text-sm font-black text-primary truncate">{formatCurrency(totalEarnings, currency)}</span>
              </div>
            )}

            {/* Legend */}
            <div className="flex items-center gap-4 px-4 py-2 bg-secondary/20">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded bg-primary/30 border border-primary/50" />
                <span className="text-[9px] text-muted-foreground">Sales</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                <span className="text-[9px] text-muted-foreground">Note</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-profit" />
                <span className="text-[9px] text-muted-foreground">Buys</span>
              </div>
            </div>

            {/* Calendar grid */}
            <div className="p-3">
              <div className="grid grid-cols-7 gap-1 text-center mb-1">
                {["S","M","T","W","T","F","S"].map((d, i) => (
                  <div key={i} className="text-[10px] font-black text-muted-foreground/60 py-0.5">{d}</div>
                ))}
              </div>
              <div className="grid grid-cols-7 gap-1">
                {cells.map((day, i) => {
                  if (!day) return <div key={`e-${i}`} />;
                  const amount = salesByDay.get(day);
                  const note = notesByDay.get(day);
                  const dayDateStr = `${calYear}-${String(calMonth).padStart(2,"0")}-${String(day).padStart(2,"0")}`;
                  const hasDeal = dealsByDate.has(dayDateStr);
                  const isToday = day === todayDate.getDate() && calMonth === todayDate.getMonth() + 1 && calYear === todayDate.getFullYear();
                  const isSelected = selectedDay === day;
                  // Heat map intensity based on relative earnings
                  const intensity = amount && maxDayEarnings > 0 ? amount / maxDayEarnings : 0;
                  const heatOpacity = intensity > 0 ? Math.max(0.15, intensity * 0.7) : 0;

                  return (
                    <button
                      key={day}
                      onClick={() => isSelected ? closeNote() : openDay(day)}
                      className={`cursor-pointer aspect-square rounded-xl flex flex-col items-center justify-center relative transition-all duration-150 overflow-hidden
                        ${isSelected
                          ? "ring-2 ring-primary border-2 border-primary bg-primary/20 scale-105 shadow-lg shadow-primary/20"
                          : isToday
                          ? "ring-2 ring-primary/60 border border-primary/40 bg-secondary"
                          : amount
                          ? "border border-primary/30 hover:border-primary/60 hover:scale-105"
                          : "border border-border/40 bg-card/60 hover:bg-secondary/50 hover:border-border"
                        }`}
                      style={amount && !isSelected ? {
                        background: `rgba(var(--primary-rgb, 204, 0, 0), ${heatOpacity})`,
                      } : undefined}
                    >
                      <span className={`text-xs leading-none font-bold ${isToday ? "text-primary" : isSelected ? "text-primary" : amount ? "text-foreground" : "text-muted-foreground"}`}>
                        {day}
                      </span>
                      {amount !== undefined && (
                        <span className="text-[8px] font-black leading-tight mt-0.5 text-primary/90">
                          {formatCurrency(amount, currency).replace(/^[£$€]/, "")}
                        </span>
                      )}
                      {/* Dots row */}
                      {(note || hasDeal) && (
                        <div className="flex gap-0.5 mt-0.5">
                          {note && <span className="w-1 h-1 rounded-full bg-amber-500" />}
                          {hasDeal && <span className="w-1 h-1 rounded-full bg-profit" />}
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Day detail panel */}
          <AnimatePresence>
            {selectedDay !== null && (
              <motion.div
                initial={{ opacity: 0, y: -10, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -6, scale: 0.98 }}
                transition={{ duration: 0.2, ease: [0.25, 0.1, 0.25, 1] as const }}
                className="rounded-2xl border border-primary/30 bg-secondary/40 overflow-hidden"
              >
                {/* Day header */}
                <div className="flex items-center justify-between px-4 py-3 border-b border-border/60 bg-primary/5">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-primary/20 flex items-center justify-center">
                      <CalendarIcon className="w-3.5 h-3.5 text-primary" />
                    </div>
                    <span className="font-bold text-sm">
                      {new Date(calYear, calMonth - 1, selectedDay).toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short" })}
                    </span>
                  </div>
                  <button onClick={closeNote} className="cursor-pointer w-6 h-6 flex items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="p-4 space-y-3">
                  {/* Sales summary for this day */}
                  {selectedDaySales.length > 0 && (
                    <div className="rounded-xl border border-primary/20 bg-primary/5 p-3 space-y-2">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-primary shrink-0" />
                        <p className="text-[10px] font-black uppercase tracking-widest text-primary flex-1">Sales</p>
                        <p className="text-xs font-black text-primary">{formatCurrency(salesByDay.get(selectedDay) ?? 0, currency)}</p>
                      </div>
                      <p className="text-[10px] text-muted-foreground">Cards you sold on this day</p>
                      <div className="space-y-1">
                        {selectedDaySales.map(card => (
                          <div key={card._id} className="flex items-center justify-between px-3 py-2 rounded-lg bg-background/70 border border-border/50">
                            <span className="text-xs font-semibold truncate flex-1 mr-2">{card.name}</span>
                            <span className="text-xs font-black text-primary shrink-0">{formatCurrency(card.salePrice ?? card.marketValue ?? 0, currency)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Buying deals for this day */}
                  {selectedDayDeals.length > 0 && (
                    <div className="rounded-xl border border-profit/20 bg-profit/5 p-3 space-y-2">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-profit shrink-0" />
                        <p className="text-[10px] font-black uppercase tracking-widest text-profit flex-1">Buying Deals</p>
                        <p className="text-xs font-black text-profit">{formatCurrency(selectedDayDeals.reduce((s, d) => s + d.amountPaid, 0), currency)} paid</p>
                      </div>
                      <p className="text-[10px] text-muted-foreground">Cards you bought from sellers using the Buyer Percentage Calculator</p>
                      <div className="space-y-1">
                        {selectedDayDeals.map(deal => (
                          <div key={deal._id} className="px-3 py-2 rounded-lg bg-background/70 border border-profit/20 space-y-0.5">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-semibold">{formatCurrency(deal.cardPrice, currency)} card · {deal.pct}%</span>
                              <span className="text-xs font-black text-profit">{formatCurrency(deal.amountPaid, currency)}</span>
                            </div>
                            {deal.note && <p className="text-[10px] text-muted-foreground">{deal.note}</p>}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* No activity */}
                  {selectedDaySales.length === 0 && selectedDayDeals.length === 0 && !notesByDay.has(selectedDay) && (
                    <p className="text-xs text-muted-foreground text-center py-1">No sales or deals on this day</p>
                  )}

                  {/* Notes section */}
                  <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-3 space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-amber-500 shrink-0" />
                      <StickyNote className="w-3.5 h-3.5 text-amber-500" />
                      <p className="text-[10px] font-black uppercase tracking-widest text-amber-500 flex-1">Notes</p>
                      {notesByDay.has(selectedDay) && (
                        <span className="text-[9px] text-muted-foreground">({(notesByDay.get(selectedDay) ?? []).length}/5)</span>
                      )}
                    </div>
                    <p className="text-[10px] text-muted-foreground">Personal reminders for this day — only visible to you</p>

                    {/* Existing notes list */}
                    {(notesByDay.get(selectedDay) ?? []).map((n) => (
                      <div key={n._id} className="rounded-lg border border-amber-500/30 bg-amber-500/5 px-3 py-2 space-y-1.5">
                        {editingNoteId === n._id ? (
                          <>
                            <Textarea
                              value={editingNoteText}
                              onChange={e => setEditingNoteText(e.target.value)}
                              rows={2}
                              className="resize-none text-sm bg-background/60"
                              onKeyDown={e => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) void saveEditNote(); }}
                              autoFocus
                            />
                            <div className="flex gap-2">
                              <Button size="sm" className="flex-1 gap-1" onClick={saveEditNote} disabled={savingNote}>
                                <Check className="w-3 h-3" />
                                {savingNote ? "Saving…" : "Save"}
                              </Button>
                              <Button size="sm" variant="ghost" className="px-3" onClick={() => { setEditingNoteId(null); setEditingNoteText(""); }}>
                                Cancel
                              </Button>
                            </div>
                          </>
                        ) : (
                          <div className="flex items-start gap-2">
                            <p className="text-xs text-foreground/90 whitespace-pre-wrap leading-relaxed flex-1">{n.note}</p>
                            <div className="flex gap-1 shrink-0">
                              <button
                                onClick={() => { setEditingNoteId(n._id); setEditingNoteText(n.note); }}
                                className="text-amber-500/60 hover:text-amber-500 transition-colors cursor-pointer p-0.5"
                                title="Edit note"
                              >
                                <Pencil className="w-3 h-3" />
                              </button>
                              <button
                                onClick={() => void deleteNote(n._id)}
                                disabled={savingNote}
                                className="text-destructive/60 hover:text-destructive transition-colors cursor-pointer disabled:opacity-40 p-0.5"
                                title="Delete note"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}

                    {/* Add new note */}
                    {(notesByDay.get(selectedDay) ?? []).length < 5 && (
                      <div className="space-y-1.5">
                        <Textarea
                          ref={noteRef}
                          value={newNoteText}
                          onChange={e => setNewNoteText(e.target.value)}
                          placeholder="e.g. London Card Show — bring Charizard binder"
                          rows={2}
                          className="resize-none text-sm bg-background/60"
                          onKeyDown={e => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) void addNote(); }}
                        />
                        <div className="flex gap-2">
                          <Button size="sm" className="flex-1 gap-1.5" onClick={addNote} disabled={savingNote || !newNoteText.trim()}>
                            <Check className="w-3 h-3" />
                            {savingNote ? "Saving…" : "Add Note"}
                          </Button>
                        </div>
                        <p className="text-[10px] text-muted-foreground">Cmd/Ctrl + Enter to add</p>
                      </div>
                    )}
                    {(notesByDay.get(selectedDay) ?? []).length >= 5 && (
                      <p className="text-[10px] text-muted-foreground text-center">Max 5 notes reached for this day</p>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

        </div>
      )}

      {/* ── Fixed Recalculate button ── */}
      <div className="fixed bottom-20 md:bottom-6 right-4 md:right-8 z-40">
        <Button
          size="sm"
          className="gap-1.5 shadow-lg rounded-full px-4"
          onClick={handleRebuild}
          disabled={rebuilding}
        >
          <RefreshCw className={`w-3.5 h-3.5 ${rebuilding ? "animate-spin" : ""}`} />
          {rebuilding ? "Recalculating…" : "Recalculate"}
        </Button>
      </div>
    </div>
  );
}
