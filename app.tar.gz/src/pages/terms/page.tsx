import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, Shield, ArrowUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useEffect, useRef, useState } from "react";

type Section = {
  id: string;
  title: string;
  content: React.ReactNode;
};

const sections: Section[] = [
  {
    id: "01",
    title: "About DatCARDVault",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          DatCARDVault is a <span className="font-semibold text-primary">TCG inventory and collection management platform</span> designed to make managing trading cards faster and easier.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">Depending on the features available to you, the Service may allow you to:</p>
        <ul className="space-y-2 pl-1">
          {[
            "Scan trading cards",
            "Add cards to your inventory",
            "Store and organise card information",
            "Track card quantities and conditions",
            "Record purchase prices and selling prices",
            "Track estimated card values",
            "Create and manage inventory",
            "Organise cards into collections",
            "Create labels or other inventory identifiers",
            "Manage cards for vending or selling",
            "Track stock",
            "Search and filter inventory",
            "Add notes and additional information",
            "Export or otherwise use your inventory information",
            "Access other card-management tools introduced by DatCARDVault",
          ].map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
        <p className="text-sm text-muted-foreground leading-relaxed">
          DatCARDVault is a management and organisational tool. Unless expressly stated otherwise, DatCARDVault does <span className="font-semibold text-foreground">not</span> act as a marketplace, card dealer, grading company, financial adviser, payment processor, authentication service, or guarantor of card values.
        </p>
      </div>
    ),
  },
  {
    id: "02",
    title: "Acceptance of These Terms",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-muted-foreground leading-relaxed">By creating an account, accessing the Service, or using any DatCARDVault feature, you confirm that:</p>
        <ol className="space-y-2 pl-1 list-none">
          {[
            "You have read these Terms",
            "You understand these Terms",
            "You agree to comply with these Terms",
            "You have the legal authority to enter into this agreement",
          ].map((item, i) => (
            <li key={i} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
              <span className="text-primary font-black text-xs mt-0.5 w-4 shrink-0">{i + 1}.</span>
              {item}
            </li>
          ))}
        </ol>
        <p className="text-sm text-muted-foreground leading-relaxed">If you do not agree to these Terms, you must stop using DatCARDVault.</p>
      </div>
    ),
  },
  {
    id: "03",
    title: "Eligibility",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">You must be legally capable of entering into a binding agreement to use DatCARDVault.</p>
        <p className="text-sm text-muted-foreground leading-relaxed">If you use DatCARDVault on behalf of a company, business, organisation, vendor, or other entity, you confirm that you have authority to accept these Terms on its behalf.</p>
        <p className="text-sm text-muted-foreground leading-relaxed">You are responsible for ensuring that your use of DatCARDVault complies with all laws and regulations applicable to you.</p>
      </div>
    ),
  },
  {
    id: "04",
    title: "Your DatCARDVault Account",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-muted-foreground leading-relaxed">Some DatCARDVault features may require you to create an account. You are responsible for:</p>
        <ul className="space-y-2 pl-1">
          {[
            "Providing accurate information",
            "Keeping your login details confidential",
            "Maintaining the security of your account",
            "Preventing unauthorised access",
            "Ensuring information associated with your account remains accurate",
            "All activity carried out through your account",
          ].map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
        <p className="text-sm text-muted-foreground leading-relaxed">You must not knowingly allow another person to access your account in a way that violates these Terms. If you believe your account has been accessed without permission, contact DatCARDVault as soon as reasonably possible.</p>
      </div>
    ),
  },
  {
    id: "05",
    title: "Your Card Inventory",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">DatCARDVault allows you to record and manage information about trading cards. You remain responsible for the accuracy of the information you enter.</p>
        <p className="text-sm text-muted-foreground leading-relaxed">DatCARDVault does not guarantee that information entered by you is accurate, complete, current, or suitable for any particular purpose. You should verify important information before using it for sales, purchases, insurance, tax records, accounting, or other business purposes.</p>
      </div>
    ),
  },
  {
    id: "06",
    title: "Card Scanning",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">DatCARDVault may provide card scanning, image recognition, barcode recognition, or similar functionality. Scanning technology may not always correctly identify a card.</p>
        <p className="text-sm text-muted-foreground leading-relaxed">Factors including image quality, lighting, card condition, language, printing variations, sets, and database availability may affect identification. You are responsible for checking the card information returned by the Service before adding it to your inventory or relying upon it.</p>
      </div>
    ),
  },
  {
    id: "07",
    title: "Card Prices and Market Values",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">DatCARDVault may display, calculate, or allow you to record card prices or estimated values.</p>
        <p className="text-sm text-muted-foreground leading-relaxed">Any price or value shown within DatCARDVault is provided for <span className="font-semibold text-foreground">informational and organisational purposes only</span>. DatCARDVault does not guarantee that a card can be sold for any displayed price or estimated value. You are responsible for independently verifying market prices before making financial decisions.</p>
      </div>
    ),
  },
  {
    id: "08",
    title: "No Financial or Investment Advice",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">DatCARDVault is not a financial advisory service. Nothing within the Service should be considered financial advice, investment advice, tax advice, accounting advice, legal advice, or a recommendation to purchase, sell, trade, or hold any trading card.</p>
        <p className="text-sm text-muted-foreground leading-relaxed">Trading cards can increase or decrease in value and may be difficult to sell at a particular price. You are solely responsible for your own purchasing, selling, collecting, trading, and investment decisions.</p>
      </div>
    ),
  },
  {
    id: "09",
    title: "Vendors and Sellers",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">DatCARDVault may provide features specifically designed for TCG vendors, sellers, dealers, and businesses including inventory management, scanning, pricing, labelling, and sales tracking.</p>
        <p className="text-sm text-muted-foreground leading-relaxed">DatCARDVault does not guarantee that use of the Service will result in increased sales, profits, customers, or business performance. You are solely responsible for your products, pricing, sales, customers, refunds, taxes, and business operations.</p>
      </div>
    ),
  },
  {
    id: "10",
    title: "Buying, Selling and Trading Cards",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">Unless expressly stated otherwise, DatCARDVault does not purchase, sell, trade, broker, or physically handle trading cards on your behalf.</p>
        <p className="text-sm text-muted-foreground leading-relaxed">Any transaction you arrange with another person or business is your responsibility. DatCARDVault is not responsible for card condition, authenticity, counterfeit products, pricing disputes, payment disputes, shipping disputes, refunds, or disputes between buyers and sellers.</p>
      </div>
    ),
  },
  {
    id: "11",
    title: "Third-Party Marketplaces and Services",
    content: (
      <p className="text-sm text-foreground leading-relaxed">DatCARDVault may reference, integrate with, or provide functionality relating to third-party marketplaces, card databases, pricing services, payment providers, or other external services. Third-party services are independent from DatCARDVault unless expressly stated otherwise. We do not guarantee the availability, accuracy, security, pricing, content, or policies of third-party services.</p>
    ),
  },
  {
    id: "12",
    title: "Card Databases and Third-Party Information",
    content: (
      <p className="text-sm text-foreground leading-relaxed">DatCARDVault may use third-party data sources, databases, APIs, or other information providers to supply card information. Third-party data may contain errors, omissions, outdated information, or incorrect prices. DatCARDVault does not guarantee that third-party information is accurate, complete, or current.</p>
    ),
  },
  {
    id: "13",
    title: "Your Content",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">You may upload or provide content to DatCARDVault including card images, inventory information, photos, notes, labels, prices, and other content. You retain ownership of content that you submit, subject to the rights required for us to operate the Service.</p>
        <p className="text-sm text-muted-foreground leading-relaxed">By submitting content, you grant DatCARDVault the limited rights necessary to store, process, reproduce, display, and otherwise use that content solely for providing, maintaining, improving, and securing the Service. You are responsible for ensuring that you have the necessary rights to upload any content.</p>
      </div>
    ),
  },
  {
    id: "14",
    title: "Prohibited Content",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-muted-foreground leading-relaxed">You must not upload, store, transmit, or distribute content through DatCARDVault that:</p>
        <ul className="space-y-2 pl-1">
          {[
            "Is unlawful",
            "Infringes another person's intellectual property rights",
            "Contains malicious software",
            "Is fraudulent or deliberately misleading",
            "Attempts to impersonate another person or business",
            "Attempts to compromise the Service",
            "Contains unauthorised personal information",
            "Promotes illegal activity",
            "Violates these Terms",
          ].map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
      </div>
    ),
  },
  {
    id: "15",
    title: "Intellectual Property",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">DatCARDVault and its associated software, technology, branding, designs, graphics, logos, interfaces, features, text, databases, and other materials are owned by or licensed to DatCARDVault.</p>
        <p className="text-sm text-muted-foreground leading-relaxed">You are granted a limited, non-exclusive, non-transferable, revocable licence to use the Service for its intended purpose. You must not copy, reproduce, resell, reverse engineer, scrape, or use the Service to create a competing product without our written permission.</p>
      </div>
    ),
  },
  {
    id: "16",
    title: "DatCARDVault Branding",
    content: (
      <p className="text-sm text-foreground leading-relaxed">The DatCARDVault name, logo, branding, designs, slogans, and related intellectual property belong to DatCARDVault. You may not use our branding in a manner that suggests an unauthorised partnership, sponsorship, endorsement, or affiliation.</p>
    ),
  },
  {
    id: "17",
    title: "Subscriptions and Paid Features",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">DatCARDVault may offer free features, paid features, subscriptions, upgrades, credits, or other paid services. The applicable price and billing terms will be displayed before purchase.</p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          <span className="font-semibold text-foreground">Right to Cancel (Cooling-Off Period):</span> If you are a UK consumer, you have the right to cancel a digital subscription within 14 days of purchase without giving a reason. However, if you begin using the service within that 14-day period and you have expressly agreed to waive your cancellation right at the point of purchase, you may lose the right to a refund for the portion of the service already delivered.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">Subscriptions may automatically renew unless cancelled before the next billing period. Unless required by applicable law or expressly stated otherwise, payments may be non-refundable once a billing period has started and the cooling-off right has been waived or expired.</p>
      </div>
    ),
  },
  {
    id: "18",
    title: "Changes to Pricing",
    content: (
      <p className="text-sm text-foreground leading-relaxed">We reserve the right to change the pricing of DatCARDVault subscriptions or paid features. Where required by applicable law, we will provide appropriate notice of material pricing changes. Changes will generally apply to future billing periods rather than periods that have already been paid for.</p>
    ),
  },
  {
    id: "19",
    title: "Data Storage and Backups",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">DatCARDVault may store your account information, inventory, card data, images, notes, and other information on our systems or systems operated by service providers.</p>
        <p className="text-sm text-muted-foreground leading-relaxed">Although we take reasonable measures to protect stored information, we cannot guarantee that data will never be lost, corrupted, or become unavailable. You should maintain independent backups of important information. DatCARDVault should not be considered your sole backup or permanent archival system.</p>
      </div>
    ),
  },
  {
    id: "20",
    title: "Service Availability",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">We aim to provide a reliable Service but do not guarantee that DatCARDVault will always be available or operate without interruption.</p>
        <p className="text-sm text-muted-foreground leading-relaxed">The Service may become temporarily unavailable due to maintenance, software updates, technical failures, third-party service failures, security incidents, or circumstances outside our reasonable control.</p>
      </div>
    ),
  },
  {
    id: "21",
    title: "Updates",
    content: (
      <p className="text-sm text-foreground leading-relaxed">DatCARDVault may receive updates, improvements, security patches, bug fixes, and new features. Some updates may be required for continued access to certain features. We may modify, replace, or discontinue features at any time where reasonably necessary.</p>
    ),
  },
  {
    id: "22",
    title: "Acceptable Use",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-muted-foreground leading-relaxed">You agree not to use DatCARDVault to:</p>
        <ul className="space-y-2 pl-1">
          {[
            "Break the law",
            "Commit fraud",
            "Store unlawful content",
            "Attack or compromise our systems",
            "Attempt to access another user's account",
            "Circumvent security measures",
            "Reverse engineer the Service",
            "Scrape or harvest data without permission",
            "Introduce viruses or malicious code",
            "Overload or disrupt our infrastructure",
            "Create fake or fraudulent accounts",
            "Circumvent subscription or payment systems",
            "Resell access without permission",
            "Build or operate a competing service using DatCARDVault",
          ].map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
      </div>
    ),
  },
  {
    id: "23",
    title: "Account Suspension and Termination",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-muted-foreground leading-relaxed">We may suspend, restrict, or terminate your account if we reasonably believe that you have breached these Terms, used DatCARDVault unlawfully, attempted to compromise the Service, engaged in fraudulent activity, or failed to pay applicable fees.</p>
        <p className="text-sm text-foreground leading-relaxed">You may stop using DatCARDVault at any time. Where appropriate, we may provide notice before suspension or termination.</p>
      </div>
    ),
  },
  {
    id: "24",
    title: "Effect of Termination",
    content: (
      <p className="text-sm text-foreground leading-relaxed">Following termination, your right to access the Service may end. Certain provisions of these Terms will continue to apply after termination, including provisions relating to intellectual property, liability, disclaimers, indemnification, and dispute resolution. Where applicable, we may provide you with an opportunity to export your information before account termination.</p>
    ),
  },
  {
    id: "25",
    title: "Privacy",
    content: (
      <p className="text-sm text-foreground leading-relaxed">Your privacy is important to us. Our collection, use, storage, and processing of personal information is explained in our <span className="font-semibold text-primary">Privacy Policy</span>. By using DatCARDVault, you acknowledge that your information may be processed in accordance with our Privacy Policy and applicable data protection laws.</p>
    ),
  },
  {
    id: "26",
    title: "Third-Party Links and Services",
    content: (
      <p className="text-sm text-foreground leading-relaxed">DatCARDVault may contain links to third-party websites, services, marketplaces, or resources. We do not control and are not responsible for third-party websites or services. A link or integration does not mean that DatCARDVault endorses or is affiliated with the third party. You access third-party services at your own risk.</p>
    ),
  },
  {
    id: "27",
    title: "Disclaimer of Warranties",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">To the maximum extent permitted by applicable law, DatCARDVault is provided on an <span className="font-semibold text-primary">"as is" and "as available"</span> basis.</p>
        <p className="text-sm text-muted-foreground leading-relaxed">We do not guarantee that the Service will always be available, error-free, that card information will always be accurate, that card scans will always correctly identify cards, or that calculations will always be correct. You are responsible for verifying important information before relying upon it.</p>
      </div>
    ),
  },
  {
    id: "28",
    title: "Limitation of Liability",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">To the maximum extent permitted by applicable law, DatCARDVault, its owners, directors, employees, contractors, affiliates, and service providers will not be liable for indirect, incidental, special, consequential, or punitive losses arising from your use of the Service.</p>
        <p className="text-sm text-muted-foreground leading-relaxed">Nothing in these Terms excludes or limits liability that cannot legally be excluded or limited.</p>
      </div>
    ),
  },
  {
    id: "29",
    title: "Your Responsibility",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">You are responsible for your own use of DatCARDVault and for decisions made using information obtained through the Service.</p>
        <p className="text-sm text-muted-foreground leading-relaxed">DatCARDVault is a tool to assist you and should not replace professional advice or appropriate record-keeping practices. You should independently verify important information relating to card authenticity, card value, market prices, taxes, and accounting records.</p>
      </div>
    ),
  },
  {
    id: "30",
    title: "Indemnification",
    content: (
      <p className="text-sm text-foreground leading-relaxed">To the maximum extent permitted by applicable law, you agree to indemnify and hold harmless DatCARDVault and its owners, directors, employees, contractors, affiliates, and service providers against claims, losses, liabilities, damages, costs, and expenses arising from your breach of these Terms, misuse of the Service, violation of applicable laws, infringement of another person's rights, or content you upload or submit.</p>
    ),
  },
  {
    id: "31",
    title: "Changes to These Terms",
    content: (
      <p className="text-sm text-foreground leading-relaxed">We may update these Terms from time to time. When appropriate, we may notify users of significant changes through the Service, email, or another reasonable method. Your continued use of DatCARDVault after the effective date means that you accept the updated Terms.</p>
    ),
  },
  {
    id: "32",
    title: "Governing Law",
    content: (
      <p className="text-sm text-foreground leading-relaxed">These Terms shall be governed by the laws of <span className="font-semibold text-primary">England and Wales</span>, subject to any mandatory consumer protection rights applicable to you in your jurisdiction.</p>
    ),
  },
  {
    id: "33",
    title: "Consumer Rights",
    content: (
      <p className="text-sm text-foreground leading-relaxed">If you are a consumer, you may have statutory rights under applicable consumer protection legislation. Nothing in these Terms is intended to exclude, restrict, or reduce any rights that cannot legally be excluded or limited.</p>
    ),
  },
  {
    id: "34",
    title: "No Partnership",
    content: (
      <p className="text-sm text-foreground leading-relaxed">Nothing in these Terms creates or establishes a partnership, joint venture, employment relationship, agency relationship, or franchise between you and DatCARDVault. Your use of DatCARDVault does not make you an employee, agent, representative, or partner of DatCARDVault.</p>
    ),
  },
  {
    id: "35",
    title: "Severability",
    content: (
      <p className="text-sm text-foreground leading-relaxed">If any provision of these Terms is determined to be unlawful, invalid, or unenforceable, that provision will be interpreted or modified to the minimum extent necessary to make it enforceable. The remaining provisions will continue in full force and effect.</p>
    ),
  },
  {
    id: "36",
    title: "Entire Agreement",
    content: (
      <p className="text-sm text-foreground leading-relaxed">These Terms, together with any additional terms, policies, or agreements expressly incorporated into them, constitute the agreement between you and DatCARDVault regarding your use of the Service. They replace any previous agreements or understandings relating to your use of the Service, except where otherwise expressly stated.</p>
    ),
  },
  {
    id: "37",
    title: "Third-Party Trademarks",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">DatCARDVault references the names of trading card games and their publishers solely to describe the types of cards that can be managed within the Service.</p>
        <p className="text-sm text-muted-foreground leading-relaxed">All trading card game names, logos, and related trademarks — including but not limited to Pokémon, Magic: The Gathering, Yu-Gi-Oh!, One Piece, Flesh and Blood, Lorcana, Digimon, and others — are the property of their respective owners. DatCARDVault is <span className="font-semibold text-foreground">not affiliated with, endorsed by, or sponsored by</span> any trading card game publisher.</p>
      </div>
    ),
  },
  {
    id: "38",
    title: "Contact",
    content: (
      <div className="space-y-2">
        <p className="text-sm text-foreground leading-relaxed">If you have questions regarding these Terms, your account, or DatCARDVault, you can contact us using the contact details provided through <span className="font-semibold text-primary">DatCARDVault.com</span> or within the Service.</p>
      </div>
    ),
  },
];

export default function TermsPage() {
  const navigate = useNavigate();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [showBackToTop, setShowBackToTop] = useState(false);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => {
      // Show button when near the bottom (within 600px)
      const nearBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - 600;
      setShowBackToTop(nearBottom);
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll);
  }, []);

  const scrollToTop = () => {
    scrollRef.current?.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div ref={scrollRef} className="min-h-screen bg-background flex flex-col items-center p-4 md:p-6 pb-12 relative overflow-y-auto h-screen">
      {/* Subtle background */}
      <div className="absolute inset-0 pointer-events-none select-none overflow-hidden">
        <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at 30% 20%, rgba(204,0,0,0.08) 0%, transparent 60%), radial-gradient(ellipse at 70% 80%, rgba(204,0,0,0.05) 0%, transparent 60%)" }} />
      </div>

      <div className="relative z-10 w-full max-w-2xl">
        {/* Back button */}
        <motion.button
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </motion.button>

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="flex items-center gap-3 mb-8"
        >
          <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
            <Shield className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-black tracking-wide text-foreground">Terms & Conditions</h1>
            <p className="text-xs text-muted-foreground mt-0.5">DatCARDVault · Last Updated: 10 August 2026</p>
          </div>
        </motion.div>

        {/* Intro card */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="rounded-2xl border border-border bg-card p-5 md:p-6 mb-4 space-y-3"
        >
          <p className="text-sm text-foreground leading-relaxed">
            Welcome to <span className="font-bold text-primary">DatCARDVault</span> ("DatCARDVault", "we", "our", or "us").
          </p>
          <p className="text-sm text-muted-foreground leading-relaxed">
            DatCARDVault is a <span className="font-semibold text-foreground">Pocket Business Assistant</span> platform designed to help TCG collectors, sellers, vendors, traders, and businesses manage and organise their card inventory and related information.
          </p>
          <p className="text-sm text-muted-foreground leading-relaxed">
            By accessing or using <span className="font-semibold text-foreground">DatCARDVault.com</span>, the DatCARDVault web application, mobile application, or any related services (collectively, the "Service"), you agree to be legally bound by these Terms & Conditions ("Terms").
          </p>
          <div className="rounded-xl bg-primary/5 border border-primary/20 p-3">
            <p className="text-xs text-muted-foreground leading-relaxed">
              <span className="font-bold text-foreground">If you do not agree to these Terms, you must not access or use the Service.</span>
            </p>
          </div>
        </motion.div>

        {/* Sections */}
        <div className="space-y-3">
          {sections.map((section, i) => (
            <motion.div
              key={section.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.12 + i * 0.015 }}
              className="rounded-2xl border border-border bg-card p-5 md:p-6 space-y-4"
            >
              <div className="flex items-center gap-2.5">
                <span className="text-xs font-black text-primary tracking-widest tabular-nums">{section.id}</span>
                <div className="h-px flex-1 bg-border" />
                <h2 className="text-sm font-bold text-foreground">{section.title}</h2>
              </div>
              {section.content}
            </motion.div>
          ))}
        </div>

        {/* Final Agreement */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="mt-4 rounded-2xl border border-primary/30 bg-primary/5 p-5 md:p-6 space-y-3 text-center"
        >
          <p className="text-sm font-bold text-foreground leading-relaxed">
            By accessing or using DatCARDVault, you acknowledge that you have read, understood, and agreed to these Terms & Conditions.
          </p>
          <p className="text-xs text-primary font-black tracking-widest uppercase">
            DatCARDVault — The Pocket Business Assistant For TCG Vendors!
          </p>
        </motion.div>

        {/* Footer */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="mt-6 text-center"
        >
          <p className="text-[10px] text-muted-foreground tracking-widest uppercase">
            Dat<span className="text-primary font-bold">CARD</span>Vault · Scan · Store · Label
          </p>
          <p className="text-[10px] text-muted-foreground mt-1">© {new Date().getFullYear()} DatCARDVault™ All rights reserved.</p>
        </motion.div>
      </div>

      {/* Back to Top button */}
      <AnimatePresence>
        {showBackToTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 8 }}
            transition={{ duration: 0.2 }}
            onClick={scrollToTop}
            className="fixed bottom-8 right-6 z-50 flex items-center gap-2 px-4 py-2.5 rounded-full bg-primary text-primary-foreground text-xs font-black tracking-widest shadow-lg hover:bg-primary/90 transition-colors cursor-pointer"
          >
            <ArrowUp className="w-3.5 h-3.5" />
            Back to Top
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}
