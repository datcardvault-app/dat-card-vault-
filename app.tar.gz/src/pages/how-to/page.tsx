import { motion } from "motion/react";
import React from "react";
import { useNavigate } from "react-router-dom";
import {
  LayoutDashboard, Package, Tag, ScanLine, TrendingUp,
  Settings, Zap, Printer, Star, CheckCircle2, AlertCircle,
  ChevronRight, Camera, QrCode, DollarSign, RefreshCw,
  BarChart3, Calendar, Bluetooth, Sparkles, ArrowRight,
  AtSign, Globe, Building2, Shield, Mail,
  Wifi, Users, Banknote, CreditCard,
  Bell, MousePointerClick, SortAsc, TrendingDown, ShoppingCart, Receipt, ShoppingBag, Target,
  Sun, Moon, MoveVertical, Minus, Plus, Barcode, FileText, Clock, Pencil, Square,
} from "lucide-react";

/* ─── Version badges (update these when bumping versions) ─── */
const BUILD_VERSION = "1.8";
const UI_VERSION = "1.8";

/* ─── Shared fade-in ─── */
function Fade({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.45, delay, ease: [0.25, 0.1, 0.25, 1] as const }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

/* ─── Scroll cue animated label ─── */
const SCROLL_LABEL = "The pocket business assistant for TCG vendors complete guide.";
function ScrollCueLabel() {
  const [displayed, setDisplayed] = React.useState("");
  const [phase, setPhase] = React.useState<"typing" | "pause" | "erasing">("typing");

  React.useEffect(() => {
    let timeout: ReturnType<typeof setTimeout>;
    if (phase === "typing") {
      if (displayed.length < SCROLL_LABEL.length) {
        timeout = setTimeout(() => setDisplayed(SCROLL_LABEL.slice(0, displayed.length + 1)), 55);
      } else {
        timeout = setTimeout(() => setPhase("pause"), 2200);
      }
    } else if (phase === "pause") {
      timeout = setTimeout(() => setPhase("erasing"), 400);
    } else {
      if (displayed.length > 0) {
        timeout = setTimeout(() => setDisplayed(SCROLL_LABEL.slice(0, displayed.length - 1)), 30);
      } else {
        timeout = setTimeout(() => setPhase("typing"), 600);
      }
    }
    return () => clearTimeout(timeout);
  }, [displayed, phase]);

  return (
    <span className="text-sm font-bold tracking-[0.12em] text-primary/80 uppercase flex items-center">
      {displayed}
      <motion.span
        animate={{ opacity: [1, 0] }}
        transition={{ repeat: Infinity, duration: 0.7, ease: "easeInOut" }}
        className="inline-block w-[2px] h-4 bg-primary/70 ml-[2px] -mb-[1px]"
      />
    </span>
  );
}

/* ─── Callout ─── */
type CalloutVariant = "tip" | "warn" | "pro";
function Callout({ variant, children }: { variant: CalloutVariant; children: React.ReactNode }) {
  const styles = {
    tip:  { border: "border-amber-600/30", bg: "bg-amber-600/8",  icon: <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500 shrink-0 mt-0.5" />, label: "TIP" },
    warn: { border: "border-orange-500/30", bg: "bg-orange-500/8",  icon: <AlertCircle className="w-3.5 h-3.5 text-orange-400 shrink-0 mt-0.5" />, label: "HEADS UP" },
    pro:  { border: "border-primary/40",    bg: "bg-primary/8",     icon: <Zap className="w-3.5 h-3.5 text-primary fill-primary shrink-0 mt-0.5" />, label: "PRO MOVE" },
  } satisfies Record<CalloutVariant, { border: string; bg: string; icon: React.ReactNode; label: string }>;
  const s = styles[variant];
  return (
    <Fade className={`flex gap-3 rounded-xl border ${s.border} ${s.bg} px-4 py-3.5`}>
      {s.icon}
      <div>
        <span className="text-[9px] font-black tracking-widest text-muted-foreground mr-2">{s.label}</span>
        <span className="text-xs text-muted-foreground leading-relaxed">{children}</span>
      </div>
    </Fade>
  );
}

/* ─── Numbered step — big card style ─── */
function BigStep({ n, icon: Icon, color, title, children }: {
  n: number; icon: React.ElementType; color: string; title: string; children: React.ReactNode
}) {
  return (
    <Fade className="rounded-2xl border border-border bg-secondary/20 overflow-hidden">
      <div className={`flex items-center gap-4 p-4 border-b border-border ${color}`}>
        <div className="w-10 h-10 rounded-xl bg-background/60 border border-current/20 flex items-center justify-center shrink-0">
          <Icon className="w-5 h-5" />
        </div>
        <div className="flex-1 min-w-0">
          <span className="text-[9px] font-black tracking-[0.25em] opacity-60 uppercase">Step {n} of 12</span>
          <h3 className="text-sm font-black text-foreground leading-tight mt-0.5">{title}</h3>
        </div>
        <div className="w-8 h-8 rounded-full bg-background/50 border border-current/20 flex items-center justify-center shrink-0">
          <span className="text-lg font-sans text-current leading-none">{n}</span>
        </div>
      </div>
      <div className="p-4 space-y-3 text-xs text-muted-foreground leading-relaxed">
        {children}
      </div>
    </Fade>
  );
}

/* ─── Inline check row ─── */
function CheckRow({ label, desc }: { label: string; desc: string }) {
  return (
    <div className="flex gap-3 items-start py-2 border-b border-border/50 last:border-0">
      <CheckCircle2 className="w-4 h-4 text-primary shrink-0 mt-0.5 fill-primary/10" />
      <div>
        <p className="text-xs font-semibold text-foreground leading-snug">{label}</p>
        <p className="text-[11px] text-muted-foreground">{desc}</p>
      </div>
    </div>
  );
}

/* ─── Flow diagram ─── */
function FlowDiagram({ steps }: { steps: { icon: React.ElementType; label: string; color: string }[] }) {
  const lastStep = steps[steps.length - 1];
  const mainSteps = steps.slice(0, -1);
  // Split main steps into rows of 3
  const rows: typeof mainSteps[] = [];
  for (let i = 0; i < mainSteps.length; i += 3) {
    rows.push(mainSteps.slice(i, i + 3));
  }
  return (
    <Fade className="space-y-2">
      {rows.map((row, ri) => (
        <div key={ri} className="flex items-center justify-center gap-1">
          {row.map((step, i) => (
            <React.Fragment key={i}>
              <div className={`flex flex-col items-center gap-1.5 rounded-xl border w-[68px] h-[68px] justify-center ${step.color}`}>
                <step.icon className="w-4 h-4" />
                <span className="text-[8px] sm:text-[9px] font-bold text-center leading-tight whitespace-pre-line">{step.label}</span>
              </div>
              {i < row.length - 1 && (
                <ArrowRight className="w-3 h-3 text-muted-foreground/60 shrink-0" />
              )}
            </React.Fragment>
          ))}
        </div>
      ))}
      {/* Last step — wide rectangle spanning 3 boxes */}
      <div className="flex justify-center">
        <div className={`flex items-center justify-center gap-2 rounded-xl border h-[42px] ${lastStep.color}`} style={{ width: "calc(68px * 3 + 0.25rem * 4)" }}>
          <lastStep.icon className="w-4 h-4" />
          <span className="text-[9px] font-bold text-center leading-tight">{lastStep.label.replace("\n", " ")}</span>
        </div>
      </div>
    </Fade>
  );
}

/* ─── Phone mockup ─── */
function PhoneMockup({ children }: { children: React.ReactNode }) {
  return (
    <Fade className="mx-auto max-w-[200px]">
      <div className="relative border-[3px] border-border/60 rounded-[2rem] overflow-hidden shadow-2xl bg-background"
        style={{ aspectRatio: "9/18" }}>
        <div className="flex items-center justify-between px-4 py-2 bg-secondary/50 border-b border-border/40">
          <span className="text-[9px] text-muted-foreground font-bold">9:41</span>
          <div className="w-14 h-2 rounded-full bg-foreground/10" />
          <div className="flex gap-1">
            {[0,1,2].map(i => <div key={i} className="w-1 h-1 rounded-full bg-muted-foreground/60" />)}
          </div>
        </div>
        <div className="p-3 overflow-hidden h-full">{children}</div>
      </div>
    </Fade>
  );
}

/* ─── Section divider ─── */
function SectionDivider({ label }: { label: string }) {
  return (
    <Fade className="flex items-center gap-3 my-10">
      <div className="h-px flex-1 bg-gradient-to-r from-transparent to-primary/30" />
      <span className="text-[9px] font-black tracking-[0.3em] text-primary uppercase px-2">{label}</span>
      <div className="h-px flex-1 bg-gradient-to-l from-transparent to-primary/30" />
    </Fade>
  );
}

/* ─── Pro Tip card ─── */
function ProTip({ icon: Icon, title, desc }: { icon: React.ElementType; title: string; desc: string }) {
  return (
    <Fade className="flex gap-3 p-4 rounded-2xl border border-primary/25 bg-primary/5 hover:border-primary/50 transition-colors">
      <div className="w-9 h-9 rounded-xl bg-primary/15 border border-primary/25 flex items-center justify-center shrink-0">
        <Icon className="w-4 h-4 text-primary" />
      </div>
      <div>
        <p className="text-xs font-black text-foreground">{title}</p>
        <p className="text-[11px] text-muted-foreground mt-0.5 leading-relaxed">{desc}</p>
      </div>
    </Fade>
  );
}

/* ══════════════════════════════════════════════════
   MAIN PAGE
   ══════════════════════════════════════════════════ */
export default function HowToPage() {
  const navigate = useNavigate();

  return (
    <div className="max-w-2xl mx-auto px-4 pb-20 pt-0 space-y-0 overflow-x-hidden">

      {/* ═══════════════════ HERO ═══════════════════ */}
      <div className="relative -mx-4 px-4 pt-10 pb-16 overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[600px]"
            style={{ background: "radial-gradient(ellipse at top, rgba(204,0,0,0.18) 0%, transparent 70%)" }} />
          <div className="absolute inset-0"
            style={{ background: "radial-gradient(ellipse at 50% 60%, rgba(204,0,0,0.07) 0%, transparent 60%)" }} />
          <div className="absolute bottom-0 left-0 right-0 h-56"
            style={{ background: "linear-gradient(to bottom, transparent, var(--background))" }} />
          <div className="absolute left-0 top-0 bottom-0 w-20"
            style={{ background: "linear-gradient(to right, var(--background), transparent)" }} />
          <div className="absolute right-0 top-0 bottom-0 w-20"
            style={{ background: "linear-gradient(to left, var(--background), transparent)" }} />
        </div>

        <div className="relative z-10 flex flex-col items-center text-center w-full overflow-hidden px-4">

          {/* Top badge */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-6 flex items-center gap-2 px-4 py-1.5 rounded-full border border-primary/30 bg-primary/8"
          >
            <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
            <span className="text-[9px] font-black tracking-[0.35em] text-primary uppercase">The Official Vault Guide</span>
            <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
          </motion.div>

          {/* Logo with orbits — outer wrapper is sized to contain all rings */}
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.75, ease: [0.34, 1.56, 0.64, 1] as const }}
            className="relative mb-8 flex items-center justify-center"
            style={{ width: 200, height: 200 }}
          >
            {/* Glow blob */}
            <div className="absolute inset-0 rounded-full"
              style={{ background: "radial-gradient(ellipse, rgba(204,0,0,0.2) 0%, transparent 70%)" }} />
            {/* Inner ring (r≈82px = 100 - 18) */}
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 14, ease: "linear" }}
              className="absolute rounded-full border border-dashed border-primary/30"
              style={{ inset: 18 }}
            >
              {/* Dots on inner ring */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-primary shadow-[0_0_8px_rgba(204,0,0,0.8)]" />
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 w-1.5 h-1.5 rounded-full bg-primary/60" />
            </motion.div>
            {/* Outer ring (r≈100px = full inset 0) */}
            <motion.div
              animate={{ rotate: -360 }}
              transition={{ repeat: Infinity, duration: 22, ease: "linear" }}
              className="absolute inset-0 rounded-full border border-dashed border-primary/15"
            />
            {/* Logo centred */}
            <div className="relative z-10 w-32 h-32">
              <img
                src="https://hercules-cdn.com/file_EE34NaUnA3bKpI5N0uZwrMZy"
                alt="DatCARDVault"
                className="w-full h-full object-contain drop-shadow-[0_0_30px_rgba(204,0,0,0.5)]"
                style={{ filter: "brightness(1.45) saturate(1.2)" }}
              />
            </div>
          </motion.div>

          {/* Wordmark */}
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3, duration: 0.6 }} className="relative">
            {/* Glow behind text */}
            <div className="absolute inset-0 pointer-events-none"
              style={{ filter: "blur(40px)", background: "radial-gradient(ellipse, rgba(204,0,0,0.35) 0%, transparent 70%)", transform: "scaleY(0.5) translateY(20px)" }} />

            <p className="relative text-[10px] font-black tracking-[0.4em] text-muted-foreground/60 uppercase mb-3">Become A</p>

            <h1 className="relative font-sans leading-none select-none">
              {/* DatCARDVault line */}
              <motion.span
                initial={{ opacity: 0, scale: 0.85 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.35, duration: 0.6, ease: [0.34, 1.2, 0.64, 1] as const }}
                className="block text-4xl sm:text-5xl md:text-6xl font-black tracking-[0.06em] drop-shadow-[0_2px_16px_rgba(204,0,0,0.3)]"
                style={{ textShadow: "0 0 60px rgba(204,0,0,0.2)" }}
              >
                <span className="text-foreground">Dat</span>
                <span className="text-primary" style={{ textShadow: "0 0 30px rgba(204,0,0,0.6), 0 0 60px rgba(204,0,0,0.3)" }}>CARD</span>
                <span className="text-foreground">Vault</span>
              </motion.span>

              {/* PRO — biggest, most dominant */}
              <motion.span
                initial={{ opacity: 0, scale: 1.3, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                transition={{ delay: 0.6, duration: 0.7, ease: [0.34, 1.56, 0.64, 1] as const }}
                className="block relative mt-0"
              >
                {/* PRO stroke outline for depth */}
                <span
                  aria-hidden
                  className="absolute inset-0 flex items-center justify-center text-6xl sm:text-7xl md:text-8xl font-black tracking-[0.25em] select-none pointer-events-none"
                  style={{
                    WebkitTextStroke: "2px rgba(204,0,0,0.25)",
                    color: "transparent",
                    letterSpacing: "0.28em",
                  }}
                >
                  PRO
                </span>
                <motion.span
                  animate={{ textShadow: [
                    "0 0 20px rgba(204,0,0,0.7), 0 0 60px rgba(204,0,0,0.4)",
                    "0 0 40px rgba(204,0,0,0.9), 0 0 80px rgba(204,0,0,0.5)",
                    "0 0 20px rgba(204,0,0,0.7), 0 0 60px rgba(204,0,0,0.4)",
                  ]}}
                  transition={{ repeat: Infinity, duration: 2.5, ease: "easeInOut" }}
                  className="relative text-6xl sm:text-7xl md:text-8xl font-black tracking-[0.28em] text-primary"
                >
                  PRO
                </motion.span>
              </motion.span>
            </h1>
          </motion.div>

          {/* Tagline */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.75 }}
            className="text-sm text-muted-foreground max-w-xs mx-auto mt-5 leading-relaxed"
          >
            12 steps from zero to fully running your vault like a professional trading card vendor.
          </motion.p>

          {/* Pills */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
            className="mt-7 flex items-center gap-2"
          >
            {(["SCAN", "STORE", "LABEL"] as const).map((word, i) => (
              <div key={word} className="flex items-center gap-2">
                <div className={`px-3 py-1.5 rounded-full text-[9px] font-black tracking-[0.2em] uppercase border ${
                  i === 1
                    ? "border-primary bg-primary text-white shadow-[0_0_16px_rgba(204,0,0,0.5)]"
                    : "border-border/60 bg-secondary/40 text-muted-foreground"
                }`}>
                  {word}
                </div>
                {i < 2 && <div className="w-1 h-1 rounded-full bg-primary/40" />}
              </div>
            ))}
          </motion.div>

          {/* Scroll cue */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2 }}
            className="mt-10 flex flex-col items-center"
          >
            <ScrollCueLabel />
          </motion.div>
        </div>
      </div>

      {/* ═══════════════════ FULL WORKFLOW ═══════════════════ */}
      <SectionDivider label="The Full Workflow" />

      <section className="space-y-4">
        <Fade>
          <div className="rounded-2xl border border-border bg-secondary/20 p-4 space-y-3">
            <p className="text-[10px] font-black tracking-[0.2em] text-muted-foreground uppercase">From Card To Cash</p>
            <FlowDiagram steps={[
              { icon: Camera,       label: "Photo\n& Details",   color: "border-blue-500/30 bg-blue-500/8 text-blue-400" },
              { icon: Package,      label: "Add to\nVault",      color: "border-purple-500/30 bg-purple-500/8 text-purple-400" },
              { icon: Tag,          label: "Auto\nLabel",        color: "border-amber-600/30 bg-amber-600/8 text-amber-500" },
              { icon: Printer,      label: "Print\nLabel",       color: "border-blue-500/30 bg-blue-500/8 text-blue-400" },
              { icon: ScanLine,     label: "Scan\n& Sell",       color: "border-primary/30 bg-primary/8 text-primary" },
              { icon: ShoppingCart, label: "Bulk\nSale",         color: "border-orange-500/30 bg-orange-500/8 text-orange-400" },
              { icon: TrendingUp,   label: "Earnings\nLogged",   color: "border-profit/30 bg-profit/8 text-profit" },
            ]} />
          </div>
        </Fade>

        <Fade>
          <div className="rounded-2xl border border-border bg-secondary/20 p-4 space-y-3">
            <p className="text-[10px] font-black tracking-[0.2em] text-muted-foreground uppercase">App Navigation</p>
            <div className="grid grid-cols-3 gap-2">
              {[
                { icon: LayoutDashboard, label: "Dashboard",   sub: "Stats & Greetings", color: "text-primary border-primary/20 bg-primary/5" },
                { icon: Package,         label: "Inventory",   sub: "Your Card Vault",   color: "text-purple-400 border-purple-500/20 bg-purple-500/5" },
                { icon: ScanLine,        label: "Scan",        sub: "QR & Sell",         color: "text-primary border-primary/20 bg-primary/5" },
                { icon: Tag,             label: "Labels",      sub: "Print Tags",        color: "text-amber-500 border-amber-600/20 bg-amber-600/5" },
                { icon: TrendingUp,      label: "Earnings",    sub: "Revenue & History", color: "text-profit border-profit/20 bg-profit/5" },
                { icon: Settings,        label: "More ···",    sub: "Settings & Tools",  color: "text-muted-foreground border-border bg-secondary/30" },
              ].map(({ icon: Icon, label, sub, color }) => (
                <div key={label} className={`rounded-xl border p-2.5 text-center ${color}`}>
                  <Icon className="w-4 h-4 mx-auto mb-1" />
                  <p className="text-[10px] font-black leading-tight">{label}</p>
                  <p className="text-[9px] text-muted-foreground mt-0.5 leading-tight">{sub}</p>
                </div>
              ))}
            </div>
            <p className="text-[10px] text-muted-foreground">On mobile, Earnings · Settings · Printer Hub · Vault Guide are under the <strong className="text-foreground">More ···</strong> tab at the bottom right.</p>
          </div>
        </Fade>
      </section>

      {/* ═══════════════════ 10 STEPS ═══════════════════ */}
      <SectionDivider label="12-Step Guide" />

      <section className="space-y-4">

        {/* STEP 1 */}
        <BigStep n={1} icon={Settings} color="text-muted-foreground" title="Set Up Your Profile & Label Branding">
          <p>Do this before anything else. Head to <strong className="text-foreground">Settings</strong> (desktop sidebar, or mobile More ···) and fill in:</p>
          <div className="space-y-0 rounded-xl border border-border overflow-hidden divide-y divide-border">
            {[
              { icon: Sparkles,   label: "Username",              desc: "Your display name across the app" },
              { icon: DollarSign, label: "Currency",              desc: "GBP £, USD $, or EUR € — applies to all prices, earnings, and PDF exports" },
              { icon: Building2,  label: "Business Name",         desc: "Printed on every label you produce" },
              { icon: AtSign,     label: "Instagram",             desc: "@handle — appears on every label" },
              { icon: Globe,      label: "Website",               desc: "Your URL on every label" },
              { icon: Mail,       label: "Verified Receipt Sender Email",  desc: "Automatically generated and encrypted from your account email — no setup needed, can't be edited" },
            ].map(({ icon: Icon, label, desc }) => (
              <div key={label} className="flex items-start gap-3 px-3 py-2.5 bg-secondary/30">
                <Icon className="w-3.5 h-3.5 text-muted-foreground shrink-0 mt-0.5" />
                <div className="min-w-0">
                  <span className="text-xs font-semibold text-foreground block">{label}</span>
                  <span className="text-[10px] text-muted-foreground leading-tight">{desc}</span>
                </div>
              </div>
            ))}
          </div>
          <p>Hit <strong className="text-foreground">Save Branding & Receipt Settings</strong>. Every label you print carries your branding automatically. Your <strong className="text-foreground">Verified Receipt Sender Email</strong> is automatically generated and encrypted from your account email — no setup required and it cannot be edited.</p>
          <Callout variant="warn">If you skip this step, your labels will print without a business name or social handles. Set it up before your first print job.</Callout>
        </BigStep>

        {/* STEP 2 */}
        <BigStep n={2} icon={Package} color="text-purple-400" title="Add Your First Card to the Vault">
          <p>Go to <strong className="text-foreground">Inventory</strong> and tap the red <strong className="text-foreground">+ button</strong> in the top right.</p>
          <div className="flex flex-col sm:flex-row gap-4 items-start">
            <PhoneMockup>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="h-3 rounded bg-purple-400/20 w-20" />
                  <div className="w-6 h-6 rounded-lg bg-primary flex items-center justify-center">
                    <span className="text-white text-[10px] font-black">+</span>
                  </div>
                </div>
                <div className="rounded-xl border border-border bg-secondary/50 p-3 space-y-2">
                  <div className="h-14 rounded-lg bg-secondary border border-dashed border-border flex items-center justify-center">
                    <Camera className="w-4 h-4 text-muted-foreground/50" />
                  </div>
                  {[["Card Name", 28], ["Game", 20], ["Condition", 22], ["Price", 16]].map(([l, w]) => (
                    <div key={l as string}>
                      <div className="h-2 rounded bg-muted-foreground/20 mb-1" style={{ width: `${w as number * 2}px` }} />
                      <div className="h-5 rounded-md bg-secondary border border-border" />
                    </div>
                  ))}
                </div>
              </div>
            </PhoneMockup>
            <div className="flex-1 space-y-0">
              <CheckRow label="Take a photo" desc="Desktop: click the live camera feed to capture. Mobile: uses your native camera." />
              <CheckRow label="Fill in details" desc="Name, game, set, condition, grade, rarity — as much or as little as you like." />
              <CheckRow label="% Bought At" desc="Record what % of market value you paid — e.g. 50% means you paid half market price." />
              <CheckRow label="Save to vault" desc="Card is added instantly. A QR label is generated in the background ready to print." />
            </div>
          </div>
          <div className="rounded-xl border border-primary/20 bg-primary/5 p-3">
            <p className="text-[10px] font-black tracking-widest text-primary uppercase mb-1">Vault Capacity</p>
            <p>Your vault holds up to <strong className="text-foreground">3,000 active (unsold) cards</strong>. A progress bar at the top of Inventory shows how full you are. Sold cards don't count — they're archived and free the slot.</p>
            <div className="mt-2 h-1.5 rounded-full bg-secondary overflow-hidden">
              <div className="h-full rounded-full bg-primary" style={{ width: "56%" }} />
            </div>
            <div className="flex justify-between mt-1">
              <span className="text-[9px] text-muted-foreground">850 / 3,000 active cards</span>
              <span className="text-[9px] text-primary font-bold">56%</span>
            </div>
          </div>
          <Callout variant="tip">You can also add a new card directly from the <strong>Scan page</strong> — useful mid-show when you need to add and sell a card quickly in one flow.</Callout>

          {/* Quick Price Edit */}
          <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-3 space-y-1.5">
            <div className="flex items-center gap-2">
              <Pencil className="w-4 h-4 text-amber-400 shrink-0" />
              <p className="text-[10px] font-black tracking-widest text-amber-400 uppercase">Quick Price Edit</p>
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              Need to reprice quickly before a show? In the Inventory list, the <strong className="text-foreground">Price</strong> value on every active card is a tappable button. Tap it → an inline input appears pre-filled with the current price → type the new value → press <strong className="text-foreground">Enter</strong> or tap away to save. The label price updates at the same time. Press <strong className="text-foreground">Escape</strong> to cancel.
            </p>
          </div>
          <div className="rounded-xl border border-pink-500/30 bg-pink-500/8 p-3 space-y-2">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-pink-400 shrink-0" />
              <p className="text-[10px] font-black tracking-widest text-pink-400 uppercase">eBay CSV Import — Add Cards in Bulk</p>
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              Already selling on eBay, or have a spreadsheet of cards? Skip manual entry entirely — use the <strong className="text-foreground">Import CSV</strong> button at the top of the Inventory cards tab.
            </p>
            <div className="space-y-1">
              {[
                { t: "eBay Seller Hub format", d: "Export your sold orders from eBay: Seller Hub → Orders → Download report. Upload the CSV directly — no column editing needed. Item Title maps to name, Sold For to purchase price, Custom Label to set, and Item Condition to condition. Order number and sale date are saved in the notes field automatically." },
                { t: "Standard format", d: "Have a spreadsheet from another source? Switch to Standard mode. Required columns: name, game. Optional: set, condition, grade, purchase_price, market_value, rarity, language, notes. Download the template from the importer to get started." },
                { t: "Default game selector (eBay)", d: "eBay listings don't include a game name. Use the Default Game dropdown in the importer to apply one game to all rows — e.g. Pokémon, Magic: The Gathering, Yu-Gi-Oh! Official." },
                { t: "Preview before importing", d: "The importer shows a full preview table of all valid rows and highlights any rows with errors (which are skipped). Confirm once you're happy — no changes are made until you tap Import." },
                { t: "Auto QR labels", d: "A QR label is generated for every card imported — exactly the same as adding a card manually. They're ready to print from the Labels page immediately." },
                { t: "Duplicate detection", d: "As you type a card name (or when a CSV row is previewed), the Duplicate Detector checks your existing vault for matching unsold cards — so you don't accidentally re-add something you already have." },
              ].map(({ t, d }) => (
                <div key={t} className="flex items-start gap-2 text-[10px] text-muted-foreground border-t border-border/50 pt-1.5">
                  <div className="w-1 h-1 rounded-full bg-pink-400/70 shrink-0 mt-1.5" />
                  <span><strong className="text-foreground">{t}:</strong> {d}</span>
                </div>
              ))}
            </div>
            <div className="rounded-lg bg-background/60 border border-pink-500/20 p-2.5">
              <p className="text-[9px] font-black text-pink-400 uppercase tracking-widest mb-1">eBay Column Mapping</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 text-[9px]">
                {[
                  ["Item Title", "Card name"],
                  ["Sold For", "Purchase price"],
                  ["Custom Label", "Set"],
                  ["Item Condition", "Condition (auto-translated)"],
                  ["Quantity", "Expands to individual cards"],
                  ["Order Number / Sale Date", "Saved to Notes"],
                ].map(([from, to]) => (
                  <div key={from} className="flex items-center gap-1.5 rounded bg-secondary/60 px-2 py-1.5">
                    <span className="font-mono text-pink-400 font-bold">{from}</span>
                    <span className="text-muted-foreground">→ {to}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sold Cards in Inventory */}
          <div className="rounded-xl border border-profit/20 bg-profit/5 p-3 space-y-1.5">
            <div className="flex items-center gap-2">
              <Receipt className="w-4 h-4 text-profit shrink-0" />
              <p className="text-[10px] font-black tracking-widest text-profit uppercase">Sold Cards — Receipt & Unsold</p>
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              Switch to the <strong className="text-foreground">Sold</strong> tab in Inventory to see all archived cards. Each sold card row has two action buttons:
            </p>
            <div className="space-y-1">
              {[
                { t: "Receipt", d: "Opens a receipt dialog showing a full preview — store name, card details, sale price, and profit. You can email the receipt to the customer from the same dialog." },
                { t: "Unsold", d: "Moves the card back to active inventory. A new QR label is auto-generated if the old one was deleted." },
              ].map(({ t, d }) => (
                <div key={t} className="flex items-start gap-2 text-[10px] text-muted-foreground border-t border-border/50 pt-1.5">
                  <div className="w-1 h-1 rounded-full bg-profit/70 shrink-0 mt-1.5" />
                  <span><strong className="text-foreground">{t}:</strong> {d}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Sealed Products */}
          <div className="rounded-xl border border-blue-500/20 bg-blue-500/5 p-3 space-y-2">
            <div className="flex items-center gap-2">
              <Barcode className="w-4 h-4 text-blue-400 shrink-0" />
              <p className="text-[10px] font-black tracking-widest text-blue-400 uppercase">Sealed Products Tab</p>
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              Alongside cards, Inventory has a <strong className="text-foreground">Sealed</strong> tab for managing booster packs, ETBs, tins, boxes, and other sealed TCG products. Tap the <strong className="text-foreground">Sealed</strong> toggle at the top of Inventory to switch view.
            </p>
            <div className="space-y-1">
              {[
                { t: "Add a sealed product", d: "Tap + Add Product in the header. Fill in the name, game, type (booster box, ETB, tin…), barcode (EAN-13/UPC-A), purchase price, sell price, and quantity." },
                { t: "2,000 product limit", d: "The Sealed tab holds up to 2,000 unique products. A capacity bar at the top shows how full it is — amber at 1,800, red when full. Sold-out products count toward the limit, so Restock or delete old entries to free space." },
                { t: "Search & filter", d: "Use the search bar to find products by name. Switch between Active (in stock) and Sold (quantity zero) using the tabs below the search bar." },
                { t: "Sell a unit", d: "Tap Sell on any product card, enter the sale price, and confirm. Stock reduces by 1 and the sale is logged to Earnings automatically." },
                { t: "Scan the barcode at the till", d: "On the Scan page, point the camera at any product barcode. The sealed product sheet opens — tap Sell to process the sale immediately." },
                { t: "Restock sold-out products", d: "In the Sold tab, tap Restock on any greyed-out card to set a new quantity and move it back to Active." },
                { t: "Stock tracking", d: "Each product shows its quantity with a green badge when in stock and red when at zero. Edit any time to restock or adjust the price." },
              ].map(({ t, d }) => (
                <div key={t} className="flex items-start gap-2 text-[10px] text-muted-foreground border-t border-border/50 pt-1.5">
                  <div className="w-1 h-1 rounded-full bg-blue-400/70 shrink-0 mt-1.5" />
                  <span><strong className="text-foreground">{t}:</strong> {d}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Aging Report */}
          <div className="rounded-xl border border-amber-500/30 bg-amber-500/8 p-3 space-y-2">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400 shrink-0" />
              <p className="text-[10px] font-black tracking-widest text-amber-400 uppercase">Aging Report — Spot Slow-Movers Instantly</p>
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              The <strong className="text-foreground">Aging</strong> tab in Inventory shows every unsold card and in-stock sealed product sorted by how long it has been sitting — oldest first. Use it to spot what to discount before or after a show.
            </p>
            <div className="space-y-1">
              {[
                { t: "Age badges", d: "Each row carries a colour-coded badge showing exactly how many days that item has been in your vault — green for fresh stock, amber for slow movers (15–30 days), orange for 31–60 days, and red for anything over 60 days." },
                { t: "Filter by age range", d: "Tap any filter chip at the top to narrow the list: 0–7d, 8–14d, 15–30d, 31–60d, 61–90d, or 90d+. Tap All to see everything at once." },
                { t: "Cards and Sealed", d: "Use the Cards / Sealed toggle inside the Aging tab to switch between your card vault and sealed product stock. Both are sorted oldest first." },
                { t: "Summary stats", d: "Three stat tiles at the top show your total unsold cards, total unsold sealed products, and a count of items over 60 days. If anything is over 60 days, a red warning prompts you to consider discounting." },
                { t: "Purchase price and market value shown", d: "Each row displays the card's market value and what you paid — so you can quickly decide whether a discount still leaves you in profit before editing the price in Inventory." },
              ].map(({ t, d }) => (
                <div key={t} className="flex items-start gap-2 text-[10px] text-muted-foreground border-t border-border/50 pt-1.5">
                  <div className="w-1 h-1 rounded-full bg-amber-400/70 shrink-0 mt-1.5" />
                  <span><strong className="text-foreground">{t}:</strong> {d}</span>
                </div>
              ))}
            </div>
            <div className="rounded-lg bg-background/60 border border-amber-500/20 p-2.5">
              <p className="text-[9px] font-black text-amber-400 uppercase tracking-widest mb-1">Age Colour Key</p>
              <div className="grid grid-cols-3 gap-1 text-[9px]">
                {[
                  { label: "0–7d",   color: "text-profit",  bg: "bg-profit/10 border-profit/30",  desc: "Fresh" },
                  { label: "8–14d",  color: "text-cyan-400",   bg: "bg-cyan-500/10 border-cyan-500/30",    desc: "Recent" },
                  { label: "15–30d", color: "text-amber-400",  bg: "bg-amber-500/10 border-amber-500/30",  desc: "Reprice?" },
                  { label: "31–60d", color: "text-orange-400", bg: "bg-orange-500/10 border-orange-500/30",desc: "Slow" },
                  { label: "61–90d", color: "text-red-400",    bg: "bg-red-500/10 border-red-500/30",      desc: "Discount" },
                  { label: "90d+",   color: "text-red-600",    bg: "bg-red-600/10 border-red-600/30",      desc: "Dead stock" },
                ].map(({ label, color, bg, desc }) => (
                  <div key={label} className={`rounded px-2 py-1 border text-center ${bg}`}>
                    <p className={`font-black ${color}`}>{label}</p>
                    <p className="text-muted-foreground">{desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </BigStep>

        {/* STEP 3 */}
        <BigStep n={3} icon={MousePointerClick} color="text-blue-400" title="View Card Info — Tap Any Card">
          <p>In both <strong className="text-foreground">Inventory</strong> and <strong className="text-foreground">Dashboard → Recent Cards</strong>, tap a card's name or row to open its full info panel.</p>
          <div className="flex gap-3 items-start">
            <PhoneMockup>
              <div className="space-y-1.5">
                <div className="rounded-lg border border-primary/30 bg-primary/5 p-2.5">
                  <p className="text-[9px] font-black text-primary tracking-widest">Charizard VMAX</p>
                  <div className="flex flex-wrap gap-1 mt-1.5">
                    {["Pokémon", "Near Mint", "PSA 10"].map(b => (
                      <span key={b} className="text-[7px] px-1.5 py-0.5 rounded-full border border-border bg-secondary text-foreground/70">{b}</span>
                    ))}
                  </div>
                  <div className="grid grid-cols-2 gap-1 mt-2">
                    {[["Set", "SWSH07"], ["Set #", "074/185"], ["Market", "£85.00"], ["Bought", "£40.00"]].map(([l, v]) => (
                      <div key={l} className="rounded bg-secondary/60 p-1.5">
                        <p className="text-[7px] text-muted-foreground uppercase tracking-wide">{l}</p>
                        <p className="text-[8px] font-bold text-foreground">{v}</p>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="rounded-lg border border-border p-2 text-center">
                  <p className="text-[7px] text-muted-foreground">✏ Edit this card</p>
                </div>
              </div>
            </PhoneMockup>
            <div className="flex-1 space-y-0">
              <CheckRow label="Full details" desc="Game, condition, grade, set, set number, rarity, language, edition." />
              <CheckRow label="Pricing" desc="Purchase price and market value displayed side by side." />
              <CheckRow label="Sale info" desc="If the card is sold: sale price, date, and profit (if purchase price was recorded) shown in green." />
              <CheckRow label="Notes" desc="Any personal notes you added are shown here." />
              <CheckRow label="Edit shortcut" desc="Tap 'Edit this card' to jump straight into the edit form without navigating away." />
            </div>
          </div>
        </BigStep>

        {/* STEP 4 */}
        <BigStep n={4} icon={Tag} color="text-amber-500" title="Print Your First Label">
          <p>Go to <strong className="text-foreground">Labels</strong> — every card you've added already has a label waiting. Select one (or many) and tap <strong className="text-foreground">Print</strong>.</p>
          <div className="space-y-2">
            <p className="text-[10px] font-black tracking-[0.2em] text-muted-foreground uppercase">3 Label Templates — All 42×24mm (Default)</p>
            {[
              { name: "Standard",    desc: "QR left, full card info right. Best all-rounder.",           color: "text-blue-400 border-blue-500/20 bg-blue-500/5" },
              { name: "Graded Card", desc: "Prominent grade badge (PSA/BGS). Built for slabs.",          color: "text-amber-500 border-amber-600/20 bg-amber-600/5" },
              { name: "Minimal",     desc: "QR, name, condition, price only. Clean and fast to read.",   color: "text-gray-400 border-border bg-secondary/20" },
            ].map(({ name, desc, color }) => (
              <div key={name} className={`flex items-center gap-3 p-3 rounded-xl border ${color}`}>
                <Tag className="w-4 h-4 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-foreground">{name}</p>
                  <p className="text-[10px] text-muted-foreground">{desc}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="rounded-xl border border-border bg-background p-3 space-y-1.5">
            <p className="text-[10px] font-black tracking-widest text-muted-foreground uppercase">Every Label Includes</p>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-[10px] text-muted-foreground">
              {["Vendor QR badge","Business name","Instagram @handle","Website URL","Card name","Game & set info","Condition","Price (pinned bottom)"].map(item => (
                <div key={item} className="flex items-center gap-1.5">
                  <div className="w-1 h-1 rounded-full bg-primary/50 shrink-0" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-xl border border-border bg-secondary/20 p-3 space-y-1.5">
            <p className="text-[10px] font-black tracking-widest text-muted-foreground uppercase">How Labels Print</p>
            <p className="text-[10px] text-muted-foreground leading-relaxed">Labels render at <strong className="text-foreground">203 DPI</strong> to exactly match your printer's native resolution — the same as the calibration test print. Everything prints in <strong className="text-foreground">pure black on white</strong> for crisp thermal output. Each label is sent as its own job and stacks on the roll, just like the test print.</p>
          </div>
          {/* Controlled Label Deletion & Regeneration */}
          <div className="rounded-xl border border-primary/20 bg-primary/5 p-3 space-y-2">
            <p className="text-[10px] font-black tracking-widest text-primary uppercase">Controlled Label Deletion &amp; Regeneration</p>
            <p className="text-[10px] text-muted-foreground leading-relaxed">Labels are protected while a card is still active in your vault. You can only delete a label once its linked card has been <strong className="text-foreground">sold or archived</strong>.</p>
            <div className="space-y-1.5">
              {[
                { t: "Delete only when sold", d: "The trash icon only appears on labels whose card is marked sold. Active cards keep their labels locked — no accidental deletions." },
                { t: "Auto-regeneration on unsold", d: "If you move a sold card back to active inventory (tap Unsold) and the label was previously deleted, a brand new label is generated automatically — no manual steps needed." },
                { t: "Confirmation required", d: "Deleting a label always shows a confirmation dialog. Once deleted, it cannot be undone (but regeneration handles it if the card returns to active)." },
              ].map(({ t, d }) => (
                <div key={t} className="flex items-start gap-2 text-[10px] text-muted-foreground">
                  <div className="w-1 h-1 rounded-full bg-primary/60 shrink-0 mt-1.5" />
                  <span><strong className="text-foreground">{t}:</strong> {d}</span>
                </div>
              ))}
            </div>
          </div>
          <Callout variant="warn"><strong>Deleting a card also deletes its label permanently.</strong> If you want to retire a card from sale, mark it Sold instead — don't delete.</Callout>
        </BigStep>

        {/* STEP 5 */}
        <BigStep n={5} icon={Printer} color="text-primary" title="Printer Hub — WiFi & Bluetooth Printing">
          {/* WiFi Printing — All Platforms */}
          <div className="rounded-xl border border-blue-500/30 bg-blue-500/5 p-3 space-y-3">
            <div className="flex items-center gap-2">
              <Wifi className="w-4 h-4 text-blue-400 shrink-0" />
              <p className="text-[10px] font-black tracking-widest text-blue-400 uppercase">WiFi Printing</p>
              <span className="text-[8px] font-black bg-blue-500/20 border border-blue-500/30 text-blue-400 px-1.5 py-0.5 rounded-full ml-auto uppercase tracking-wide">All Platforms</span>
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">Print labels over WiFi using your device&apos;s built-in print dialog. Works on <strong className="text-foreground">Android</strong>, <strong className="text-foreground">iOS</strong>, and <strong className="text-foreground">desktop</strong> — no Bluetooth pairing required. This is the <strong className="text-blue-400">recommended method for iOS</strong> users.</p>
            <div className="space-y-2">
              <p className="text-[9px] font-black tracking-widest text-muted-foreground uppercase">How It Works</p>
              {[
                { n: 1, t: "Go to the Labels page", d: "Select the labels you want to print." },
                { n: 2, t: "Tap the blue WiFi button", d: "Individual label WiFi button, or the batch \"WiFi\" button in the header for multiple labels." },
                { n: 3, t: "Confirm in the WiFi Print dialog", d: "A print-optimized popup window opens automatically." },
                { n: 4, t: "Select your WiFi printer", d: "Your device's native print dialog appears — pick your printer from the network." },
              ].map(({ n, t, d }) => (
                <div key={n} className="flex gap-3 items-start">
                  <div className="w-5 h-5 rounded-lg bg-blue-500/20 text-blue-400 text-[9px] font-black flex items-center justify-center shrink-0">{n}</div>
                  <div className="flex-1 pb-2 border-b border-blue-500/10 last:border-0">
                    <p className="text-[10px] font-bold text-foreground">{t}</p>
                    <p className="text-[9px] text-muted-foreground">{d}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="rounded-lg bg-blue-500/10 border border-blue-500/20 p-2.5 space-y-1">
              <p className="text-[9px] font-black tracking-widest text-blue-400 uppercase">Tips</p>
              <ul className="text-[10px] text-muted-foreground space-y-0.5 list-disc list-inside">
                <li>Set margins to <strong className="text-foreground">None</strong> and scale to <strong className="text-foreground">100%</strong> in the print dialog</li>
                <li>Printer must be on the <strong className="text-foreground">same WiFi network</strong> as your device</li>
                <li>Up to <strong className="text-foreground">20 labels</strong> can be printed at once</li>
              </ul>
            </div>
          </div>

          {/* Bluetooth Printing — Android & Desktop */}
          <div className="rounded-xl border border-border bg-secondary/20 p-3 space-y-3">
            <div className="flex items-center gap-2">
              <Bluetooth className="w-4 h-4 text-primary shrink-0" />
              <p className="text-[10px] font-black tracking-widest text-primary uppercase">Bluetooth Printing</p>
              <span className="text-[8px] font-black bg-primary/20 border border-primary/30 text-primary px-1.5 py-0.5 rounded-full ml-auto uppercase tracking-wide">Android &amp; Desktop</span>
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">Direct Bluetooth printing via Web Bluetooth. Pairs your thermal printer and sends labels directly — no WiFi network needed. <strong className="text-foreground">Not available on iOS</strong> (Apple blocks Web Bluetooth).</p>
          </div>

          <p>In <strong className="text-foreground">Printer Hub</strong> (sidebar or More ···), tap <strong className="text-foreground">Connect</strong> on the printer card. Your browser shows a Bluetooth device picker — select your printer and it pairs in seconds. Once connected, <strong className="text-foreground">swipe the card left</strong> to access all printer controls: Test Print, Stop, Clear Cache, and Disconnect.</p>
          <div className="rounded-xl border border-border bg-secondary/20 p-3 space-y-2">
            <p className="text-[10px] font-black tracking-widest text-muted-foreground uppercase">Connection Steps</p>
            {[
              { n: 1, t: "Power on printer",        d: "Put it into pairing / discoverable mode." },
              { n: 2, t: "Tap Connect",              d: "Tap the Connect button on the printer card. Your browser shows the Bluetooth device picker." },
              { n: 3, t: "Select your printer",      d: "Pairs in seconds. 'Ready to print' confirms the connection." },
              { n: 4, t: "Swipe left for options",   d: "Once connected, swipe the printer card left to reveal Test Print, Stop, Clear Cache, and Disconnect." },
              { n: 5, t: "Print from Labels",        d: "Hit Print on any label — your printer fires immediately." },
            ].map(({ n, t, d }) => (
              <div key={n} className="flex gap-3 items-start">
                <div className="w-6 h-6 rounded-lg bg-primary text-white text-[10px] font-black flex items-center justify-center shrink-0">{n}</div>
                <div className="flex-1 pb-2 border-b border-border/50 last:border-0">
                  <p className="text-xs font-bold text-foreground">{t}</p>
                  <p className="text-[10px] text-muted-foreground">{d}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Compatible Printers */}
          <div className="rounded-xl border border-border bg-secondary/20 p-3 space-y-2">
            <p className="text-[10px] font-black tracking-widest text-muted-foreground uppercase">Compatible Printers</p>
            <p className="text-[10px] text-muted-foreground leading-relaxed">50+ Bluetooth thermal label printers supported via BLE auto-detection. Any ESC/POS-compatible Bluetooth thermal printer should work.</p>
            <div className="flex flex-wrap gap-1.5">
              {["MarkLife D100 ✓", "MarkLife P50S ✓", "MarkLife X2 ✓", "Phomemo M110", "MUNBYN ITP01", "NIIMBOT B21", "Vretti HP3", "Zebra ZQ620", "Brother QL-820NWB"].map(m => (
                <span key={m} className={`text-[10px] px-2 py-0.5 rounded-md ${m.includes("✓") ? "bg-primary/20 text-primary font-semibold border border-primary/30" : "bg-secondary text-muted-foreground border border-border"}`}>{m}</span>
              ))}
            </div>
            <p className="text-[9px] text-muted-foreground">Full list available in Printer Hub. If yours isn't listed, try connecting — it may still be compatible.</p>
          </div>

          {/* Label Calibration */}
          <div className="rounded-xl border border-primary/20 bg-primary/5 p-3 space-y-3">
            <div className="flex items-center gap-2">
              <Printer className="w-4 h-4 text-primary shrink-0" />
              <p className="text-[10px] font-black tracking-widest text-primary uppercase">Label Calibration</p>
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">Every printer and label roll is slightly different. Use the <strong className="text-foreground">Label Calibration</strong> card in Printer Hub to dial in your print perfectly — then hit <strong className="text-foreground">Save</strong> to lock it in. Settings are stored on your device.</p>

            {/* Quick Presets */}
            <div className="space-y-1.5">
              <p className="text-[9px] font-black tracking-widest text-muted-foreground uppercase">Quick Presets</p>
              <p className="text-[10px] text-muted-foreground leading-relaxed">Tap a preset to snap to that label size instantly — no typing needed.</p>
              <div className="flex flex-wrap gap-1.5">
                {["50×30mm","50×40mm","52×32mm","57×33mm","62×29mm"].map(s => (
                  <div key={s} className="text-[10px] font-bold px-2.5 py-1 rounded-lg border border-primary/30 bg-primary/8 text-primary">{s}</div>
                ))}
              </div>
            </div>

            {/* Size & Alignment */}
            <div className="space-y-1.5">
              <p className="text-[9px] font-black tracking-widest text-muted-foreground uppercase">Size &amp; Alignment</p>
              <div className="grid grid-cols-1 gap-1.5">
                {[
                  { label: "Label Width / Height", desc: "Set exact label dimensions in mm to match your roll." },
                  { label: "Offset X / Y",          desc: "Shift the print area left/right or up/down to fix misalignment." },
                  { label: "Scale X / Y",           desc: "Stretch or compress the print to fill your label precisely." },
                ].map(({ label, desc }) => (
                  <div key={label} className="rounded-lg bg-background/60 border border-border p-2 flex gap-2 items-start">
                    <div className="w-1 h-1 rounded-full bg-primary/60 shrink-0 mt-1.5" />
                    <div>
                      <p className="text-[10px] font-bold text-foreground">{label}</p>
                      <p className="text-[9px] text-muted-foreground">{desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Print Darkness */}
            <div className="space-y-1.5">
              <p className="text-[9px] font-black tracking-widest text-muted-foreground uppercase">Print Darkness</p>
              <p className="text-[10px] text-muted-foreground leading-relaxed">Slide left for lighter prints, right for darker. Default (Normal) works for most rolls — adjust if text prints too faint or bleeds together.</p>
              <div className="rounded-lg bg-background/60 border border-border p-2.5 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <div className="w-5 h-5 rounded-md bg-secondary border border-border flex items-center justify-center">
                      <Sun className="w-3 h-3 text-amber-500" />
                    </div>
                    <span className="text-[9px] font-bold text-foreground">Print Darkness</span>
                  </div>
                  <span className="text-[8px] font-semibold px-1.5 py-0.5 rounded-md bg-secondary border border-border text-foreground">Normal</span>
                </div>
                <div className="flex items-center gap-2">
                  <Sun className="w-3 h-3 text-muted-foreground shrink-0" />
                  <div className="flex-1 h-1.5 rounded-full bg-secondary relative">
                    <div className="absolute left-0 top-0 h-full w-[50%] rounded-full bg-primary/50" />
                    <div className="absolute top-1/2 -translate-y-1/2 bg-primary rounded-full w-3 h-3" style={{ left: "50%" }} />
                  </div>
                  <Moon className="w-3 h-3 text-muted-foreground shrink-0" />
                </div>
              </div>
            </div>

            {/* Feed After Print */}
            <div className="space-y-1.5">
              <p className="text-[9px] font-black tracking-widest text-muted-foreground uppercase">Feed After Print</p>
              <p className="text-[10px] text-muted-foreground leading-relaxed">Controls blank lines fed after each label. Default is <strong className="text-foreground">0</strong> for the tightest gap. Increase if the cutter clips your label, decrease if there's too much blank tape.</p>
              <div className="rounded-lg bg-background/60 border border-border p-2.5 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <div className="w-5 h-5 rounded-md bg-secondary border border-border flex items-center justify-center">
                      <MoveVertical className="w-3 h-3 text-blue-400" />
                    </div>
                    <span className="text-[9px] font-bold text-foreground">Feed After Print</span>
                  </div>
                  <span className="text-[8px] font-semibold px-1.5 py-0.5 rounded-md bg-secondary border border-border text-foreground">0 lines</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-md bg-secondary border border-border flex items-center justify-center">
                    <Minus className="w-2.5 h-2.5 text-muted-foreground" />
                  </div>
                  <div className="flex-1 h-1.5 rounded-full bg-secondary relative">
                    <div className="absolute top-1/2 -translate-y-1/2 bg-primary rounded-full w-3 h-3" style={{ left: "0%" }} />
                  </div>
                  <div className="w-5 h-5 rounded-md bg-secondary border border-border flex items-center justify-center">
                    <Plus className="w-2.5 h-2.5 text-muted-foreground" />
                  </div>
                </div>
              </div>
            </div>

            {/* Cut-Guide Border */}
            <div className="space-y-1.5">
              <p className="text-[9px] font-black tracking-widest text-muted-foreground uppercase">Cut-Guide Border</p>
              <p className="text-[10px] text-muted-foreground leading-relaxed">Toggles the dotted rectangle border printed around each label. When <strong className="text-foreground">ON</strong> (default), a cut-guide border prints around the label edge — useful for hand-cutting labels from continuous rolls. Turn it <strong className="text-foreground">OFF</strong> for a cleaner look on pre-cut or die-cut label stock.</p>
              <div className="rounded-lg bg-background/60 border border-border p-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <div className="w-5 h-5 rounded-md bg-secondary border border-border flex items-center justify-center">
                      <Square className="w-3 h-3 text-blue-400" />
                    </div>
                    <span className="text-[9px] font-bold text-foreground">Cut-Guide Border</span>
                  </div>
                  <div className="w-7 h-4 rounded-full bg-primary flex items-center justify-end px-0.5">
                    <div className="w-3 h-3 rounded-full bg-white" />
                  </div>
                </div>
              </div>
            </div>

            {/* Print Preview */}
            <div className="space-y-1.5">
              <p className="text-[9px] font-black tracking-widest text-muted-foreground uppercase">Print Preview</p>
              <p className="text-[10px] text-muted-foreground leading-relaxed">A live preview shows exactly where your label will print on a gradient canvas. A size badge above the mockup displays your current dimensions. The red dashed outline represents the print area on a shadow-lifted white label mockup. Below, six calibration value cards show Offset X/Y, Scale X/Y, Darkness level, and Feed lines at a glance. Adjust until aligned, then run a <strong className="text-foreground">Test Print</strong> to verify on real tape.</p>
            </div>

            <Callout variant="pro">Run a <strong>Test Print</strong> (swipe the printer card left) after changing calibration settings to verify the result on real tape before printing a full batch.</Callout>
          </div>

          <div className="rounded-xl border-2 border-primary/30 bg-primary/5 p-3">
            <div className="flex items-center gap-2 mb-2">
              <Printer className="w-4 h-4 text-primary" />
              <p className="text-xs font-black text-foreground">MarkLife D100 — Recommended</p>
              <span className="text-[8px] font-black bg-primary text-white px-1.5 py-0.5 rounded-full ml-auto">TESTED</span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center">
              {[["203 DPI","Quality"], ["Bluetooth","Wireless"], ["USB-C","Charging"]].map(([v, l]) => (
                <div key={l} className="rounded-lg bg-background border border-border p-2">
                  <p className="text-[10px] font-bold text-primary">{v}</p>
                  <p className="text-[9px] text-muted-foreground mt-0.5">{l}</p>
                </div>
              ))}
            </div>
          </div>
          <Callout variant="warn">Web Bluetooth requires a <strong>Chromium-based browser</strong>. On Android use <strong>Chrome</strong> or <strong>Samsung Internet</strong>. On Desktop use <strong>Chrome, Edge, Opera, or Firefox</strong>. Safari and iOS browsers do not support Web Bluetooth — use <strong>WiFi Print</strong> instead.</Callout>
          <Callout variant="pro"><strong>iOS users:</strong> WiFi Printing works natively on iPhone and iPad — tap the blue WiFi button on the Labels page. You can also use <strong>Save Label Image</strong> to export up to 10 labels as high-res PNGs and print via the <strong>MarkLife Label</strong> app.</Callout>
        </BigStep>

        {/* STEP 6 */}
        <BigStep n={6} icon={ScanLine} color="text-primary" title="Scan & Sell — QR Codes & Product Barcodes">
          <p>Tap the big red <strong className="text-foreground">SCAN</strong> button in the bottom nav. The scanner handles <strong className="text-foreground">two types</strong> of code automatically — no mode switching needed.</p>

          {/* Two-mode explainer */}
          <div className="grid grid-cols-2 gap-2">
            <div className="rounded-xl border border-primary/30 bg-primary/5 p-3 flex flex-col gap-1.5">
              <QrCode className="w-4 h-4 text-primary" />
              <p className="text-[10px] font-bold text-foreground">DatCARDVault QR</p>
              <p className="text-[10px] text-muted-foreground">Scans your printed card labels. Opens the card detail sheet to sell, edit, or send a receipt.</p>
            </div>
            <div className="rounded-xl border border-blue-500/30 bg-blue-500/5 p-3 flex flex-col gap-1.5">
              <Barcode className="w-4 h-4 text-blue-400" />
              <p className="text-[10px] font-bold text-foreground">Product Barcode</p>
              <p className="text-[10px] text-muted-foreground">Scans EAN-13 / UPC-A barcodes on sealed products. Opens the sealed product sheet to sell a unit instantly.</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 items-start">
            <PhoneMockup>
              <div className="space-y-2">
                <div className="h-24 rounded-xl border border-primary/30 bg-primary/5 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center opacity-30">
                    <QrCode className="w-12 h-12 text-primary" />
                  </div>
                  <div className="absolute left-3 right-3 h-0.5 bg-primary/60 rounded" style={{ top: "40%" }} />
                  <span className="text-[8px] text-primary font-black uppercase tracking-wider relative z-10 bg-background/60 px-2 py-1 rounded">Scanning...</span>
                </div>
                <div className="rounded-xl border border-border bg-secondary/50 p-2.5 space-y-1.5">
                  <p className="text-[9px] font-black text-foreground">Charizard VMAX</p>
                  <div className="flex gap-1">
                    <span className="text-[7px] px-1.5 py-0.5 rounded-full bg-secondary border border-border text-muted-foreground">Near Mint</span>
                    <span className="text-[7px] px-1.5 py-0.5 rounded-full bg-amber-600/10 border border-amber-600/20 text-amber-500">PSA 10</span>
                  </div>
                  <p className="text-[9px] text-primary font-black">£85.00</p>
                  <div className="grid grid-cols-2 gap-1">
                    <div className="rounded bg-profit/20 border border-profit/30 p-1.5 text-center">
                      <p className="text-[8px] font-black text-profit">✓ Sold</p>
                    </div>
                    <div className="rounded bg-secondary border border-border p-1.5 text-center">
                      <p className="text-[8px] font-black text-foreground/70">✏ Edit</p>
                    </div>
                  </div>
                </div>
              </div>
            </PhoneMockup>
            <div className="flex-1 space-y-0">
              <CheckRow label="Action sheet opens" desc="Name, condition, grade, and price shown immediately." />
              <CheckRow label="Edit button in header" desc="An Edit button appears in the top-right of the card sheet as soon as a card is found — one tap jumps straight into the edit form." />
              <CheckRow label="Mark as Sold" desc="Enter the sale price, pick Cash or Bank Card, confirm. Logged and archived instantly." />
              <CheckRow label="Edit Card" desc="Update any field without leaving the Scan page — accessible from both the header button and the action menu." />
              <CheckRow label="Send Receipt" desc="Email a branded receipt — your sender email is auto-filled from Settings. Just enter the customer's email and tap Send." />
              <CheckRow label="Recent Scans" desc="Scroll below the camera to see your full scan history — pulled from the database, not just today. Tap any entry to reopen that card." />
              <CheckRow label="Bulk Sale reminder" desc="A Pro Tip banner at the top of the Scan page reminds you Bulk Sale is available — tap Bulk in the header to launch it instantly." />
            </div>
          </div>

          {/* Barcode scan flow */}
          <div className="rounded-xl border border-blue-500/20 bg-blue-500/5 p-3 space-y-2">
            <div className="flex items-center gap-2">
              <Barcode className="w-4 h-4 text-blue-400 shrink-0" />
              <p className="text-[10px] font-black tracking-widest text-blue-400 uppercase">Sealed Product Barcode Flow</p>
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              When the camera picks up a numeric product barcode (EAN-13, UPC-A), it looks up the matching sealed product in your inventory. If found, the sealed product sheet opens with the product name, type, stock count, and sell price pre-filled.
            </p>
            <div className="space-y-1.5">
              {[
                { t: "Product found → sell immediately", d: "Tap Sell, confirm the price, done. Stock reduces by 1 and the sale logs to Earnings." },
                { t: "Product not yet in inventory", d: "A 'New Product' sheet appears. Fill in the details and save — the product is added to your Sealed inventory and ready to sell right away." },
                { t: "Auto-detection", d: "The scanner tells QR codes and barcodes apart automatically. No setting to flip — point and scan." },
              ].map(({ t, d }) => (
                <div key={t} className="flex items-start gap-2 text-[10px] text-muted-foreground border-t border-border/50 pt-1.5">
                  <div className="w-1 h-1 rounded-full bg-blue-400/70 shrink-0 mt-1.5" />
                  <span><strong className="text-foreground">{t}:</strong> {d}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-xl border border-border bg-secondary/20 p-3">
            <div className="flex items-center gap-2 mb-1.5">
              <Wifi className="w-3.5 h-3.5 text-profit" />
              <p className="text-[10px] font-black tracking-widest text-muted-foreground uppercase">Offline Mode</p>
            </div>
            <p>No signal? Scans queue locally with the correct timestamp. Back online, the queue syncs automatically. You have until <strong className="text-foreground">6am the next morning</strong> to reconnect — the queue clears at 6am as part of the daily reset.</p>
          </div>

          {/* Smart Error Handling */}
          <div className="rounded-xl border border-amber-600/20 bg-amber-600/5 p-3 space-y-2">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-500 shrink-0" />
              <p className="text-[10px] font-black tracking-widest text-amber-500 uppercase">Smart Scan Errors</p>
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">Scanning handles edge cases gracefully so you never get stuck at the table:</p>
            <div className="space-y-1.5">
              {[
                { t: "Card Not Found", d: "If the QR doesn't match any card in your vault, you'll see the scanned QR value, helpful suggestions (check inventory, re-scan, or it may belong to another vault), and a 'Close & Re-scan' button — no cryptic error codes." },
                { t: "Already Sold", d: "If you scan a card that's already been marked sold, an amber warning banner appears above the card details showing the sale date. You can still view the card info or move it back to inventory if needed." },
                { t: "Camera Permission Blocked", d: "If you've blocked camera access, a step-by-step guide appears showing exactly how to re-enable it in your specific browser (Chrome, Safari, Firefox, Samsung Internet). Tap 'Check Again' to retry without reloading the page." },
                { t: "Camera In Use", d: "If another app has the camera open, you'll see a blue panel explaining what to close (video calls, other tabs). Tap 'Check Again' once you've freed the camera." },
                { t: "No Camera Found", d: "If the device has no camera hardware, a clear message suggests switching to a phone or tablet. Appears on desktops without a webcam." },
              ].map(({ t, d }) => (
                <div key={t} className="flex items-start gap-2 text-[10px] text-muted-foreground">
                  <div className="w-1 h-1 rounded-full bg-amber-500/60 shrink-0 mt-1.5" />
                  <span><strong className="text-foreground">{t}:</strong> {d}</span>
                </div>
              ))}
            </div>
          </div>
          <Callout variant="warn">Offline scans queue locally and sync automatically when you reconnect. Any sales confirmed while online are always saved immediately. Unsynced pending entries show in yellow at the top of Recent Scans until they sync.</Callout>
          <div className="grid grid-cols-2 gap-2">
            <div className="flex items-center gap-2 p-3 rounded-xl border border-profit/30 bg-profit/8">
              <Banknote className="w-4 h-4 text-profit shrink-0" />
              <span className="text-xs font-bold text-foreground">Cash</span>
            </div>
            <div className="flex items-center gap-2 p-3 rounded-xl border border-blue-500/30 bg-blue-500/8">
              <CreditCard className="w-4 h-4 text-blue-400 shrink-0" />
              <span className="text-xs font-bold text-foreground">Bank Card</span>
            </div>
          </div>
          <Callout variant="pro">Tap <strong>Sell & Send Receipt</strong> to mark sold and email the customer simultaneously — one action, no extra steps. Your sender email is pre-filled automatically.</Callout>
        </BigStep>

        {/* STEP 7 — BULK SALE */}
        <BigStep n={7} icon={ShoppingCart} color="text-orange-400" title="Run a Bulk Sale — Scan Multiple Cards at Once">
          <p>Selling a customer multiple cards at once? <strong className="text-foreground">Bulk Sale</strong> lets you scan up to 100 cards, set a price for each, see a live running total, confirm the sale in one go, and send a single combined receipt.</p>
          <p>Find it on the <strong className="text-foreground">Dashboard → Bulk Sale</strong> quick-action tile, or via the <strong className="text-foreground">SCAN button</strong> on the Scan page header.</p>

          <div className="flex flex-col sm:flex-row gap-4 items-start">
            <PhoneMockup>
              <div className="space-y-1.5">
                {/* camera area */}
                <div className="h-20 rounded-xl border border-orange-500/30 bg-orange-500/8 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center opacity-20">
                    <QrCode className="w-10 h-10 text-orange-400" />
                  </div>
                  {/* corner guides */}
                  <div className="absolute top-2 left-3 w-3 h-3 border-t-2 border-l-2 border-orange-400 rounded-tl" />
                  <div className="absolute top-2 right-3 w-3 h-3 border-t-2 border-r-2 border-orange-400 rounded-tr" />
                  <div className="absolute bottom-2 left-3 w-3 h-3 border-b-2 border-l-2 border-orange-400 rounded-bl" />
                  <div className="absolute bottom-2 right-3 w-3 h-3 border-b-2 border-r-2 border-orange-400 rounded-br" />
                  <span className="text-[7px] font-black text-orange-400 bg-background/70 px-1.5 py-0.5 rounded z-10">Scanning…</span>
                </div>
                {/* pending card */}
                <div className="rounded-xl border-2 border-orange-500/50 bg-orange-500/8 p-2">
                  <p className="text-[8px] font-black text-foreground">Charizard VMAX</p>
                  <p className="text-[7px] text-muted-foreground">Pokémon · Near Mint</p>
                  <div className="flex gap-1.5 mt-1.5 items-center">
                    <div className="flex-1 h-5 rounded bg-secondary border border-border" />
                    <div className="px-2 h-5 rounded bg-orange-500 flex items-center">
                      <span className="text-[7px] font-black text-white">+ Add</span>
                    </div>
                  </div>
                </div>
                {/* cart */}
                <div className="rounded-xl border border-border overflow-hidden">
                  {[["Charizard VMAX","£85.00"],["Pikachu V","£12.00"]].map(([n, p]) => (
                    <div key={n} className="flex items-center justify-between px-2 py-1.5 border-b border-border last:border-0">
                      <span className="text-[7px] font-semibold">{n}</span>
                      <span className="text-[7px] font-black text-primary">{p}</span>
                    </div>
                  ))}
                  <div className="flex items-center justify-between px-2 py-1.5 bg-primary/10">
                    <span className="text-[7px] font-black uppercase text-primary">Total</span>
                    <span className="text-[9px] font-black text-primary">£97.00</span>
                  </div>
                </div>
              </div>
            </PhoneMockup>
            <div className="flex-1 space-y-0">
              <CheckRow label="Scan labels" desc="Open the Bulk Sale dialog — the camera activates instantly. Scan each card's QR label one by one." />
              <CheckRow label="Set price per card" desc="After each scan a price field pops up, pre-filled with the card's market value. Confirm or adjust." />
              <CheckRow label="Edit prices in cart" desc="Changed your mind on a price? Tap any price in the cart to edit it inline — the running total updates instantly. Confirm with the green tick or Enter, cancel with Escape." />
              <CheckRow label="Running total" desc="Cart updates live as you add, remove, or edit cards. Remove any card with the trash icon before confirming." />
              <CheckRow label="Confirm Sale" desc="Tap Confirm Sale — all cards are marked sold simultaneously and earnings are updated in a single batch write for maximum speed." />
              <CheckRow label="Combined receipt" desc="After confirming, optionally send one email receipt listing every card and the combined total. Sender email is pre-filled." />
            </div>
          </div>

          <div className="space-y-2">
            <p className="text-[10px] font-black tracking-[0.2em] text-muted-foreground uppercase">How Bulk Sale Works</p>
            <FlowDiagram steps={[
              { icon: ScanLine,     label: "Scan\nQR Labels",    color: "border-primary/30 bg-primary/8 text-primary" },
              { icon: DollarSign,   label: "Set\nPrices",        color: "border-amber-600/30 bg-amber-600/8 text-amber-500" },
              { icon: ShoppingCart, label: "Confirm\nSale",      color: "border-orange-500/30 bg-orange-500/8 text-orange-400" },
              { icon: TrendingUp,   label: "Logged to\nEarnings", color: "border-profit/30 bg-profit/8 text-profit" },
              { icon: Receipt,      label: "Send\nReceipt",      color: "border-blue-500/30 bg-blue-500/8 text-blue-400" },
            ]} />
          </div>

          <div className="rounded-xl border border-orange-500/20 bg-orange-500/8 p-3 space-y-1.5">
            <p className="text-[10px] font-black tracking-widest text-orange-400 uppercase">Limits & Error Handling</p>
            {["Max 100 cards per bulk sale.","Earnings update in one batch — no lag or conflicts even with 100 cards.","Sender email is pre-filled from Settings (set it in Step 1).","Already-sold cards trigger an amber alert overlay (4 seconds) showing the card name and an instant 'Unsell' recovery button — tap it to move the card back to active inventory and add it to the cart without leaving the scanner.","Card Not Found alerts show a clear icon badge and message to check and re-scan — no confusing error codes."].map(r => (
              <div key={r} className="flex items-start gap-2 text-[10px] text-muted-foreground">
                <div className="w-1 h-1 rounded-full bg-orange-400/60 shrink-0 mt-1.5" /><span>{r}</span>
              </div>
            ))}
          </div>
          <Callout variant="pro">At a busy show, keep Bulk Sale open the whole time a customer is browsing. Scan each card they pick up — when they're ready to buy, the total is already there. No mental maths, no delays.</Callout>
        </BigStep>

        {/* STEP 8 — EARNINGS (was 7) */}
        <BigStep n={8} icon={TrendingUp} color="text-profit" title="Track Your Earnings">
          <p>Every sale is logged automatically. The <strong className="text-foreground">Earnings</strong> page shows your complete financial history — broken down by day.</p>
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-xl border border-profit/20 bg-profit/8 p-3 flex flex-col gap-2">
              <BarChart3 className="w-4 h-4 text-profit" />
              <p className="text-[10px] font-bold text-foreground">Daily History</p>
              <p className="text-[10px] text-muted-foreground">Revenue, cards sold, profit, and top card per day. Tap a day to expand the full breakdown.</p>
            </div>
            <div className="rounded-xl border border-amber-600/20 bg-amber-600/8 p-3 flex flex-col gap-2">
              <Calendar className="w-4 h-4 text-amber-500" />
              <p className="text-[10px] font-bold text-foreground">Calendar Notes</p>
              <p className="text-[10px] text-muted-foreground">Yellow dots mark days with notes. Tap any day to open a preview box directly below the calendar showing that day's full note — no separate page needed. Tap the Edit button in the preview to update the note, or Add Note to create one.</p>
            </div>
            <div className="rounded-xl border border-profit/30 bg-profit/8 p-3 flex gap-3 items-start col-span-2">
              <TrendingUp className="w-4 h-4 text-profit shrink-0 mt-0.5" />
              <div>
                <p className="text-[10px] font-bold text-foreground">Profit Tracking</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">When you enter a purchase price on a card, profit is calculated automatically on every sale (sale price − purchase price). Today's profit appears as its own card on Earnings, and each day in history shows a profit line when available.</p>
              </div>
            </div>
            <div className="col-span-2 rounded-xl border border-primary/20 bg-primary/8 p-3 flex gap-3 items-start">
              <Zap className="w-4 h-4 text-primary fill-primary/20 shrink-0 mt-0.5" />
              <div>
                <p className="text-[10px] font-bold text-foreground">Event Mode — Multi-Day Shows</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">Turn it on from the Earnings page before or during a show. Your running total won't reset at 6am — it holds for 2–5 days depending on how many you choose. A full per-day breakdown is saved permanently when you end the event. A <strong className="text-foreground">Pro Tip reminder</strong> sits above the Event Mode toggle so you never forget to turn it on.</p>
              </div>
            </div>
          </div>

          {/* Buys Tab */}
          <div className="rounded-xl border border-orange-500/20 bg-orange-500/8 p-3 space-y-2">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-orange-400 shrink-0" />
              <p className="text-[10px] font-black tracking-widest text-orange-400 uppercase">Buys Tab — Your Buying History</p>
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">All deals logged from the Buyer Percentage Calculator appear here. The tab has three clickable summary stats at the top:</p>
            <div className="grid grid-cols-3 gap-1.5">
              <div className="rounded-lg bg-background/60 border border-border p-2 text-center">
                <p className="text-[9px] font-black text-foreground">12</p>
                <p className="text-[8px] text-muted-foreground">Total Deals</p>
              </div>
              <div className="rounded-lg bg-background/60 border border-orange-500/20 p-2 text-center">
                <p className="text-[9px] font-black text-orange-400">£840</p>
                <p className="text-[8px] text-muted-foreground">Total Paid</p>
              </div>
              <div className="rounded-lg bg-background/60 border border-profit/20 p-2 text-center">
                <p className="text-[9px] font-black text-profit">£360</p>
                <p className="text-[8px] text-muted-foreground">Margin Held</p>
              </div>
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed"><strong className="text-foreground">Tap Total Paid</strong> to pop up a detailed card showing your total paid-out amount across all deals. <strong className="text-foreground">Tap Margin Held</strong> to see your total margin kept. Each popup shows the number of deals included and has an X to dismiss.</p>
            <p className="text-[10px] text-muted-foreground leading-relaxed"><strong className="text-foreground">Tap any deal row</strong> to expand it — revealing the full breakdown (card value, paid out, you keep), the note you wrote at the time, card count if it was a multi-card deal, and a Delete button to remove the deal entirely.</p>
          </div>

          <Callout variant="tip">If totals look wrong after editing sold/unsold statuses, tap <strong>Recalculate</strong> (top-right of Earnings). It rebuilds all daily totals from your card records in one go.</Callout>
          <Callout variant="pro">Tap the <strong>Export PDF</strong> button to download a full earnings report — all daily totals, cards sold, average per card, and your best day. Works in GBP, USD, and EUR. The Buys PDF also exports with card count per deal.</Callout>
        </BigStep>

        {/* STEP 9 */}
        <BigStep n={9} icon={LayoutDashboard} color="text-primary" title="Use the Dashboard — Your Command Centre">
          <p>The <strong className="text-foreground">Dashboard</strong> is your live vault snapshot — open it first thing at every show. A personalised greeting welcomes you each time you visit — picked randomly from <strong className="text-foreground">141 unique messages</strong> packed with Pokemon, One Piece, MTG, Lorcana, sports references, and vendor humour.</p>
          <div className="flex flex-col sm:flex-row gap-4 items-start">
            <PhoneMockup>
              <div className="space-y-1.5">
                <div className="h-2 rounded bg-primary/20 w-20" />
                <div className="rounded-lg border border-primary/30 bg-primary/10 p-2.5 text-center">
                  <div className="text-[7px] text-primary/60 font-bold uppercase tracking-widest">Today's Earnings</div>
                  <div className="text-lg font-sans text-primary mt-0.5">£0.00</div>
                </div>
                <div className="grid grid-cols-2 gap-1">
                  {[["Vault","0/3,000"],["Sold","£0"],["Cards","0"],["Value","£0"]].map(([l,v]) => (
                    <div key={l} className="rounded border border-border bg-secondary/50 p-1.5 text-center">
                      <div className="text-[6px] text-muted-foreground uppercase">{l}</div>
                      <div className="text-[9px] font-bold">{v}</div>
                    </div>
                  ))}
                </div>
                <div className="rounded border border-primary/30 bg-primary/5 p-1.5 flex items-center gap-1.5">
                  <Bell className="w-3 h-3 text-primary" />
                  <span className="text-[8px] font-black text-primary">Nudge (2)</span>
                </div>
                <div className="rounded border border-border bg-secondary/30 p-1.5">
                  <div className="text-[6px] text-muted-foreground uppercase mb-1">Recent Cards</div>
                  <div className="space-y-0.5">
                    {["Charizard VMAX","Pikachu V"].map(c => (
                      <div key={c} className="rounded bg-secondary border border-border p-1 flex items-center justify-between">
                        <span className="text-[7px] font-semibold">{c}</span>
                        <span className="text-[7px] text-primary">ⓘ</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </PhoneMockup>
            <div className="flex-1 space-y-0">
              <CheckRow label="Today's Earnings" desc="Live running total. Resets at 6am each morning unless Event Mode is active (see Step 8)." />
              <CheckRow label="Target Tracker" desc="Set a money target — tap 'Set Target' below the earnings hero. Revenue from cards sold fills the progress bar, turning green with a trophy when you hit your goal. It rolls across days and never resets until reached." />
              <CheckRow label="Stats grid" desc="Cards in vault, total inventory value, cards sold today, all-time revenue." />
              <CheckRow label="Nudge button" desc="Team-only: appears in the header. One tap sends a full-screen alert with alarm sound to your teammate (see Step 10 for Team setup)." />
              <CheckRow label="Recent Cards" desc="Last 5 cards added. Tap any row to open the full info panel (same as Step 3)." />
              <CheckRow label="Quick Actions" desc="Scan QR Code, View Inventory, Bulk Sale, Print Labels — one-tap shortcuts to the most-used features." />
              <CheckRow label="7-Day Overview" desc="Collapsible bar chart showing Sales (red) and Buys (green) for the last 7 days. Tap any bar for exact amounts." />
              <CheckRow label="Buyer Percentage Calculator" desc="Enter up to 20 card prices and your buying percentage — the calculator shows the combined total, how much to pay the customer, and your margin. Tap Deal Accepted to log the deal and optionally email the customer a receipt." />
            </div>
          </div>

          {/* Target Tracker explainer */}
          <div className="rounded-xl border border-primary/20 bg-primary/5 p-3 space-y-3">
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-primary shrink-0" />
              <p className="text-[10px] font-black tracking-widest text-primary uppercase">Target Tracker</p>
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">The Target Tracker lets you set a revenue goal in your currency. Unlike the earnings total, it <strong className="text-foreground">never resets at 6am</strong> — the counter keeps rolling across days until you hit your target, then turns green with a trophy.</p>
            <div className="rounded-lg bg-background/60 border border-border p-2.5 space-y-1.5">
              <p className="text-[9px] font-black text-muted-foreground uppercase tracking-widest">How it works</p>
              {[
                { n: 1, t: "Set a target", d: "Tap 'Set Target' on the Dashboard. Enter a revenue amount in your currency — e.g. £500. This saves today as your start point." },
                { n: 2, t: "Progress rolls across days", d: "Every card you sell from that date onwards adds to the running total. If you earn £300 today and £200 tomorrow, you hit £500 and the tracker completes — no overnight reset." },
                { n: 3, t: "Target reached", d: "The progress bar turns green and a trophy icon appears. Tap 'Edit' to set a new target for your next goal — this resets the counter from today." },
                { n: 4, t: "Edit or clear any time", d: "Tap 'Edit' to change your target amount. Tap 'Clear' to remove it entirely. Setting a new target always resets the start date to today." },
              ].map(({ n, t, d }) => (
                <div key={n} className="flex gap-2.5 items-start pb-1.5 border-b border-border/50 last:border-0">
                  <div className="w-5 h-5 rounded-md bg-primary/20 text-primary text-[9px] font-black flex items-center justify-center shrink-0 mt-0.5">{n}</div>
                  <div>
                    <p className="text-[10px] font-bold text-foreground">{t}</p>
                    <p className="text-[9px] text-muted-foreground">{d}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="rounded-lg bg-background/60 border border-primary/20 p-2.5">
              <p className="text-[9px] font-black text-primary uppercase tracking-widest mb-1">Example</p>
              <p className="text-[9px] text-muted-foreground leading-relaxed">You set a target of <strong className="text-foreground">£500</strong> on Monday. By Tuesday evening you've earned £300. The bar shows <strong className="text-foreground">60% complete, £200 to go</strong>. On Wednesday you hit the final £200 — the bar turns green. You tap Edit and set a new target of £750 for the rest of the show.</p>
            </div>
          </div>

          {/* 7-Day Overview explainer */}
          <div className="rounded-xl border border-border bg-secondary/20 p-3 space-y-3">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-primary shrink-0" />
              <p className="text-[10px] font-black tracking-widest text-primary uppercase">7-Day Overview</p>
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">A collapsible bar chart at the bottom of the Dashboard showing your <strong className="text-foreground">Sales</strong> (red) and <strong className="text-foreground">Buys</strong> (green) side-by-side for the last 7 days. Tap the strip to expand or collapse the chart.</p>
            <div className="rounded-lg bg-background/60 border border-border p-2.5 space-y-1.5">
              <p className="text-[9px] font-black text-muted-foreground uppercase tracking-widest">Features</p>
              {[
                { t: "Rolling 7-day window", d: "Always shows the last 7 days ending today. Today's bar is highlighted with a bold label." },
                { t: "Sales vs Buys", d: "Red bars = revenue from selling cards/sealed. Green bars = money spent buying from customers via the Buyer Calculator." },
                { t: "Tap for details", d: "Tap any day's bar to see a tooltip with the exact Sales and Buys amounts for that day." },
                { t: "Adapts to all modes", d: "Grid lines work in both light and dark appearance. The chart collapses to save space when not needed." },
              ].map(({ t, d }) => (
                <div key={t} className="flex gap-2.5 items-start pb-1.5 border-b border-border/50 last:border-0">
                  <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0 mt-0.5" />
                  <div>
                    <p className="text-[10px] font-bold text-foreground">{t}</p>
                    <p className="text-[9px] text-muted-foreground">{d}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="rounded-lg bg-background/60 border border-border p-2.5">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  <ShoppingBag className="w-3 h-3 text-profit" />
                  <span className="text-[8px] font-black text-muted-foreground uppercase tracking-widest">7-Day Overview</span>
                </div>
                <div className="flex items-center gap-2 text-[7px] text-muted-foreground">
                  <span className="flex items-center gap-0.5"><span className="inline-block w-1.5 h-1.5 rounded-full bg-primary" /> Sales</span>
                  <span className="flex items-center gap-0.5"><span className="inline-block w-1.5 h-1.5 rounded-full bg-profit" /> Buys</span>
                </div>
              </div>
              <div className="relative flex items-end gap-1 h-10">
                {/* Horizontal grid lines */}
                <div className="absolute inset-0 flex flex-col justify-between pointer-events-none">
                  <div className="border-t border-current opacity-10" />
                  <div className="border-t border-current opacity-10" />
                  <div className="border-t border-current opacity-10" />
                  <div className="border-t border-current opacity-10" />
                </div>
                {[
                  { s: 20, b: 10 }, { s: 40, b: 25 }, { s: 15, b: 5 }, { s: 60, b: 30 },
                  { s: 35, b: 20 }, { s: 50, b: 40 }, { s: 70, b: 15 },
                ].map((d, i) => (
                  <div key={i} className="flex-1 flex gap-px items-end relative z-10">
                    <div className="flex-1 rounded-sm bg-primary" style={{ height: `${d.s}%` }} />
                    <div className="flex-1 rounded-sm bg-profit" style={{ height: `${d.b}%` }} />
                  </div>
                ))}
              </div>
              <div className="flex justify-between mt-1">
                {["Mon","Tue","Wed","Thu","Fri","Sat","Sun"].map((d, i) => (
                  <span key={d} className={`text-[6px] flex-1 text-center ${i === 6 ? "font-black text-primary" : "text-muted-foreground"}`}>{d}</span>
                ))}
              </div>
            </div>
          </div>

          {/* Buyer % Calculator explainer */}
          <div className="rounded-xl border border-orange-500/20 bg-orange-500/8 p-3 space-y-3">
            <div className="flex items-center gap-2">
              <Banknote className="w-4 h-4 text-orange-400 shrink-0" />
              <p className="text-[10px] font-black tracking-widest text-orange-400 uppercase">Buyer Percentage Calculator</p>
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">When buying a customer's cards at an event, you need to quickly work out a fair offer without doing mental arithmetic under pressure. The Buyer % Calculator is on the Dashboard for exactly this moment — and now supports <strong className="text-foreground">up to 20 cards</strong> in a single deal.</p>
            <div className="space-y-1.5">
              <div className="rounded-lg bg-background/60 border border-border p-2.5 space-y-1.5">
                <p className="text-[9px] font-black text-muted-foreground uppercase tracking-widest">How it works</p>
                {[
                  { n: 1, t: "Enter card prices", d: "Type in the market value for the first card. Tap the + button to add more cards — up to 20 per deal. A running total updates live as you add prices." },
                  { n: 2, t: "Pick your buying percentage", d: "Use the quick-tap buttons (50%, 60%, 70%, 75%, 80%) or type a custom %. This is what you're offering as a proportion of the combined total." },
                  { n: 3, t: "Read the live result", d: "Two figures update instantly: Pay Customer (what you hand over for all cards combined) and You Keep (your total margin on the deal)." },
                  { n: 4, t: "Tap Deal Accepted", d: "Logs the deal to your Buys history in Earnings, then opens a Deal Receipt dialog where you can email the customer a professional receipt showing every card value, the rate, and the total they received." },
                ].map(({ n, t, d }) => (
                  <div key={n} className="flex gap-2.5 items-start pb-1.5 border-b border-border/50 last:border-0">
                    <div className="w-5 h-5 rounded-md bg-orange-500/20 text-orange-400 text-[9px] font-black flex items-center justify-center shrink-0 mt-0.5">{n}</div>
                    <div>
                      <p className="text-[10px] font-bold text-foreground">{t}</p>
                      <p className="text-[9px] text-muted-foreground">{d}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Multi-price feature highlight */}
            <div className="rounded-lg bg-background/60 border border-orange-500/20 p-2.5 space-y-1.5">
              <p className="text-[9px] font-black text-orange-400 uppercase tracking-widest">Multi-Price Deals (Up to 20 Cards)</p>
              <p className="text-[9px] text-muted-foreground leading-relaxed">A customer wants to sell you a stack of cards? Tap <strong className="text-foreground">+ Add another card price</strong> for each card. Each entry gets its own input and a remove button. The counter shows your progress (e.g. 5/20). The total, pay amount, and your margin all calculate across the entire bundle automatically.</p>
            </div>

            <div className="rounded-lg bg-background/60 border border-border p-2.5">
              <p className="text-[9px] font-black text-muted-foreground uppercase tracking-widest mb-1.5">Example — Multi-Card Deal</p>
              <div className="space-y-1.5">
                <div className="grid grid-cols-4 gap-1 text-center">
                  {[["Card 1","£50"],["Card 2","£30"],["Card 3","£20"],["Total","£100"]].map(([l,v]) => (
                    <div key={l} className={`rounded p-1.5 ${l === "Total" ? "bg-orange-500/10 border border-orange-500/20" : "bg-secondary border border-border"}`}>
                      <p className={`text-[8px] font-black ${l === "Total" ? "text-orange-400" : "text-foreground"}`}>{v}</p>
                      <p className="text-[7px] text-muted-foreground mt-0.5">{l}</p>
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-3 gap-1.5 text-center">
                  <div className="rounded bg-orange-500/10 border border-orange-500/20 p-2">
                    <p className="text-[9px] font-black text-orange-400">70%</p>
                    <p className="text-[8px] text-muted-foreground mt-0.5">Offer</p>
                  </div>
                  <div className="rounded bg-profit/10 border border-profit/20 p-2">
                    <p className="text-[9px] font-black text-profit">£70.00</p>
                    <p className="text-[8px] text-muted-foreground mt-0.5">Pay Customer</p>
                  </div>
                  <div className="rounded bg-primary/10 border border-primary/20 p-2">
                    <p className="text-[9px] font-black text-primary">£30.00</p>
                    <p className="text-[8px] text-muted-foreground mt-0.5">You Keep</p>
                  </div>
                </div>
              </div>
              <p className="text-[9px] text-muted-foreground mt-2">3 cards totalling £100 at 70%: you pay £70 and keep £30 margin.</p>
            </div>

            {/* Deal Receipt feature */}
            <div className="rounded-lg bg-background/60 border border-blue-500/20 p-2.5 space-y-1.5">
              <div className="flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                <p className="text-[9px] font-black text-blue-400 uppercase tracking-widest">Deal Receipt Email</p>
              </div>
              <p className="text-[9px] text-muted-foreground leading-relaxed">After tapping <strong className="text-foreground">Deal Accepted</strong>, a receipt dialog opens showing a summary of the deal (amount paid, your margin, card count). Enter the customer's email and tap <strong className="text-foreground">Send Receipt</strong> to email them a professional branded receipt listing every card's value, the rate offered, and the total they received. Your business name, Instagram, and website are pulled from Settings automatically.</p>
            </div>

            <p className="text-[10px] text-muted-foreground leading-relaxed"><strong className="text-foreground">All logged deals</strong> appear in <strong className="text-foreground">Earnings → Buys tab</strong> with the card price, percentage offered, amount paid, and margin held. Today's buying activity also shows as a summary card on <strong className="text-foreground">Earnings → Today</strong>. The calendar also marks days where you logged buying deals with an orange dot.</p>
          </div>

          <Callout variant="pro">Run the Buyer Percentage Calculator before you name a price out loud. Knowing your exact margin before you speak keeps your offers confident and consistent — customers can tell when you're making it up as you go.</Callout>
        </BigStep>

        {/* STEP 10 */}
        <BigStep n={10} icon={Users} color="text-blue-400" title="Set Up Team Mode">
          <p>Running a stall with a partner? <strong className="text-foreground">Team Mode</strong> gives you both live presence and instant communication — go to <strong className="text-foreground">Settings → Team Mode</strong>.</p>
          <div className="rounded-xl border border-border bg-secondary/20 p-3 space-y-2">
            {[
              { n: 1, t: "Create or join a team", d: "Tap Create Team to become owner, or enter a 6-character code from your partner." },
              { n: 2, t: "Share your join code",  d: "Send the 6-character code to your teammate. They enter it under Join Team." },
              { n: 3, t: "You're both live",       d: "A presence bar appears at the top of every page showing who's online." },
            ].map(({ n, t, d }) => (
              <div key={n} className="flex gap-3 items-start">
                <div className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 text-[10px] font-black flex items-center justify-center shrink-0">{n}</div>
                <div className="flex-1 pb-2 border-b border-border/50 last:border-0">
                  <p className="text-xs font-bold text-foreground">{t}</p>
                  <p className="text-[10px] text-muted-foreground">{d}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-xl border border-blue-500/20 bg-blue-500/8 p-3 flex flex-col gap-1.5">
              <Wifi className="w-4 h-4 text-blue-400" />
              <p className="text-[10px] font-bold text-foreground">Live Presence</p>
              <p className="text-[10px] text-muted-foreground">Green dot = online. Grey = offline. Heartbeat fires every 20 seconds; a member is shown as online if seen within the last 60 seconds.</p>
            </div>
            <div className="rounded-xl border border-primary/20 bg-primary/8 p-3 flex flex-col gap-1.5">
              <Bell className="w-4 h-4 text-primary" />
              <p className="text-[10px] font-bold text-foreground">Nudge</p>
              <p className="text-[10px] text-muted-foreground">Sends a full-screen alert with an alarm sound to your teammate. Max 2 per minute. Available from Dashboard header AND Settings.</p>
            </div>
          </div>
          <div className="rounded-xl border border-border bg-secondary/20 p-3 space-y-1.5 text-[11px] text-muted-foreground">
            <p className="text-[10px] font-black tracking-widest text-muted-foreground uppercase mb-1">Team Rules</p>
            {["Max 2 members (owner + 1).","Owner can remove the member or dissolve the team at any time.","Members can leave whenever they like.","Owner can regenerate the join code to block the old one."].map(r => (
              <div key={r} className="flex items-start gap-2"><div className="w-1 h-1 rounded-full bg-primary/50 shrink-0 mt-1.5" /><span>{r}</span></div>
            ))}
          </div>
          <Callout variant="pro">Agree a nudge code with your teammate before the show — e.g. 1 nudge = "I need help at the table". Faster than shouting across a busy hall.</Callout>
        </BigStep>

        {/* STEP 11 */}
        <BigStep n={11} icon={Shield} color="text-muted-foreground" title="Account Rules & Activity Log">
          <p>Significant account actions are logged automatically. Find it in <strong className="text-foreground">Settings → Security</strong>.</p>

          {/* Account Rules */}
          <div className="rounded-xl border border-primary/20 bg-primary/5 p-3 space-y-1.5">
            <p className="text-[10px] font-black tracking-widest text-primary uppercase mb-1">Account Rules</p>
            {[
              "1 account per email — you cannot create multiple accounts with the same email address.",
              "Username changes are limited to once every 14 days.",
              "Names and usernames must follow community guidelines (no offensive language).",
              "Suspended accounts cannot access any app features until reinstated by an admin.",
            ].map(r => (
              <div key={r} className="flex items-start gap-2 text-[10px] text-muted-foreground">
                <div className="w-1 h-1 rounded-full bg-primary/60 shrink-0 mt-1.5" /><span>{r}</span>
              </div>
            ))}
          </div>

          <div className="rounded-xl border border-border bg-secondary/20 p-3 space-y-0">
            <p className="text-[10px] font-black tracking-widest text-muted-foreground uppercase mb-2">What Gets Logged</p>
            <CheckRow label="Team events"    desc="Team created, joined, left, or dissolved." />
            <CheckRow label="Account events" desc="Settings saved, username changed." />
            <CheckRow label="Earnings events" desc="Earnings recalculated or snapshot restored." />
            <CheckRow label="Timestamps on all entries" desc="Every log entry shows the full date and time — including the hour and minute — so you have a precise audit trail." />
          </div>
          <Callout variant="warn">The log is <strong>read-only</strong> — entries cannot be edited or deleted. This is by design: it's a trustworthy audit trail.</Callout>
          <Callout variant="tip">Check the log after making any account or team changes to confirm everything registered correctly.</Callout>
        </BigStep>

        {/* STEP 12 — PWA */}
        <BigStep n={12} icon={Sparkles} color="text-purple-400" title="Make DatCARDVault An App On Your Phone">
          <p>DatCARDVault works as a <strong className="text-foreground">Progressive Web App (PWA)</strong> — you can save it to your home screen so it opens like a native app, full screen, no browser bar.</p>
          <div className="rounded-xl border border-border bg-secondary/20 p-3 space-y-2">
            <p className="text-[10px] font-black tracking-widest text-muted-foreground uppercase">How to Add to Your Home Screen</p>
            {[
              { n: 1, t: "Android — Google Chrome (Recommended)", d: "Open in Chrome → tap the three-dot menu (⋮) → tap 'Add to Home Screen' or 'Install app'. Chrome gives the most reliable install experience on Android." },
              { n: 2, t: "iPhone / iPad — Safari",     d: "Tap the Share button (box with arrow) → scroll down → tap 'Add to Home Screen'. Must use Safari on iOS." },
              { n: 3, t: "Desktop — Chrome / Edge / Opera", d: "Click the install icon (⊕) in the address bar, or open the menu → 'Install DatCARDVault' / 'Install app'." },
            ].map(({ n, t, d }) => (
              <div key={n} className="flex gap-3 items-start">
                <div className="w-6 h-6 rounded-lg bg-purple-500/20 text-purple-400 text-[10px] font-black flex items-center justify-center shrink-0">{n}</div>
                <div className="flex-1 pb-2 border-b border-border/50 last:border-0">
                  <p className="text-xs font-bold text-foreground">{t}</p>
                  <p className="text-[10px] text-muted-foreground">{d}</p>
                </div>
              </div>
            ))}
          </div>
          <Callout variant="tip">We <strong>highly recommend Google Chrome</strong> on Android and Desktop — it has the most reliable "Install app" feature and works great with DatCARDVault. On iOS, use <strong>Safari</strong> (required for Add to Home Screen on iPhone/iPad).</Callout>
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-xl border border-purple-500/20 bg-purple-500/8 p-3 flex flex-col gap-1.5">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <p className="text-[10px] font-bold text-foreground">Full Screen</p>
              <p className="text-[10px] text-muted-foreground">No browser chrome, no URL bar — just the app, exactly like a native install.</p>
            </div>
            <div className="rounded-xl border border-profit/20 bg-profit/8 p-3 flex flex-col gap-1.5">
              <Wifi className="w-4 h-4 text-profit" />
              <p className="text-[10px] font-bold text-foreground">Works Offline</p>
              <p className="text-[10px] text-muted-foreground">The app caches itself so it loads even with no signal. Scans queue and sync when back online.</p>
            </div>
          </div>
          <Callout variant="pro">Save the app to your phone's home screen before a show — it's faster to launch, stays full screen, and works even in dead-signal venues.</Callout>
          <Callout variant="tip">If you see a notification in the bottom-left corner saying "New version available", tap <strong>Refresh now</strong> to get the latest DatCARDVault updates instantly.</Callout>
        </BigStep>

      </section>

      {/* ═══════════════════ PRO TIPS ═══════════════════ */}
      <SectionDivider label="Pro Tips" />

      <section className="space-y-4">
        <Fade>
          <div className="text-center mb-2">
            <p className="text-[10px] font-black tracking-[0.2em] text-primary uppercase mb-1">Level Up Your Game</p>
            <h2 className="text-2xl font-sans tracking-wider">Pro Tips</h2>
            <p className="text-sm text-muted-foreground mt-1">Advanced habits that separate casual users from power vendors.</p>
          </div>
        </Fade>

        <ProTip icon={DollarSign} title="Update Market Values Before Every Show"
          desc="Check TCGPlayer or eBay the night before and update your market values in Inventory. Prices shift fast — a stale value means you might undersell or lose a customer who knows the real price." />

        <ProTip icon={Tag} title="Batch Print All Labels the Night Before"
          desc="Never scramble to print on show morning. Add all new cards the evening before, go to Labels, select them all, hit Print once. One job, all labels done — show day starts calm." />

        <ProTip icon={RefreshCw} title="Track % Bought At Over Time"
          desc="Filling in % Bought At for every purchase lets you see if your buying habits are improving. If your average starts dropping below 50%, you're buying smarter and leaving more margin on the table." />

        <ProTip icon={TrendingDown} title="Drop the Price on Cards That Aren't Selling"
          desc="If a card has been in your vault for multiple shows without a sale, edit its market value down in Inventory. Reprint the label and the new price shows next time. Sometimes a small cut moves stuck stock." />

        <ProTip icon={SortAsc} title="Organise Physical Cards by Game"
          desc="Sort your physical card binders to match your vault — Pokémon together, Yu-Gi-Oh together, etc. When a customer asks 'got any Pokémon?', you know exactly where to look without fumbling." />

        <ProTip icon={Calendar} title="Use Calendar Notes to Evaluate Shows"
          desc="After every show, tap that date on the Calendar page — a preview box opens below the grid. Hit Add Note and jot down the venue name, how busy it was, and what sold best. Over time, this tells you which events are worth attending again and which aren't worth the table fee." />

        <ProTip icon={Banknote} title="Always Enter a Sale Price, Even Zero"
          desc="Giving a card away free? Log it as £0 / $0. Cards sold without any price appear in your Sold archive but don't count toward your earnings totals — which makes your numbers look inaccurate." />

        <ProTip icon={Camera} title="Photo Every Card Before a Show"
          desc="Customers regularly ask about a card you sold earlier in the day or at a previous show. The photo in your Sold archive answers the question without guesswork — and looks far more professional than a shrug." />

        <ProTip icon={Mail} title="Set Your Sender Email Once in Settings"
          desc="Your verified sender email is saved in Settings under Label Branding / Receipt Setup. Once saved, it's locked in and auto-fills every time you send a receipt — you'll never see or need to type it again. Just enter the customer's email and hit Send." />

        <ProTip icon={Banknote} title="Use the Buyer Percentage Calculator Before Naming a Price"
          desc="Before quoting a buying price at the table, open the Dashboard and punch in the market value. Pick your % with one tap — 50%, 60%, 70%, 75%, or 80% — and read your exact offer and margin before you speak. Tap Deal Accepted to log it, then review everything in Earnings → Buys." />
      </section>

      {/* ═══════════════════ BECOME A PRO ═══════════════════ */}
      <SectionDivider label="Become a Pro" />

      <section className="space-y-5">
        <Fade>
          <div className="relative rounded-2xl border-2 border-primary/40 bg-primary/5 overflow-hidden p-6 text-center">
            <div className="absolute inset-0 pointer-events-none"
              style={{ background: "radial-gradient(ellipse at top, rgba(204,0,0,0.12) 0%, transparent 65%)" }} />
            <motion.div
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
              className="relative z-10"
            >
              <p className="text-[10px] font-black tracking-[0.3em] text-primary uppercase mb-2">The Pro Vendor Checklist</p>
              <h2 className="text-3xl font-sans tracking-widest text-foreground">Are You a Pro?</h2>
            </motion.div>
          </div>
        </Fade>

        <Fade>
          <div className="rounded-2xl border border-border bg-secondary/20 p-4 space-y-0">
            {[
              { label: "Profile complete",              desc: "Username, currency, business name, Instagram, and website all saved." },
              { label: "Sender email set & locked",    desc: "Verified sender email saved in Label Branding / Receipt Setup — auto-fills on every receipt." },
              { label: "Labels printed with branding",  desc: "Every label carries your business name and social handles." },
              { label: "Every card has a photo",        desc: "No placeholder icons — real photos for all active cards." },
              { label: "Bluetooth printer paired",      desc: "Printing labels in under 30 seconds from anywhere in the app." },
              { label: "Printer calibrated",            desc: "Darkness, feed, and scale dialled in via Print Preview — test print verified on real tape." },
              { label: "Scanning to sell at the table", desc: "Using the SCAN button for every sale — not editing Inventory manually." },
              { label: "Scan errors understood",        desc: "You know 'Card Not Found' shows the QR value with suggestions, and 'Already Sold' shows the sale date — no panic at the table." },
              { label: "Bulk Sale used at shows",       desc: "Multi-card sales confirmed in one scan session with a combined receipt sent. 'Unsell' recovery used if needed." },
              { label: "Buyer Percentage Calculator used",        desc: "Calculator opened on Dashboard before quoting any buying price. Deals logged via Deal Accepted button." },
              { label: "Buys tab reviewed after shows", desc: "Tap deals to expand breakdowns — check notes, card counts, and margins. Tap Total Paid or Margin Held stats for quick summaries." },
              { label: "Event Mode on at shows",        desc: "Running total doesn't reset overnight during multi-day events (2–5 days)." },
              { label: "Calendar notes logged",         desc: "Every show has a note — tap the date, preview opens below, add venue name, what sold, how busy it was." },
              { label: "Team Mode active",              desc: "Partner has joined, presence bar is showing, nudge has been tested." },
              { label: "Activity log reviewed",         desc: "Audit trail checked after every show before closing out." },
              { label: "Market values kept fresh",      desc: "Prices updated before each show from current market data." },
              { label: "CSV Import used for bulk stock", desc: "eBay Seller Hub CSV or Standard spreadsheet imported via Inventory → Import CSV instead of manual entry." },
              { label: "Aging Report checked", desc: "Inventory → Aging tab reviewed before every show — anything over 60 days repriced or discounted." },
              { label: "App saved to phone",          desc: "Added to home screen as a PWA — full screen, fast launch, works offline." },
            ].map(({ label, desc }) => (
              <CheckRow key={label} label={label} desc={desc} />
            ))}
          </div>
        </Fade>

        <Fade>
          <div className="rounded-2xl border border-primary/30 bg-primary/5 p-5 text-center space-y-3">
            <div className="w-14 h-14 rounded-full bg-primary/15 border-2 border-primary/30 flex items-center justify-center mx-auto">
              <Star className="w-6 h-6 text-primary fill-primary/30" />
            </div>
            <p className="text-sm font-black text-foreground">19 / 19 checked?</p>
            <p className="text-xs text-muted-foreground max-w-xs mx-auto leading-relaxed">
              You're running your vault like a pro. Your inventory is organised, your branding is on every card, bulk sales fly through at shows, and your earnings are tracked to the penny. That's the DatCARDVault way.
            </p>
            <p className="text-[10px] font-black tracking-[0.3em] text-primary uppercase">The pocket business assistant for TCG vendors</p>
          </div>
        </Fade>
      </section>

      {/* ═══════════════════ QUICK JUMP ═══════════════════ */}
      <SectionDivider label="Jump To" />

      <section className="space-y-3">
        <Fade>
          <p className="text-[10px] font-black tracking-[0.2em] text-muted-foreground uppercase mb-2">Go To Page</p>
        </Fade>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {[
            { label: "Dashboard",    path: "/",          icon: LayoutDashboard },
            { label: "Inventory",    path: "/inventory", icon: Package },
            { label: "Labels",       path: "/labels",    icon: Tag },
            { label: "Scan & Sell",  path: "/scan",      icon: ScanLine },
            { label: "Earnings",     path: "/earnings",  icon: TrendingUp },
            { label: "Printer Hub",  path: "/printer",   icon: Printer },
            { label: "Settings",     path: "/settings",  icon: Settings },
          ].map(({ label, path, icon: Icon }, i) => (
            <Fade key={path} delay={i * 0.04}>
              <button
                onClick={() => navigate(path)}
                className="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-border bg-secondary/30 hover:border-primary/60 hover:bg-primary/5 transition-all cursor-pointer group"
              >
                <div className="flex items-center gap-2">
                  <Icon className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
                  <span className="text-sm font-semibold text-foreground">{label}</span>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
              </button>
            </Fade>
          ))}
        </div>
      </section>

      {/* Footer */}
      <Fade className="flex flex-col items-center gap-3 pt-12 pb-4">
        <img src="https://hercules-cdn.com/file_EE34NaUnA3bKpI5N0uZwrMZy" alt="" className="w-10 h-10 opacity-30" />
        <p className="text-[10px] text-muted-foreground tracking-[0.25em] uppercase text-center">Dat<span className="text-primary font-bold">CARD</span>Vault · The pocket business assistant for TCG vendors</p>
        <p className="text-[10px] text-muted-foreground/50">Run Your Vault Like A Pro.</p>
        <div className="flex items-center gap-2 mt-1">
          <span className="text-[9px] font-bold tracking-widest text-primary bg-primary/10 border border-primary/30 px-2 py-0.5 rounded-full">Build-v{BUILD_VERSION}</span>
          <span className="text-[9px] font-bold tracking-widest text-primary bg-primary/10 border border-primary/30 px-2 py-0.5 rounded-full">UI-v{UI_VERSION}</span>
        </div>
      </Fade>
    </div>
  );
}
