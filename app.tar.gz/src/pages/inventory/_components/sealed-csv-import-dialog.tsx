import { useRef, useState } from "react";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import Papa from "papaparse";
import { Button } from "@/components/ui/button.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Upload, Download, CheckCircle, AlertCircle, AlertTriangle, Loader2, FileText, X,
} from "lucide-react";
import { toast } from "sonner";
import { formatCurrency } from "@/lib/utils.ts";
import { motion } from "motion/react";

const VALID_GAMES = [
  "Pokémon", "Magic: The Gathering", "Yu-Gi-Oh! Official", "One Piece",
  "Flesh and Blood", "Digimon", "Star Wars: Unlimited", "Weiss Schwarz",
  "Cardfight!! Vanguard", "Lorcana", "Dragon Ball Super", "Other",
];

const SEALED_TYPES = [
  "Booster Box", "Elite Trainer Box", "Booster Pack", "Collection Box",
  "Tin", "Bundle", "Blister Pack", "Case", "Build & Battle", "Other",
];

// ─── Standard template ───────────────────────────────────────────────────────
const STANDARD_TEMPLATE_ROWS = [
  ["name", "game", "type", "barcode", "purchase_price", "sell_price", "quantity", "notes"],
  ["Scarlet & Violet Booster Box", "Pokémon", "Booster Box", "820650853791", "90.00", "130.00", "3", "Sealed"],
  ["Modern Horizons 3 Bundle", "Magic: The Gathering", "Bundle", "", "45.00", "60.00", "5", ""],
];

// ─── eBay column aliases for sealed products ─────────────────────────────────
const EBAY_TITLE_KEYS     = ["item_title", "title", "item_name", "listing_title", "product_name"];
const EBAY_PRICE_KEYS     = ["sold_for", "buy_it_now_price", "start_price", "price", "item_price", "total_price", "amount", "purchase_price"];
const EBAY_QTY_KEYS       = ["quantity", "qty", "quantity_sold", "quantity_available", "quantity_purchased"];
const EBAY_CONDITION_KEYS = ["item_condition", "condition"];
const EBAY_SKU_KEYS       = ["custom_label", "custom_label_(sku)", "sku", "custom_label_sku", "barcode", "upc", "ean"];

function findKey(row: Record<string, string>, aliases: string[]): string | undefined {
  for (const k of aliases) {
    if (k in row) return k;
  }
  return undefined;
}

// Strip currency symbols and commas then parse
function parseMoney(s: string): number | undefined {
  const cleaned = s.replace(/[^0-9.]/g, "");
  const n = parseFloat(cleaned);
  return isNaN(n) ? undefined : n;
}

type ParsedSealedRow = {
  name: string;
  game: string;
  type: string;
  barcode: string;
  purchasePrice?: number;
  sellPrice?: number;
  quantity: number;
  notes?: string;
  _rowNum: number;
  _errors: string[];
};

// ─── Parsers ─────────────────────────────────────────────────────────────────
function parseStandardRows(raw: Record<string, string>[]): ParsedSealedRow[] {
  return raw.map((row, i) => {
    const errors: string[] = [];
    const name = (row["name"] ?? "").trim();
    const game = (row["game"] ?? "").trim();
    const type = (row["type"] ?? "Other").trim();
    const barcode = (row["barcode"] ?? "").trim();
    const qtyRaw = parseInt(row["quantity"] ?? "1");
    const quantity = isNaN(qtyRaw) ? 1 : Math.max(1, qtyRaw);

    if (!name) errors.push("Name is required");
    if (!game) errors.push("Game is required");
    else if (!VALID_GAMES.includes(game)) errors.push(`Game "${game}" not recognised — use: ${VALID_GAMES.join(", ")}`);
    if (type && !SEALED_TYPES.includes(type)) errors.push(`Type "${type}" not recognised — use: ${SEALED_TYPES.join(", ")}`);

    const purchasePrice = row["purchase_price"] ? parseMoney(row["purchase_price"]) : undefined;
    const sellPrice     = row["sell_price"]     ? parseMoney(row["sell_price"])     : undefined;

    if (row["purchase_price"] && purchasePrice === undefined) errors.push("purchase_price must be a number");
    if (row["sell_price"]     && sellPrice     === undefined) errors.push("sell_price must be a number");

    return {
      name,
      game: VALID_GAMES.includes(game) ? game : "Other",
      type: SEALED_TYPES.includes(type) ? type : "Other",
      barcode,
      purchasePrice,
      sellPrice,
      quantity,
      notes: row["notes"]?.trim() || undefined,
      _rowNum: i + 2,
      _errors: errors,
    };
  });
}

function parseEbayRows(raw: Record<string, string>[], defaultGame: string, defaultType: string): ParsedSealedRow[] {
  return raw.map((row, i) => {
    const errors: string[] = [];

    // Name — from item title
    const titleKey = findKey(row, EBAY_TITLE_KEYS);
    const name = titleKey ? (row[titleKey] ?? "").trim() : "";
    if (!name) errors.push("Could not find item title column (expected: Item Title, Title, or Product Name)");

    // Price — treat as purchase price (what was paid)
    const priceKey = findKey(row, EBAY_PRICE_KEYS);
    const purchasePrice = priceKey ? parseMoney(row[priceKey] ?? "") : undefined;

    // Qty
    const qtyKey = findKey(row, EBAY_QTY_KEYS);
    const qtyRaw = qtyKey ? parseInt(row[qtyKey] ?? "1") : 1;
    const quantity = isNaN(qtyRaw) ? 1 : Math.max(1, qtyRaw);

    // Barcode / SKU
    const skuKey = findKey(row, EBAY_SKU_KEYS);
    const barcode = skuKey ? (row[skuKey] ?? "").trim() : "";

    // Condition — informational, stored in notes
    const condKey = findKey(row, EBAY_CONDITION_KEYS);
    const rawCond = condKey ? (row[condKey] ?? "").trim() : "";

    // Build notes from eBay metadata
    const noteParts: string[] = [];
    if (rawCond) noteParts.push(`Condition: ${rawCond}`);
    if (row["order_number"])              noteParts.push(`eBay order: ${row["order_number"]}`);
    else if (row["sales_record_number"])  noteParts.push(`eBay record: ${row["sales_record_number"]}`);
    if (row["sale_date"] ?? row["sold_on"] ?? row["date"] ?? row["purchase_date"]) {
      const d = row["sale_date"] ?? row["sold_on"] ?? row["date"] ?? row["purchase_date"];
      if (d) noteParts.push(`Date: ${d}`);
    }

    return {
      name,
      game: defaultGame,
      type: defaultType,
      barcode,
      purchasePrice,
      sellPrice: purchasePrice, // use purchase price as sell reference too
      quantity,
      notes: noteParts.join(" | ") || undefined,
      _rowNum: i + 2,
      _errors: errors,
    };
  });
}

// ─── Template downloads ───────────────────────────────────────────────────────
type ImportMode = "standard" | "ebay";

function downloadTemplate(mode: ImportMode) {
  let rows: string[][];
  let filename: string;

  if (mode === "ebay") {
    rows = [
      ["Item Title", "Price", "Custom Label", "Quantity", "Item Condition", "Order Number", "Purchase Date"],
      ["Scarlet & Violet 151 Booster Box", "90.00", "820650853791", "2", "Brand New", "12-34567-89012", "2024-03-15"],
      ["Modern Horizons 3 Collector Box", "250.00", "", "1", "New", "12-34567-89013", "2024-03-16"],
    ];
    filename = "ebay_sealed_import_template.csv";
  } else {
    rows = STANDARD_TEMPLATE_ROWS;
    filename = "sealed_import_template.csv";
  }

  const csv = rows.map(r => r.map(c => `"${c.replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// ─── Types ────────────────────────────────────────────────────────────────────
type Props = {
  open: boolean;
  onClose: () => void;
  currency: string;
};

type Step = "upload" | "preview" | "importing" | "done";

// ─── Component ────────────────────────────────────────────────────────────────
export default function SealedCsvImportDialog({ open, onClose, currency }: Props) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [step, setStep]               = useState<Step>("upload");
  const [mode, setMode]               = useState<ImportMode>("standard");
  const [defaultGame, setDefaultGame] = useState<string>("Pokémon");
  const [defaultType, setDefaultType] = useState<string>("Booster Box");
  const [rows, setRows]               = useState<ParsedSealedRow[]>([]);
  const [parseError, setParseError]   = useState<string | null>(null);
  const [importedCount, setImportedCount] = useState(0);
  const [skippedCount, setSkippedCount]   = useState(0);
  const [fileName, setFileName]           = useState<string | null>(null);

  const addSealedProduct = useMutation(api.sealedProducts.addSealedProduct);

  const reset = () => {
    setStep("upload");
    setRows([]);
    setParseError(null);
    setImportedCount(0);
    setSkippedCount(0);
    setFileName(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleClose = () => { reset(); onClose(); };

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setParseError(null);
    setFileName(file.name);

    if (!file.name.endsWith(".csv") && file.type !== "text/csv") {
      setParseError("Please upload a .csv file.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setParseError("File must be under 5 MB.");
      return;
    }

    Papa.parse<Record<string, string>>(file, {
      header: true,
      skipEmptyLines: true,
      transformHeader: h => h.trim().toLowerCase().replace(/[\s/()]+/g, "_").replace(/_+$/, ""),
      complete: results => {
        if (results.errors.length > 0) {
          setParseError(`Could not read file: ${results.errors[0].message}`);
          return;
        }
        let parsed: ParsedSealedRow[];
        if (mode === "ebay") {
          parsed = parseEbayRows(results.data, defaultGame, defaultType);
        } else {
          parsed = parseStandardRows(results.data);
        }
        if (parsed.length === 0) {
          setParseError("The CSV has no data rows.");
          return;
        }
        setRows(parsed);
        setStep("preview");
      },
      error: err => setParseError(`Parse error: ${err.message}`),
    });
  };

  const validRows   = rows.filter(r => r._errors.length === 0);
  const invalidRows = rows.filter(r => r._errors.length > 0);

  const handleImport = async () => {
    setStep("importing");
    let ok = 0;
    let skipped = 0;
    for (const row of validRows) {
      try {
        await addSealedProduct({
          name: row.name,
          game: row.game,
          type: row.type,
          barcode: row.barcode,
          purchasePrice: row.purchasePrice,
          sellPrice: row.sellPrice,
          quantity: row.quantity,
          notes: row.notes,
        });
        ok++;
      } catch {
        skipped++;
      }
    }
    setImportedCount(ok);
    setSkippedCount(skipped + invalidRows.length);
    setStep("done");
    toast.success(`Imported ${ok} sealed product${ok !== 1 ? "s" : ""} to your inventory`);
  };

  return (
    <Dialog open={open} onOpenChange={o => { if (!o) handleClose(); }}>
      <DialogContent className="max-w-2xl max-h-[90dvh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="font-sans text-primary tracking-widest flex items-center gap-2">
            <Upload className="h-4 w-4" /> Import Sealed Products from CSV
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-4 min-h-0">

          {/* Upload step */}
          {step === "upload" && (
            <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">

              {/* Mode switcher */}
              <div className="flex gap-1.5 p-1 bg-secondary/50 rounded-xl border border-border w-fit">
                {(["standard", "ebay"] as ImportMode[]).map(m => (
                  <button
                    key={m}
                    onClick={() => { setMode(m); setParseError(null); }}
                    className={`px-4 py-1.5 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
                      mode === m ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {m === "standard" ? "Standard" : "eBay"}
                  </button>
                ))}
              </div>

              {/* Mode-specific instructions */}
              {mode === "standard" && (
                <div className="flex items-start gap-3 p-3 rounded-xl border border-border bg-secondary/40">
                  <FileText className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0 space-y-1">
                    <p className="text-sm font-semibold">Standard format</p>
                    <p className="text-xs text-muted-foreground">
                      Required columns: <span className="font-mono text-foreground">name</span>, <span className="font-mono text-foreground">game</span>.
                      {" "}Optional: type, barcode, purchase_price, sell_price, quantity, notes.
                    </p>
                  </div>
                  <Button size="sm" variant="secondary" onClick={() => downloadTemplate("standard")} className="gap-1.5 shrink-0">
                    <Download className="h-3.5 w-3.5" /> Template
                  </Button>
                </div>
              )}

              {mode === "ebay" && (
                <div className="space-y-3">
                  <div className="flex items-start gap-3 p-3 rounded-xl border border-border bg-secondary/40">
                    <FileText className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
                    <div className="flex-1 min-w-0 space-y-2">
                      <p className="text-sm font-semibold">eBay Sealed Product format</p>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        Export your purchase history or orders from eBay. Columns automatically mapped:
                        {" "}<span className="font-mono text-foreground">Item Title</span> → product name,
                        {" "}<span className="font-mono text-foreground">Price</span> → purchase price,
                        {" "}<span className="font-mono text-foreground">Custom Label / UPC</span> → barcode,
                        {" "}<span className="font-mono text-foreground">Quantity</span> → stock count.
                        {" "}Condition, order number, and date are saved in notes.
                      </p>
                      <p className="text-xs text-amber-400/90">
                        eBay listings don&apos;t include game or product type, so select defaults below.
                      </p>
                    </div>
                    <Button size="sm" variant="secondary" onClick={() => downloadTemplate("ebay")} className="gap-1.5 shrink-0">
                      <Download className="h-3.5 w-3.5" /> Template
                    </Button>
                  </div>

                  {/* Default game & type selector */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <Label className="text-sm font-semibold">Default game</Label>
                      <Select value={defaultGame} onValueChange={setDefaultGame}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {VALID_GAMES.map(g => (
                            <SelectItem key={g} value={g}>{g}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-sm font-semibold">Default type</Label>
                      <Select value={defaultType} onValueChange={setDefaultType}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {SEALED_TYPES.map(t => (
                            <SelectItem key={t} value={t}>{t}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              )}

              {/* File picker */}
              <input ref={fileInputRef} type="file" accept=".csv" className="hidden" onChange={handleFile} />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full h-32 rounded-2xl border-2 border-dashed border-primary/40 bg-primary/5 hover:bg-primary/10 hover:border-primary/60 transition-all cursor-pointer flex flex-col items-center justify-center gap-2"
              >
                <Upload className="h-7 w-7 text-primary" />
                <span className="font-semibold text-primary text-sm">
                  {mode === "ebay" ? "Click to select eBay sealed CSV" : "Click to select CSV file"}
                </span>
                <span className="text-xs text-muted-foreground">Max 5 MB</span>
              </button>

              {parseError && (
                <div className="flex items-start gap-2 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-400">
                  <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                  {parseError}
                </div>
              )}
            </motion.div>
          )}

          {/* Preview step */}
          {step === "preview" && (
            <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="space-y-3">
              {/* Summary */}
              <div className="flex items-center gap-2 flex-wrap">
                {mode === "ebay" && (
                  <Badge className="bg-primary/20 text-primary border-primary/30 gap-1 text-[10px]">
                    eBay import · {defaultGame} · {defaultType}
                  </Badge>
                )}
                <Badge className="bg-profit/20 text-profit border-profit/30 gap-1">
                  <CheckCircle className="h-3 w-3" /> {validRows.length} ready to import
                </Badge>
                {invalidRows.length > 0 && (
                  <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30 gap-1">
                    <AlertTriangle className="h-3 w-3" /> {invalidRows.length} will be skipped
                  </Badge>
                )}
                {fileName && <span className="text-xs text-muted-foreground">{fileName}</span>}
                <button onClick={reset} className="ml-auto text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 cursor-pointer">
                  <X className="h-3 w-3" /> Change file
                </button>
              </div>

              {/* Errors */}
              {invalidRows.length > 0 && (
                <div className="rounded-xl border border-amber-500/30 bg-amber-500/8 p-3 space-y-1.5">
                  <p className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                    <AlertTriangle className="h-3.5 w-3.5" /> Rows with errors (will be skipped)
                  </p>
                  <div className="space-y-1 max-h-32 overflow-y-auto">
                    {invalidRows.map(r => (
                      <div key={r._rowNum} className="text-[10px] text-muted-foreground">
                        <span className="font-bold text-amber-400">Row {r._rowNum}</span>{" "}
                        {r.name ? `(${r.name})` : ""}: {r._errors.join("; ")}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Preview table */}
              {validRows.length > 0 && (
                <div className="rounded-xl border border-border overflow-hidden">
                  <div className="overflow-x-auto max-h-64">
                    <table className="w-full text-xs">
                      <thead className="bg-secondary/60 sticky top-0">
                        <tr>
                          {["Name", "Game", "Type", "Barcode", "Buy Price", "Sell Price", "Qty"].map(h => (
                            <th key={h} className="px-3 py-2 text-left font-semibold text-muted-foreground whitespace-nowrap">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {validRows.map((r, idx) => (
                          <tr key={`${r._rowNum}-${idx}`} className="hover:bg-secondary/30">
                            <td className="px-3 py-2 font-medium max-w-[160px] truncate">{r.name}</td>
                            <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{r.game}</td>
                            <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{r.type}</td>
                            <td className="px-3 py-2 text-muted-foreground font-mono text-[10px]">{r.barcode || "—"}</td>
                            <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{r.purchasePrice !== undefined ? formatCurrency(r.purchasePrice, currency) : "—"}</td>
                            <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{r.sellPrice !== undefined ? formatCurrency(r.sellPrice, currency) : "—"}</td>
                            <td className="px-3 py-2 text-muted-foreground text-center">{r.quantity}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  {validRows.length > 10 && (
                    <div className="px-3 py-1.5 border-t border-border bg-secondary/30 text-[10px] text-muted-foreground">
                      Showing all {validRows.length} valid rows
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          )}

          {/* Importing */}
          {step === "importing" && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col items-center justify-center py-12 gap-4">
              <Loader2 className="h-10 w-10 animate-spin text-primary" />
              <p className="font-semibold">Importing {validRows.length} sealed product{validRows.length !== 1 ? "s" : ""}…</p>
              <p className="text-xs text-muted-foreground">Please don&apos;t close this window.</p>
            </motion.div>
          )}

          {/* Done */}
          {step === "done" && (
            <motion.div initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col items-center justify-center py-10 gap-4 text-center">
              <div className="w-16 h-16 rounded-full bg-profit/20 flex items-center justify-center">
                <CheckCircle className="h-9 w-9 text-profit" />
              </div>
              <div>
                <p className="text-xl font-bold">{importedCount} product{importedCount !== 1 ? "s" : ""} imported!</p>
                {skippedCount > 0 && (
                  <p className="text-sm text-muted-foreground mt-1">{skippedCount} row{skippedCount !== 1 ? "s" : ""} skipped due to errors</p>
                )}
                <p className="text-xs text-muted-foreground mt-2">Products have been added to your sealed inventory.</p>
              </div>
            </motion.div>
          )}

        </div>

        <DialogFooter className="pt-2">
          {step === "upload" && (
            <Button variant="secondary" onClick={handleClose}>Cancel</Button>
          )}
          {step === "preview" && (
            <>
              <Button variant="secondary" onClick={handleClose}>Cancel</Button>
              <Button onClick={handleImport} disabled={validRows.length === 0} className="gap-2">
                <Upload className="h-4 w-4" />
                Import {validRows.length} Product{validRows.length !== 1 ? "s" : ""}
              </Button>
            </>
          )}
          {step === "done" && (
            <Button onClick={handleClose} className="gap-2">
              <CheckCircle className="h-4 w-4" /> Done
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
