import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { motion, AnimatePresence } from "motion/react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { cn, formatCurrency } from "@/lib/utils.ts";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from "@/components/ui/empty.tsx";
import { Clock, Package, Barcode, TrendingDown, Filter, Percent, Check, Loader2 } from "lucide-react";
import { toast } from "sonner";

type Props = {
  userId: Id<"users">;
  currency: string;
};

type BucketKey = "0-7" | "8-14" | "15-30" | "31-60" | "61-90" | "90+" | "all";

const BUCKETS: { key: BucketKey; label: string; color: string; bg: string; border: string; desc: string }[] = [
  { key: "all",   label: "All",    color: "text-foreground",    bg: "bg-secondary/60",       border: "border-border",          desc: "Everything unsold" },
  { key: "0-7",   label: "0–7d",   color: "text-profit",     bg: "bg-profit/10",        border: "border-profit/30",    desc: "Fresh stock" },
  { key: "8-14",  label: "8–14d",  color: "text-cyan-400",      bg: "bg-cyan-500/10",         border: "border-cyan-500/30",     desc: "Recent adds" },
  { key: "15-30", label: "15–30d", color: "text-amber-400",     bg: "bg-amber-500/10",        border: "border-amber-500/30",    desc: "Consider repricing" },
  { key: "31-60", label: "31–60d", color: "text-orange-400",    bg: "bg-orange-500/10",       border: "border-orange-500/30",   desc: "Slow movers" },
  { key: "61-90", label: "61–90d", color: "text-red-400",       bg: "bg-red-500/10",          border: "border-red-500/30",      desc: "Discount urgently" },
  { key: "90+",   label: "90d+",   color: "text-red-600",       bg: "bg-red-600/10",          border: "border-red-600/30",      desc: "Dead stock" },
];

const DISCOUNT_PCTS = [-10, -20, -30, -50] as const;

function bucketColor(bucket: string) {
  const b = BUCKETS.find(x => x.key === bucket);
  return b?.color ?? "text-foreground";
}

function bucketBg(bucket: string) {
  const b = BUCKETS.find(x => x.key === bucket);
  return { bg: b?.bg ?? "bg-secondary/60", border: b?.border ?? "border-border" };
}

function isRepriceable(bucket: string) {
  return bucket === "31-60" || bucket === "61-90" || bucket === "90+";
}

function DaysBadge({ days, bucket }: { days: number; bucket: string }) {
  const color = bucketColor(bucket);
  const { bg, border } = bucketBg(bucket);
  return (
    <span className={cn("inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full border shrink-0", bg, border, color)}>
      <Clock className="w-3 h-3" />
      {days}d
    </span>
  );
}

function RepricePctButtons({
  currentPrice,
  onApply,
  currency,
}: {
  currentPrice: number;
  onApply: (newPrice: number, pct: number) => Promise<void>;
  currency: string;
}) {
  const [applying, setApplying] = useState<number | null>(null);
  const [applied, setApplied] = useState<number | null>(null);

  const handleClick = async (pct: typeof DISCOUNT_PCTS[number]) => {
    const newPrice = Math.max(0.01, parseFloat((currentPrice * (1 + pct / 100)).toFixed(2)));
    setApplying(pct);
    try {
      await onApply(newPrice, pct);
      setApplied(pct);
      setTimeout(() => setApplied(null), 1500);
    } finally {
      setApplying(null);
    }
  };

  return (
    <div className="flex gap-1 flex-wrap justify-end" onClick={e => e.stopPropagation()}>
      {DISCOUNT_PCTS.map(pct => {
        const isApplying = applying === pct;
        const isApplied = applied === pct;
        return (
          <button
            key={pct}
            onClick={() => void handleClick(pct)}
            disabled={applying !== null}
            className={cn(
              "text-[10px] font-black px-2 py-1 rounded-lg border transition-all cursor-pointer",
              isApplied
                ? "bg-profit/20 border-profit/40 text-profit"
                : "bg-orange-500/10 border-orange-500/30 text-orange-400 hover:bg-orange-500/20 active:scale-95"
            )}
          >
            {isApplying ? (
              <Loader2 className="w-3 h-3 animate-spin" />
            ) : isApplied ? (
              <Check className="w-3 h-3" />
            ) : (
              `${pct}%`
            )}
          </button>
        );
      })}
    </div>
  );
}

export default function AgingReport({ userId, currency }: Props) {
  const [tab, setTab] = useState<"cards" | "sealed">("cards");
  const [bucket, setBucket] = useState<BucketKey>("all");

  const agingCards  = useQuery(api.inventory.aging.getAgingCards,  { userId });
  const agingSealed = useQuery(api.inventory.aging.getAgingSealed, { userId });

  const updateCard       = useMutation(api.cards.updateCard);
  const patchLabelPrice  = useMutation(api.labels.patchLabelPrice);
  const updateSealed     = useMutation(api.sealedProducts.updateSealedProduct);

  const loading = agingCards === undefined || agingSealed === undefined;

  const filteredCards = (agingCards ?? []).filter(c =>
    bucket === "all" ? true : c.bucket === bucket
  );
  const filteredSealed = (agingSealed ?? []).filter(s =>
    bucket === "all" ? true : s.bucket === bucket
  );

  const totalCards  = agingCards?.length ?? 0;
  const totalSealed = agingSealed?.length ?? 0;
  const staleCards  = (agingCards ?? []).filter(c => c.bucket === "61-90" || c.bucket === "90+").length;
  const staleSealed = (agingSealed ?? []).filter(s => s.bucket === "61-90" || s.bucket === "90+").length;

  const cardBucketCount  = (key: BucketKey) => key === "all" ? totalCards  : (agingCards  ?? []).filter(c => c.bucket === key).length;
  const sealedBucketCount = (key: BucketKey) => key === "all" ? totalSealed : (agingSealed ?? []).filter(s => s.bucket === key).length;

  const handleRepriceCard = async (cardId: string, newPrice: number, pct: number) => {
    await updateCard({ id: cardId as Id<"cards">, marketValue: newPrice });
    await patchLabelPrice({ cardId: cardId as Id<"cards">, price: newPrice });
    toast.success(`Price cut ${Math.abs(pct)}% → ${formatCurrency(newPrice, currency)}`);
  };

  const handleRepriceSealed = async (productId: string, newPrice: number, pct: number) => {
    await updateSealed({ id: productId as Id<"sealedProducts">, sellPrice: newPrice });
    toast.success(`Price cut ${Math.abs(pct)}% → ${formatCurrency(newPrice, currency)}`);
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="rounded-xl border border-amber-500/30 bg-amber-500/8 p-3 space-y-1.5">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-amber-400 shrink-0" />
          <p className="text-[10px] font-black tracking-widest text-amber-400 uppercase">Aging Report</p>
        </div>
        <p className="text-[11px] text-muted-foreground leading-relaxed">
          Cards and sealed products sorted by how long they've been sitting unsold. Use this to spot slow-movers and decide what to reprice or discount.
        </p>
        <div className="flex items-start gap-2 mt-1 p-2 rounded-lg bg-orange-500/10 border border-orange-500/20">
          <Percent className="w-3.5 h-3.5 text-orange-400 shrink-0 mt-0.5" />
          <div>
            <p className="text-[10px] font-black tracking-widest text-orange-400 uppercase mb-0.5">Pro Tip</p>
            <p className="text-[10px] text-muted-foreground leading-relaxed">Items 30+ days old show quick discount buttons — tap to apply instantly.</p>
          </div>
        </div>
        {!loading && (staleCards + staleSealed) > 0 && (
          <div className="flex items-center gap-2 pt-0.5">
            <TrendingDown className="w-3.5 h-3.5 text-red-400 shrink-0" />
            <p className="text-[10px] font-semibold text-red-400">
              {staleCards + staleSealed} item{staleCards + staleSealed !== 1 ? "s" : ""} over 60 days — consider discounting
            </p>
          </div>
        )}
      </div>

      {/* Summary stats */}
      {loading ? (
        <div className="grid grid-cols-3 gap-2">
          {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-14" />)}
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-2">
          {[
            { label: "Unsold Cards",   value: totalCards,  color: "text-foreground",   icon: Package },
            { label: "Unsold Sealed",  value: totalSealed, color: "text-blue-400",      icon: Barcode },
            { label: "Over 60 Days",   value: staleCards + staleSealed, color: staleCards + staleSealed > 0 ? "text-red-400" : "text-profit", icon: TrendingDown },
          ].map(({ label, value, color, icon: Icon }) => (
            <div key={label} className="rounded-xl border border-border bg-secondary/30 p-2.5 text-center space-y-0.5">
              <Icon className={cn("w-4 h-4 mx-auto", color)} />
              <p className={cn("text-base font-black", color)}>{value}</p>
              <p className="text-[9px] text-muted-foreground uppercase tracking-wide">{label}</p>
            </div>
          ))}
        </div>
      )}

      {/* Cards / Sealed toggle */}
      <div className="flex gap-1 p-1 bg-secondary/50 rounded-xl border border-border w-fit">
        {(["cards", "sealed"] as const).map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer",
              tab === t ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
            )}
          >
            {t === "cards" ? <Package className="w-3.5 h-3.5" /> : <Barcode className="w-3.5 h-3.5" />}
            {t === "cards" ? "Cards" : "Sealed"}
          </button>
        ))}
      </div>

      {/* Bucket filter chips */}
      <div className="flex flex-wrap gap-1.5">
        {BUCKETS.map(b => {
          const count = tab === "cards" ? cardBucketCount(b.key) : sealedBucketCount(b.key);
          const active = bucket === b.key;
          return (
            <button
              key={b.key}
              onClick={() => setBucket(b.key)}
              className={cn(
                "flex items-center gap-1 text-[10px] font-bold px-2.5 py-1 rounded-full border transition-all cursor-pointer",
                active ? cn(b.bg, b.border, b.color) : "border-border text-muted-foreground hover:border-border/80"
              )}
            >
              {b.key !== "all" && <Filter className="w-3 h-3" />}
              {b.label}
              {count > 0 && (
                <span className={cn("ml-0.5 rounded-full px-1.5 py-0 text-[9px] font-black", active ? "bg-white/15" : "bg-secondary")}>
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* List */}
      {loading ? (
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16" />)}
        </div>
      ) : tab === "cards" ? (
        filteredCards.length === 0 ? (
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon"><Clock /></EmptyMedia>
              <EmptyTitle>No cards in this range</EmptyTitle>
              <EmptyDescription>Nothing matches the selected age filter</EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : (
          <AnimatePresence>
            <motion.div className="space-y-2" initial="hidden" animate="show" variants={{ show: { transition: { staggerChildren: 0.03 } } }}>
              {filteredCards.map((card) => {
                const { bg, border } = bucketBg(card.bucket);
                const canReprice = isRepriceable(card.bucket) && card.marketValue != null;
                return (
                  <motion.div
                    key={card._id}
                    variants={{ hidden: { opacity: 0, y: 6 }, show: { opacity: 1, y: 0 } }}
                    className={cn("rounded-xl border p-3 space-y-2", bg, border)}
                  >
                    <div className="flex items-center gap-3">
                      <DaysBadge days={card.daysInInventory} bucket={card.bucket} />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-foreground truncate">{card.name}</p>
                        <p className="text-[10px] text-muted-foreground truncate">
                          {card.game}{card.set ? ` · ${card.set}` : ""} · {card.condition}{card.grade ? ` (${card.grade})` : ""}
                        </p>
                      </div>
                      <div className="text-right shrink-0 space-y-0.5">
                        {card.marketValue != null && (
                          <p className="text-xs font-bold text-foreground">{formatCurrency(card.marketValue, currency)}</p>
                        )}
                        {card.purchasePrice != null && (
                          <p className="text-[10px] text-muted-foreground">Paid {formatCurrency(card.purchasePrice, currency)}</p>
                        )}
                      </div>
                    </div>
                    {canReprice && (
                      <div className="flex items-center justify-between gap-2 pt-1 border-t border-orange-500/20">
                        <span className="text-[10px] text-orange-400 font-semibold flex items-center gap-1">
                          <Percent className="w-3 h-3" /> Quick reprice
                        </span>
                        <RepricePctButtons
                          currentPrice={card.marketValue!}
                          currency={currency}
                          onApply={(newPrice, pct) => handleRepriceCard(card._id, newPrice, pct)}
                        />
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </motion.div>
          </AnimatePresence>
        )
      ) : (
        filteredSealed.length === 0 ? (
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon"><Clock /></EmptyMedia>
              <EmptyTitle>No sealed products in this range</EmptyTitle>
              <EmptyDescription>Nothing matches the selected age filter</EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : (
          <AnimatePresence>
            <motion.div className="space-y-2" initial="hidden" animate="show" variants={{ show: { transition: { staggerChildren: 0.03 } } }}>
              {filteredSealed.map((prod) => {
                const { bg, border } = bucketBg(prod.bucket);
                const canReprice = isRepriceable(prod.bucket) && prod.sellPrice != null;
                return (
                  <motion.div
                    key={prod._id}
                    variants={{ hidden: { opacity: 0, y: 6 }, show: { opacity: 1, y: 0 } }}
                    className={cn("rounded-xl border p-3 space-y-2", bg, border)}
                  >
                    <div className="flex items-center gap-3">
                      <DaysBadge days={prod.daysInInventory} bucket={prod.bucket} />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-foreground truncate">{prod.name}</p>
                        <p className="text-[10px] text-muted-foreground truncate">
                          {prod.game} · {prod.type} · {prod.quantity} in stock
                        </p>
                      </div>
                      <div className="text-right shrink-0 space-y-0.5">
                        {prod.sellPrice != null && (
                          <p className="text-xs font-bold text-foreground">{formatCurrency(prod.sellPrice, currency)}</p>
                        )}
                        {prod.purchasePrice != null && (
                          <p className="text-[10px] text-muted-foreground">Paid {formatCurrency(prod.purchasePrice, currency)}</p>
                        )}
                      </div>
                    </div>
                    {canReprice && (
                      <div className="flex items-center justify-between gap-2 pt-1 border-t border-orange-500/20">
                        <span className="text-[10px] text-orange-400 font-semibold flex items-center gap-1">
                          <Percent className="w-3 h-3" /> Quick reprice
                        </span>
                        <RepricePctButtons
                          currentPrice={prod.sellPrice!}
                          currency={currency}
                          onApply={(newPrice, pct) => handleRepriceSealed(prod._id, newPrice, pct)}
                        />
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </motion.div>
          </AnimatePresence>
        )
      )}
    </div>
  );
}
