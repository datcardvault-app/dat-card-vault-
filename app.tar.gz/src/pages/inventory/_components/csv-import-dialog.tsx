import { useRef, useState } from "react";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import Papa from "papaparse";
import { Button } from "@/components/ui/button.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Upload, Download, CheckCircle, AlertCircle, AlertTriangle, Loader2, FileText, X,
} from "lucide-react";
import { toast } from "sonner";
import { formatCurrency } from "@/lib/utils.ts";
import { motion } from "motion/react";

export const VALID_GAMES = [
  "Pokémon", "Magic: The Gathering", "Yu-Gi-Oh! Official", "One Piece",
  "Flesh and Blood", "Digimon", "Star Wars: Unlimited", "Weiss Schwarz",
  "Cardfight!! Vanguard", "Lorcana", "Dragon Ball Super", "Other",
];
const VALID_CONDITIONS = ["Mint", "Near Mint", "Excellent", "Good", "Lightly Played", "Moderately Played", "Heavily Played", "Poor"];

// ─── Standard template ───────────────────────────────────────────────────────
const STANDARD_TEMPLATE_ROWS = [
  ["name", "game", "set", "condition", "grade", "purchase_price", "market_value", "rarity", "language", "notes"],
  ["Charizard", "Pokémon", "Base Set", "Near Mint", "PSA 10", "200.00", "450.00", "Rare Holo", "English", "Slab"],
  ["Black Lotus", "Magic: The Gathering", "Alpha", "Good", "", "5000.00", "8000.00", "Rare", "English", ""],
];

type ParsedRow = {
  name: string;
  game: string;
  set?: string;
  condition: string;
  grade?: string;
  purchasePrice?: number;
  marketValue?: number;
  rarity?: string;
  language?: string;
  notes?: string;
  _rowNum: number;
  _errors: string[];
};

// ─── eBay column aliases ──────────────────────────────────────────────────────
// eBay Seller Hub "Orders" CSV  →  our fields
// eBay My eBay "Purchase history" doesn't export natively, but
// third-party tools produce a similar layout.
const EBAY_TITLE_KEYS   = ["item_title", "title", "item_name", "listing_title"];
const EBAY_PRICE_KEYS   = ["sold_for", "buy_it_now_price", "start_price", "price", "item_price", "total_price", "amount"];
const EBAY_LABEL_KEYS   = ["custom_label", "custom_label_(sku)", "sku", "custom_label_sku"];
const EBAY_CONDITION_KEYS = ["item_condition", "condition"];
const EBAY_QTY_KEYS     = ["quantity", "qty", "quantity_sold", "quantity_available"];

function findKey(row: Record<string, string>, aliases: string[]): string | undefined {
  for (const k of aliases) {
    if (k in row) return k;
  }
  return undefined;
}

// Strip currency symbols and commas then parse
function parseMoney(s: string): number | undefined {
  const cleaned = s.replace(/[^0-9.]/g, "");
  const n = parseFloat(cleaned);
  return isNaN(n) ? undefined : n;
}

// Map eBay condition strings to our vocabulary (best-effort)
function mapEbayCondition(raw: string): string {
  const r = raw.toLowerCase();
  if (r.includes("brand new") || r.includes("new"))        return "Near Mint";
  if (r.includes("like new"))                              return "Near Mint";
  if (r.includes("very good"))                             return "Excellent";
  if (r.includes("good"))                                  return "Good";
  if (r.includes("acceptable") || r.includes("fair"))      return "Lightly Played";
  if (r.includes("poor") || r.includes("damaged"))         return "Poor";
  if (r.includes("graded") || r.includes("psa") || r.includes("bgs") || r.includes("cgc")) return "Near Mint";
  return "Near Mint";
}

// ─── Parsers ─────────────────────────────────────────────────────────────────
function parseStandardRows(raw: Record<string, string>[]): ParsedRow[] {
  return raw.map((row, i) => {
    const errors: string[] = [];
    const name = (row["name"] ?? "").trim();
    const game = (row["game"] ?? "").trim();
    const condition = (row["condition"] ?? "Near Mint").trim();

    if (!name) errors.push("Name is required");
    if (!game) errors.push("Game is required");
    else if (!VALID_GAMES.includes(game)) errors.push(`Game "${game}" not recognised — use: ${VALID_GAMES.join(", ")}`);
    if (condition && !VALID_CONDITIONS.includes(condition)) errors.push(`Condition "${condition}" not recognised`);

    const purchasePrice = row["purchase_price"] ? parseMoney(row["purchase_price"]) : undefined;
    const marketValue   = row["market_value"]   ? parseMoney(row["market_value"])   : undefined;

    if (row["purchase_price"] && purchasePrice === undefined) errors.push("purchase_price must be a number");
    if (row["market_value"]   && marketValue   === undefined) errors.push("market_value must be a number");

    return {
      name,
      game,
      set: row["set"]?.trim() || undefined,
      condition: VALID_CONDITIONS.includes(condition) ? condition : "Near Mint",
      grade: row["grade"]?.trim() || undefined,
      purchasePrice,
      marketValue,
      rarity: row["rarity"]?.trim() || undefined,
      language: row["language"]?.trim() || "English",
      notes: row["notes"]?.trim() || undefined,
      _rowNum: i + 2,
      _errors: errors,
    };
  });
}

function parseEbayRows(raw: Record<string, string>[], defaultGame: string): ParsedRow[] {
  return raw.map((row, i) => {
    const errors: string[] = [];

    // Name — from item title
    const titleKey = findKey(row, EBAY_TITLE_KEYS);
    const name = titleKey ? (row[titleKey] ?? "").trim() : "";
    if (!name) errors.push("Could not find item title column (expected: Item Title, Title, or Listing Title)");

    // Price — treat as purchase price (what was paid)
    const priceKey = findKey(row, EBAY_PRICE_KEYS);
    const purchasePrice = priceKey ? parseMoney(row[priceKey] ?? "") : undefined;

    // Condition
    const condKey = findKey(row, EBAY_CONDITION_KEYS);
    const rawCond = condKey ? (row[condKey] ?? "").trim() : "";
    const condition = rawCond ? mapEbayCondition(rawCond) : "Near Mint";

    // Custom label → use as set / SKU hint
    const labelKey = findKey(row, EBAY_LABEL_KEYS);
    const customLabel = labelKey ? (row[labelKey] ?? "").trim() : undefined;

    // Qty — informational only, not imported (each eBay row = one card)
    const qtyKey = findKey(row, EBAY_QTY_KEYS);
    const qtyRaw = qtyKey ? parseInt(row[qtyKey] ?? "1") : 1;
    const qty = isNaN(qtyRaw) ? 1 : Math.max(1, qtyRaw);

    // Build a notes string from eBay metadata
    const noteParts: string[] = [];
    if (row["order_number"])         noteParts.push(`eBay order: ${row["order_number"]}`);
    else if (row["sales_record_number"]) noteParts.push(`eBay record: ${row["sales_record_number"]}`);
    if (row["sale_date"] || row["sold_on"] || row["date"]) {
      const d = row["sale_date"] ?? row["sold_on"] ?? row["date"];
      if (d) noteParts.push(`Date: ${d}`);
    }

    return {
      name,
      game: defaultGame || "Other",
      set: customLabel || undefined,
      condition,
      grade: undefined,
      purchasePrice,
      marketValue: purchasePrice,  // use sale price as market reference too
      rarity: undefined,
      language: "English",
      notes: noteParts.join(" | ") || undefined,
      // If qty > 1 we clone the row — handled below
      _rowNum: i + 2,
      _errors: errors,
      _qty: qty,
    } as ParsedRow & { _qty: number };
  });
}

// Expand rows with qty > 1 into individual entries (each card gets its own label)
function expandQty(rows: (ParsedRow & { _qty?: number })[]): ParsedRow[] {
  const out: ParsedRow[] = [];
  for (const row of rows) {
    const qty = (row as ParsedRow & { _qty?: number })._qty ?? 1;
    for (let q = 0; q < qty; q++) {
      out.push({ ...row });
    }
  }
  return out;
}

// ─── Template downloads ───────────────────────────────────────────────────────
function downloadTemplate(mode: ImportMode) {
  let rows: string[][];
  let filename: string;

  if (mode === "ebay") {
    rows = [
      ["Item Title", "Sold For", "Custom Label", "Quantity", "Item Condition", "Order Number", "Sale Date"],
      ["Charizard Holo Base Set", "85.00", "Base Set", "1", "Like New", "12-34567-89012", "2024-03-15"],
      ["PSA 10 Pikachu VMAX", "220.00", "Vivid Voltage", "1", "Brand New", "12-34567-89013", "2024-03-16"],
    ];
    filename = "ebay_import_template.csv";
  } else {
    rows = STANDARD_TEMPLATE_ROWS;
    filename = "card_import_template.csv";
  }

  const csv = rows.map(r => r.map(c => `"${c.replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// ─── Types ────────────────────────────────────────────────────────────────────
type ImportMode = "standard" | "ebay";

type Props = {
  open: boolean;
  onClose: () => void;
  currency: string;
};

type Step = "upload" | "preview" | "importing" | "done";

// ─── Component ────────────────────────────────────────────────────────────────
export default function CsvImportDialog({ open, onClose, currency }: Props) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [step, setStep]               = useState<Step>("upload");
  const [mode, setMode]               = useState<ImportMode>("standard");
  const [defaultGame, setDefaultGame] = useState<string>("Pokémon");
  const [rows, setRows]               = useState<ParsedRow[]>([]);
  const [parseError, setParseError]   = useState<string | null>(null);
  const [importedCount, setImportedCount] = useState(0);
  const [skippedCount, setSkippedCount]   = useState(0);
  const [fileName, setFileName]           = useState<string | null>(null);

  const addCard     = useMutation(api.cards.addCard);
  const createLabel = useMutation(api.labels.createLabel);

  const reset = () => {
    setStep("upload");
    setRows([]);
    setParseError(null);
    setImportedCount(0);
    setSkippedCount(0);
    setFileName(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleClose = () => { reset(); onClose(); };

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setParseError(null);
    setFileName(file.name);

    if (!file.name.endsWith(".csv") && file.type !== "text/csv") {
      setParseError("Please upload a .csv file.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setParseError("File must be under 5 MB.");
      return;
    }

    Papa.parse<Record<string, string>>(file, {
      header: true,
      skipEmptyLines: true,
      transformHeader: h => h.trim().toLowerCase().replace(/[\s/()]+/g, "_").replace(/_+$/, ""),
      complete: results => {
        if (results.errors.length > 0) {
          setParseError(`Could not read file: ${results.errors[0].message}`);
          return;
        }
        let parsed: ParsedRow[];
        if (mode === "ebay") {
          const raw = parseEbayRows(results.data, defaultGame) as (ParsedRow & { _qty?: number })[];
          parsed = expandQty(raw);
        } else {
          parsed = parseStandardRows(results.data);
        }
        if (parsed.length === 0) {
          setParseError("The CSV has no data rows.");
          return;
        }
        setRows(parsed);
        setStep("preview");
      },
      error: err => setParseError(`Parse error: ${err.message}`),
    });
  };

  const validRows   = rows.filter(r => r._errors.length === 0);
  const invalidRows = rows.filter(r => r._errors.length > 0);

  const handleImport = async () => {
    setStep("importing");
    let ok = 0;
    let skipped = 0;
    for (const row of validRows) {
      try {
        const cardId = await addCard({
          name: row.name,
          game: row.game,
          set: row.set,
          condition: row.condition,
          grade: row.grade,
          purchasePrice: row.purchasePrice,
          marketValue: row.marketValue,
          rarity: row.rarity,
          language: row.language,
          notes: row.notes,
        });
        await createLabel({
          cardId,
          labelData: {
            cardName: row.name,
            game: row.game,
            set: row.set,
            condition: row.condition,
            grade: row.grade,
            price: row.marketValue,
            rarity: row.rarity,
            language: row.language,
          },
          currency,
        });
        ok++;
      } catch {
        skipped++;
      }
    }
    setImportedCount(ok);
    setSkippedCount(skipped + invalidRows.length);
    setStep("done");
    toast.success(`Imported ${ok} card${ok !== 1 ? "s" : ""} to your vault`);
  };

  return (
    <Dialog open={open} onOpenChange={o => { if (!o) handleClose(); }}>
      <DialogContent className="max-w-2xl max-h-[90dvh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="font-sans text-primary tracking-widest flex items-center gap-2">
            <Upload className="h-4 w-4" /> Import Cards from CSV
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-4 min-h-0">

          {/* Upload step */}
          {step === "upload" && (
            <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">

              {/* Mode switcher */}
              <div className="flex gap-1.5 p-1 bg-secondary/50 rounded-xl border border-border w-fit">
                {(["standard", "ebay"] as ImportMode[]).map(m => (
                  <button
                    key={m}
                    onClick={() => { setMode(m); setParseError(null); }}
                    className={`px-4 py-1.5 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
                      mode === m ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {m === "standard" ? "Standard" : "eBay"}
                  </button>
                ))}
              </div>

              {/* Mode-specific instructions */}
              {mode === "standard" && (
                <div className="flex items-start gap-3 p-3 rounded-xl border border-border bg-secondary/40">
                  <FileText className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0 space-y-1">
                    <p className="text-sm font-semibold">Standard format</p>
                    <p className="text-xs text-muted-foreground">
                      Required columns: <span className="font-mono text-foreground">name</span>, <span className="font-mono text-foreground">game</span>.
                      {" "}Optional: set, condition, grade, purchase_price, market_value, rarity, language, notes.
                    </p>
                  </div>
                  <Button size="sm" variant="secondary" onClick={() => downloadTemplate("standard")} className="gap-1.5 shrink-0">
                    <Download className="h-3.5 w-3.5" /> Template
                  </Button>
                </div>
              )}

              {mode === "ebay" && (
                <div className="space-y-3">
                  <div className="flex items-start gap-3 p-3 rounded-xl border border-border bg-secondary/40">
                    <FileText className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
                    <div className="flex-1 min-w-0 space-y-2">
                      <p className="text-sm font-semibold">eBay Seller Hub format</p>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        Export your sold orders from eBay: <span className="text-foreground font-medium">Seller Hub → Orders → Download report</span>.
                        {" "}Columns automatically mapped: <span className="font-mono text-foreground">Item Title</span> → name,
                        {" "}<span className="font-mono text-foreground">Sold For</span> → purchase price,
                        {" "}<span className="font-mono text-foreground">Custom Label</span> → set,
                        {" "}<span className="font-mono text-foreground">Item Condition</span> → condition.
                        {" "}Order number and sale date are saved in notes.
                      </p>
                      <p className="text-xs text-amber-400/90">
                        Since eBay listings don&apos;t include a game name, select a default game below to apply to all imported rows.
                      </p>
                    </div>
                    <Button size="sm" variant="secondary" onClick={() => downloadTemplate("ebay")} className="gap-1.5 shrink-0">
                      <Download className="h-3.5 w-3.5" /> Template
                    </Button>
                  </div>

                  {/* Default game selector */}
                  <div className="flex items-center gap-3">
                    <Label className="text-sm font-semibold whitespace-nowrap shrink-0">Default game</Label>
                    <Select value={defaultGame} onValueChange={setDefaultGame}>
                      <SelectTrigger className="flex-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {VALID_GAMES.map(g => (
                          <SelectItem key={g} value={g}>{g}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}

              {/* File picker */}
              <input ref={fileInputRef} type="file" accept=".csv" className="hidden" onChange={handleFile} />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full h-32 rounded-2xl border-2 border-dashed border-primary/40 bg-primary/5 hover:bg-primary/10 hover:border-primary/60 transition-all cursor-pointer flex flex-col items-center justify-center gap-2"
              >
                <Upload className="h-7 w-7 text-primary" />
                <span className="font-semibold text-primary text-sm">
                  {mode === "ebay" ? "Click to select eBay orders CSV" : "Click to select CSV file"}
                </span>
                <span className="text-xs text-muted-foreground">Max 5 MB</span>
              </button>

              {parseError && (
                <div className="flex items-start gap-2 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-400">
                  <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                  {parseError}
                </div>
              )}
            </motion.div>
          )}

          {/* Preview step */}
          {step === "preview" && (
            <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="space-y-3">
              {/* Summary */}
              <div className="flex items-center gap-2 flex-wrap">
                {mode === "ebay" && (
                  <Badge className="bg-primary/20 text-primary border-primary/30 gap-1 text-[10px]">
                    eBay import · {defaultGame}
                  </Badge>
                )}
                <Badge className="bg-profit/20 text-profit border-profit/30 gap-1">
                  <CheckCircle className="h-3 w-3" /> {validRows.length} ready to import
                </Badge>
                {invalidRows.length > 0 && (
                  <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30 gap-1">
                    <AlertTriangle className="h-3 w-3" /> {invalidRows.length} will be skipped
                  </Badge>
                )}
                {fileName && <span className="text-xs text-muted-foreground">{fileName}</span>}
                <button onClick={reset} className="ml-auto text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 cursor-pointer">
                  <X className="h-3 w-3" /> Change file
                </button>
              </div>

              {/* Errors */}
              {invalidRows.length > 0 && (
                <div className="rounded-xl border border-amber-500/30 bg-amber-500/8 p-3 space-y-1.5">
                  <p className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                    <AlertTriangle className="h-3.5 w-3.5" /> Rows with errors (will be skipped)
                  </p>
                  <div className="space-y-1 max-h-32 overflow-y-auto">
                    {invalidRows.map(r => (
                      <div key={r._rowNum} className="text-[10px] text-muted-foreground">
                        <span className="font-bold text-amber-400">Row {r._rowNum}</span>{" "}
                        {r.name ? `(${r.name})` : ""}: {r._errors.join("; ")}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Preview table */}
              {validRows.length > 0 && (
                <div className="rounded-xl border border-border overflow-hidden">
                  <div className="overflow-x-auto max-h-64">
                    <table className="w-full text-xs">
                      <thead className="bg-secondary/60 sticky top-0">
                        <tr>
                          {["Name", "Game", "Set", "Condition", "Grade", "Buy Price", "Market Value"].map(h => (
                            <th key={h} className="px-3 py-2 text-left font-semibold text-muted-foreground whitespace-nowrap">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {validRows.map((r, idx) => (
                          <tr key={`${r._rowNum}-${idx}`} className="hover:bg-secondary/30">
                            <td className="px-3 py-2 font-medium max-w-[140px] truncate">{r.name}</td>
                            <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{r.game}</td>
                            <td className="px-3 py-2 text-muted-foreground max-w-[100px] truncate">{r.set ?? "—"}</td>
                            <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{r.condition}</td>
                            <td className="px-3 py-2 text-muted-foreground">{r.grade ?? "—"}</td>
                            <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{r.purchasePrice !== undefined ? formatCurrency(r.purchasePrice, currency) : "—"}</td>
                            <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{r.marketValue !== undefined ? formatCurrency(r.marketValue, currency) : "—"}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  {validRows.length > 10 && (
                    <div className="px-3 py-1.5 border-t border-border bg-secondary/30 text-[10px] text-muted-foreground">
                      Showing all {validRows.length} valid rows
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          )}

          {/* Importing */}
          {step === "importing" && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col items-center justify-center py-12 gap-4">
              <Loader2 className="h-10 w-10 animate-spin text-primary" />
              <p className="font-semibold">Importing {validRows.length} cards…</p>
              <p className="text-xs text-muted-foreground">A QR label is created for each card. Please don&apos;t close this window.</p>
            </motion.div>
          )}

          {/* Done */}
          {step === "done" && (
            <motion.div initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col items-center justify-center py-10 gap-4 text-center">
              <div className="w-16 h-16 rounded-full bg-profit/20 flex items-center justify-center">
                <CheckCircle className="h-9 w-9 text-profit" />
              </div>
              <div>
                <p className="text-xl font-bold">{importedCount} card{importedCount !== 1 ? "s" : ""} imported!</p>
                {skippedCount > 0 && (
                  <p className="text-sm text-muted-foreground mt-1">{skippedCount} row{skippedCount !== 1 ? "s" : ""} skipped due to errors</p>
                )}
                <p className="text-xs text-muted-foreground mt-2">QR labels have been generated for each card.</p>
              </div>
            </motion.div>
          )}

        </div>

        <DialogFooter className="pt-2">
          {step === "upload" && (
            <Button variant="secondary" onClick={handleClose}>Cancel</Button>
          )}
          {step === "preview" && (
            <>
              <Button variant="secondary" onClick={handleClose}>Cancel</Button>
              <Button onClick={handleImport} disabled={validRows.length === 0} className="gap-2">
                <Upload className="h-4 w-4" />
                Import {validRows.length} Card{validRows.length !== 1 ? "s" : ""}
              </Button>
            </>
          )}
          {step === "done" && (
            <Button onClick={handleClose} className="gap-2">
              <CheckCircle className="h-4 w-4" /> Done
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
