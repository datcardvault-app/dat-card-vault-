import { useState, useRef, useEffect } from "react";
import { useMutation, usePaginatedQuery, useQuery, useAction, useConvex, useConvexAuth } from "convex/react";
import { useStableQuery } from "@/hooks/use-stable-query.ts";
import { motion, AnimatePresence } from "motion/react";
import DuplicateWarning from "@/components/duplicate-warning.tsx";
import CsvImportDialog from "@/pages/inventory/_components/csv-import-dialog.tsx";
import SealedCsvImportDialog from "@/pages/inventory/_components/sealed-csv-import-dialog.tsx";
import { api } from "@/convex/_generated/api.js";
import type { Id, Doc } from "@/convex/_generated/dataModel.d.ts";
import { cn, formatCurrency, formatDate } from "@/lib/utils.ts";
import { CARD_GAMES, CARD_CONDITIONS, VAULT_CARD_LIMIT } from "@/lib/constants.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { toast } from "sonner";
import { ConvexError } from "convex/values";
import {
  Plus, Package, Camera, Tag, CheckCircle, RotateCcw,
  Pencil, Trash2, ChevronDown, Filter, X, Loader2,
  Receipt, Mail, Barcode, ShoppingCart, Search, Upload, Clock,
  LayoutGrid, List,
} from "lucide-react";
import Webcam from "react-webcam";
import AgingReport from "@/pages/inventory/_components/aging-report.tsx";



type CardFormData = {
  name: string; game: string; set: string; cardNumber: string;
  condition: string; grade: string; purchasePrice: string;
  marketValue: string; rarity: string; language: string;
  edition: string; notes: string;
};

const EMPTY_FORM: CardFormData = {
  name: "", game: "Pokémon", set: "", cardNumber: "", condition: "Near Mint",
  grade: "", purchasePrice: "", marketValue: "", rarity: "", language: "English",
  edition: "", notes: "",
};

type FilterType = "unsold" | "sold";

export default function InventoryPage() {
  const convex = useConvex();
  const { isAuthenticated } = useConvexAuth();
  const [inventoryTab, setInventoryTab] = useState<"cards" | "sealed" | "aging">("cards");
  const [filter, setFilter] = useState<FilterType>("unsold");
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [showCsvImport, setShowCsvImport] = useState(false);
  const [showSealedCsvImport, setShowSealedCsvImport] = useState(false);
  const [saved, setSaved] = useState(false);
  const [editCard, setEditCard] = useState<Id<"cards"> | null>(null);
  const [form, setForm] = useState<CardFormData>(EMPTY_FORM);
  const [imageStorageId, setImageStorageId] = useState<Id<"_storage"> | null>(null);
  const [imageBackStorageId, setImageBackStorageId] = useState<Id<"_storage"> | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const [activePhotoSlot, setActivePhotoSlot] = useState<"front" | "back">("front");
  const [uploading, setUploading] = useState(false);
  const [showSellDialog, setShowSellDialog] = useState<Id<"cards"> | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<Id<"cards"> | null>(null);
  const [previewImages, setPreviewImages] = useState<{ ids: Id<"_storage">[]; startIndex: number }>({ ids: [], startIndex: 0 });
  const [salePrice, setSalePrice] = useState("");
  // selectedCard removed — inline expand replaces card info dialog
  const [receiptCard, setReceiptCard] = useState<Doc<"cards"> | null>(null);
  const [receiptEmail, setReceiptEmail] = useState("");
  const [sendingReceipt, setSendingReceipt] = useState(false);
  const [tileSize, setTileSize] = useState<"compact" | "full">(() => {
    try { return (localStorage.getItem("dcv_tile_size") as "compact" | "full") ?? "full"; } catch { return "full"; }
  });
  const [expandedCardId, setExpandedCardId] = useState<Id<"cards"> | null>(null);

  const toggleTileSize = () => {
    const next = tileSize === "full" ? "compact" : "full";
    setTileSize(next);
    try { localStorage.setItem("dcv_tile_size", next); } catch { /* noop */ }
  };
  const webcamRef = useRef<Webcam>(null);
  const nativeCameraRef = useRef<HTMLInputElement>(null);
  const cardFileInputRef = useRef<HTMLInputElement>(null);
  const [cardFileSlot, setCardFileSlot] = useState<"front" | "back">("front");

  const user = useStableQuery(api.users.getCurrentUser, isAuthenticated ? {} : "skip");
  const currency = user?.currency ?? "GBP";
  const sendReceipt = useAction(api.emails.sendReceipt);
  const vaultCount = useStableQuery(api.cards.getActiveCardCount, isAuthenticated ? {} : "skip");
  const sealedProducts = useStableQuery(api.sealedProducts.listSealedProducts, isAuthenticated ? {} : "skip");
  const sealedCount = sealedProducts?.length ?? 0;
  const SEALED_LIMIT = 500;

  const { results: cards, status, loadMore } = usePaginatedQuery(
    api.cards.getCards,
    isAuthenticated ? { sold: filter === "sold" } : "skip",
    { initialNumItems: 20 }
  );

  const addCard = useMutation(api.cards.addCard);
  const updateCard = useMutation(api.cards.updateCard);
  const deleteCard = useMutation(api.cards.deleteCard);
  const markSold = useMutation(api.cards.markSold);
  const markUnsold = useMutation(api.cards.markUnsold);
  const generateUploadUrl = useMutation(api.cards.generateUploadUrl);
  const createLabel = useMutation(api.labels.createLabel);
  const updateLabel = useMutation(api.labels.updateLabelByCardId);

  const openNew = () => {
    setForm(EMPTY_FORM);
    setImageStorageId(null);
    setImageBackStorageId(null);
    setEditCard(null);
    setShowForm(true);
  };

  const openEdit = (card: Doc<"cards">) => {
    setForm({
      name: card.name, game: card.game, set: card.set ?? "", cardNumber: card.cardNumber ?? "",
      condition: card.condition, grade: card.grade ?? "", purchasePrice: card.purchasePrice?.toString() ?? "",
      marketValue: card.marketValue?.toString() ?? "", rarity: card.rarity ?? "",
      language: card.language ?? "English", edition: card.edition ?? "", notes: card.notes ?? "",
    });
    setImageStorageId(card.imageStorageId ?? null);
    setImageBackStorageId(card.imageBackStorageId ?? null);
    setEditCard(card._id);
    setShowForm(true);
  };

  const handleCapture = () => {
    const imageSrc = webcamRef.current?.getScreenshot();
    if (!imageSrc) return;
    fetch(imageSrc).then(r => r.blob()).then(async (blob) => {
      setUploading(true);
      try {
        const uploadUrl = await generateUploadUrl();
        const res = await fetch(uploadUrl, { method: "POST", headers: { "Content-Type": blob.type }, body: blob });
        const { storageId } = await res.json() as { storageId: Id<"_storage"> };
        if (activePhotoSlot === "front") setImageStorageId(storageId);
        else setImageBackStorageId(storageId);
        setShowCamera(false);
        toast.success(`${activePhotoSlot === "front" ? "Front" : "Back"} photo captured!`);
      } catch {
        toast.error("Failed to upload photo");
      } finally {
        setUploading(false);
      }
    });
  };

  const handleNativeCameraCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = "";
    setUploading(true);
    const uploadFile = async () => {
      try {
        const uploadUrl = await generateUploadUrl();
        const res = await fetch(uploadUrl, { method: "POST", headers: { "Content-Type": file.type }, body: file });
        const { storageId } = await res.json() as { storageId: Id<"_storage"> };
        if (activePhotoSlot === "front") setImageStorageId(storageId);
        else setImageBackStorageId(storageId);
        toast.success(`${activePhotoSlot === "front" ? "Front" : "Back"} photo captured!`);
      } catch {
        toast.error("Failed to upload photo");
      } finally {
        setUploading(false);
      }
    };
    void uploadFile();
  };

  const handleCardFilePick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const uploadUrl = await generateUploadUrl();
      const res = await fetch(uploadUrl, { method: "POST", headers: { "Content-Type": file.type }, body: file });
      const { storageId } = await res.json() as { storageId: Id<"_storage"> };
      if (cardFileSlot === "front") setImageStorageId(storageId);
      else setImageBackStorageId(storageId);
      toast.success(`${cardFileSlot === "front" ? "Front" : "Back"} photo uploaded!`);
    } catch {
      toast.error("Failed to upload photo");
    } finally {
      setUploading(false);
      if (cardFileInputRef.current) cardFileInputRef.current.value = "";
    }
  };

  const handleSave = async () => {
    if (!form.name.trim()) { toast.error("Card name required"); return; }
    try {
      const payload = {
        name: form.name.trim(), game: form.game,
        set: form.set || undefined, cardNumber: form.cardNumber || undefined,
        condition: form.condition, grade: form.grade || undefined,
        purchasePrice: form.purchasePrice ? parseFloat(form.purchasePrice) : undefined,
        marketValue: form.marketValue ? parseFloat(form.marketValue) : undefined,
        notes: form.notes || undefined, rarity: form.rarity || undefined,
        language: form.language || undefined, edition: form.edition || undefined,
        imageStorageId: imageStorageId ?? undefined,
        imageBackStorageId: imageBackStorageId ?? undefined,
      };
      const labelData = {
        cardName: payload.name, game: payload.game, set: payload.set,
        cardNumber: payload.cardNumber, condition: payload.condition,
        grade: payload.grade, price: payload.marketValue,
        rarity: payload.rarity, language: payload.language,
        edition: payload.edition, notes: payload.notes,
      };
      if (editCard) {
        await updateCard({ id: editCard, ...payload });
        await updateLabel({ cardId: editCard, labelData });
        toast.success("Card & label updated!");
      } else {
        const cardId = await addCard(payload);
        await createLabel({ cardId, labelData, currency });
        toast.success("Card added & label created!");
      }
      setSaved(true);
      setTimeout(() => { setSaved(false); setShowForm(false); }, 400);
    } catch (e) {
      if (e instanceof ConvexError) {
        toast.error((e.data as { message: string }).message);
      } else {
        toast.error("Failed to save card");
      }
    }
  };

  // Shared handler — called from both compact and full tile views
  const handleMarkUnsold = async (card: { _id: Id<"cards">; name: string; game: string; set?: string | null; cardNumber?: string | null; condition: string; grade?: string | null; marketValue?: number; purchasePrice?: number; rarity?: string | null; language?: string | null; edition?: string | null }) => {
    await markUnsold({ id: card._id });
    const hasLabel = await convex.query(api.labels.checkCardHasLabel, { cardId: card._id });
    if (!hasLabel) {
      await createLabel({
        cardId: card._id,
        labelData: {
          cardName: card.name,
          game: card.game,
          set: card.set ?? undefined,
          cardNumber: card.cardNumber ?? undefined,
          condition: card.condition,
          grade: card.grade ?? undefined,
          price: card.marketValue ?? card.purchasePrice ?? undefined,
          rarity: card.rarity ?? undefined,
          language: card.language ?? undefined,
          edition: card.edition ?? undefined,
        },
      });
      toast.success("Moved back to active — new label generated");
    } else {
      toast.success("Moved back to active");
    }
  };

  const confirmDelete = async () => {
    if (!confirmDeleteId) return;
    try {
      await deleteCard({ id: confirmDeleteId });
      toast.success("Card deleted");
    } catch {
      toast.error("Failed to delete");
    } finally {
      setConfirmDeleteId(null);
    }
  };

  const handleConfirmSell = async () => {
    if (!showSellDialog) return;
    if (!salePrice || parseFloat(salePrice) <= 0) {
      toast.error("Please enter a sale price to log earnings");
      return;
    }
    try {
      const now = new Date();
      const d = now.getHours() < 6 ? new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1) : now;
      const localDate = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
      await markSold({ id: showSellDialog, salePrice: parseFloat(salePrice), localDate });
      toast.success("Card marked as sold!");
      setShowSellDialog(null);
      setSalePrice("");
    } catch {
      toast.error("Failed to mark as sold");
    }
  };

  const handleSendReceipt = async () => {
    if (!receiptCard) return;
    if (!receiptEmail) { toast.error("Enter customer email"); return; }
    if (!user?.senderEmail) { toast.error("Set your sender email in Settings first"); return; }
    setSendingReceipt(true);
    try {
      await sendReceipt({
        to: receiptEmail,
        senderEmail: user.senderEmail,
        cardName: receiptCard.name,
        game: receiptCard.game,
        condition: receiptCard.condition,
        set: receiptCard.set,
        grade: receiptCard.grade,
        salePrice: receiptCard.salePrice ?? 0,
        currency,
        businessName: user?.businessName,
        instagram: user?.instagram,
        website: user?.website,
      });
      toast.success("Receipt sent!");
      setReceiptCard(null);
      setReceiptEmail("");
    } catch (err) {
      toast.error(`Failed to send receipt: ${err instanceof Error ? err.message : String(err)}`, { duration: 8000 });
    } finally {
      setSendingReceipt(false);
    }
  };

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-sans text-primary tracking-widest">Inventory</h1>
        {inventoryTab === "cards" ? (
          <div className="flex items-center gap-2">
            <Button variant="secondary" onClick={() => setShowCsvImport(true)} className="gap-2">
              <Upload className="h-4 w-4" />
              <span className="hidden sm:inline">Import CSV</span>
            </Button>
            <Button onClick={openNew} className="gap-2" disabled={vaultCount !== undefined && vaultCount.active >= VAULT_CARD_LIMIT}>
              <Plus className="h-4 w-4" />
              <span className="hidden sm:inline">Add Card</span>
            </Button>
          </div>
        ) : inventoryTab === "sealed" ? (
          <div className="flex items-center gap-2">
            <Button variant="secondary" onClick={() => setShowSealedCsvImport(true)} className="gap-2">
              <Upload className="h-4 w-4" />
              <span className="hidden sm:inline">Import CSV</span>
            </Button>
            <SealedAddButton disabled={sealedProducts !== undefined && sealedCount >= SEALED_LIMIT} />
          </div>
        ) : null}
      </div>

      {/* Tab toggle */}
      <div className="flex gap-1 p-1 bg-secondary/50 rounded-xl border border-border w-fit mx-auto">
        <button
          onClick={() => setInventoryTab("cards")}
          className={cn(
            "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-colors cursor-pointer",
            inventoryTab === "cards" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
          )}
        >
          <Package className="h-4 w-4" />
          Cards
        </button>
        <button
          onClick={() => setInventoryTab("sealed")}
          className={cn(
            "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-colors cursor-pointer",
            inventoryTab === "sealed" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
          )}
        >
          <Barcode className="h-4 w-4" />
          Sealed
        </button>
        <button
          onClick={() => setInventoryTab("aging")}
          className={cn(
            "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-colors cursor-pointer",
            inventoryTab === "aging" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
          )}
        >
          <Clock className="h-4 w-4" />
          Aging
        </button>
      </div>

      {/* Aging Report Section */}
      {inventoryTab === "aging" && user && (
        <AgingReport userId={user._id} currency={user.currency ?? "GBP"} />
      )}

      {/* Sealed Products Section */}
      {inventoryTab === "sealed" && (<>
        {/* Sealed capacity meter */}
        {sealedProducts !== undefined && (
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground font-medium">
                Sealed Capacity —{" "}
                <span className={sealedCount >= SEALED_LIMIT ? "text-red-400 font-bold" : sealedCount >= Math.round(SEALED_LIMIT * 0.9) ? "text-amber-500 font-semibold" : "text-foreground"}>
                  {sealedCount.toLocaleString()}
                </span>{" "}
                / 500 products
              </span>
              <span className="text-muted-foreground">{Math.round((sealedCount / SEALED_LIMIT) * 100)}%</span>
            </div>
            <div className="h-1.5 w-full rounded-full bg-secondary overflow-hidden">
              <motion.div
                className={`h-full rounded-full transition-colors ${sealedCount >= SEALED_LIMIT ? "bg-red-500" : sealedCount >= Math.round(SEALED_LIMIT * 0.9) ? "bg-amber-500" : "bg-blue-400"}`}
                initial={{ width: 0 }}
                animate={{ width: `${Math.min((sealedCount / SEALED_LIMIT) * 100, 100)}%` }}
                transition={{ duration: 0.6, ease: "easeOut" }}
              />
            </div>
            {sealedCount >= SEALED_LIMIT && (
              <p className="text-xs text-red-400 font-medium">Sealed product limit reached. Remove products to add more.</p>
            )}
          </div>
        )}
        <SealedInventorySection currency={user?.currency ?? "GBP"} tileSize={tileSize} onToggleTileSize={toggleTileSize} />
      </>)}

      {/* Cards Section — only shown on cards tab */}
      {inventoryTab === "cards" && (<>

      {/* Vault capacity meter */}
      {vaultCount !== undefined && (
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground font-medium">
              Vault Capacity —{" "}
              <span className={vaultCount.active >= VAULT_CARD_LIMIT ? "text-red-400 font-bold" : vaultCount.active >= Math.round(VAULT_CARD_LIMIT * 0.9) ? "text-amber-500 font-semibold" : "text-foreground"}>
                {vaultCount.active.toLocaleString()}
              </span>{" "}
              / {VAULT_CARD_LIMIT.toLocaleString()} active cards
            </span>
            <span className="text-muted-foreground">{Math.round((vaultCount.active / VAULT_CARD_LIMIT) * 100)}%</span>
          </div>
          <div className="h-1.5 w-full rounded-full bg-secondary overflow-hidden">
            <motion.div
              className={`h-full rounded-full transition-colors ${vaultCount.active >= VAULT_CARD_LIMIT ? "bg-red-500" : vaultCount.active >= Math.round(VAULT_CARD_LIMIT * 0.9) ? "bg-amber-500" : "bg-primary"}`}
              initial={{ width: 0 }}
              animate={{ width: `${Math.min((vaultCount.active / VAULT_CARD_LIMIT) * 100, 100)}%` }}
              transition={{ duration: 0.6, ease: "easeOut" }}
            />
          </div>
          {vaultCount.active >= VAULT_CARD_LIMIT && <p className="text-xs text-red-400 font-medium">Vault full — mark cards as sold or delete to free up space.</p>}
          {vaultCount.active >= Math.round(VAULT_CARD_LIMIT * 0.9) && vaultCount.active < VAULT_CARD_LIMIT && <p className="text-xs text-amber-500">Almost full — {VAULT_CARD_LIMIT - vaultCount.active} slots remaining. Sold cards free up space.</p>}
        </div>
      )}

      {/* Search */}
      <div className="relative">
        <Filter className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
        <Input
          className="pl-9 pr-9"
          placeholder="Search by card name…"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        {search && (
          <button onClick={() => setSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground cursor-pointer">
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Filter tabs + view toggle */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex gap-2 bg-secondary/50 p-1 rounded-xl w-fit">
          {(["unsold", "sold"] as FilterType[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-1.5 rounded-lg text-sm font-medium capitalize transition-colors cursor-pointer ${
                filter === f ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {f === "unsold" ? "Active" : "Sold"}
            </button>
          ))}
        </div>
        <button
          onClick={toggleTileSize}
          className="p-2 rounded-lg border border-border bg-secondary/50 text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
          title={tileSize === "full" ? "Switch to compact view" : "Switch to full view"}
        >
          {tileSize === "full" ? <List className="h-4 w-4" /> : <LayoutGrid className="h-4 w-4" />}
        </button>
      </div>

      {/* Cards list */}
      <div className="space-y-3">
        {cards === undefined || status === "LoadingFirstPage" ? (
          Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-20 w-full" />)
        ) : (() => {
          const filtered = search.trim()
            ? cards.filter(c => c.name.toLowerCase().includes(search.trim().toLowerCase()))
            : cards;
          if (filtered.length === 0) return (
            <div className="text-center py-16 text-muted-foreground">
              <Package className="h-12 w-12 mx-auto mb-3 opacity-30" />
              <p className="font-semibold">{search ? "No cards match your search" : "No cards yet"}</p>
              <p className="text-sm mt-1">{search ? "Try a different name" : "Add your first card to get started"}</p>
              {!search && <Button className="mt-4" onClick={openNew}><Plus className="h-4 w-4 mr-2" />Add Card</Button>}
            </div>
          );
          return (
            <AnimatePresence>
              {filtered.map((card, i) => (
                <motion.div
                  key={card._id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ delay: i < 8 ? i * 0.03 : 0 }}
                >
                  {tileSize === "compact" ? (
                    /* ─── Compact card tile ─── */
                    <div>
                    {expandedCardId !== card._id && (
                    <Card className={`border-border transition-all ${card.sold ? "opacity-50 grayscale" : "hover:border-primary/30"}`}>
                      <CardContent className="px-3 py-2 relative">
                        {card.sold && (
                          <div className="absolute inset-0 flex items-center justify-center pointer-events-none rounded-xl overflow-hidden">
                            <span className="text-lg font-black tracking-[0.2em] text-foreground/8 rotate-[-30deg] select-none uppercase">ARCHIVED</span>
                          </div>
                        )}
                        <div className="flex items-center gap-2 cursor-pointer" onClick={() => setExpandedCardId(card._id)}>
                          <CardImageThumb storageId={card.imageStorageId} size="sm" onClick={card.imageStorageId ? (e) => {
                            e.stopPropagation();
                            const ids = [card.imageStorageId!, ...(card.imageBackStorageId ? [card.imageBackStorageId] : [])];
                            setPreviewImages({ ids, startIndex: 0 });
                          } : undefined} />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="font-semibold text-xs truncate">{card.name}</p>
                              {card.grade && <span className="text-[10px] font-semibold text-amber-500 shrink-0">{card.grade}</span>}
                            </div>
                            <p className="text-[10px] text-muted-foreground truncate">{card.game}{card.set ? ` · ${card.set}` : ""} · {card.condition}</p>
                          </div>
                          <div className="flex items-center gap-2 shrink-0" onClick={e => e.stopPropagation()}>
                            {!card.sold && card.marketValue !== undefined && (
                              <span className="text-xs font-bold text-primary">{formatCurrency(card.marketValue, currency)}</span>
                            )}
                            {card.sold && card.salePrice !== undefined && (
                              <span className="text-xs font-bold text-profit">{formatCurrency(card.salePrice, currency)}</span>
                            )}
                            {card.sold ? (
                              <Button
                                size="sm" variant="secondary"
                                className="h-6 px-2 text-[10px] gap-1 border border-border shrink-0"
                                onClick={async () => {
                                    await handleMarkUnsold(card);
                                  }}
                              >
                                <RotateCcw className="h-2.5 w-2.5" /> Unsold
                              </Button>
                            ) : (
                              <Button
                                size="sm"
                                className="h-6 px-2 text-[10px] gap-1 bg-[var(--profit)] hover:bg-[var(--profit)]/80 text-white shrink-0"
                                onClick={() => { setShowSellDialog(card._id); setSalePrice(card.marketValue?.toString() ?? ""); }}
                              >
                                <CheckCircle className="h-2.5 w-2.5" /> Sold
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    )}
                    {/* Expanded full tile shown inline — clicking it collapses back */}
                    <AnimatePresence>
                      {expandedCardId === card._id && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.18, ease: "easeOut" }}
                          className="overflow-hidden"
                        >
                    <Card className={`border-border transition-all mt-0.5 border-primary/30 ${card.sold ? "opacity-50 grayscale" : ""}`}>
                    {/* Collapse bar — tap to close */}
                    <div
                      className="flex items-center justify-center gap-1 py-1.5 border-b border-border cursor-pointer hover:bg-secondary/50 transition-colors rounded-t-xl"
                      onClick={() => setExpandedCardId(null)}
                    >
                      <span className="text-[9px] font-black tracking-widest text-muted-foreground uppercase">Tap to collapse</span>
                    </div>
                    <CardContent className="p-4 relative">
                      {card.sold && (
                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none rounded-xl overflow-hidden">
                          <span className="text-2xl font-black tracking-[0.2em] text-foreground/8 rotate-[-30deg] select-none uppercase">ARCHIVED</span>
                        </div>
                      )}
                      <div className="flex items-start gap-3">
                        <CardImageThumb storageId={card.imageStorageId} onClick={card.imageStorageId ? () => {
                          const ids = [card.imageStorageId!, ...(card.imageBackStorageId ? [card.imageBackStorageId] : [])];
                          setPreviewImages({ ids, startIndex: 0 });
                        } : undefined} />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div className="min-w-0">
                              <p className="font-semibold text-sm truncate">{card.name}</p>
                              <p className="text-xs text-muted-foreground">{card.game}{card.set ? ` • ${card.set}` : ""}</p>
                            </div>
                            <div className="flex items-center gap-1 shrink-0">
                              {card.sold
                                ? <Badge className="bg-profit/20 text-profit border-profit/30 text-xs">Sold</Badge>
                                : <Badge className="bg-primary/20 text-primary border-primary/30 text-xs">Active</Badge>
                              }
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-x-3 gap-y-1 mt-1.5">
                            <span className="text-xs text-muted-foreground">{card.condition}</span>
                            {card.grade && <span className="text-xs font-semibold text-amber-500">{card.grade}</span>}
                            {card.rarity && <span className="text-xs text-muted-foreground">{card.rarity}</span>}
                          </div>
                          <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-1.5" onClick={e => e.stopPropagation()}>
                            {!card.sold && (
                            <span className="text-xs text-muted-foreground">
                              Price: <InlinePriceEdit
                                cardId={card._id}
                                marketValue={card.marketValue}
                                currency={currency}
                                disabled={card.sold}
                              />
                            </span>
                            )}
                            {card.sold && card.salePrice !== undefined && (
                              <span className="text-xs text-muted-foreground">
                                Sold: <span className="text-profit font-semibold">{formatCurrency(card.salePrice, currency)}</span>
                              </span>
                            )}
                            {card.sold && card.salePrice !== undefined && card.purchasePrice !== undefined && (
                              <span className="text-xs text-muted-foreground">
                                Profit: <span className={`font-semibold ${card.salePrice - card.purchasePrice >= 0 ? "text-profit" : "text-red-400"}`}>
                                  {card.salePrice - card.purchasePrice >= 0 ? "+" : ""}{formatCurrency(card.salePrice - card.purchasePrice, currency)}
                                </span>
                              </span>
                            )}
                            {!card.sold && card.marketValue !== undefined && card.purchasePrice !== undefined && (
                              <span className="text-xs text-muted-foreground">
                                Profit: <span className={`font-semibold ${card.marketValue - card.purchasePrice >= 0 ? "text-profit" : "text-red-400"}`}>
                                  {card.marketValue - card.purchasePrice >= 0 ? "+" : ""}{formatCurrency(card.marketValue - card.purchasePrice, currency)}
                                </span>
                              </span>
                            )}

                            {card.sold && card.soldAt && (
                              <span className="text-xs text-muted-foreground">{formatDate(card.soldAt)}</span>
                            )}
                          </div>
                          <div className="flex items-center gap-2 mt-3" onClick={e => e.stopPropagation()}>
                            {card.sold ? (
                              <>
                                <Button
                                  size="sm" variant="secondary"
                                  className="h-7 px-2 text-xs gap-1 border border-primary bg-primary text-white hover:bg-primary/90 shrink-0"
                                  onClick={() => { setReceiptCard(card); setReceiptEmail(""); }}
                                >
                                  <Receipt className="h-3 w-3" /> Receipt
                                </Button>
                                <Button
                                  size="sm" variant="secondary"
                                  className="h-7 px-2 text-xs gap-1 border border-border shrink-0"
                                  onClick={async () => {
                                    await handleMarkUnsold(card);
                                  }}
                                >
                                  <RotateCcw className="h-3 w-3" /> Unsold
                                </Button>
                              </>
                            ) : (
                              <Button
                                size="sm"
                                className="h-7 px-2 text-xs gap-1 bg-[var(--profit)] hover:bg-[var(--profit)]/80 text-white shrink-0"
                                onClick={() => { setShowSellDialog(card._id); setSalePrice(card.marketValue?.toString() ?? ""); }}
                              >
                                <CheckCircle className="h-3 w-3" /> Sold
                              </Button>
                            )}
                            <Button size="sm" variant="secondary" className="h-7 px-2 text-xs gap-1" onClick={() => openEdit(card)}>
                              <Pencil className="h-3.5 w-3.5" /> Edit
                            </Button>
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive shrink-0" onClick={() => setConfirmDeleteId(card._id)}>
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                    </Card>
                        </motion.div>
                      )}
                    </AnimatePresence>
                    </div>
                  ) : (
                    /* ─── Full card tile ─── */
                    <Card className={`border-border transition-all ${card.sold ? "opacity-50 grayscale" : "hover:border-primary/30"}`}>
                    <CardContent className="p-4 relative">
                      {card.sold && (
                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none rounded-xl overflow-hidden">
                          <span className="text-2xl font-black tracking-[0.2em] text-foreground/8 rotate-[-30deg] select-none uppercase">ARCHIVED</span>
                        </div>
                      )}
                      <div className="flex items-start gap-3">
                        <CardImageThumb storageId={card.imageStorageId} onClick={card.imageStorageId ? () => {
                          const ids = [card.imageStorageId!, ...(card.imageBackStorageId ? [card.imageBackStorageId] : [])];
                          setPreviewImages({ ids, startIndex: 0 });
                        } : undefined} />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div className="min-w-0">
                              <p className="font-semibold text-sm truncate">{card.name}</p>
                              <p className="text-xs text-muted-foreground">{card.game}{card.set ? ` • ${card.set}` : ""}</p>
                            </div>
                            <div className="flex items-center gap-1 shrink-0">
                              {card.sold
                                ? <Badge className="bg-profit/20 text-profit border-profit/30 text-xs">Sold</Badge>
                                : <Badge className="bg-primary/20 text-primary border-primary/30 text-xs">Active</Badge>
                              }
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-x-3 gap-y-1 mt-1.5">
                            <span className="text-xs text-muted-foreground">{card.condition}</span>
                            {card.grade && <span className="text-xs font-semibold text-amber-500">{card.grade}</span>}
                            {card.rarity && <span className="text-xs text-muted-foreground">{card.rarity}</span>}
                          </div>
                          <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-1.5" onClick={e => e.stopPropagation()}>
                            {!card.sold && (
                            <span className="text-xs text-muted-foreground">
                              Price: <InlinePriceEdit
                                cardId={card._id}
                                marketValue={card.marketValue}
                                currency={currency}
                                disabled={card.sold}
                              />
                            </span>
                            )}
                            {card.sold && card.salePrice !== undefined && (
                              <span className="text-xs text-muted-foreground">
                                Sold: <span className="text-profit font-semibold">{formatCurrency(card.salePrice, currency)}</span>
                              </span>
                            )}
                            {card.sold && card.salePrice !== undefined && card.purchasePrice !== undefined && (
                              <span className="text-xs text-muted-foreground">
                                Profit: <span className={`font-semibold ${card.salePrice - card.purchasePrice >= 0 ? "text-profit" : "text-red-400"}`}>
                                  {card.salePrice - card.purchasePrice >= 0 ? "+" : ""}{formatCurrency(card.salePrice - card.purchasePrice, currency)}
                                </span>
                              </span>
                            )}
                            {!card.sold && card.marketValue !== undefined && card.purchasePrice !== undefined && (
                              <span className="text-xs text-muted-foreground">
                                Profit: <span className={`font-semibold ${card.marketValue - card.purchasePrice >= 0 ? "text-profit" : "text-red-400"}`}>
                                  {card.marketValue - card.purchasePrice >= 0 ? "+" : ""}{formatCurrency(card.marketValue - card.purchasePrice, currency)}
                                </span>
                              </span>
                            )}
                            {card.sold && card.soldAt && (
                              <span className="text-xs text-muted-foreground">{formatDate(card.soldAt)}</span>
                            )}
                          </div>
                          <div className="flex items-center gap-2 mt-3" onClick={e => e.stopPropagation()}>
                            {card.sold ? (
                              <>
                                <Button
                                  size="sm" variant="secondary"
                                  className="h-7 px-2 text-xs gap-1 border border-primary bg-primary text-white hover:bg-primary/90 shrink-0"
                                  onClick={() => { setReceiptCard(card); setReceiptEmail(""); }}
                                >
                                  <Receipt className="h-3 w-3" /> Receipt
                                </Button>
                                <Button
                                  size="sm" variant="secondary"
                                  className="h-7 px-2 text-xs gap-1 border border-border shrink-0"
                                  onClick={async () => {
                                    await handleMarkUnsold(card);
                                  }}
                                >
                                  <RotateCcw className="h-3 w-3" /> Unsold
                                </Button>
                              </>
                            ) : (
                              <Button
                                size="sm"
                                className="h-7 px-2 text-xs gap-1 bg-[var(--profit)] hover:bg-[var(--profit)]/80 text-white shrink-0"
                                onClick={() => { setShowSellDialog(card._id); setSalePrice(card.marketValue?.toString() ?? ""); }}
                              >
                                <CheckCircle className="h-3 w-3" /> Sold
                              </Button>
                            )}
                            <Button size="sm" variant="secondary" className="h-7 px-2 text-xs gap-1" onClick={() => openEdit(card)}>
                              <Pencil className="h-3.5 w-3.5" /> Edit
                            </Button>
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive shrink-0" onClick={() => setConfirmDeleteId(card._id)}>
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                    </Card>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
          );
        })()}
        {status === "CanLoadMore" && !search && (
          <Button variant="secondary" className="w-full gap-2" onClick={() => loadMore(20)}>
            <ChevronDown className="h-4 w-4" /> Load More
          </Button>
        )}
      </div>

      {/* Add / Edit Card Dialog */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent
          className="max-w-lg max-h-[90dvh] overflow-y-auto"
          onPointerDownOutside={e => e.preventDefault()}
          onInteractOutside={e => e.preventDefault()}
          onFocusOutside={e => e.preventDefault()}
        >
          <DialogHeader>
            <DialogTitle className="font-sans text-primary tracking-widest">
              {editCard ? "Edit Card" : "Add Card"}
            </DialogTitle>
          </DialogHeader>

          {/* Photo — Front & Back */}
          <div className="space-y-2">
            <Label>Photos <span className="text-muted-foreground font-normal text-xs">({[imageStorageId, imageBackStorageId].filter(Boolean).length}/2)</span></Label>
            <div className="flex flex-wrap gap-2">
              {/* Front tile */}
              <CardPhotoTile
                storageId={imageStorageId}
                label="Front"
                uploading={uploading && cardFileSlot === "front"}
                onAdd={() => { setCardFileSlot("front"); cardFileInputRef.current?.click(); }}
                onRemove={() => setImageStorageId(null)}
              />
              {/* Back tile */}
              <CardPhotoTile
                storageId={imageBackStorageId}
                label="Back"
                uploading={uploading && cardFileSlot === "back"}
                onAdd={() => { setCardFileSlot("back"); cardFileInputRef.current?.click(); }}
                onRemove={() => setImageBackStorageId(null)}
              />
            </div>
            <input ref={cardFileInputRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={handleCardFilePick} />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2 space-y-1">
              <Label>Card Name *</Label>
              <Input placeholder="e.g. Charizard" maxLength={25} value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value.slice(0, 25) }))} />
            </div>
            <div className="col-span-2 space-y-1">
              <Label>Game</Label>
              <Select value={form.game} onValueChange={v => setForm(f => ({ ...f, game: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{CARD_GAMES.map(g => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="col-span-2 space-y-1">
              <Label>Condition</Label>
              <Select value={form.condition} onValueChange={v => setForm(f => ({ ...f, condition: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{CARD_CONDITIONS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            {!editCard && (
              <div className="col-span-2">
                <DuplicateWarning name={form.name} game={form.game} currency={currency} />
              </div>
            )}
            <div className="space-y-1">
              <Label>Set / Edition</Label>
              <Input placeholder="e.g. Base Set" value={form.set} onChange={e => setForm(f => ({ ...f, set: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label>Set Number</Label>
              <Input placeholder="e.g. 4/102" value={form.cardNumber} onChange={e => setForm(f => ({ ...f, cardNumber: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label>Grade</Label>
              <Input placeholder="e.g. PSA 10" value={form.grade} onChange={e => setForm(f => ({ ...f, grade: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label>Rarity</Label>
              <Input placeholder="e.g. Holo Rare" value={form.rarity} onChange={e => setForm(f => ({ ...f, rarity: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label>Language</Label>
              <Input placeholder="e.g. English" value={form.language} onChange={e => setForm(f => ({ ...f, language: e.target.value }))} />
            </div>
            <div className="col-span-2 space-y-1">
              <Label>% Bought At</Label>
              <Select value="" onValueChange={pct => {
                const mv = parseFloat(form.marketValue);
                if (!isNaN(mv) && mv > 0) setForm(f => ({ ...f, purchasePrice: (mv * parseInt(pct) / 100).toFixed(2) }));
                else toast.error("Enter a Market Value first");
              }}>
                <SelectTrigger>
                  <SelectValue placeholder={
                    form.purchasePrice && form.marketValue && parseFloat(form.marketValue) > 0
                      ? `${Math.round((parseFloat(form.purchasePrice) / parseFloat(form.marketValue)) * 100)}% of market`
                      : "Quick fill…"
                  } />
                </SelectTrigger>
                <SelectContent>
                  {[10, 20, 30, 40, 50, 60, 70, 80, 90, 100].map(pct => (
                    <SelectItem key={pct} value={String(pct)}>{pct}%</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Purchase Price ({currency})</Label>
              <Input type="number" step="0.01" placeholder="0.00" value={form.purchasePrice} onChange={e => setForm(f => ({ ...f, purchasePrice: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label>Market Value ({currency})</Label>
              <Input type="number" step="0.01" placeholder="0.00" value={form.marketValue} onChange={e => setForm(f => ({ ...f, marketValue: e.target.value }))} />
            </div>
            <div className="col-span-2 space-y-1">
              <Label>Notes</Label>
              <Textarea placeholder="Any additional notes..." value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} rows={2} />
            </div>
          </div>

          <DialogFooter>
            <Button variant="secondary" onClick={() => setShowForm(false)}>Cancel</Button>
            <Button onClick={handleSave} className={`transition-colors ${saved ? "bg-profit hover:bg-profit text-white" : ""}`}>
              {editCard ? "Save Changes" : "Add to Vault"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Sell Dialog */}
      <Dialog open={!!showSellDialog} onOpenChange={() => setShowSellDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-sans text-primary">Mark as Sold</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">Enter the final sale price to log this transaction.</p>
            <div className="space-y-1">
              <Label>Sale Price ({currency}) <span className="text-primary">*</span></Label>
              <Input type="number" step="0.01" placeholder="0.00" value={salePrice} onChange={e => setSalePrice(e.target.value)} autoFocus />
              <p className="text-xs text-muted-foreground">Required — used to update Today's Earnings.</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setShowSellDialog(null)}>Cancel</Button>
            <Button onClick={handleConfirmSell} className="gap-2">
              <CheckCircle className="h-4 w-4" /> Confirm Sale
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Receipt Dialog */}
      <Dialog open={!!receiptCard} onOpenChange={(open) => { if (!open) setReceiptCard(null); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-sans text-primary tracking-widest flex items-center gap-2">
              <Receipt className="h-5 w-5" /> View & Send Receipt
            </DialogTitle>
          </DialogHeader>
          {receiptCard && (
            <div className="space-y-4">
              <div className="rounded-xl border border-border bg-secondary/30 overflow-hidden">
                <div className="bg-primary/10 border-b border-border px-4 py-3 flex items-center gap-2">
                  <Receipt className="h-4 w-4 text-primary" />
                  <span className="font-bold text-sm text-primary">Sale Receipt</span>
                  <span className="ml-auto text-xs text-muted-foreground">
                    {receiptCard.soldAt ? new Date(receiptCard.soldAt).toLocaleDateString() : new Date().toLocaleDateString()}
                  </span>
                </div>
                {(user?.businessName || user?.instagram) && (
                  <div className="px-4 py-3 border-b border-border space-y-0.5">
                    {user.businessName && <p className="font-bold text-sm">{user.businessName}</p>}
                    {user.instagram && <p className="text-xs text-muted-foreground">@{user.instagram}</p>}
                    {user.website && <p className="text-xs text-muted-foreground">{user.website}</p>}
                  </div>
                )}
                <div className="px-4 py-3 border-b border-border space-y-1">
                  <p className="font-semibold text-sm">{receiptCard.name}</p>
                  <div className="flex gap-2 flex-wrap text-xs text-muted-foreground">
                    <span>{receiptCard.game}</span>
                    {receiptCard.set && <span>· {receiptCard.set}</span>}
                    <span>· {receiptCard.condition}</span>
                    {receiptCard.grade && <span>· {receiptCard.grade}</span>}
                  </div>
                </div>
                <div className="px-4 py-3 space-y-1.5">
                  {receiptCard.purchasePrice !== undefined && (
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Purchase Price</span>
                      <span>{formatCurrency(receiptCard.purchasePrice, currency)}</span>
                    </div>
                  )}
                  {receiptCard.marketValue !== undefined && (
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Listed Value</span>
                      <span>{formatCurrency(receiptCard.marketValue, currency)}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-bold text-base pt-1 border-t border-border">
                    <span>Sale Price</span>
                    <span className="text-profit">
                      {receiptCard.salePrice !== undefined ? formatCurrency(receiptCard.salePrice, currency) : "—"}
                    </span>
                  </div>
                  {receiptCard.purchasePrice !== undefined && receiptCard.salePrice !== undefined && (
                    <div className="flex justify-between text-xs font-semibold">
                      <span>Profit</span>
                      <span className={receiptCard.salePrice - receiptCard.purchasePrice >= 0 ? "text-profit" : "text-red-400"}>
                        {receiptCard.salePrice - receiptCard.purchasePrice >= 0 ? "+" : ""}
                        {formatCurrency(receiptCard.salePrice - receiptCard.purchasePrice, currency)}
                      </span>
                    </div>
                  )}
                </div>
              </div>
              <div className="space-y-3 pt-1">
                <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Send Receipt to Customer</p>
                <Input type="email" placeholder="customer@example.com" value={receiptEmail} onChange={e => setReceiptEmail(e.target.value)} />
                <Button onClick={handleSendReceipt} disabled={sendingReceipt || !receiptEmail.trim()} className="w-full gap-2">
                  {sendingReceipt ? <Loader2 className="h-4 w-4 animate-spin" /> : <Mail className="h-4 w-4" />}
                  {sendingReceipt ? "Sending..." : "Send Receipt"}
                </Button>
                <p className="text-[10px] text-muted-foreground leading-relaxed">
                  <span className="font-bold text-primary">Pro tip:</span> The receipt may land in the customer's{" "}
                  <span className="font-semibold text-foreground">junk mail</span> or{" "}
                  <span className="font-semibold text-foreground">spam</span> folder.
                </p>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="secondary" className="w-full" onClick={() => setReceiptCard(null)}>Done</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!confirmDeleteId} onOpenChange={(open) => { if (!open) setConfirmDeleteId(null); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="font-sans text-primary tracking-widest">Delete Card</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">Are you happy to continue deleting this card? This will also delete its label. This cannot be undone.</p>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="secondary" onClick={() => setConfirmDeleteId(null)}>No</Button>
            <Button variant="destructive" onClick={confirmDelete}>Yes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ImageLightbox storageIds={previewImages.ids} startIndex={previewImages.startIndex} onClose={() => setPreviewImages({ ids: [], startIndex: 0 })} />
      <CsvImportDialog open={showCsvImport} onClose={() => setShowCsvImport(false)} currency={currency} />
      <SealedCsvImportDialog open={showSealedCsvImport} onClose={() => setShowSealedCsvImport(false)} currency={currency} />
      </>)}
    </div>
  );
}

const PRODUCT_TYPES = [
  "Booster Pack",
  "Booster Box",
  "Elite Trainer Box (ETB)",
  "Half Booster Box",
  "Mini Tin",
  "Tin",
  "Collection Box",
  "Premium Collection",
  "Ultra Premium Collection (UPC)",
  "Bundle",
  "Blister Pack",
  "3-Pack Blister",
  "Build & Battle Box",
  "Stadium",
  "Special Set Box",
  "Starter Deck",
  "Theme Deck",
  "Gift Set",
  "Promo Pack",
  "Display Case",
  "Other",
];

type SealedProductDoc = {
  _id: Id<"sealedProducts">;
  name: string;
  game: string;
  type: string;
  barcode: string;
  purchasePrice?: number;
  sellPrice?: number;
  quantity: number;
  notes?: string;
  imageStorageIds?: Id<"_storage">[];
  soldAt?: string;
};

type SealedForm = {
  name: string; game: string; type: string; barcode: string;
  purchasePrice: string; sellPrice: string; quantity: string; notes: string;
};

const EMPTY_SEALED: SealedForm = {
  name: "", game: "Pokémon", type: "Booster Pack", barcode: "",
  purchasePrice: "", sellPrice: "", quantity: "1", notes: "",
};

// Button rendered in header when on sealed tab
function InlineSealedPrice({
  productId,
  sellPrice,
  currency,
  disabled,
}: {
  productId: Id<"sealedProducts">;
  sellPrice: number | undefined;
  currency: string;
  disabled?: boolean;
}) {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState("");
  const [saving, setSaving] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const update = useMutation(api.sealedProducts.updateSealedProduct);

  const startEdit = (e: React.MouseEvent) => {
    if (disabled) return;
    e.stopPropagation();
    setValue(sellPrice?.toString() ?? "");
    setEditing(true);
    setTimeout(() => inputRef.current?.select(), 30);
  };

  const commit = async () => {
    const parsed = parseFloat(value);
    if (isNaN(parsed) || parsed < 0) { setEditing(false); return; }
    if (parsed === sellPrice) { setEditing(false); return; }
    setSaving(true);
    try {
      await update({ id: productId, sellPrice: parsed });
      toast.success("Price updated");
    } catch {
      toast.error("Failed to update price");
    } finally {
      setSaving(false);
      setEditing(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") { e.preventDefault(); void commit(); }
    if (e.key === "Escape") setEditing(false);
  };

  if (editing) {
    return (
      <span className="inline-flex items-center gap-1" onClick={e => e.stopPropagation()}>
        <input
          ref={inputRef}
          type="number"
          step="0.01"
          min="0"
          value={value}
          onChange={e => setValue(e.target.value)}
          onKeyDown={handleKeyDown}
          onBlur={() => void commit()}
          disabled={saving}
          className="w-20 text-xs font-bold text-right rounded-md border border-primary bg-background px-1.5 py-0.5 focus:outline-none focus:ring-1 focus:ring-primary"
          autoFocus
        />
        {saving && <span className="w-3 h-3 border border-primary border-t-transparent rounded-full animate-spin inline-block" />}
      </span>
    );
  }

  return (
    <button
      onClick={startEdit}
      disabled={disabled}
      title={disabled ? undefined : "Tap to edit price"}
      className={`font-semibold text-foreground transition-colors rounded px-0.5 -mx-0.5 ${
        disabled ? "" : "cursor-pointer hover:text-primary hover:bg-primary/10 active:scale-95"
      }`}
    >
      {sellPrice !== undefined ? formatCurrency(sellPrice, currency) : <span className="text-muted-foreground text-xs italic">set price</span>}
    </button>
  );
}

function SealedAddButton({ disabled }: { disabled?: boolean }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button onClick={() => setOpen(true)} className="gap-2" disabled={disabled}>
        <Plus className="h-4 w-4" />
        <span className="hidden sm:inline">Add Product</span>
      </Button>
      <SealedFormDialog open={open} onClose={() => setOpen(false)} product={null} />
    </>
  );
}

function SealedFormDialog({ open, onClose, product }: { open: boolean; onClose: () => void; product: SealedProductDoc | null }) {
  const [form, setForm] = useState<SealedForm>(
    product
      ? { name: product.name, game: product.game, type: product.type, barcode: product.barcode, purchasePrice: product.purchasePrice?.toString() ?? "", sellPrice: product.sellPrice?.toString() ?? "", quantity: product.quantity.toString(), notes: product.notes ?? "" }
      : EMPTY_SEALED
  );
  const [saving, setSaving] = useState(false);
  const [imageStorageIds, setImageStorageIds] = useState<Id<"_storage">[]>(product?.imageStorageIds ?? []);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const add = useMutation(api.sealedProducts.addSealedProduct);
  const update = useMutation(api.sealedProducts.updateSealedProduct);
  const generateUploadUrlSealed = useMutation(api.sealedProducts.generateUploadUrl);

  // Fetch existing image URLs for display
  const existingUrls = useQuery(
    api.sealedProducts.getImageUrls,
    imageStorageIds.length > 0 ? { storageIds: imageStorageIds } : "skip"
  );

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    if (!files.length) return;
    const remaining = 5 - imageStorageIds.length;
    const toUpload = files.slice(0, remaining);
    setUploading(true);
    try {
      const newIds: Id<"_storage">[] = [];
      for (const file of toUpload) {
        const uploadUrl = await generateUploadUrlSealed();
        const res = await fetch(uploadUrl, { method: "POST", headers: { "Content-Type": file.type }, body: file });
        const { storageId } = await res.json() as { storageId: Id<"_storage"> };
        newIds.push(storageId);
      }
      setImageStorageIds(prev => [...prev, ...newIds]);
      toast.success(`${newIds.length} photo${newIds.length > 1 ? "s" : ""} uploaded`);
    } catch {
      toast.error("Failed to upload photo");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const handleSave = async () => {
    if (!form.name.trim() || !form.barcode.trim()) return;
    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(), game: form.game, type: form.type, barcode: form.barcode.trim(),
        purchasePrice: form.purchasePrice ? parseFloat(form.purchasePrice) : undefined,
        sellPrice: form.sellPrice ? parseFloat(form.sellPrice) : undefined,
        quantity: parseInt(form.quantity) || 1,
        notes: form.notes || undefined,
        imageStorageIds: imageStorageIds.length > 0 ? imageStorageIds : undefined,
      };
      if (product) {
        await update({ id: product._id, ...payload });
        toast.success("Product updated");
      } else {
        await add(payload);
        toast.success("Product added");
      }
      onClose();
    } catch {
      toast.error("Failed to save product");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={o => { if (!o) onClose(); }}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-sans text-primary tracking-widest">{product ? "Edit Product" : "Add Sealed Product"}</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2 space-y-1">
            <Label>Product Name *</Label>
            <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="e.g. Prismatic Evolutions ETB" />
          </div>
          <div className="space-y-1">
            <Label>Game</Label>
            <Select value={form.game} onValueChange={v => setForm(f => ({ ...f, game: v }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{CARD_GAMES.map(g => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label>Type</Label>
            <Select value={form.type} onValueChange={v => setForm(f => ({ ...f, type: v }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{PRODUCT_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="col-span-2 space-y-1">
            <Label>Barcode (EAN-13 / UPC-A) *</Label>
            <Input value={form.barcode} onChange={e => setForm(f => ({ ...f, barcode: e.target.value }))} placeholder="e.g. 0820650153228" />
          </div>
          <div className="space-y-1">
            <Label>Purchase Price</Label>
            <Input type="number" step="0.01" placeholder="0.00" value={form.purchasePrice} onChange={e => setForm(f => ({ ...f, purchasePrice: e.target.value }))} />
          </div>
          <div className="space-y-1">
            <Label>Sell Price</Label>
            <Input type="number" step="0.01" placeholder="0.00" value={form.sellPrice} onChange={e => setForm(f => ({ ...f, sellPrice: e.target.value }))} />
          </div>
          <div className="space-y-1">
            <Label>Quantity</Label>
            <Input type="number" min="0" placeholder="1" value={form.quantity} onChange={e => setForm(f => ({ ...f, quantity: e.target.value }))} />
          </div>
          <div className="space-y-1">
            <Label>Notes</Label>
            <Input placeholder="Optional" value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
          </div>

          {/* Photo upload — up to 5 */}
          <div className="col-span-2 space-y-2">
            <Label>Photos <span className="text-muted-foreground font-normal text-xs">({imageStorageIds.length}/5)</span></Label>
            <div className="flex flex-wrap gap-2">
              {(existingUrls ?? imageStorageIds.map(() => null)).map((url, i) => (
                <div key={i} className="relative w-16 h-20 rounded-lg overflow-hidden border border-border shrink-0">
                  {url
                    ? <img src={url} alt={`photo ${i + 1}`} className="w-full h-full object-cover" />
                    : <div className="w-full h-full bg-secondary flex items-center justify-center"><Loader2 className="h-4 w-4 animate-spin text-muted-foreground" /></div>
                  }
                  <button
                    className="absolute top-0.5 right-0.5 bg-black/60 rounded-full p-0.5 hover:bg-black/80 cursor-pointer"
                    onClick={() => setImageStorageIds(prev => prev.filter((_, j) => j !== i))}
                  >
                    <X className="h-3 w-3 text-white" />
                  </button>
                </div>
              ))}
              {imageStorageIds.length < 5 && (
                <button
                  className="w-16 h-20 rounded-lg border-2 border-dashed border-border flex flex-col items-center justify-center gap-1 text-muted-foreground hover:border-primary hover:text-primary transition-colors cursor-pointer shrink-0"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploading}
                >
                  {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Camera className="h-4 w-4" />}
                  <span className="text-[10px]">{uploading ? "..." : "Add"}</span>
                </button>
              )}
            </div>
            <input ref={fileInputRef} type="file" accept="image/*" multiple className="hidden" onChange={handleFileUpload} />
          </div>
        </div>
        <DialogFooter className="pt-2">
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving || !form.name.trim() || !form.barcode.trim()} className="gap-2">
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            {saving ? "Saving..." : product ? "Save Changes" : "Add Product"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function SealedInventorySection({ currency, tileSize, onToggleTileSize }: { currency: string; tileSize: "compact" | "full"; onToggleTileSize: () => void }) {
  const products = useQuery(api.sealedProducts.listSealedProducts, {});
  const user = useQuery(api.users.getCurrentUser, {});
  const deleteProduct = useMutation(api.sealedProducts.deleteSealedProduct);
  const sellOne = useMutation(api.sealedProducts.sellOne);
  const restockProduct = useMutation(api.sealedProducts.restockProduct);
  const sendReceipt = useAction(api.emails.sendReceipt);
  const [editProduct, setEditProduct] = useState<SealedProductDoc | null>(null);
  const [sellDialog, setSellDialog] = useState<SealedProductDoc | null>(null);
  const [salePrice, setSalePrice] = useState("");
  const [receiptEmail, setReceiptEmail] = useState("");
  const [sendingReceipt, setSendingReceipt] = useState(false);
  const [selling, setSelling] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<Id<"sealedProducts"> | null>(null);
  const [sealedSearch, setSealedSearch] = useState("");
  const [sealedTab, setSealedTab] = useState<"active" | "sold">("active");
  const [restockDialog, setRestockDialog] = useState<SealedProductDoc | null>(null);
  const [restockQty, setRestockQty] = useState("1");
  const [expandedProductId, setExpandedProductId] = useState<Id<"sealedProducts"> | null>(null);

  const handleSell = async () => {
    if (!sellDialog) return;
    const price = parseFloat(salePrice);
    if (isNaN(price) || price <= 0) return;
    setSelling(true);
    const now = new Date();
    const d = now.getHours() < 6 ? new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1) : now;
    const localDate = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    try {
      await sellOne({ id: sellDialog._id, salePrice: price, localDate });
      toast.success(`Sold ${sellDialog.name} for ${formatCurrency(price, currency)}`);
      // Send receipt if email provided
      if (receiptEmail.trim()) {
        if (!user?.senderEmail) {
          toast.error("Set your sender email in Settings to send receipts");
        } else {
          setSendingReceipt(true);
          try {
            await sendReceipt({
              to: receiptEmail.trim(),
              senderEmail: user.senderEmail,
              cardName: sellDialog.name,
              game: sellDialog.game,
              condition: sellDialog.type,
              salePrice: price,
              currency,
              businessName: user?.businessName,
              instagram: user?.instagram,
              website: user?.website,
            });
            toast.success("Receipt sent!");
          } catch {
            toast.error("Sale logged but receipt failed to send");
          } finally {
            setSendingReceipt(false);
          }
        }
      }
      setSellDialog(null);
      setReceiptEmail("");
    } catch {
      toast.error("Failed to record sale");
    } finally {
      setSelling(false);
    }
  };

  if (products === undefined) return (
    <div className="space-y-3">
      {[1,2,3].map(i => <Skeleton key={i} className="h-20 w-full rounded-xl" />)}
    </div>
  );

  const filteredProducts = (() => {
    const tabFiltered = sealedTab === "active"
      ? products.filter(p => p.quantity > 0)
      : products.filter(p => p.quantity === 0);
    if (!sealedSearch.trim()) return tabFiltered;
    return tabFiltered.filter(p => p.name.toLowerCase().includes(sealedSearch.toLowerCase().trim()));
  })();

  const activeCount = products.filter(p => p.quantity > 0).length;
  const soldCount = products.filter(p => p.quantity === 0).length;

  return (
    <div className="space-y-3">
      {/* Search bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
        <input
          type="text"
          placeholder="Search by product name…"
          value={sealedSearch}
          onChange={e => setSealedSearch(e.target.value)}
          className="w-full h-10 pl-9 pr-9 rounded-lg border border-input bg-background text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
        />
        {sealedSearch && (
          <button onClick={() => setSealedSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground cursor-pointer">
            <X className="h-4 w-4" />
          </button>
        )}
      </div>
      {/* Active / Sold tabs + view toggle */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex gap-2 bg-secondary/50 p-1 rounded-xl w-fit">
          <button
            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${sealedTab === "active" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
            onClick={() => setSealedTab("active")}
          >
            Active
          </button>
          <button
            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${sealedTab === "sold" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
            onClick={() => setSealedTab("sold")}
          >
            Sold
          </button>
        </div>
        <button
          onClick={onToggleTileSize}
          className="p-2 rounded-lg border border-border bg-secondary/50 text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
          title={tileSize === "full" ? "Switch to compact view" : "Switch to full view"}
        >
          {tileSize === "full" ? <List className="h-4 w-4" /> : <LayoutGrid className="h-4 w-4" />}
        </button>
      </div>
      {filteredProducts.length === 0 && (
        <div className="text-center py-10 text-muted-foreground">
          {sealedSearch ? (
            <>
              <p className="font-semibold">No products match &quot;{sealedSearch}&quot;</p>
              <p className="text-sm mt-1">Try a different name</p>
            </>
          ) : sealedTab === "active" ? (
            <>
              <Barcode className="h-10 w-10 mx-auto mb-2 opacity-30" />
              <p className="font-semibold">No active stock</p>
              <p className="text-sm mt-1">Add a product or restock existing ones</p>
            </>
          ) : (
            <>
              <CheckCircle className="h-10 w-10 mx-auto mb-2 opacity-30" />
              <p className="font-semibold">No sold-out products yet</p>
              <p className="text-sm mt-1">Products with 0 quantity will appear here</p>
            </>
          )}
        </div>
      )}
      <AnimatePresence>
        {filteredProducts.map((product, i) => (
          <motion.div key={product._id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i < 8 ? i * 0.04 : 0 }}>
            {tileSize === "compact" ? (
              /* ─── Compact sealed tile ─── */
              <div>
                {expandedProductId !== product._id && (
                  <Card className={`border-border transition-all ${product.quantity === 0 ? "opacity-50 grayscale" : "hover:border-primary/30"}`}>
                    <CardContent className="px-3 py-2 relative">
                      {product.quantity === 0 && (
                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none rounded-xl overflow-hidden">
                          <span className="text-lg font-black tracking-[0.2em] text-foreground/8 rotate-[-30deg] select-none uppercase">ARCHIVED</span>
                        </div>
                      )}
                      <div className="flex items-center gap-2 cursor-pointer" onClick={() => setExpandedProductId(product._id)}>
                        <SealedImageThumb storageIds={product.imageStorageIds} size="sm" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="font-semibold text-xs truncate">{product.name}</p>
                            {product.quantity > 0 && <span className="text-[10px] text-muted-foreground shrink-0">×{product.quantity}</span>}
                          </div>
                          <p className="text-[10px] text-muted-foreground truncate">{product.game} · {product.type}</p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0" onClick={e => e.stopPropagation()}>
                          {product.quantity > 0 && product.sellPrice !== undefined && (
                            <span className="text-xs font-bold text-primary">{formatCurrency(product.sellPrice, currency)}</span>
                          )}
                          {product.quantity === 0 && product.sellPrice !== undefined && (
                            <span className="text-xs font-bold text-profit">{formatCurrency(product.sellPrice, currency)}</span>
                          )}
                          {product.quantity === 0 ? (
                            <Button
                              size="sm" variant="secondary"
                              className="h-6 px-2 text-[10px] gap-1 border border-primary bg-primary text-white hover:bg-primary/90 shrink-0"
                              onClick={(e) => { e.stopPropagation(); setRestockQty("1"); setRestockDialog(product); }}
                            >
                              <RotateCcw className="h-2.5 w-2.5" /> Restock
                            </Button>
                          ) : (
                            <Button
                              size="sm"
                              className="h-6 px-2 text-[10px] gap-1 bg-[var(--profit)] hover:bg-[var(--profit)]/80 text-white shrink-0"
                              onClick={(e) => { e.stopPropagation(); setSalePrice(product.sellPrice?.toString() ?? ""); setSellDialog(product); }}
                            >
                              <CheckCircle className="h-2.5 w-2.5" /> Sold
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
                <AnimatePresence>
                  {expandedProductId === product._id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.18, ease: "easeOut" }}
                      className="overflow-hidden"
                    >
                      <Card className={`border-border transition-all mt-0.5 border-primary/30 ${product.quantity === 0 ? "opacity-50 grayscale" : ""}`}>
                        {/* Collapse bar */}
                        <div
                          className="flex items-center justify-center gap-1 py-1.5 border-b border-border cursor-pointer hover:bg-secondary/50 transition-colors rounded-t-xl"
                          onClick={() => setExpandedProductId(null)}
                        >
                          <span className="text-[9px] font-black tracking-widest text-muted-foreground uppercase">Tap to collapse</span>
                        </div>
                        <CardContent className="p-4 relative">
                          {product.quantity === 0 && (
                            <div className="absolute inset-0 flex items-center justify-center pointer-events-none rounded-xl overflow-hidden">
                              <span className="text-2xl font-black tracking-[0.2em] text-foreground/8 rotate-[-30deg] select-none uppercase">ARCHIVED</span>
                            </div>
                          )}
                          <div className="flex items-start gap-3">
                            <div>
                              <SealedImageThumb storageIds={product.imageStorageIds} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between gap-2">
                                <div className="min-w-0">
                                  <p className="font-semibold text-sm truncate">{product.name}</p>
                                  <p className="text-xs text-muted-foreground">{product.game} · {product.type}</p>
                                  <p className="text-[10px] text-muted-foreground/60 font-mono mt-0.5">{product.barcode}</p>
                                </div>
                                <div className="flex items-center gap-1 shrink-0">
                                  {product.quantity === 0
                                    ? <Badge className="bg-profit/20 text-profit border-profit/30 text-xs">Sold Out</Badge>
                                    : <Badge className="bg-primary/20 text-primary border-primary/30 text-xs">Active</Badge>
                                  }
                                </div>
                              </div>
                              <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-1.5">
                                {product.quantity > 0 ? (
                                  <span className="text-xs text-muted-foreground">
                                    Price: <InlineSealedPrice
                                      productId={product._id}
                                      sellPrice={product.sellPrice}
                                      currency={currency}
                                    />
                                  </span>
                                ) : (
                                  product.sellPrice !== undefined && (
                                    <span className="text-xs text-muted-foreground">
                                      Sold: <span className="text-profit font-semibold">{formatCurrency(product.sellPrice, currency)}</span>
                                    </span>
                                  )
                                )}
                                {product.purchasePrice !== undefined && product.sellPrice !== undefined && (
                                  <span className="text-xs text-muted-foreground">
                                    Profit: <span className={`font-semibold ${product.sellPrice - product.purchasePrice >= 0 ? "text-profit" : "text-red-400"}`}>
                                      {product.sellPrice - product.purchasePrice >= 0 ? "+" : ""}{formatCurrency(product.sellPrice - product.purchasePrice, currency)}
                                    </span>
                                  </span>
                                )}
                                {product.quantity > 0 && (
                                  <span className="text-xs text-muted-foreground">
                                    Stock: <span className="text-foreground font-semibold">{product.quantity}</span>
                                  </span>
                                )}
                                {product.quantity === 0 && product.soldAt && (
                                  <span className="text-xs text-muted-foreground">{formatDate(product.soldAt)}</span>
                                )}
                              </div>
                              <div className="flex items-center gap-2 mt-3">
                                {product.quantity === 0 ? (
                                  <>
                                    <Button
                                      size="sm"
                                      variant="secondary"
                                      className="h-7 px-2 text-xs gap-1 border border-primary bg-primary text-white hover:bg-primary/90 shrink-0"
                                      onClick={(e) => { e.stopPropagation(); setRestockQty("1"); setRestockDialog(product); }}
                                    >
                                      <RotateCcw className="h-3 w-3" /> Restock
                                    </Button>
                                    <Button size="sm" variant="secondary" className="h-7 px-2 text-xs gap-1" onClick={(e) => { e.stopPropagation(); setEditProduct(product); }}>
                                      <Pencil className="h-3.5 w-3.5" /> Edit
                                    </Button>
                                    <Button size="sm" variant="secondary" className="h-7 px-2 text-xs gap-1 text-destructive hover:text-destructive" onClick={(e) => { e.stopPropagation(); setConfirmDelete(product._id); }}>
                                      <Trash2 className="h-3.5 w-3.5" />
                                    </Button>
                                  </>
                                ) : (
                                  <>
                                    <Button size="sm" className="h-7 px-2 text-xs gap-1 bg-[var(--profit)] hover:bg-[var(--profit)]/80 text-white shrink-0" onClick={(e) => { e.stopPropagation(); setSalePrice(product.sellPrice?.toString() ?? ""); setSellDialog(product); }}>
                                      <CheckCircle className="h-3 w-3" /> Sold
                                    </Button>
                                    <Button size="sm" variant="secondary" className="h-8 gap-1.5 text-xs" onClick={(e) => { e.stopPropagation(); setEditProduct(product); }}>
                                      <Pencil className="h-3.5 w-3.5" /> Edit
                                    </Button>
                                    <Button size="sm" variant="secondary" className="h-8 gap-1.5 text-xs text-destructive hover:text-destructive" onClick={(e) => { e.stopPropagation(); setConfirmDelete(product._id); }}>
                                      <Trash2 className="h-3.5 w-3.5" />
                                    </Button>
                                  </>
                                )}
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              /* ─── Full sealed tile ─── */
              <Card className={`border-border transition-all ${product.quantity === 0 ? "opacity-50 grayscale" : "hover:border-primary/30"}`}>
              <CardContent className="p-4 relative">
                {product.quantity === 0 && (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none rounded-xl overflow-hidden">
                    <span className="text-2xl font-black tracking-[0.2em] text-foreground/8 rotate-[-30deg] select-none uppercase">ARCHIVED</span>
                  </div>
                )}
                <div className="flex items-start gap-3">
                  <div>
                    <SealedImageThumb storageIds={product.imageStorageIds} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="font-semibold text-sm truncate">{product.name}</p>
                        <p className="text-xs text-muted-foreground">{product.game} · {product.type}</p>
                        <p className="text-[10px] text-muted-foreground/60 font-mono mt-0.5">{product.barcode}</p>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        {product.quantity === 0
                          ? <Badge className="bg-profit/20 text-profit border-profit/30 text-xs">Sold Out</Badge>
                          : <Badge className="bg-primary/20 text-primary border-primary/30 text-xs">Active</Badge>
                        }
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-1.5">
                      {product.quantity > 0 ? (
                        <span className="text-xs text-muted-foreground">
                          Price: <InlineSealedPrice
                            productId={product._id}
                            sellPrice={product.sellPrice}
                            currency={currency}
                          />
                        </span>
                      ) : (
                        product.sellPrice !== undefined && (
                          <span className="text-xs text-muted-foreground">
                            Sold: <span className="text-profit font-semibold">{formatCurrency(product.sellPrice, currency)}</span>
                          </span>
                        )
                      )}
                      {product.purchasePrice !== undefined && product.sellPrice !== undefined && (
                        <span className="text-xs text-muted-foreground">
                          Profit: <span className={`font-semibold ${product.sellPrice - product.purchasePrice >= 0 ? "text-profit" : "text-red-400"}`}>
                            {product.sellPrice - product.purchasePrice >= 0 ? "+" : ""}{formatCurrency(product.sellPrice - product.purchasePrice, currency)}
                          </span>
                        </span>
                      )}
                      {product.quantity > 0 && (
                        <span className="text-xs text-muted-foreground">
                          Stock: <span className="text-foreground font-semibold">{product.quantity}</span>
                        </span>
                      )}
                      {product.quantity === 0 && product.soldAt && (
                        <span className="text-xs text-muted-foreground">{formatDate(product.soldAt)}</span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 mt-3">
                      {product.quantity === 0 ? (
                        <>
                          <Button
                            size="sm"
                            variant="secondary"
                            className="h-7 px-2 text-xs gap-1 border border-primary bg-primary text-white hover:bg-primary/90 shrink-0"
                            onClick={(e) => { e.stopPropagation(); setRestockQty("1"); setRestockDialog(product); }}
                          >
                            <RotateCcw className="h-3 w-3" /> Restock
                          </Button>
                          <Button size="sm" variant="secondary" className="h-7 px-2 text-xs gap-1" onClick={(e) => { e.stopPropagation(); setEditProduct(product); }}>
                            <Pencil className="h-3.5 w-3.5" /> Edit
                          </Button>
                          <Button size="sm" variant="secondary" className="h-7 px-2 text-xs gap-1 text-destructive hover:text-destructive" onClick={(e) => { e.stopPropagation(); setConfirmDelete(product._id); }}>
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </>
                      ) : (
                        <>
                          <Button size="sm" className="h-7 px-2 text-xs gap-1 bg-[var(--profit)] hover:bg-[var(--profit)]/80 text-white shrink-0" onClick={(e) => { e.stopPropagation(); setSalePrice(product.sellPrice?.toString() ?? ""); setSellDialog(product); }}>
                            <CheckCircle className="h-3 w-3" /> Sold
                          </Button>
                          <Button size="sm" variant="secondary" className="h-8 gap-1.5 text-xs" onClick={(e) => { e.stopPropagation(); setEditProduct(product); }}>
                            <Pencil className="h-3.5 w-3.5" /> Edit
                          </Button>
                          <Button size="sm" variant="secondary" className="h-8 gap-1.5 text-xs text-destructive hover:text-destructive" onClick={(e) => { e.stopPropagation(); setConfirmDelete(product._id); }}>
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
              </Card>
            )}
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Edit dialog */}
      {editProduct && <SealedFormDialog open={!!editProduct} onClose={() => setEditProduct(null)} product={editProduct} />}

      {/* Sell dialog */}
      <Dialog open={!!sellDialog} onOpenChange={o => { if (!o) { setSellDialog(null); setReceiptEmail(""); } }}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Sell {sellDialog?.name}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1">
              <Label>Sale Price ({currency})</Label>
              <Input type="number" step="0.01" autoFocus value={salePrice} onChange={e => setSalePrice(e.target.value)} className="text-xl font-bold h-14 text-center" placeholder="0.00" />
            </div>
            <div className="space-y-1">
              <Label className="flex items-center gap-1.5">
                <Mail className="h-3.5 w-3.5 text-muted-foreground" />
                Customer Email <span className="text-muted-foreground font-normal text-xs">(optional — sends receipt)</span>
              </Label>
              <Input type="email" placeholder="customer@example.com" value={receiptEmail} onChange={e => setReceiptEmail(e.target.value)} />
            </div>
            <div className="flex items-start gap-2 p-3 rounded-xl bg-profit/10 border border-profit/20 text-xs text-profit">
              <CheckCircle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
              Sale logged to Earnings. Stock reduced by 1.
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => { setSellDialog(null); setReceiptEmail(""); }}>Cancel</Button>
            <Button onClick={handleSell} disabled={selling || sendingReceipt} className="gap-2">
              {(selling || sendingReceipt) ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShoppingCart className="h-4 w-4" />}
              {selling ? "Logging..." : sendingReceipt ? "Sending..." : `Confirm · ${salePrice ? formatCurrency(parseFloat(salePrice) || 0, currency) : "—"}`}
            </Button>
          </DialogFooter>
          {receiptEmail.trim() && (
            <p className="text-[10px] text-muted-foreground leading-relaxed px-1 pb-1"><span className="font-bold text-foreground">Pro tip:</span> Let the customer know their receipt might land in their <span className="font-semibold text-foreground">junk mail</span> or <span className="font-semibold text-foreground">spam</span> folder.</p>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete confirm dialog */}
      <Dialog open={!!confirmDelete} onOpenChange={o => { if (!o) setConfirmDelete(null); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Delete Product</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">Are you sure? This cannot be undone.</p>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setConfirmDelete(null)}>No</Button>
            <Button variant="destructive" onClick={async () => { if (confirmDelete) { await deleteProduct({ id: confirmDelete }); setConfirmDelete(null); toast.success("Product deleted"); } }}>Yes, Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Restock dialog */}
      <Dialog open={!!restockDialog} onOpenChange={o => { if (!o) setRestockDialog(null); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Restock {restockDialog?.name}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1">
              <Label>New Quantity</Label>
              <Input
                type="number"
                min="1"
                placeholder="1"
                value={restockQty}
                onChange={e => setRestockQty(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setRestockDialog(null)}>Cancel</Button>
            <Button
              onClick={async () => {
                if (!restockDialog) return;
                const qty = parseInt(restockQty);
                if (isNaN(qty) || qty < 1) return;
                await restockProduct({ id: restockDialog._id, quantity: qty });
                toast.success(`${restockDialog.name} restocked with ${qty} unit${qty !== 1 ? "s" : ""}`);
                setRestockDialog(null);
              }}
              disabled={!restockQty || parseInt(restockQty) < 1}
            >
              <RotateCcw className="h-4 w-4 mr-1.5" /> Restock
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>



    </div>
  );
}

function CardPhotoTile({ storageId, label, uploading, onAdd, onRemove }: {
  storageId: Id<"_storage"> | null;
  label: string;
  uploading: boolean;
  onAdd: () => void;
  onRemove: () => void;
}) {
  const url = useQuery(api.cards.getImageUrl, storageId ? { storageId } : "skip");
  if (storageId) {
    return (
      <div className="relative w-16 h-20 rounded-lg overflow-hidden border border-border shrink-0">
        {url
          ? <img src={url} alt={label} className="w-full h-full object-cover" />
          : <div className="w-full h-full bg-secondary flex items-center justify-center"><Loader2 className="h-4 w-4 animate-spin text-muted-foreground" /></div>
        }
        <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-[9px] text-white text-center py-0.5 font-semibold">{label}</div>
        <button
          className="absolute top-0.5 right-0.5 bg-black/60 rounded-full p-0.5 hover:bg-black/80 cursor-pointer"
          onClick={onRemove}
        >
          <X className="h-3 w-3 text-white" />
        </button>
      </div>
    );
  }
  return (
    <button
      className="w-16 h-20 rounded-lg border-2 border-dashed border-border flex flex-col items-center justify-center gap-1 text-muted-foreground hover:border-primary hover:text-primary transition-colors cursor-pointer shrink-0"
      onClick={onAdd}
      disabled={uploading}
    >
      {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Camera className="h-4 w-4" />}
      <span className="text-[10px]">{uploading ? "..." : label}</span>
    </button>
  );
}

// ─── Inline Price Edit ────────────────────────────────────────────────────────
// Tap the price to edit it inline — fast repricing without opening the full form
function InlinePriceEdit({
  cardId,
  marketValue,
  currency,
  onSaved,
  disabled,
}: {
  cardId: Id<"cards">;
  marketValue: number | undefined;
  currency: string;
  onSaved?: (newValue: number) => void;
  disabled?: boolean;
}) {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState("");
  const [saving, setSaving] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const updateCard = useMutation(api.cards.updateCard);
  const patchLabelPrice = useMutation(api.labels.patchLabelPrice);

  const startEdit = (e: React.MouseEvent) => {
    if (disabled) return;
    e.stopPropagation();
    setValue(marketValue?.toString() ?? "");
    setEditing(true);
    // Focus after render
    setTimeout(() => inputRef.current?.select(), 30);
  };

  const commit = async () => {
    const parsed = parseFloat(value);
    if (isNaN(parsed) || parsed < 0) { cancel(); return; }
    if (parsed === marketValue) { setEditing(false); return; }
    setSaving(true);
    try {
      await updateCard({ id: cardId, marketValue: parsed });
      await patchLabelPrice({ cardId, price: parsed });
      onSaved?.(parsed);
      toast.success("Price updated");
    } catch {
      toast.error("Failed to update price");
    } finally {
      setSaving(false);
      setEditing(false);
    }
  };

  const cancel = () => { setEditing(false); setValue(""); };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") { e.preventDefault(); void commit(); }
    if (e.key === "Escape") cancel();
  };

  if (editing) {
    return (
      <span className="inline-flex items-center gap-1" onClick={e => e.stopPropagation()}>
        <input
          ref={inputRef}
          type="number"
          step="0.01"
          min="0"
          value={value}
          onChange={e => setValue(e.target.value)}
          onKeyDown={handleKeyDown}
          onBlur={() => void commit()}
          disabled={saving}
          className="w-20 text-xs font-bold text-right rounded-md border border-primary bg-background px-1.5 py-0.5 focus:outline-none focus:ring-1 focus:ring-primary"
          autoFocus
        />
        {saving && <span className="w-3 h-3 border border-primary border-t-transparent rounded-full animate-spin inline-block" />}
      </span>
    );
  }

  return (
    <button
      onClick={startEdit}
      disabled={disabled}
      title={disabled ? undefined : "Tap to edit price"}
      className={`font-semibold text-foreground transition-colors rounded px-0.5 -mx-0.5 ${
        disabled ? "cursor-default" : "cursor-pointer hover:text-primary hover:bg-primary/10 active:scale-95"
      }`}
    >
      {marketValue !== undefined ? formatCurrency(marketValue, currency) : <span className="text-muted-foreground text-xs italic">set price</span>}
    </button>
  );
}

function CardImageThumb({ storageId, onClick, className, size }: { storageId?: Id<"_storage">; onClick?: ((e: React.MouseEvent) => void) | (() => void); className?: string; size?: "sm" | "default" }) {
  const url = useQuery(api.cards.getImageUrl, storageId ? { storageId } : "skip");
  const isSmall = size === "sm";
  const defaultW = isSmall ? "2.25rem" : "3.5rem";
  const defaultH = isSmall ? "2.75rem" : "4.5rem";
  if (!storageId) {
    return (
      <div className={cn("rounded-lg bg-secondary border border-border flex items-center justify-center shrink-0", className ?? (isSmall ? "w-9" : "w-14"))} style={!className ? { minWidth: defaultW, height: defaultH } : undefined}>
        <Package className={isSmall ? "h-3.5 w-3.5 text-muted-foreground" : "h-5 w-5 text-muted-foreground"} />
      </div>
    );
  }
  if (!url) return <Skeleton className={cn("rounded-lg shrink-0", className ?? (isSmall ? "w-9" : "w-14"))} style={!className ? { height: defaultH } : undefined} />;
  return (
    <button
      onClick={onClick}
      className={cn("shrink-0 rounded-lg overflow-hidden border border-border focus:outline-none focus:ring-2 focus:ring-primary cursor-pointer", className)}
      style={!className ? { width: defaultW, height: defaultH } : undefined}
      title="View full image"
    >
      <img src={url} alt="card" className="w-full h-full object-cover" />
    </button>
  );
}

function SealedImageThumb({ storageIds, size }: { storageIds?: Id<"_storage">[]; size?: "sm" | "default" }) {
  const firstId = storageIds?.[0];
  const url = useQuery(api.sealedProducts.getImageUrls, firstId ? { storageIds: [firstId] } : "skip");
  const isSmall = size === "sm";
  const sizeClass = isSmall ? "w-7 h-7 rounded-lg" : "w-10 h-10 rounded-xl";
  const iconClass = isSmall ? "h-3.5 w-3.5 text-blue-400" : "h-5 w-5 text-blue-400";
  if (!firstId) {
    return (
      <div className={`${sizeClass} bg-blue-500/10 border border-blue-500/20 flex items-center justify-center shrink-0`}>
        <Barcode className={iconClass} />
      </div>
    );
  }
  if (!url) return <Skeleton className={`${sizeClass} shrink-0`} />;
  const imgUrl = url[0];
  if (!imgUrl) return (
    <div className={`${sizeClass} bg-blue-500/10 border border-blue-500/20 flex items-center justify-center shrink-0`}>
      <Barcode className={iconClass} />
    </div>
  );
  return (
    <div className={`${sizeClass} overflow-hidden border border-border shrink-0`}>
      <img src={imgUrl} alt="product" className="w-full h-full object-cover" />
    </div>
  );
}

function ImageLightbox({ storageIds, startIndex, onClose }: { storageIds: Id<"_storage">[]; startIndex: number; onClose: () => void }) {
  const [currentIndex, setCurrentIndex] = useState(startIndex);
  const dragStartX = useRef<number | null>(null);
  const dragDeltaX = useRef(0);

  useEffect(() => {
    setCurrentIndex(startIndex);
  }, [startIndex, storageIds]);

  const currentStorageId = storageIds[currentIndex] ?? null;
  const url = useQuery(api.cards.getImageUrl, currentStorageId ? { storageId: currentStorageId } : "skip");

  useEffect(() => {
    if (storageIds.length === 0) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft" && currentIndex > 0) setCurrentIndex(i => i - 1);
      if (e.key === "ArrowRight" && currentIndex < storageIds.length - 1) setCurrentIndex(i => i + 1);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [storageIds, currentIndex, onClose]);

  const handleTouchStart = (e: React.TouchEvent) => {
    dragStartX.current = e.touches[0].clientX;
    dragDeltaX.current = 0;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (dragStartX.current === null) return;
    dragDeltaX.current = e.touches[0].clientX - dragStartX.current;
  };

  const handleTouchEnd = () => {
    if (dragStartX.current === null) return;
    const threshold = 50;
    if (dragDeltaX.current < -threshold && currentIndex < storageIds.length - 1) setCurrentIndex(i => i + 1);
    else if (dragDeltaX.current > threshold && currentIndex > 0) setCurrentIndex(i => i - 1);
    dragStartX.current = null;
    dragDeltaX.current = 0;
  };

  if (storageIds.length === 0) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center"
      onClick={onClose}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      <button onClick={onClose} className="absolute top-4 right-4 text-white/70 hover:text-white cursor-pointer z-10">
        <X className="h-6 w-6" />
      </button>
      {storageIds.length > 1 && (
        <>
          <button
            onClick={e => { e.stopPropagation(); if (currentIndex > 0) setCurrentIndex(i => i - 1); }}
            className="absolute left-4 top-1/2 -translate-y-1/2 text-white/70 hover:text-white cursor-pointer z-10 disabled:opacity-30"
            disabled={currentIndex === 0}
          >
            <Tag className="h-6 w-6 rotate-180" />
          </button>
          <button
            onClick={e => { e.stopPropagation(); if (currentIndex < storageIds.length - 1) setCurrentIndex(i => i + 1); }}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-white/70 hover:text-white cursor-pointer z-10 disabled:opacity-30"
            disabled={currentIndex === storageIds.length - 1}
          >
            <Tag className="h-6 w-6" />
          </button>
          <div className="absolute bottom-4 flex gap-2">
            {storageIds.map((_, i) => (
              <div key={i} className={`w-2 h-2 rounded-full ${i === currentIndex ? "bg-white" : "bg-white/30"}`} />
            ))}
          </div>
        </>
      )}
      <div className="max-w-[90vw] max-h-[90vh]" onClick={e => e.stopPropagation()}>
        {url ? (
          <img src={url} alt="card" className="max-w-full max-h-[90vh] object-contain rounded-lg" />
        ) : (
          <Skeleton className="w-64 h-96 rounded-lg" />
        )}
      </div>
    </div>
  );
}
