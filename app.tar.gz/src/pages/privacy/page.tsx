import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, Lock, ArrowUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useEffect, useRef, useState } from "react";

type Section = {
  id: string;
  title: string;
  content: React.ReactNode;
};

const sections: Section[] = [
  {
    id: "01",
    title: "About DatCARDVault",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          DatCARDVault™ is a <span className="font-semibold text-primary">pocket business assistant</span> designed for trading-card game (TCG) vendors and sellers.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          DatCARDVault helps sellers manage inventory, card information, pricing, QR-code labels, thermal printing, sales, and inventory updates.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">Depending on the features available to you, the Service may allow you to:</p>
        <ul className="space-y-2 pl-1">
          {[
            "Photograph trading cards",
            "Create inventory records",
            "Store card information",
            "Set and update prices",
            "Generate QR-code price labels",
            "Print labels using compatible thermal printers",
            "Scan QR codes at card shows and selling events",
            "View inventory information",
            "Edit inventory",
            "Mark inventory as sold",
            "Track sales and related business information",
          ].map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
      </div>
    ),
  },
  {
    id: "02",
    title: "Our Privacy Principles",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          Your TCG business information <span className="font-semibold text-primary">belongs to you</span>.
        </p>
        <ul className="space-y-2 pl-1">
          {[
            "DatCARDVault does not sell your personal information, inventory information, card information, sales information, or collection/business information",
            "DatCARDVault does not provide your information to unrelated businesses for their own advertising or marketing purposes",
            "DatCARDVault only processes information necessary to provide, operate, secure, maintain, and improve the service",
          ].map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
      </div>
    ),
  },
  {
    id: "03",
    title: "Information We Collect",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          <span className="font-semibold text-primary">Account information:</span> Email address, information required to authenticate and maintain your account.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">DatCARDVault does not currently require:</p>
        <ul className="space-y-2 pl-1">
          {[
            "Full name",
            "Home address",
            "Telephone number",
            "Date of birth",
            "Government identification",
            "Payment-card information (unless the service changes)",
          ].map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
      </div>
    ),
  },
  {
    id: "04",
    title: "TCG Business & Inventory Information",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-muted-foreground leading-relaxed">You may choose to enter:</p>
        <ul className="space-y-2 pl-1">
          {[
            "Card name",
            "Trading-card game",
            "Set",
            "Card number",
            "Rarity",
            "Condition",
            "Language",
            "Purchase price",
            "Sale price",
            "Inventory status",
            "Sale information",
            "Card photographs",
            "Vendor notes",
            "Inventory locations",
            "Other information you voluntarily enter",
          ].map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
        <p className="text-sm text-muted-foreground leading-relaxed">
          This information is processed to provide inventory and business-management functionality. Where associated with your account, it may be treated as information associated with you.
        </p>
      </div>
    ),
  },
  {
    id: "05",
    title: "Card Photographs",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          DatCARDVault allows sellers to photograph and upload trading cards. Photographs become associated with the relevant inventory item.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Photographs are used to support inventory-management activities. You control which photographs you upload.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          You should not upload photographs containing another person's personal or confidential information without their permission.
        </p>
      </div>
    ),
  },
  {
    id: "06",
    title: "How We Use Information",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-muted-foreground leading-relaxed">We use the information we collect to:</p>
        <ul className="space-y-2 pl-1">
          {[
            "Create and maintain your account",
            "Authenticate you",
            "Manage inventory",
            "Store card information and photographs",
            "Manage pricing",
            "Generate QR codes and labels",
            "Support thermal-label printing",
            "Support QR-code scanning",
            "Display and edit inventory",
            "Record cards as sold",
            "Maintain sales information",
            "Provide business-management functionality",
            "Maintain and secure DatCARDVault",
            "Troubleshoot",
            "Improve the application",
          ].map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
        <p className="text-sm text-muted-foreground leading-relaxed">
          DatCARDVault does not use your TCG inventory as advertising material.
        </p>
      </div>
    ),
  },
  {
    id: "07",
    title: "Lawful Basis for Processing",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          Under UK data-protection law, we rely on the following lawful bases:
        </p>
        <ul className="space-y-2 pl-1">
          {[
            "Contract: processing necessary to provide the service (e.g. email for account creation)",
            "Legitimate Interests: operating, maintaining security, preventing misuse, troubleshooting, reliability, improving service, understanding performance",
            "Consent: where applicable law requires it",
          ].map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
      </div>
    ),
  },
  {
    id: "08",
    title: "Google Fonts",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          DatCARDVault loads fonts from <span className="font-semibold text-primary">Google Fonts</span>, a service provided by Google LLC.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          When the app loads, your browser makes a request to Google's servers to retrieve font files. This is a standard technical process and may involve your IP address being transmitted to Google as part of that request.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          DatCARDVault does not send any personal account or inventory information to Google as part of font loading. Google's own privacy policy applies to data processed by Google Fonts.
        </p>
      </div>
    ),
  },
  {
    id: "09",
    title: "Cookies & Similar Technologies",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          DatCARDVault uses only <span className="font-semibold text-primary">essential cookies</span> — those strictly necessary for authentication and core functionality. No analytics or advertising cookies are used.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          DatCARDVault will comply with UK requirements regarding cookies and similar technologies.
        </p>
      </div>
    ),
  },
  {
    id: "10",
    title: "Where Your Information Is Stored",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          DatCARDVault uses database infrastructure provided by <span className="font-semibold text-primary">Hercules, Systems Inc. DBA Hercules</span>.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Information may be stored and processed outside the UK, including in the United States. International transfers may use appropriate safeguards including Standard Contractual Clauses.
        </p>
      </div>
    ),
  },
  {
    id: "11",
    title: "Hercules",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          Hercules provides the infrastructure for the DatCARDVault database. Hercules may use service providers, contractors, and cloud providers.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          DatCARDVault does not control Hercules' independent privacy practices.
        </p>
      </div>
    ),
  },
  {
    id: "12",
    title: "Selling or Sharing Information",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          DatCARDVault does <span className="font-semibold text-primary">NOT</span> sell:
        </p>
        <ul className="space-y-2 pl-1">
          {[
            "Your email address",
            "Your personal information",
            "Your card inventory",
            "Your photographs",
            "Your prices",
            "Your sales information",
            "Your TCG business information",
          ].map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
        <p className="text-sm text-muted-foreground leading-relaxed">
          DatCARDVault does not provide information to unrelated businesses for advertising or marketing. We use third-party services (Hercules, Google Analytics) necessary to operate.
        </p>
      </div>
    ),
  },
  {
    id: "13",
    title: "Your TCG Business Information",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          Your information remains associated with your account. DatCARDVault does not claim ownership of your trading cards, inventory, photographs, prices, sales records, or business information.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Recording an item in DatCARDVault does not transfer ownership of that item to DatCARDVault.
        </p>
      </div>
    ),
  },
  {
    id: "14",
    title: "QR Codes",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          DatCARDVault generates QR codes for individual inventory records. These allow sellers to quickly identify items and access information.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          QR codes should be treated as inventory identifiers. Users should not place passwords or credentials into QR-code data.
        </p>
      </div>
    ),
  },
  {
    id: "15",
    title: "Thermal Printing",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          DatCARDVault generates labels for compatible thermal printers. Labels may contain:
        </p>
        <ul className="space-y-2 pl-1">
          {[
            "Card name",
            "Set",
            "Card number",
            "Condition",
            "Price",
            "QR code",
            "Other inventory information",
          ].map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Once physically printed, DatCARDVault cannot control who sees, handles, or copies that label.
        </p>
      </div>
    ),
  },
  {
    id: "16",
    title: "Sales & Inventory Status",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          DatCARDVault allows sellers to update inventory and mark items as sold. Sale information may include:
        </p>
        <ul className="space-y-2 pl-1">
          {[
            "Sale price",
            "Inventory item",
            "Sale status",
            "Notes",
          ].map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
        <p className="text-sm text-muted-foreground leading-relaxed">
          This information is processed to provide inventory and business-management functionality.
        </p>
      </div>
    ),
  },
  {
    id: "16b",
    title: "Customer Receipts & Email Addresses",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          DatCARDVault allows vendors to send sale receipts to their customers by email. To do this, a vendor may enter a customer's email address into the app.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          DatCARDVault acts only as a <span className="font-semibold text-foreground">technical delivery tool</span> in these cases. Customer email addresses entered for this purpose are used solely to send the requested receipt and are not retained for any other purpose.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Vendors are responsible for ensuring they have the right to communicate with their customers and for complying with applicable laws when sending emails.
        </p>
      </div>
    ),
  },
  {
    id: "17",
    title: "Account Deletion",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          Users can <span className="font-semibold text-primary">permanently delete</span> their account. Deletion is permanent and cannot be restored.
        </p>
        <ul className="space-y-2 pl-1">
          {[
            "Previous inventory cannot be recovered",
            "If you return, you must create a new account",
            "There is no undo button — retain important information before deleting",
          ].map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
      </div>
    ),
  },
  {
    id: "18",
    title: "Backups & Deletion",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          Hercules infrastructure may retain information in backups as part of its disaster-recovery policies.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Deleted means removed from the active service and cannot be restored through DatCARDVault. Temporary backup copies may remain subject to backup processes.
        </p>
      </div>
    ),
  },
  {
    id: "19",
    title: "Data Retention",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          DatCARDVault retains information while your account is active and as required.
        </p>
        <ul className="space-y-2 pl-1">
          {[
            "Activity logs (account audit trail) are automatically deleted after 90 days",
            "QR scan logs are automatically deleted after 30 days",
            "All other account and inventory data is retained until you delete your account",
          ].map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
        <p className="text-sm text-muted-foreground leading-relaxed">
          On deletion, information is removed from the active service. Technical backup copies are subject to infrastructure provider retention policies.
        </p>
      </div>
    ),
  },
  {
    id: "20",
    title: "Security",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          DatCARDVault uses Hercules infrastructure and takes reasonable measures to protect information.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          No internet service can guarantee absolute security. Keep your credentials secure and do not share them.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          If you suspect unauthorised access, contact <span className="font-semibold text-primary">datcardvault@gmail.com</span>.
        </p>
      </div>
    ),
  },
  {
    id: "21",
    title: "International Data Transfers",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          DatCARDVault is operated from the United Kingdom. Information may be processed outside the UK.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Hercules uses appropriate safeguards including Standard Contractual Clauses. DatCARDVault will use appropriate safeguards where required by applicable law.
        </p>
      </div>
    ),
  },
  {
    id: "22",
    title: "Your Data Protection Rights",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-muted-foreground leading-relaxed">Your rights may include:</p>
        <ul className="space-y-2 pl-1">
          {[
            "Right to be informed",
            "Right of access",
            "Right to rectification",
            "Right to erasure",
            "Right to restrict processing",
            "Right to object",
            "Right to data portability",
            "Right to withdraw consent",
          ].map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Availability depends on circumstances. Contact: <span className="font-semibold text-primary">datcardvault@gmail.com</span>
        </p>
      </div>
    ),
  },
  {
    id: "23",
    title: "Direct Marketing",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          DatCARDVault does not sell personal information for marketing purposes.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          If marketing communications are introduced in future, UK privacy and electronic-marketing requirements will be considered.
        </p>
      </div>
    ),
  },
  {
    id: "24",
    title: "Children's Privacy",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          DatCARDVault is a TCG vendor business-management application. It does not intentionally request unnecessary personal information from children.
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Users should not enter another person's personal information without their permission.
        </p>
      </div>
    ),
  },
  {
    id: "25",
    title: "Third-Party Services",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-muted-foreground leading-relaxed">DatCARDVault uses the following third-party services:</p>
        <ul className="space-y-2 pl-1">
          {[
            "Hercules: Database and infrastructure services",
            "Google Fonts (Google LLC): Font delivery — your browser contacts Google's servers to load fonts; your IP address may be transmitted to Google as part of this",
          ].map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Third-party services have their own terms and privacy policies.
        </p>
      </div>
    ),
  },
  {
    id: "26",
    title: "Changes to This Privacy Policy",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-muted-foreground leading-relaxed">We may update this Privacy Policy when:</p>
        <ul className="space-y-2 pl-1">
          {[
            "New features are added",
            "The application changes",
            "New information is collected",
            "New third-party services are used",
            "Data-processing changes occur",
            "Privacy requirements change",
          ].map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
              {item}
            </li>
          ))}
        </ul>
        <p className="text-sm text-muted-foreground leading-relaxed">
          The "Last Updated" date will be updated accordingly. DatCARDVault will maintain accuracy in this policy.
        </p>
      </div>
    ),
  },
  {
    id: "27",
    title: "Contact DatCARDVault",
    content: (
      <div className="space-y-3">
        <p className="text-sm text-foreground leading-relaxed">
          <span className="font-semibold text-primary">DatCARDVault™</span>
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Country: <span className="font-semibold text-foreground">United Kingdom</span>
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Email: <span className="font-semibold text-primary">datcardvault@gmail.com</span>
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Website: <span className="font-semibold text-primary">datcardvault.com</span>
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Social Media: <a href="https://www.instagram.com/datcardvault_app" target="_blank" rel="noopener noreferrer" className="font-semibold text-primary hover:underline cursor-pointer">@datcardvault_app</a>
        </p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          <span className="font-semibold text-foreground">ICO Registration:</span> DatCARDVault is required to register with the Information Commissioner's Office (ICO) under UK data protection law. If you have questions about our registration status, contact us at datcardvault@gmail.com.
        </p>
      </div>
    ),
  },
];

export default function PrivacyPage() {
  const navigate = useNavigate();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [showBackToTop, setShowBackToTop] = useState(false);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => {
      const nearBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - 600;
      setShowBackToTop(nearBottom);
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll);
  }, []);

  const scrollToTop = () => {
    scrollRef.current?.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div ref={scrollRef} className="min-h-screen bg-background flex flex-col items-center p-4 md:p-6 pb-12 relative overflow-y-auto h-screen">
      {/* Subtle background */}
      <div className="absolute inset-0 pointer-events-none select-none overflow-hidden">
        <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at 30% 20%, rgba(204,0,0,0.08) 0%, transparent 60%), radial-gradient(ellipse at 70% 80%, rgba(204,0,0,0.05) 0%, transparent 60%)" }} />
      </div>

      <div className="relative z-10 w-full max-w-2xl">
        {/* Back button */}
        <motion.button
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </motion.button>

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="flex items-center gap-3 mb-8"
        >
          <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
            <Lock className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-black tracking-wide text-foreground">Privacy Policy</h1>
            <p className="text-xs text-muted-foreground mt-0.5">DatCARDVault · Effective: 15 August 2026</p>
          </div>
        </motion.div>

        {/* Intro card */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="rounded-2xl border border-border bg-card p-5 md:p-6 mb-4 space-y-3"
        >
          <p className="text-sm text-foreground leading-relaxed">
            This Privacy Policy explains what information <span className="font-bold text-primary">DatCARDVault</span> processes and how that information is handled.
          </p>
          <div className="rounded-xl bg-primary/5 border border-primary/20 p-3">
            <p className="text-xs text-muted-foreground leading-relaxed">
              <span className="font-bold text-foreground">Your TCG business information belongs to you. We don't sell your data.</span>
            </p>
          </div>
        </motion.div>

        {/* Sections */}
        <div className="space-y-3">
          {sections.map((section, i) => (
            <motion.div
              key={section.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.12 + i * 0.015 }}
              className="rounded-2xl border border-border bg-card p-5 md:p-6 space-y-4"
            >
              <div className="flex items-center gap-2.5">
                <span className="text-xs font-black text-primary tracking-widest tabular-nums">{section.id}</span>
                <div className="h-px flex-1 bg-border" />
                <h2 className="text-sm font-bold text-foreground">{section.title}</h2>
              </div>
              {section.content}
            </motion.div>
          ))}
        </div>

        {/* Final Agreement */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="mt-4 rounded-2xl border border-primary/30 bg-primary/5 p-5 md:p-6 space-y-3"
        >
          <p className="text-sm font-bold text-foreground leading-relaxed text-center">
            DatCARDVault™ Privacy Promise
          </p>
          <ul className="space-y-2 pl-1">
            {[
              "Your TCG business is yours",
              "We don't sell your data",
              "We don't sell your inventory",
              "We don't sell your card information",
              "We don't sell your sales information",
              "You can permanently delete your account",
              "Deleted accounts cannot be restored",
            ].map((item) => (
              <li key={item} className="flex items-start gap-2.5 text-sm text-foreground leading-relaxed">
                <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
                {item}
              </li>
            ))}
          </ul>
        </motion.div>

        {/* Footer */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="mt-6 text-center"
        >
          <p className="text-[10px] text-muted-foreground tracking-widest uppercase">
            Dat<span className="text-primary font-bold">CARD</span>Vault · Your TCG business in your pocket.
          </p>
          <p className="text-[10px] text-muted-foreground mt-1">© {new Date().getFullYear()} DatCARDVault™ All rights reserved.</p>
        </motion.div>
      </div>

      {/* Back to Top button */}
      <AnimatePresence>
        {showBackToTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 8 }}
            transition={{ duration: 0.2 }}
            onClick={scrollToTop}
            className="fixed bottom-8 right-6 z-50 flex items-center gap-2 px-4 py-2.5 rounded-full bg-primary text-primary-foreground text-xs font-black tracking-widest shadow-lg hover:bg-primary/90 transition-colors cursor-pointer"
          >
            <ArrowUp className="w-3.5 h-3.5" />
            Back to Top
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}
