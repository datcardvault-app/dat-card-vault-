import { useEffect, useRef, useState } from "react";
import { useQuery } from "convex/react";
import { motion, useMotionValue, useTransform, animate } from "motion/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Slider } from "@/components/ui/slider.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import {
  Bluetooth, BluetoothConnected, BluetoothOff, Printer,
  Settings2, ZoomIn, RotateCcw, TestTube, AlertCircle, CheckCircle2, Trash2, Square,
  ChevronLeft, ChevronDown, Minus, Plus, Sun, Moon, MoveVertical, Wifi, Monitor, Smartphone as SmartphoneIcon, Laptop,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useBtPrinterContext } from "@/hooks/use-bt-printer-context.tsx";
import { formatCurrency } from "@/lib/utils.ts";
import QRCode from "qrcode";

const PX_PER_MM = 3.7795;
const PREVIEW_SCALE = 2.8;
const RENDER_FACTOR = 0.38;

const OTHER_PRINTERS = [
  { brand: "Phomemo", models: [
    { name: "M110", ios: false }, { name: "M120", ios: false }, { name: "M200", ios: false },
    { name: "D30", ios: false }, { name: "D35", ios: false }, { name: "Q30", ios: false }, { name: "M02", ios: false },
  ]},
  { brand: "MUNBYN", models: [
    { name: "ITP01", ios: false }, { name: "ITP900", ios: false }, { name: "ITP01B", ios: false },
    { name: "ITP90", ios: false }, { name: "ITPP047", ios: false }, { name: "ITPP048", ios: false }, { name: "IMW-P001", ios: false },
  ]},
  { brand: "NIIMBOT", models: [
    { name: "B1", ios: true }, { name: "B21", ios: true }, { name: "D11", ios: true },
    { name: "D110", ios: false }, { name: "B3S", ios: false }, { name: "B18", ios: false }, { name: "D61", ios: false },
  ]},
  { brand: "Vretti", models: [
    { name: "HP3", ios: false }, { name: "HP4", ios: false }, { name: "LM-210", ios: false },
  ]},
  { brand: "Aibecy", models: [
    { name: "PRT01", ios: false }, { name: "BT-X5", ios: false }, { name: "BT-X6", ios: false },
  ]},
  { brand: "iDPRT", models: [
    { name: "SP450D", ios: false }, { name: "SP410", ios: false }, { name: "iT4B", ios: false },
  ]},
  { brand: "Polono", models: [
    { name: "PL-T403", ios: false }, { name: "PL-402", ios: false }, { name: "PL50B", ios: false },
  ]},
  { brand: "Zebra", models: [
    { name: "ZQ620", ios: false }, { name: "ZQ630", ios: false }, { name: "ZQ520", ios: false }, { name: "ZD420D", ios: false },
  ]},
  { brand: "Brother", models: [
    { name: "QL-820NWB", ios: false }, { name: "QL-810W", ios: false }, { name: "PT-P910BT", ios: false }, { name: "PT-P300BT", ios: false },
  ]},
  { brand: "Other", models: [
    { name: "DYMO LabelWriter", ios: false }, { name: "Rollo Label", ios: false },
    { name: "Bixolon SPP-R200", ios: false }, { name: "Star SM-L200", ios: false }, { name: "Generic ESC/POS BLE", ios: false },
  ]},
];

function OtherPrintersDropdown() {
  const [open, setOpen] = useState(false);
  return (
    <div>
      <button
        onClick={() => setOpen(v => !v)}
        className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-secondary border border-border cursor-pointer hover:bg-secondary/80 transition-colors"
      >
        <span className="text-[11px] font-semibold text-muted-foreground">Other Compatible Brands</span>
        <ChevronDown className={`h-3.5 w-3.5 text-muted-foreground transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div className="mt-2 space-y-3">
          {OTHER_PRINTERS.map(group => (
            <div key={group.brand}>
              <p className="text-[10px] font-bold uppercase tracking-widest mb-1 text-muted-foreground">{group.brand}</p>
              <div className="flex flex-wrap gap-1.5">
                {group.models.map(m => (
                  <span
                    key={m.name}
                    className={`text-[11px] px-2 py-1 rounded-md font-semibold border ${
                      m.ios
                        ? "bg-blue-500/15 text-blue-400 border-blue-500/30"
                        : "bg-primary/15 text-primary border-primary/30"
                    }`}
                  >
                    {m.name}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function PrinterPage() {
  const user = useQuery(api.users.getCurrentUser, {});
  const currency = user?.currency ?? "GBP";
  const navigate = useNavigate();

  const bt = useBtPrinterContext();
  const [testQr, setTestQr] = useState<string>("");

  useEffect(() => {
    QRCode.toDataURL("datcardvault://test/calibration", { width: 400, margin: 0 })
      .then(url => setTestQr(url))
      .catch(() => { /* ignore */ });
  }, []);

  const handleConnect = async () => {
    if (!bt.isAvailable) {
      toast.error("Web Bluetooth is not supported. Use Chrome on Android or desktop.");
      return;
    }
    try {
      const ok = await bt.connect();
      if (ok) toast.success(`Connected to ${bt.device?.name ?? "printer"}!`);
    } catch (e) {
      toast.error("Could not connect: " + (e as Error).message);
    }
  };

  const handleStopPrint = () => {
    bt.stopPrint();
    toast.warning("Stop signal sent — printer will halt after the current chunk.");
  };

  const handleTestPrint = async () => {
    if (!bt.connected) { toast.error("Connect a printer first"); return; }
    toast.info("Sending test print…");
    try {
      // Build a test label canvas
      const wPx = Math.round((bt.cal.widthMm / 25.4) * 203 * bt.cal.scaleX);
      const hPx = Math.round((bt.cal.heightMm / 25.4) * 203 * bt.cal.scaleY);
      const canvas = document.createElement("canvas");
      canvas.width = wPx;
      canvas.height = hPx;
      const ctx = canvas.getContext("2d")!;
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, wPx, hPx);

      // QR code
      const qrSizePx = Math.round(hPx * 0.85);
      const GAP_PX = Math.round((6 / 25.4) * 203); // 6mm gap
      const qrImg = new Image();
      await new Promise<void>((resolve, reject) => {
        qrImg.onload = () => resolve();
        qrImg.onerror = reject;
        qrImg.src = testQr;
      });
      ctx.drawImage(qrImg, 2, Math.round((hPx - qrSizePx) / 2), qrSizePx - 4, qrSizePx - 4);
      ctx.strokeStyle = "#ccc"; ctx.lineWidth = 1;
      const divX = qrSizePx + Math.round(GAP_PX / 2);
      ctx.beginPath(); ctx.moveTo(divX, 4); ctx.lineTo(divX, hPx - 4); ctx.stroke();

      const scale = hPx / 106;
      const tx = qrSizePx + GAP_PX;
      ctx.textBaseline = "top"; let y = 4;
      ctx.fillStyle = "#000"; ctx.font = `bold ${Math.round(14 * scale)}px Arial`;
      ctx.fillText("CALIBRATION TEST", tx, y); y += Math.round(14 * scale) + 3;
      ctx.fillStyle = "#cc0000"; ctx.font = `bold ${Math.round(11 * scale)}px Arial`;
      ctx.fillText("DatCardVault", tx, y); y += Math.round(11 * scale) + 3;
      ctx.fillStyle = "#333"; ctx.font = `${Math.round(9 * scale)}px Arial`;
      ctx.fillText(`${bt.cal.widthMm}×${bt.cal.heightMm}mm`, tx, y); y += Math.round(9 * scale) + 3;
      ctx.fillStyle = "#000"; ctx.font = `bold ${Math.round(9 * scale)}px Arial`;
      ctx.fillText(`Scale ${bt.cal.scaleX.toFixed(2)}×${bt.cal.scaleY.toFixed(2)}`, tx, y); y += Math.round(9 * scale) + 3;
      ctx.fillStyle = "#cc0000"; ctx.font = `900 ${Math.round(16 * scale)}px Arial`;
      ctx.fillText(formatCurrency(0, currency), tx, y);
      ctx.fillStyle = "#aaa"; ctx.font = `${Math.round(6 * scale)}px Arial`;
      ctx.fillText("DatCardVault", tx, hPx - Math.round(8 * scale));

      await bt.printLabelCanvas(canvas, 1);
      toast.success("Test print sent!");
    } catch (e) {
      toast.error("Print failed: " + (e as Error).message);
    }
  };

  const handleDisconnect = () => {
    bt.disconnect();
    toast.info("Disconnected from printer");
  };

  const [calSaved, setCalSaved] = useState(false);

  const handleSaveCal = () => {
    if (bt.cal.widthMm < 10 || bt.cal.widthMm > 200) {
      toast.error("Label Width must be between 10mm and 200mm");
      return;
    }
    if (bt.cal.heightMm < 5 || bt.cal.heightMm > 100) {
      toast.error("Label Height must be between 5mm and 100mm");
      return;
    }
    if (bt.cal.offsetXmm < -20 || bt.cal.offsetXmm > 20) {
      toast.error("Offset X must be between -20mm and +20mm");
      return;
    }
    if (bt.cal.offsetYmm < -20 || bt.cal.offsetYmm > 20) {
      toast.error("Offset Y must be between -20mm and +20mm");
      return;
    }
    if (bt.cal.scaleX < 0.5 || bt.cal.scaleX > 2) {
      toast.error("Scale X must be between 0.5× and 2×");
      return;
    }
    if (bt.cal.scaleY < 0.5 || bt.cal.scaleY > 2) {
      toast.error("Scale Y must be between 0.5× and 2×");
      return;
    }
    bt.saveCal();
    toast.success("Calibration saved!");
    setCalSaved(true);
    setTimeout(() => setCalSaved(false), 500);
  };
  const previewW = bt.cal.widthMm * PX_PER_MM * PREVIEW_SCALE * bt.cal.scaleX;
  const previewH = bt.cal.heightMm * PX_PER_MM * PREVIEW_SCALE * bt.cal.scaleY;
  const qrSizePrev = previewH * 0.85;
  const gapPrev = 6 * PX_PER_MM * PREVIEW_SCALE; // 6mm in preview px

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto space-y-5 touch-pan-y overscroll-x-none">
      <div className="flex items-center gap-3">
        <Printer className="h-7 w-7 text-primary" />
        <h1 className="text-3xl font-sans text-primary tracking-widest">Printer Hub</h1>
      </div>

      {/* Connection card */}
      <SwipeableConnectionCard
        bt={bt}
        onConnect={handleConnect}
        onTestPrint={handleTestPrint}
        onStopPrint={handleStopPrint}
        onDisconnect={handleDisconnect}
        onClearCache={() => { bt.clearCache(); toast.success("Printer cache cleared — next print will re-probe"); }}
      />

      {/* iOS notice — shown on all iOS devices regardless of Bluetooth availability */}
      {/iphone|ipad|ipod/i.test(navigator.userAgent) && (
        <div className="flex items-start gap-3 p-4 rounded-xl bg-blue-500/10 border border-blue-500/30">
          <AlertCircle className="h-5 w-5 text-blue-400 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-sm text-blue-400">Bluetooth printing not available on iPhone / iPad</p>
            <p className="text-xs text-muted-foreground mt-1">
              Apple blocks Web Bluetooth on all iOS devices — this is an Apple restriction that cannot be worked around.
              Instead, use <strong>Save Label Image</strong> on the Labels page to export your labels as high-res PNGs (up to 10 at once), then print via the MarkLife Label app.
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              For direct Bluetooth printing, use an Android phone or a desktop browser (Chrome).
            </p>
          </div>
        </div>
      )}

      {/* WiFi Printing panel */}
      <Card className="border-blue-500/30 bg-gradient-to-br from-blue-500/5 to-transparent">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Wifi className="h-4 w-4 text-blue-400" />
            <span className="text-blue-400">WiFi Printing</span>
            <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-blue-500/15 text-blue-400 border border-blue-500/30 ml-auto">All Platforms</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-xs text-muted-foreground leading-relaxed">
            Print labels over WiFi using your device&apos;s built-in print dialog. Works on <strong>Android</strong>, <strong>iOS</strong>, and <strong>desktop</strong> — no Bluetooth setup required.
          </p>

          {/* Platform icons */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <SmartphoneIcon className="h-3.5 w-3.5 text-blue-400" />
              <span className="text-[11px] font-semibold text-blue-400">Android</span>
            </div>
            <div className="flex items-center gap-1.5">
              <SmartphoneIcon className="h-3.5 w-3.5 text-blue-400" />
              <span className="text-[11px] font-semibold text-blue-400">iOS</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Laptop className="h-3.5 w-3.5 text-blue-400" />
              <span className="text-[11px] font-semibold text-blue-400">Desktop</span>
            </div>
          </div>

          {/* How it works */}
          <div className="space-y-2">
            <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">How It Works</p>
            <div className="space-y-2">
              {[
                "Go to the Labels page and select the labels you want to print",
                "Tap the blue WiFi button (or batch \"WiFi\" button in the header)",
                "Confirm in the WiFi Print dialog — a print-ready popup will open",
                "Select your WiFi printer from your device's native print dialog",
              ].map((step, i) => (
                <div key={i} className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-blue-500/20 text-blue-400 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">{i + 1}</span>
                  <p className="text-xs text-muted-foreground">{step}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Tips */}
          <div className="rounded-lg bg-blue-500/10 border border-blue-500/20 p-3 space-y-1.5">
            <p className="text-[10px] font-bold uppercase tracking-widest text-blue-400">Tips for Best Results</p>
            <ul className="text-xs text-muted-foreground space-y-1 list-disc list-inside">
              <li>Set margins to <span className="font-semibold text-foreground">None</span> in the print dialog</li>
              <li>Set scale to <span className="font-semibold text-foreground">100%</span></li>
              <li>Make sure your printer is on the <span className="font-semibold text-foreground">same WiFi network</span> as your device</li>
              <li>Up to <span className="font-semibold text-foreground">20 labels</span> can be printed at once</li>
            </ul>
          </div>

          {/* CTA button */}
          <Button
            onClick={() => navigate("/labels")}
            className="w-full gap-2 bg-blue-500 hover:bg-blue-600 text-white"
          >
            <Wifi className="h-4 w-4" /> Go to Labels Page
          </Button>
        </CardContent>
      </Card>

      {/* Pro tip — always visible */}
      <div className="flex items-start gap-3 p-4 rounded-xl bg-primary/5 border border-primary/20">
        <span className="text-base shrink-0 mt-0.5">💡</span>
        <div>
          <p className="font-semibold text-sm text-primary">Pro Tip — iOS Printing</p>
          <p className="text-xs text-muted-foreground mt-1">
            Web Bluetooth isn&apos;t available on iOS (Apple blocks it), but you have two great alternatives:
          </p>
          <ul className="text-xs text-muted-foreground mt-2 space-y-1.5 list-disc list-inside">
            <li><strong className="text-blue-400">WiFi Print</strong> — tap the blue WiFi button on the Labels page to print directly to any WiFi printer on your network. Works natively on iPhone &amp; iPad.</li>
            <li><strong className="text-foreground">Save Label Image</strong> — exports your labels as high-res PNGs you can print via the <strong>MarkLife Label</strong> app.</li>
          </ul>
          <p className="text-xs text-muted-foreground mt-2">
            For direct Bluetooth printing, use Android or Chrome on desktop.
          </p>
        </div>
      </div>

      {!bt.isAvailable && !/iphone|ipad|ipod/i.test(navigator.userAgent) && (
        <div className="flex items-start gap-3 p-4 rounded-xl bg-amber-500/10 border border-amber-700/30">
          <AlertCircle className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-sm text-amber-500">Web Bluetooth not available</p>
            <p className="text-xs text-muted-foreground mt-1">
              Use Google Chrome on Android or desktop to connect Bluetooth printers.
              Safari and Firefox do not support Web Bluetooth.
            </p>
          </div>
        </div>
      )}

      {/* Compatible printers */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-primary" /> Compatible Thermal Printers
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-xs text-muted-foreground mb-3">50+ Bluetooth thermal label printers supported via BLE auto-detection. Highlighted models are verified with DatCARDVault.</p>

          {/* Legend */}
          <div className="flex items-center gap-3 mb-3 px-1">
            <div className="flex items-center gap-1.5">
              <span className="inline-block w-3 h-3 rounded-sm bg-primary/20 border border-primary/40" />
              <span className="text-[10px] font-semibold text-primary">Android &amp; Desktop</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="inline-block w-3 h-3 rounded-sm bg-blue-500/15 border border-blue-500/30" />
              <span className="text-[10px] font-semibold text-blue-400">iOS Compatible*</span>
            </div>
          </div>

          {/* MarkLife — always shown */}
          <div className="mb-3">
            <p className="text-[10px] font-bold uppercase tracking-widest mb-1 text-primary">MarkLife</p>
            <div className="flex flex-wrap gap-1.5">
              {["D100 ✓", "P50S ✓", "X2 ✓", "P50", "P11", "P12", "P15", "Z401"].map(m => (
                <span key={m} className="text-[11px] px-2 py-1 rounded-md bg-primary/20 text-primary font-semibold border border-primary/30">{m}</span>
              ))}
            </div>
          </div>

          {/* Other brands — collapsible */}
          <OtherPrintersDropdown />
          <p className="text-xs text-muted-foreground mt-2 pt-2 border-t border-border">
            Any ESC/POS-compatible Bluetooth thermal printer should work. If yours isn&apos;t listed, try connecting — it may still be compatible.
          </p>
          <p className="text-[10px] text-blue-400/80 mt-1">* iOS: Web Bluetooth isn't available — use Save Label Image on the Labels page and print via the MarkLife app.</p>
        </CardContent>
      </Card>

      {/* Calibration */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm flex items-center gap-2">
              <Settings2 className="h-4 w-4 text-primary" /> Label Calibration
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" onClick={() => { bt.resetCal(); toast.success("Reset to defaults"); }} className="gap-1 text-xs">
                <RotateCcw className="h-3 w-3" /> Reset
              </Button>
              <Button size="sm" onClick={handleSaveCal} className={`gap-1 text-xs transition-colors ${calSaved ? "bg-profit hover:bg-profit text-white" : ""}`}>
                <CheckCircle2 className="h-3 w-3" /> Save
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-5">

          {/* ── Preset sizes ─────────────────────────────────── */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Quick Presets</p>
            <div className="flex flex-wrap gap-1.5">
              {([
                { label: "50×30mm", w: 50, h: 30 },
                { label: "50×40mm", w: 50, h: 40 },
                { label: "52×32mm", w: 52, h: 32 },
                { label: "57×33mm", w: 57, h: 33 },
                { label: "62×29mm", w: 62, h: 29 },
              ] satisfies { label: string; w: number; h: number }[]).map(p => {
                const active = bt.cal.widthMm === p.w && bt.cal.heightMm === p.h;
                return (
                  <button
                    key={p.label}
                    onClick={() => { bt.updateCal("widthMm", p.w); bt.updateCal("heightMm", p.h); }}
                    className={`text-[11px] font-semibold px-2.5 py-1 rounded-lg border transition-colors cursor-pointer ${active ? "bg-primary text-primary-foreground border-primary" : "bg-secondary text-muted-foreground border-border hover:border-primary/40 hover:text-foreground"}`}
                  >
                    {p.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* ── Size + offset + scale ─────────────────────────── */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Size &amp; Alignment</p>
            <p className="text-xs text-muted-foreground">
              <strong>Offset X:</strong> positive = shift right &nbsp;|&nbsp; negative = shift left<br />
              <strong>Offset Y:</strong> positive = shift down &nbsp;|&nbsp; negative = shift up
            </p>
            <div className="grid grid-cols-2 gap-3">
              <CalInput label="Label Width (mm)" value={bt.cal.widthMm} min={10} max={200} step={0.5} onChange={v => bt.updateCal("widthMm", v)} />
              <CalInput label="Label Height (mm)" value={bt.cal.heightMm} min={5} max={100} step={0.5} onChange={v => bt.updateCal("heightMm", v)} />
              <CalInput label="Offset X (mm)" value={bt.cal.offsetXmm} min={-20} max={20} step={0.1} onChange={v => bt.updateCal("offsetXmm", v)} />
              <CalInput label="Offset Y (mm)" value={bt.cal.offsetYmm} min={-20} max={20} step={0.1} onChange={v => bt.updateCal("offsetYmm", v)} />
              <CalInput label="Scale X" value={bt.cal.scaleX} min={0.5} max={2} step={0.01} onChange={v => bt.updateCal("scaleX", v)} />
              <CalInput label="Scale Y" value={bt.cal.scaleY} min={0.5} max={2} step={0.01} onChange={v => bt.updateCal("scaleY", v)} />
            </div>
          </div>

          {/* ── Print darkness ────────────────────────────────── */}
          <div className="rounded-xl border border-border bg-secondary/30 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-background border border-border flex items-center justify-center">
                  <Sun className="w-3.5 h-3.5 text-amber-500" />
                </div>
                <p className="text-xs font-bold text-foreground">Print Darkness</p>
              </div>
              <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-background border border-border text-foreground">
                {bt.cal.darkness < 90 ? "Very Dark" : bt.cal.darkness < 118 ? "Dark" : bt.cal.darkness < 138 ? "Normal" : bt.cal.darkness < 180 ? "Light" : "Very Light"}
              </span>
            </div>
            <div className="flex items-center gap-3">
              <Sun className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
              <Slider
                min={40} max={220} step={1}
                value={[260 - bt.cal.darkness]}
                onValueChange={([v]) => bt.updateCal("darkness", 260 - v)}
                className="flex-1"
              />
              <Moon className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">Adjust if text prints too faint or blobs together. Each printer and label roll is different.</p>
          </div>

          {/* ── Feed lines ────────────────────────────────────── */}
          <div className="rounded-xl border border-border bg-secondary/30 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-background border border-border flex items-center justify-center">
                  <MoveVertical className="w-3.5 h-3.5 text-blue-400" />
                </div>
                <p className="text-xs font-bold text-foreground">Feed After Print</p>
              </div>
              <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-background border border-border text-foreground">
                {bt.cal.feedLines} line{bt.cal.feedLines !== 1 ? "s" : ""}
              </span>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => bt.updateCal("feedLines", Math.max(0, bt.cal.feedLines - 1))}
                className="w-8 h-8 rounded-lg bg-background border border-border flex items-center justify-center hover:bg-secondary cursor-pointer transition-colors"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <Slider
                min={0} max={10} step={1}
                value={[bt.cal.feedLines]}
                onValueChange={([v]) => bt.updateCal("feedLines", v)}
                className="flex-1"
              />
              <button
                onClick={() => bt.updateCal("feedLines", Math.min(10, bt.cal.feedLines + 1))}
                className="w-8 h-8 rounded-lg bg-background border border-border flex items-center justify-center hover:bg-secondary cursor-pointer transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">Increase if labels get cut off. Decrease if there&apos;s too much blank space between labels.</p>
          </div>

          {/* ── Cut-guide border toggle ─────────────────────────── */}
          <div className="rounded-xl border border-border bg-secondary/30 p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-background border border-border flex items-center justify-center">
                  <Square className="w-3.5 h-3.5 text-muted-foreground" style={{ strokeDasharray: "3 2" }} />
                </div>
                <div>
                  <p className="text-xs font-bold text-foreground">Cut-Guide Border</p>
                  <p className="text-[10px] text-muted-foreground">Dotted rectangle around label edge</p>
                </div>
              </div>
              <Switch
                checked={bt.cal.showBorder !== false}
                onCheckedChange={(v) => bt.updateCal("showBorder", v)}
              />
            </div>
          </div>

        </CardContent>
      </Card>

      {/* Live preview */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <ZoomIn className="h-4 w-4 text-primary" /> Print Preview
          </CardTitle>
          <p className="text-[11px] text-muted-foreground mt-1">
            The red dashed outline shows where the label will print. Adjust scale and offset until it aligns with your media.
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Preview canvas */}
          <div className="rounded-xl border border-border bg-gradient-to-b from-muted/50 to-muted p-5 flex flex-col items-center gap-3">
            {/* Size badge */}
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-muted-foreground px-2 py-0.5 rounded-md bg-background border border-border">
                {bt.cal.widthMm}mm × {bt.cal.heightMm}mm
              </span>
            </div>
            {/* Label mockup */}
            <div className="relative bg-white rounded-lg shadow-md flex-shrink-0 border border-gray-200"
              style={{ width: `${(bt.cal.widthMm + 20) * PX_PER_MM * PREVIEW_SCALE * RENDER_FACTOR}px`, height: `${(bt.cal.heightMm + 16) * PX_PER_MM * PREVIEW_SCALE * RENDER_FACTOR}px` }}>
              {/* Label at offset */}
              <div style={{
                position: "absolute",
                left: `${10 * PX_PER_MM * PREVIEW_SCALE * RENDER_FACTOR + bt.cal.offsetXmm * PX_PER_MM * PREVIEW_SCALE * RENDER_FACTOR}px`,
                top: `${8 * PX_PER_MM * PREVIEW_SCALE * RENDER_FACTOR + bt.cal.offsetYmm * PX_PER_MM * PREVIEW_SCALE * RENDER_FACTOR}px`,
                width: `${previewW * RENDER_FACTOR}px`,
                height: `${previewH * RENDER_FACTOR}px`,
                border: bt.cal.showBorder !== false ? "2px dashed #cc0000" : "2px solid transparent",
                borderRadius: "4px",
                overflow: "hidden",
                display: "flex",
                backgroundColor: "#fff",
              }}>
                {/* QR */}
                <div style={{ width: `${qrSizePrev * RENDER_FACTOR}px`, backgroundColor: "#fafafa", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  {testQr && <img src={testQr} alt="QR" style={{ width: `${(qrSizePrev - 6) * RENDER_FACTOR}px`, height: `${(qrSizePrev - 6) * RENDER_FACTOR}px` }} />}
                </div>
                {/* 6mm gap with centre divider */}
                <div style={{ width: `${gapPrev * RENDER_FACTOR}px`, position: "relative", flexShrink: 0 }}>
                  <div style={{ position: "absolute", left: "50%", top: 4, bottom: 4, width: "0.5px", backgroundColor: "#eee" }} />
                </div>
                {/* Text */}
                <div style={{ flex: 1, padding: "2px 3px", display: "flex", flexDirection: "column", justifyContent: "space-around" }}>
                  <div style={{ fontWeight: 900, fontSize: `${5.5 * PREVIEW_SCALE * RENDER_FACTOR * bt.cal.scaleX}px`, color: "#000", fontFamily: "Arial", lineHeight: 1.2 }}>Charizard</div>
                  <div style={{ fontWeight: 700, fontSize: `${4.5 * PREVIEW_SCALE * RENDER_FACTOR * bt.cal.scaleX}px`, color: "#cc0000", fontFamily: "Arial" }}>Pokémon</div>
                  <div style={{ fontWeight: 600, fontSize: `${4 * PREVIEW_SCALE * RENDER_FACTOR * bt.cal.scaleX}px`, color: "#333", fontFamily: "Arial" }}>Base Set #4/102</div>
                  <div style={{ fontWeight: 700, fontSize: `${4 * PREVIEW_SCALE * RENDER_FACTOR * bt.cal.scaleX}px`, color: "#000", fontFamily: "Arial" }}>Near Mint · PSA 9</div>
                  <div style={{ fontWeight: 900, fontSize: `${6.5 * PREVIEW_SCALE * RENDER_FACTOR * bt.cal.scaleX}px`, color: "#cc0000", fontFamily: "Arial" }}>{formatCurrency(450, currency)}</div>
                  <div style={{ fontWeight: 500, fontSize: `${3 * PREVIEW_SCALE * RENDER_FACTOR * bt.cal.scaleX}px`, color: "#888", fontFamily: "Arial" }}>DatCardVault</div>
                </div>
              </div>
            </div>
          </div>

          {/* Cal values summary */}
          <div className="grid grid-cols-3 gap-2">
            {[
              ["Offset X", `${bt.cal.offsetXmm > 0 ? "+" : ""}${bt.cal.offsetXmm}mm`],
              ["Offset Y", `${bt.cal.offsetYmm > 0 ? "+" : ""}${bt.cal.offsetYmm}mm`],
              ["Scale X", `${bt.cal.scaleX.toFixed(2)}×`],
              ["Scale Y", `${bt.cal.scaleY.toFixed(2)}×`],
              ["Darkness", bt.cal.darkness < 90 ? "Very Dark" : bt.cal.darkness < 118 ? "Dark" : bt.cal.darkness < 138 ? "Normal" : bt.cal.darkness < 180 ? "Light" : "Very Light"],
              ["Feed", `${bt.cal.feedLines} lines`],
              ["Border", bt.cal.showBorder !== false ? "On" : "Off"],
            ].map(([k, v]) => (
              <div key={k} className="rounded-lg border border-border bg-secondary/30 p-2 text-center">
                <p className="text-[9px] text-muted-foreground uppercase tracking-widest font-bold">{k}</p>
                <p className="text-xs font-semibold text-foreground mt-0.5">{v}</p>
              </div>
            ))}
          </div>

          {bt.connected && (
            <Button className="w-full gap-2" onClick={handleTestPrint}>
              <TestTube className="h-4 w-4" /> Send Calibration Test Print
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Setup instructions */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Setup Instructions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {[
            "Turn on your Bluetooth thermal label printer and load your label roll (supported sizes: 50×30mm, 50×40mm, 52×32mm, 57×33mm, or 62×29mm)",
            "Enable Bluetooth on your device and make sure location permission is granted (required for Web Bluetooth)",
            "Tap 'Connect Printer' above and select your printer from the list",
            "In Label Calibration, tap the Quick Preset that matches your loaded roll",
            "Adjust Offset X/Y and Scale X/Y if the print is slightly off-centre",
            "Set Print Darkness — slide right for darker print, left for lighter",
            "Tap Save to store your calibration settings",
            "Tap 'Test Print' to verify alignment before printing real labels",
            "Go to the Labels page and tap the print icon on any label to send it to the printer",
          ].map((step, i) => (
            <div key={i} className="flex items-start gap-3">
              <span className="w-5 h-5 rounded-full bg-primary/20 text-primary text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">{i + 1}</span>
              <p className="text-sm">{step}</p>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

// ── Swipeable connection card ─────────────────────────────────────────────
type BtCtx = ReturnType<typeof useBtPrinterContext>;

function SwipeableConnectionCard({
  bt, onConnect, onTestPrint, onStopPrint, onDisconnect, onClearCache,
}: {
  bt: BtCtx;
  onConnect: () => void;
  onTestPrint: () => void;
  onStopPrint: () => void;
  onDisconnect: () => void;
  onClearCache: () => void;
}) {
  const ACTIONS_WIDTH = 220; // px — revealed on swipe-left
  const x = useMotionValue(0);
  const dragStartX = useRef(0);
  const isOpen = useRef(false);

  // Reset when connection state changes
  useEffect(() => {
    void animate(x, 0, { type: "spring", stiffness: 400, damping: 35 });
    isOpen.current = false;
  }, [bt.connected, x]);

  const cardOpacity = useTransform(x, [-ACTIONS_WIDTH, 0], [0.92, 1]);

  const snapTo = (target: number) => {
    isOpen.current = target !== 0;
    void animate(x, target, { type: "spring", stiffness: 400, damping: 35 });
  };

  const handleDragEnd = () => {
    const cur = x.get();
    if (cur < -ACTIONS_WIDTH / 2) snapTo(-ACTIONS_WIDTH);
    else snapTo(0);
  };

  return (
    <div className={`relative rounded-2xl overflow-hidden border-2 transition-colors ${bt.connected ? "border-profit/40" : "border-border"}`}>
      {/* Action drawer (behind the card, revealed on left-swipe) */}
      {bt.connected && (
        <div
          className="absolute right-0 top-0 bottom-0 flex items-stretch bg-secondary"
          style={{ width: ACTIONS_WIDTH }}
        >
          <button
            onClick={() => { snapTo(0); onTestPrint(); }}
            className="flex-1 flex flex-col items-center justify-center gap-1 px-1 hover:bg-primary/10 transition-colors cursor-pointer border-r border-border"
          >
            <TestTube className="h-4 w-4 text-primary" />
            <span className="text-[9px] font-black tracking-wide text-primary uppercase">Test</span>
          </button>
          <button
            onClick={() => { snapTo(0); onStopPrint(); }}
            className="flex-1 flex flex-col items-center justify-center gap-1 px-1 hover:bg-destructive/10 transition-colors cursor-pointer border-r border-border"
          >
            <Square className="h-4 w-4 text-destructive fill-destructive/30" />
            <span className="text-[9px] font-black tracking-wide text-destructive uppercase">Stop</span>
          </button>
          <button
            onClick={() => { snapTo(0); onClearCache(); }}
            className="flex-1 flex flex-col items-center justify-center gap-1 px-1 hover:bg-amber-600/10 transition-colors cursor-pointer border-r border-border"
          >
            <Trash2 className="h-4 w-4 text-amber-500" />
            <span className="text-[9px] font-black tracking-wide text-amber-500 uppercase">Cache</span>
          </button>
          <button
            onClick={() => { snapTo(0); onDisconnect(); }}
            className="flex-1 flex flex-col items-center justify-center gap-1 px-1 hover:bg-secondary/80 transition-colors cursor-pointer"
          >
            <BluetoothOff className="h-4 w-4 text-muted-foreground" />
            <span className="text-[9px] font-black tracking-wide text-muted-foreground uppercase">Off</span>
          </button>
        </div>
      )}

      {/* Draggable card face */}
      <motion.div
        drag={bt.connected ? "x" : false}
        dragConstraints={{ left: -ACTIONS_WIDTH, right: 0 }}
        dragElastic={0.05}
        style={{ x, opacity: cardOpacity }}
        onDragStart={() => { dragStartX.current = x.get(); }}
        onDragEnd={handleDragEnd}
        className={`relative bg-card cursor-grab active:cursor-grabbing touch-pan-y ${bt.connected ? "" : ""}`}
      >
        <div className="p-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className={`p-2 rounded-full shrink-0 ${bt.connected ? "bg-profit/20" : "bg-secondary"}`}>
              {bt.connected
                ? <BluetoothConnected className="h-5 w-5 text-profit" />
                : <BluetoothOff className="h-5 w-5 text-muted-foreground" />}
            </div>
            <div className="min-w-0">
              <p className="font-semibold text-sm truncate">
                {bt.connected ? bt.device?.name ?? "Connected Printer" : "No Printer Connected"}
              </p>
              <p className="text-xs text-muted-foreground">
                {bt.connected ? "Ready to print" : "Pair a Bluetooth thermal label printer"}
              </p>
            </div>
          </div>

          {bt.connected ? (
            /* Swipe hint */
            <motion.div
              animate={{ x: [0, -4, 0] }}
              transition={{ repeat: Infinity, duration: 1.6, ease: "easeInOut" }}
              className="shrink-0 flex items-center gap-1 text-muted-foreground/50"
            >
              <span className="text-[10px] font-medium tracking-wide select-none">Swipe left for options</span>
              <ChevronLeft className="h-5 w-5" />
            </motion.div>
          ) : (
            <Button onClick={onConnect} disabled={bt.connecting} size="sm" className="gap-2 shrink-0">
              <Bluetooth className="h-4 w-4" />
              {bt.connecting ? "Connecting…" : "Connect"}
            </Button>
          )}
        </div>
      </motion.div>
    </div>
  );
}

function CalInput({ label, value, min, max, step, onChange }: {
  label: string; value: number; min: number; max: number; step: number;
  onChange: (v: number) => void;
}) {
  const [raw, setRaw] = useState(String(value));

  // Sync if parent value changes externally (e.g. reset)
  useEffect(() => { setRaw(String(value)); }, [value]);

  return (
    <div className="space-y-1">
      <Label className="text-xs">{label}</Label>
      <Input type="number" min={min} max={max} step={step} value={raw}
        onFocus={e => e.target.select()}
        onChange={e => {
          setRaw(e.target.value);
          const n = parseFloat(e.target.value);
          if (!isNaN(n)) onChange(n);
        }}
        onBlur={() => {
          // Restore valid display value on blur if field left empty/invalid
          const n = parseFloat(raw);
          if (isNaN(n)) setRaw(String(value));
        }}
        className="h-8 text-sm" />
    </div>
  );
}
