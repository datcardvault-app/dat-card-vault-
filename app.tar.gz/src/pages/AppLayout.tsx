import { Outlet, useLocation, useNavigate } from "react-router-dom";
import { useConvexAuth, useQuery } from "convex/react";
import { AnimatePresence, motion } from "motion/react";
import {
  LayoutDashboard, Package, Tag, ScanLine, Settings, BookOpen,
  ChevronRight, Printer, TrendingUp, X, Menu, LogOut, Ban, Coffee, MessageSquare, ShieldCheck,
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { cn } from "@/lib/utils.ts";
import LoginPage from "./Login.tsx";
import { useAppTheme } from "@/hooks/use-app-theme.ts";
import { useState, useEffect, useRef } from "react";
import TeamPresenceBar from "@/components/team-presence-bar.tsx";
import NudgeAlert from "@/components/nudge-alert.tsx";
import { useAuth } from "@/hooks/use-auth.ts";
import { api } from "@/convex/_generated/api.js";
import FirstRunWelcome from "@/components/first-run-welcome.tsx";

const NAV_ITEMS = [
  { path: "/", label: "Dashboard", icon: LayoutDashboard },
  { path: "/inventory", label: "Inventory", icon: Package },
  { path: "/labels", label: "Labels", icon: Tag },
  { path: "/scan", label: "Scan", icon: ScanLine },
  { path: "/earnings", label: "Earnings", icon: TrendingUp },
];

const SIDEBAR_EXTRA = [
  { path: "/settings", label: "Settings", icon: Settings },
  { path: "/how-to", label: "Vault Guide", icon: BookOpen },
  { path: "/printer", label: "Printer Hub", icon: Printer },
];

/** Remember auth state so returning to the app doesn't flash login/skeleton */
const AUTH_SESSION_KEY = "dcv_auth_session";

/** Read the session flag once — avoids repeated localStorage access on every render */
function getHadSession(): boolean {
  try { return localStorage.getItem(AUTH_SESSION_KEY) === "1"; } catch { return false; }
}

export default function AppLayout() {
  useAppTheme();
  const { isAuthenticated, isLoading } = useConvexAuth();

  // "Sticky auth" — once the user has been authenticated, keep the layout mounted
  // even during brief re-auth loading states (e.g. tabbing back into the app)
  const wasEverAuthenticated = useRef(false);
  if (isAuthenticated) wasEverAuthenticated.current = true;
  // Reset on explicit sign-out (not authenticated AND not loading)
  if (!isAuthenticated && !isLoading) wasEverAuthenticated.current = false;

  const hadSession = getHadSession();

  // Determine what to show:
  // 1. If currently authenticated (or was authenticated and currently re-checking) → show app
  // 2. If loading and never authenticated → show skeleton (unless hadSession → show nothing)
  // 3. If not authenticated and not loading → show login (with grace period if hadSession)
  const showApp = isAuthenticated || (wasEverAuthenticated.current && isLoading);
  const showSkeleton = isLoading && !wasEverAuthenticated.current && !hadSession;
  const showUnauthenticated = !isAuthenticated && !isLoading && !wasEverAuthenticated.current;

  return (
    <>
      {showSkeleton && (
        <div className="min-h-screen flex items-center justify-center bg-background">
          <div className="text-center space-y-4">
            <Skeleton className="h-12 w-48 mx-auto" />
            <Skeleton className="h-4 w-32 mx-auto" />
          </div>
        </div>
      )}

      {showUnauthenticated && <UnauthenticatedGate />}

      {showApp && (
        <>
          <AuthSessionMarker />
          <AuthenticatedLayout />
        </>
      )}

      {/* Global nudge alert — visible to anyone in a team */}
      <NudgeAlert />
    </>
  );
}

/** Marks localStorage so future app resumes don't flash */
function AuthSessionMarker() {
  useEffect(() => {
    try { localStorage.setItem(AUTH_SESSION_KEY, "1"); } catch { /* ignore */ }
  }, []);
  return null;
}

/** Only show login after a short grace period to avoid a flash on resume */
function UnauthenticatedGate() {
  const [showLogin, setShowLogin] = useState(false);
  const hadSession = getHadSession();

  useEffect(() => {
    if (!hadSession) {
      // Never logged in — show login immediately
      setShowLogin(true);
      return;
    }
    // Had a session — wait a moment before showing login (covers brief re-auth)
    const timer = setTimeout(() => {
      // Clear the session flag since we're genuinely logged out now
      try { localStorage.removeItem(AUTH_SESSION_KEY); } catch { /* ignore */ }
      setShowLogin(true);
    }, 1500);
    return () => clearTimeout(timer);
  }, [hadSession]);

  if (!showLogin) return null;
  return <LoginPage />;
}

function AuthenticatedLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const { signout } = useAuth();
  const [moreOpen, setMoreOpen] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Scroll to top on route change
  useEffect(() => {
    scrollRef.current?.scrollTo(0, 0);
  }, [location.pathname]);
  const currentUser = useQuery(api.users.getCurrentUser, {});
  const suspended = currentUser?.suspended === true;
  // Keep overlay visible during signout so the dashboard doesn't flash
  const wasSuspended = useRef(false);
  if (suspended) wasSuspended.current = true;
  const showSuspendedOverlay = suspended || (wasSuspended.current && currentUser === undefined);

  // First-run onboarding: show only when user exists and hasn't completed onboarding
  const [welcomeDismissed, setWelcomeDismissed] = useState(false);
  const showWelcome =
    !welcomeDismissed &&
    currentUser !== undefined &&
    currentUser !== null &&
    currentUser.onboardingComplete !== true;

  const isActive = (path: string) => {
    if (path === "/") return location.pathname === "/";
    return location.pathname.startsWith(path);
  };

  return (
    <>
      <div className="flex h-screen overflow-hidden bg-background">
        {/* Desktop Sidebar */}
        <aside className="hidden md:flex md:w-60 flex-col bg-sidebar border-r border-sidebar-border shrink-0">
          {/* Logo */}
          <div className="px-4 py-5 border-b border-sidebar-border">
            <div className="flex items-center gap-3">
              <div className="relative shrink-0">
                <img src="https://hercules-cdn.com/file_3dzmLjTtZEhTAwTQYzz2XFce" alt="DatCardVault" className="h-12 w-12 object-contain" style={{ filter: "brightness(1.45) saturate(1.2)" }} />
                <span className="absolute -top-0.5 -right-0.5 text-[8px] font-bold text-white/70 leading-none">™</span>
              </div>
              <div className="flex flex-col min-w-0" style={{ gap: 4 }}>
                <span className="font-sans font-black tracking-[0.1em] leading-none block" style={{ fontSize: 16 }}>Dat<span className="text-primary">CARD</span>Vault<sup className="text-[8px] align-super">™</sup></span>
                <p className="font-black tracking-[0.18em] text-muted-foreground uppercase leading-none" style={{ fontSize: 9 }}>Scan &bull; Store &bull; Label</p>
              </div>
            </div>
          </div>

          {/* Nav */}
          <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
            {NAV_ITEMS.map(({ path, label, icon: Icon }) => (
              <button
                key={path}
                onClick={() => navigate(path)}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer",
                  isActive(path)
                    ? "bg-primary text-primary-foreground"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                )}
              >
                <Icon className="h-4 w-4 shrink-0" />
                {label}
                {isActive(path) && <ChevronRight className="h-3 w-3 ml-auto" />}
              </button>
            ))}

            <div className="pt-4 pb-1">
              <p className="px-3 text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-1">More</p>
            </div>

            {SIDEBAR_EXTRA.map(({ path, label, icon: Icon }) => (
              <button
                key={path}
                onClick={() => navigate(path)}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer",
                  isActive(path)
                    ? "bg-primary text-primary-foreground"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                )}
              >
                <Icon className="h-4 w-4 shrink-0" />
                {label}
                {isActive(path) && <ChevronRight className="h-3 w-3 ml-auto" />}
              </button>
            ))}
          </nav>

          {/* Feedback — desktop sidebar only */}
          <div className="hidden md:block px-3 pb-0.5">
            <button
              onClick={() => navigate("/feedback")}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer",
                isActive("/feedback")
                  ? "bg-primary text-primary-foreground"
                  : "text-profit hover:bg-profit/10 hover:text-profit"
              )}
            >
              <MessageSquare className="h-4 w-4 shrink-0" />
              Feedback
              {isActive("/feedback") && <ChevronRight className="h-3 w-3 ml-auto" />}
            </button>
          </div>

          {/* Support Us */}
          <div className="px-3 pb-0.5">
            <button
              onClick={() => navigate("/support")}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer",
                isActive("/support")
                  ? "bg-primary text-primary-foreground"
                  : "hover:bg-[#e8b931]/10 hover:text-[#d4a306]"
              )}
              style={!isActive("/support") ? { color: "#d4a306" } : undefined}
            >
              <Coffee className="h-4 w-4 shrink-0" />
              Support Us ☕
              {isActive("/support") && <ChevronRight className="h-3 w-3 ml-auto" />}
            </button>
          </div>

          {/* Sign out */}
          <div className="px-3 pb-2">
            <button
              onClick={() => void signout()}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors cursor-pointer"
            >
              <LogOut className="h-4 w-4 shrink-0" />
              Sign Out
            </button>
          </div>

          {/* DatCARDVault branding footer */}
          <div className="px-3 pb-4 pt-3 border-t border-sidebar-border flex flex-col items-center">
            <div className="bg-muted/50 rounded-xl px-6 py-3 flex flex-col items-center gap-1.5">
              <div className="flex items-center gap-1">
                <ShieldCheck className="h-3.5 w-3.5 text-profit" />
                <span className="text-[9px] font-semibold text-profit">Secure & Protected</span>
              </div>
              <span className="text-[8px] text-muted-foreground/50">&copy; 2026 Dat<span className="text-primary/60">CARD</span>Vault&trade;</span>
            </div>
          </div>
        </aside>

        {/* Main content */}
        <main className="flex-1 flex flex-col overflow-hidden">
          {/* Mobile header */}
          <header className="md:hidden flex items-center justify-between px-4 bg-sidebar border-b border-sidebar-border shrink-0" style={{ height: 56 }}>
            <div className="w-8" />
            <div className="flex flex-col items-center justify-center" style={{ gap: 3 }}>
              <div className="flex items-center gap-1.5">
                <div className="relative shrink-0">
                  <img src="https://hercules-cdn.com/file_3dzmLjTtZEhTAwTQYzz2XFce" alt="DatCardVault" className="h-7 w-7 object-contain" style={{ filter: "brightness(1.45) saturate(1.2)" }} />
                  <span className="absolute -top-0.5 -right-1 text-[8px] font-bold text-white/70 leading-none">™</span>
                </div>
                <span className="font-sans font-black leading-none tracking-[0.1em]" style={{ fontSize: 15 }}>Dat<span className="text-primary">CARD</span>Vault<sup className="text-[8px] align-super">™</sup></span>
              </div>
              <p className="font-black uppercase leading-none tracking-[0.22em] text-muted-foreground text-center w-full pl-[0.22em]" style={{ fontSize: 9 }}>Scan &bull; Store &bull; Label</p>
            </div>
            <button
              onClick={() => setMoreOpen(v => !v)}
              className="w-8 h-8 flex items-center justify-center rounded-lg text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
              aria-label="Menu"
            >
              {moreOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </header>

          <div ref={scrollRef} className="flex-1 overflow-y-auto overflow-x-hidden pb-[calc(6rem+env(safe-area-inset-bottom))] md:pb-0 overscroll-x-none">
            {/* Team presence bar — shown at top when in a team */}
            <TeamPresenceBar />
            <Outlet />
            {/* Global footer — hidden on Vault Guide */}
            {location.pathname !== "/how-to" && (
              <div className="px-4 py-4 mt-2 flex items-center justify-center">
                <p className="text-[10px] text-muted-foreground/50 tracking-widest text-center select-none">
                  © {new Date().getFullYear()} Dat<span className="text-primary/60 font-bold">CARD</span>Vault™ All rights reserved.
                </p>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Mobile Bottom Nav — perfectly symmetric: 2 | FAB | 2 */}
      <nav className="fixed bottom-0 left-0 right-0 md:hidden bg-sidebar border-t border-sidebar-border z-50" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
        <div className="flex items-stretch" style={{ height: 64 }}>
          {[
            { path: "/", label: "Dashboard", icon: LayoutDashboard },
            { path: "/inventory", label: "Inventory", icon: Package },
          ].map(item => (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={cn(
                "flex-1 flex flex-col items-center justify-center gap-0.5 transition-colors cursor-pointer",
                isActive(item.path) ? "text-primary" : "text-muted-foreground"
              )}
            >
              <item.icon className="h-5 w-5" />
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          ))}

          {/* FAB — dead centre */}
          <div className="relative flex items-end justify-center pb-1" style={{ width: 80 }}>
            <button
              onClick={() => navigate("/scan")}
              aria-label="Scan"
              className="cursor-pointer active:scale-95 transition-transform absolute bottom-2 left-1/2 -translate-x-1/2"
            >
              <div className={cn(
                "w-20 h-20 rounded-full flex flex-col items-center justify-center gap-0.5",
                "bg-primary shadow-[0_0_32px_8px_rgba(204,0,0,0.6)]",
                "border-4 border-sidebar",
                "-translate-y-3"
              )}>
                <ScanLine className="h-6 w-6 text-white" />
                <span className="text-[9px] font-black tracking-widest text-white leading-none">SCAN</span>
              </div>
            </button>
          </div>

          {[
            { path: "/labels", label: "Labels", icon: Tag },
            { path: "/earnings", label: "Earnings", icon: TrendingUp },
          ].map(item => (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={cn(
                "flex-1 flex flex-col items-center justify-center gap-0.5 transition-colors cursor-pointer",
                isActive(item.path) ? "text-primary" : "text-muted-foreground"
              )}
            >
              <item.icon className="h-5 w-5" />
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          ))}
        </div>
      </nav>

      {/* Mobile slide-down menu (Settings / Guide / Printer) */}
      <AnimatePresence>
        {moreOpen && (
          <>
            <motion.div
              key="more-backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="fixed inset-0 bg-black/60 z-40 md:hidden"
              onClick={() => setMoreOpen(false)}
            />
            <motion.div
              key="more-sheet"
              initial={{ y: "-100%" }}
              animate={{ y: 0 }}
              exit={{ y: "-100%" }}
              transition={{ type: "spring", damping: 30, stiffness: 300 }}
              className="fixed top-[56px] left-0 right-0 bg-sidebar border-b border-sidebar-border rounded-b-2xl z-50 md:hidden"
            >
              <div className="px-4 pt-3 pb-4">
                <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2">More</p>
                <div className="space-y-1">
                  {SIDEBAR_EXTRA.map(({ path, label, icon: Icon }) => (
                    <button
                      key={path}
                      onClick={() => { setMoreOpen(false); navigate(path); }}
                      className={cn(
                        "w-full flex items-center gap-4 px-4 py-3.5 rounded-xl text-sm font-semibold transition-colors cursor-pointer",
                        isActive(path)
                          ? "bg-primary text-primary-foreground"
                          : "text-foreground hover:bg-secondary"
                      )}
                    >
                      <Icon className="h-5 w-5 shrink-0" />
                      {label}
                      {isActive(path) && <ChevronRight className="h-4 w-4 ml-auto" />}
                    </button>
                  ))}
                </div>
                <div className="mt-3 pt-3 border-t border-border/50">
                  <button
                    onClick={() => { setMoreOpen(false); navigate("/feedback"); }}
                    className="w-full flex items-center gap-4 px-4 py-3.5 rounded-xl text-sm font-semibold text-profit hover:bg-profit/10 transition-colors cursor-pointer"
                  >
                    <MessageSquare className="h-5 w-5 shrink-0" />
                    Feedback
                  </button>
                  <button
                    onClick={() => { setMoreOpen(false); navigate("/support"); }}
                    className="w-full flex items-center gap-4 px-4 py-3.5 rounded-xl text-sm font-semibold hover:bg-[#e8b931]/10 transition-colors cursor-pointer"
                    style={{ color: "#d4a306" }}
                  >
                    <Coffee className="h-5 w-5 shrink-0" />
                    Support Us ☕
                  </button>
                  <button
                    onClick={() => { setMoreOpen(false); void signout(); }}
                    className="w-full flex items-center gap-4 px-4 py-3.5 rounded-xl text-sm font-semibold text-destructive hover:bg-destructive/10 transition-colors cursor-pointer"
                  >
                    <LogOut className="h-5 w-5 shrink-0" />
                    Sign Out
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* First-run welcome flow */}
      {showWelcome && !showSuspendedOverlay && (
        <FirstRunWelcome onComplete={() => setWelcomeDismissed(true)} />
      )}

      {/* Suspension overlay — shown over everything when account is suspended */}
      {showSuspendedOverlay && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-6">
          {/* Blurred backdrop */}
          <div className="absolute inset-0 backdrop-blur-xl bg-black/75" />
          {/* Card */}
          <div className="relative z-10 w-full max-w-sm bg-background border border-red-500/50 rounded-2xl shadow-2xl p-8 flex flex-col items-center gap-5 text-center">
            <div className="w-16 h-16 rounded-full bg-red-500/15 border-2 border-red-500/40 flex items-center justify-center">
              <Ban className="h-8 w-8 text-red-400" />
            </div>
            <div className="space-y-3">
              <h2 className="text-xl font-black tracking-widest text-red-400 uppercase">Account Suspended</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Reach out to{" "}
                <span className="font-bold text-foreground">
                  Dat<span className="text-primary">CARD</span>Vault
                </span>{" "}
                for help on social media.
              </p>
              {/* Verification code derived from user ID — stable per account */}
              {currentUser && (() => {
                const raw = currentUser._id ?? "";
                let hash = 0;
                for (let i = 0; i < raw.length; i++) {
                  hash = (hash * 31 + raw.charCodeAt(i)) >>> 0;
                }
                const code = String(hash % 1000000).padStart(6, "0");
                return (
                  <div className="w-full rounded-xl bg-red-500/10 border border-red-500/30 px-4 py-3 space-y-1">
                    <p className="text-xs text-muted-foreground uppercase tracking-widest font-semibold">Your Verification Code</p>
                    <p className="text-3xl font-black tracking-[0.3em] text-red-400">{code}</p>
                    <p className="text-[11px] text-muted-foreground leading-relaxed">
                      <span className="font-semibold text-foreground">Pro Tip:</span> Use this code to <span className="font-semibold text-foreground">verify who you are</span> when you contact us.
                    </p>
                  </div>
                );
              })()}
              <a
                href="https://www.instagram.com/DatCARDVault_app"
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-bold text-primary tracking-widest underline underline-offset-2 cursor-pointer"
              >
                Instagram: @DatCARDVault_app
              </a>
            </div>
            <button
              onClick={() => void signout()}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-secondary border border-border text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
            >
              <LogOut className="h-4 w-4" />
              Sign Out
            </button>
          </div>
        </div>
      )}
    </>
  );
}
