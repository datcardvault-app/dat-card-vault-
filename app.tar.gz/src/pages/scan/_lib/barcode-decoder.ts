import {
  BrowserMultiFormatReader,
  NotFoundException,
  HTMLCanvasElementLuminanceSource,
  HybridBinarizer,
  BinaryBitmap,
} from "@zxing/library";

// Singleton reader — reuse to avoid re-init overhead
let reader: BrowserMultiFormatReader | null = null;

function getReader(): BrowserMultiFormatReader {
  if (!reader) reader = new BrowserMultiFormatReader();
  return reader;
}

/**
 * Try to decode a 1D/2D barcode from canvas pixel data using ZXing.
 * Returns the decoded string or null if nothing found.
 */
export function decodeBarcodeFromCanvas(canvas: HTMLCanvasElement): string | null {
  try {
    const luminanceSource = new HTMLCanvasElementLuminanceSource(canvas);
    const binaryBitmap = new BinaryBitmap(new HybridBinarizer(luminanceSource));
    const result = getReader().decodeBitmap(binaryBitmap);
    return result.getText();
  } catch (e) {
    if (e instanceof NotFoundException) return null;
    // Silence all other decode errors — not found is expected most frames
    return null;
  }
}

/**
 * Heuristic: is the scanned value a DatCARDVault QR code (not a product barcode)?
 * Product barcodes (EAN-13, UPC-A, EAN-8, UPC-E) are purely numeric 8–14 digits.
 * DCV QR values are Convex document IDs — alphanumeric, 20+ chars.
 */
export function isDcvQrCode(value: string): boolean {
  return !/^\d{8,14}$/.test(value);
}
