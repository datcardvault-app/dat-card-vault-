import { useState, useEffect, useRef, useCallback } from "react";
import { useMutation, useQuery, useAction } from "convex/react";
import { motion, AnimatePresence } from "motion/react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import DuplicateWarning from "@/components/duplicate-warning.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Separator } from "@/components/ui/separator.tsx";
import {
  ScanLine, CheckCircle, XCircle, Camera, QrCode,
  Package, Plus, X, RotateCcw, Tag, ShoppingCart,
  Pencil, Mail, ChevronRight, Loader2, AlertCircle,
  Wifi, WifiOff, Banknote, CreditCard, Trash2, Users, Receipt, Monitor, Barcode,
} from "lucide-react";
import { formatDate, formatCurrency } from "@/lib/utils.ts";
import { toast } from "sonner";
import Webcam from "react-webcam";
import jsQR from "jsqr";
import CameraErrorPanel from "./_components/camera-error-panel.tsx";
import BulkSale from "./bulk-sale.tsx";
import SealedProductSheet from "./_components/sealed-product-sheet.tsx";
import { decodeBarcodeFromCanvas, isDcvQrCode } from "./_lib/barcode-decoder.ts";

import { useScanFeedback, type SoundType } from "@/hooks/use-scan-feedback.ts";

const GAMES = ["Pokémon", "Magic: The Gathering", "Yu-Gi-Oh! Official", "One Piece", "Flesh and Blood", "Digimon", "Star Wars: Unlimited", "Weiss Schwarz", "Cardfight!! Vanguard", "Lorcana", "Dragon Ball Super", "Other"];
const CONDITIONS = ["Mint", "Near Mint", "Excellent", "Good", "Lightly Played", "Moderately Played", "Heavily Played", "Poor"];

type QueuedScan = { id: string; qrValue: string; cardName?: string; scannedAt: string; synced: boolean };

type CardFormData = {
  name: string; game: string; set: string; cardNumber: string;
  condition: string; grade: string; purchasePrice: string;
  marketValue: string; rarity: string; language: string; notes: string;
};

const EMPTY_FORM: CardFormData = {
  name: "", game: "Pokémon", set: "", cardNumber: "", condition: "Near Mint",
  grade: "", purchasePrice: "", marketValue: "", rarity: "", language: "English", notes: "",
};

// ─── Card Action Sheet ────────────────────────────────────────────────────────
type ScannedCard = { _id: Id<"cards">; name: string; game: string; condition: string; marketValue?: number; salePrice?: number; sold: boolean; soldAt?: string; set?: string; grade?: string; rarity?: string; language?: string; notes?: string; purchasePrice?: number; cardNumber?: number };

function CardActionSheet({
  card,
  currency,
  user,
  onClose,
  initialView = "actions",
  scanSound = false,
  scanHaptics = false,
  soundType = "beep" as SoundType,
}: {
  card: ScannedCard;
  currency: string;
  user: { businessName?: string; instagram?: string; website?: string; senderEmail?: string } | null | undefined;
  onClose: () => void;
  initialView?: "actions" | "edit" | "sell" | "receipt" | "view-receipt";
  scanSound?: boolean;
  scanHaptics?: boolean;
  soundType?: SoundType;
}) {
  const [view, setView] = useState<"actions" | "edit" | "sell" | "receipt" | "view-receipt">(initialView);
  const { trigger: triggerFeedback } = useScanFeedback(scanSound, scanHaptics, soundType);
  const [salePrice, setSalePrice] = useState(card.marketValue?.toString() ?? "");
  const [paymentMethod, setPaymentMethod] = useState<"cash" | "card">("cash");
  const [customerEmail, setCustomerEmail] = useState("");
  const [sendingReceipt, setSendingReceipt] = useState(false);
  const [form, setForm] = useState<CardFormData>({
    name: card.name, game: card.game, set: card.set ?? "", cardNumber: card.cardNumber?.toString() ?? "",
    condition: card.condition, grade: card.grade ?? "", purchasePrice: card.purchasePrice?.toString() ?? "",
    marketValue: card.marketValue?.toString() ?? "", rarity: card.rarity ?? "",
    language: card.language ?? "English", notes: card.notes ?? "",
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [selling, setSelling] = useState(false);

  const markSold = useMutation(api.cards.markSold);
  const updateCard = useMutation(api.cards.updateCard);
  const markUnsold = useMutation(api.cards.markUnsold);
  const sendReceipt = useAction(api.emails.sendReceipt);

  const handleSell = async () => {
    const price = parseFloat(salePrice);
    if (isNaN(price) || price <= 0) return;
    setSelling(true);
    const now = new Date();
    // Use the same 6am business day shift as the dashboard so earnings land on the correct day
    const d = now.getHours() < 6 ? new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1) : now;
    const localDate = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    try {
      await markSold({ id: card._id, salePrice: price, localDate });
      triggerFeedback();
      if (view === "sell") setView("receipt");
      else onClose();
    } catch {
      // failed to mark as sold
    } finally {
      setSelling(false);
    }
  };

  const handleUnsell = async () => {
    try {
      await markUnsold({ id: card._id });
      onClose();
    } catch {
      // failed
    }
  };

  const handleSaveEdit = async () => {
    if (!form.name.trim()) return;
    setSaving(true);
    try {
      await updateCard({
        id: card._id,
        name: form.name.trim(),
        game: form.game,
        set: form.set || undefined,
        condition: form.condition,
        grade: form.grade || undefined,
        purchasePrice: form.purchasePrice ? parseFloat(form.purchasePrice) : undefined,
        marketValue: form.marketValue ? parseFloat(form.marketValue) : undefined,
        rarity: form.rarity || undefined,
        language: form.language || undefined,
        notes: form.notes || undefined,
      });
      setSaved(true);
      setTimeout(() => { setSaved(false); onClose(); }, 400);
    } catch {
      // failed to update card
    } finally {
      setSaving(false);
    }
  };

  const handleSendReceipt = async () => {
    if (!customerEmail.trim()) return;
    if (!user?.senderEmail) {
      toast.error("Set your sender email in Settings first");
      return;
    }
    const price = card.salePrice ?? parseFloat(salePrice);
    if (isNaN(price) || price <= 0) return;
    setSendingReceipt(true);
    try {
      await sendReceipt({
        to: customerEmail.trim(),
        senderEmail: user.senderEmail,
        cardName: card.name,
        game: card.game,
        condition: card.condition,
        salePrice: price,
        currency,
        set: card.set,
        grade: card.grade,
        businessName: user?.businessName,
        instagram: user?.instagram,
        website: user?.website,
      });
      toast.success("Receipt sent to customer!");
      onClose();
    } catch {
      toast.error("Failed to send receipt. Check your sender email is verified.");
    } finally {
      setSendingReceipt(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Card summary banner */}
      <div className={`rounded-xl p-4 border ${card.sold ? "bg-amber-500/10 border-amber-700/20" : "bg-primary/8 border-primary/20"}`}>
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className="font-bold text-lg leading-tight">{card.name}</p>
            <p className="text-sm text-muted-foreground mt-0.5">{card.game}{card.set ? ` · ${card.set}` : ""}</p>
            <div className="flex items-center gap-2 mt-2 flex-wrap">
              <Badge variant="secondary" className="text-xs">{card.condition}</Badge>
              {card.grade && <Badge variant="outline" className="text-xs">{card.grade}</Badge>}
              {card.sold && <Badge className="text-xs bg-amber-600/20 text-amber-500 border-amber-700/30">SOLD</Badge>}
            </div>
          </div>
          <div className="text-right shrink-0">
            {card.marketValue !== undefined && (
              <p className="text-2xl font-black text-primary">{formatCurrency(card.marketValue, currency)}</p>
            )}
            {card.sold && card.salePrice !== undefined && (
              <div className="mt-0.5 text-right">
                <p className="text-xs text-muted-foreground">Sold: <span className="text-profit font-semibold">{formatCurrency(card.salePrice, currency)}</span></p>
                {card.purchasePrice !== undefined && (() => {
                  const profit = card.salePrice! - card.purchasePrice!;
                  return (
                    <p className={`text-xs font-bold ${profit >= 0 ? "text-profit" : "text-red-400"}`}>
                      {profit >= 0 ? "+" : ""}{formatCurrency(profit, currency)} profit
                    </p>
                  );
                })()}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Views */}
      <AnimatePresence mode="wait">
        {view === "actions" && (
          <motion.div key="actions" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }} className="space-y-2">
            {!card.sold ? (
              <>
                <button onClick={() => setView("sell")}
                  className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl bg-primary text-primary-foreground font-semibold cursor-pointer hover:bg-primary/90 transition-colors">
                  <ShoppingCart className="h-5 w-5 shrink-0" />
                  <span>Mark as Sold</span>
                  <ChevronRight className="h-4 w-4 ml-auto" />
                </button>
                <button onClick={() => setView("edit")}
                  className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl bg-secondary text-secondary-foreground font-semibold cursor-pointer hover:bg-secondary/80 transition-colors border border-border">
                  <Pencil className="h-5 w-5 shrink-0" />
                  <span>Edit Card Details</span>
                  <ChevronRight className="h-4 w-4 ml-auto" />
                </button>
                <button onClick={() => setView("receipt")}
                  className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl bg-secondary text-secondary-foreground font-semibold cursor-pointer hover:bg-secondary/80 transition-colors border border-border">
                  <Mail className="h-5 w-5 shrink-0" />
                  <span>Send Invoice/Receipt</span>
                  <ChevronRight className="h-4 w-4 ml-auto" />
                </button>
              </>
            ) : (
              <>
                <button onClick={() => setView("view-receipt")}
                  className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl bg-primary text-primary-foreground font-semibold cursor-pointer hover:bg-primary/90 transition-colors">
                  <Receipt className="h-5 w-5 shrink-0" />
                  <span>View Receipt</span>
                  <ChevronRight className="h-4 w-4 ml-auto" />
                </button>
                <button onClick={() => setView("receipt")}
                  className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl bg-secondary text-secondary-foreground font-semibold cursor-pointer hover:bg-secondary/80 transition-colors border border-border">
                  <Mail className="h-5 w-5 shrink-0" />
                  <span>Resend Receipt to Customer</span>
                  <ChevronRight className="h-4 w-4 ml-auto" />
                </button>
                <button onClick={handleUnsell}
                  className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl bg-secondary text-secondary-foreground font-semibold cursor-pointer hover:bg-secondary/80 transition-colors border border-border">
                  <RotateCcw className="h-5 w-5 shrink-0" />
                  <span>Move Back to Inventory</span>
                  <ChevronRight className="h-4 w-4 ml-auto" />
                </button>
              </>
            )}
          </motion.div>
        )}

        {view === "sell" && (
          <motion.div key="sell" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }} className="space-y-4">
            <button onClick={() => setView("actions")} className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 cursor-pointer">
              ← Back
            </button>
            <div className="space-y-1">
              <Label className="text-sm font-semibold">Sale Price ({currency})</Label>
              <Input
                type="number" step="0.01" autoFocus
                placeholder={card.marketValue?.toString() ?? "0.00"}
                value={salePrice}
                onChange={e => setSalePrice(e.target.value)}
                className="text-xl font-bold h-14 text-center"
              />
              {card.marketValue !== undefined && (
                <p className="text-xs text-muted-foreground text-center">
                  Listed at {formatCurrency(card.marketValue, currency)}
                </p>
              )}
            </div>

            {/* Payment method toggle */}
            <div className="space-y-1.5">
              <Label className="text-sm font-semibold">Payment Method</Label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod("cash")}
                  className={`flex items-center justify-center gap-2 py-3 rounded-xl border-2 font-semibold text-sm transition-all cursor-pointer ${
                    paymentMethod === "cash"
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border bg-secondary/40 text-muted-foreground hover:border-primary/40"
                  }`}
                >
                  <Banknote className="h-4 w-4" />
                  Cash
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod("card")}
                  className={`flex items-center justify-center gap-2 py-3 rounded-xl border-2 font-semibold text-sm transition-all cursor-pointer ${
                    paymentMethod === "card"
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border bg-secondary/40 text-muted-foreground hover:border-primary/40"
                  }`}
                >
                  <CreditCard className="h-4 w-4" />
                  Bank Card
                </button>
              </div>
            </div>
            <div className="flex items-start gap-2 p-3 rounded-xl bg-profit/10 border border-profit/20 text-xs text-profit">
              <CheckCircle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
              Sale will be logged to your Earnings page automatically.
            </div>
            <Button onClick={handleSell} disabled={selling} className="w-full h-12 text-base font-bold gap-2">
              {selling ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShoppingCart className="h-4 w-4" />}
              {selling ? "Logging sale..." : `Confirm Sale · ${salePrice ? formatCurrency(parseFloat(salePrice) || 0, currency) : "—"}`}
            </Button>
            <Button variant="secondary" className="w-full" onClick={() => { handleSell().then(() => setView("receipt")); }}>
              Sell &amp; Send Receipt →
            </Button>
          </motion.div>
        )}

        {view === "edit" && (
          <motion.div key="edit" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }} className="space-y-3">
            <button onClick={() => setView("actions")} className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 cursor-pointer">
              ← Back
            </button>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2 space-y-1">
                <Label>Card Name *</Label>
                <Input value={form.name} maxLength={25} onChange={e => setForm(f => ({ ...f, name: e.target.value.slice(0, 25) }))} />
              </div>
              <div className="space-y-1">
                <Label>Game</Label>
                <Select value={form.game} onValueChange={v => setForm(f => ({ ...f, game: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{GAMES.map(g => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label>Condition</Label>
                <Select value={form.condition} onValueChange={v => setForm(f => ({ ...f, condition: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{CONDITIONS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label>Set</Label>
                <Input placeholder="e.g. Base Set" value={form.set} onChange={e => setForm(f => ({ ...f, set: e.target.value }))} />
              </div>
              <div className="space-y-1">
                <Label>Grade</Label>
                <Input placeholder="e.g. PSA 10" value={form.grade} onChange={e => setForm(f => ({ ...f, grade: e.target.value }))} />
              </div>
              <div className="col-span-2 space-y-1">
                <Label>% Bought At</Label>
                <Select
                  value=""
                  onValueChange={pct => {
                    const mv = parseFloat(form.marketValue);
                    if (!isNaN(mv) && mv > 0) {
                      setForm(f => ({ ...f, purchasePrice: (mv * parseInt(pct) / 100).toFixed(2) }));
                    }
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={
                      form.purchasePrice && form.marketValue && parseFloat(form.marketValue) > 0
                        ? `${Math.round((parseFloat(form.purchasePrice) / parseFloat(form.marketValue)) * 100)}% of market`
                        : "Quick fill…"
                    } />
                  </SelectTrigger>
                  <SelectContent>
                    {[10, 20, 30, 40, 50, 60, 70, 80, 90, 100].map(pct => (
                      <SelectItem key={pct} value={String(pct)}>{pct}%</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label>Purchase Price</Label>
                <Input type="number" step="0.01" placeholder="0.00" value={form.purchasePrice} onChange={e => setForm(f => ({ ...f, purchasePrice: e.target.value }))} />
              </div>
              <div className="space-y-1">
                <Label>Market Value</Label>
                <Input type="number" step="0.01" placeholder="0.00" value={form.marketValue} onChange={e => setForm(f => ({ ...f, marketValue: e.target.value }))} />
              </div>
              <div className="col-span-2 space-y-1">
                <Label>Notes</Label>
                <Textarea placeholder="Any notes..." value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} rows={2} />
              </div>
            </div>
            <Button onClick={handleSaveEdit} disabled={saving} className={`w-full gap-2 transition-colors ${saved ? "bg-profit hover:bg-profit text-white" : ""}`}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Pencil className="h-4 w-4" />}
              {saving ? "Saving..." : "Save Changes"}
            </Button>
          </motion.div>
        )}

        {view === "view-receipt" && (
          <motion.div key="view-receipt" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }} className="space-y-4">
            <button onClick={() => setView("actions")} className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 cursor-pointer">
              ← Back
            </button>
            {/* Receipt preview */}
            <div className="rounded-xl border border-border bg-card overflow-hidden">
              {/* Header */}
              <div className="bg-primary/10 border-b border-border px-4 py-3 flex items-center gap-2">
                <Receipt className="h-4 w-4 text-primary" />
                <span className="font-bold text-sm text-primary">Sale Receipt</span>
                <span className="ml-auto text-xs text-muted-foreground">
                  {card.soldAt ? new Date(card.soldAt).toLocaleDateString() : new Date().toLocaleDateString()}
                </span>
              </div>
              {/* Store info */}
              {(user?.businessName || user?.instagram) && (
                <div className="px-4 py-3 border-b border-border space-y-0.5">
                  {user.businessName && <p className="font-bold text-sm">{user.businessName}</p>}
                  {user.instagram && <p className="text-xs text-muted-foreground">@{user.instagram}</p>}
                  {user.website && <p className="text-xs text-muted-foreground">{user.website}</p>}
                </div>
              )}
              {/* Card details */}
              <div className="px-4 py-3 border-b border-border space-y-1.5">
                <p className="font-semibold text-sm">{card.name}</p>
                <div className="flex gap-2 flex-wrap text-xs text-muted-foreground">
                  <span>{card.game}</span>
                  {card.set && <span>· {card.set}</span>}
                  <span>· {card.condition}</span>
                  {card.grade && <span>· {card.grade}</span>}
                  {card.language && <span>· {card.language}</span>}
                </div>
              </div>
              {/* Pricing */}
              <div className="px-4 py-3 space-y-1.5">
                {card.purchasePrice !== undefined && (
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Purchase Price</span>
                    <span>{formatCurrency(card.purchasePrice, currency)}</span>
                  </div>
                )}
                {card.marketValue !== undefined && (
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Listed Value</span>
                    <span>{formatCurrency(card.marketValue, currency)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-base pt-1 border-t border-border">
                  <span>Sale Price</span>
                  <span className="text-profit">{card.salePrice !== undefined ? formatCurrency(card.salePrice, currency) : "—"}</span>
                </div>
                {card.purchasePrice !== undefined && card.salePrice !== undefined && (
                  <div className="flex justify-between text-xs font-semibold">
                    <span>Profit</span>
                    <span className={card.salePrice - card.purchasePrice >= 0 ? "text-profit" : "text-red-400"}>
                      {card.salePrice - card.purchasePrice >= 0 ? "+" : ""}{formatCurrency(card.salePrice - card.purchasePrice, currency)}
                    </span>
                  </div>
                )}
              </div>
            </div>
            <Button className="w-full gap-2" onClick={() => setView("receipt")}>
              <Mail className="h-4 w-4" /> Resend Receipt to Customer
            </Button>
          </motion.div>
        )}

        {view === "receipt" && (
          <motion.div key="receipt" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }} className="space-y-4">
            <button onClick={() => setView("actions")} className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 cursor-pointer">
              ← Back
            </button>
            <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Send Receipt to Customer</p>
            <div className="space-y-3">
              <Input type="email" placeholder="customer@example.com" value={customerEmail} onChange={e => setCustomerEmail(e.target.value)} />
              <Button onClick={handleSendReceipt} disabled={sendingReceipt || !customerEmail.trim()} className="w-full gap-2">
                {sendingReceipt ? <Loader2 className="h-4 w-4 animate-spin" /> : <Mail className="h-4 w-4" />}
                {sendingReceipt ? "Sending..." : "Send Receipt"}
              </Button>
              <p className="text-[10px] text-muted-foreground leading-relaxed"><span className="font-bold text-primary">Pro tip:</span> Let the customer know that their receipt might land in their <span className="font-semibold text-foreground">junk mail</span> or <span className="font-semibold text-foreground">spam</span> folder.</p>
            </div>
            <Button variant="secondary" className="w-full" onClick={() => setView("actions")}>
              Done
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── QR + Barcode Scanner ─────────────────────────────────────────────────────
type ScanResult = { value: string; type: "qr" | "barcode" };

function QrScannerPanel({ onScan, scanSound, scanHaptics, soundType }: { onScan: (result: ScanResult) => void; scanSound: boolean; scanHaptics: boolean; soundType: SoundType }) {
  const [scanning, setScanning] = useState(false);
  const [facingMode, setFacingMode] = useState<"environment" | "user">("environment");
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [showNudge, setShowNudge] = useState(false);
  const [successFlash, setSuccessFlash] = useState(false);
  const webcamRef = useRef<Webcam>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number | null>(null);
  const lastScanRef = useRef<string | null>(null);
  const lastScanTimeRef = useRef<number>(0);
  const nudgeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const { trigger: triggerFeedback } = useScanFeedback(scanSound, scanHaptics, soundType);

  const stopScanning = useCallback(() => {
    setScanning(false);
    setShowNudge(false);
    if (rafRef.current) { cancelAnimationFrame(rafRef.current); rafRef.current = null; }
    if (nudgeTimerRef.current) { clearTimeout(nudgeTimerRef.current); nudgeTimerRef.current = null; }
  }, []);

  useEffect(() => () => stopScanning(), [stopScanning]);

  const startScanning = () => {
    setCameraError(null);
    setScanning(true);
    setShowNudge(false);
    setSuccessFlash(false);
    lastScanRef.current = null;

    // Start 8-second nudge timer
    if (nudgeTimerRef.current) clearTimeout(nudgeTimerRef.current);
    nudgeTimerRef.current = setTimeout(() => setShowNudge(true), 8000);

    const tick = (now: number) => {
      rafRef.current = requestAnimationFrame(tick);

      const video = webcamRef.current?.video;
      if (!video || video.readyState !== 4) return;
      const vw = video.videoWidth;
      const vh = video.videoHeight;
      if (!vw || !vh) return;

      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext("2d", { willReadFrequently: true });
      if (!ctx) return;

      // Fast-path: full frame at 400px, raw pixels, dontInvert (~2-3ms)
      const scale = Math.min(1, 400 / Math.max(vw, vh));
      canvas.width  = Math.round(vw * scale);
      canvas.height = Math.round(vh * scale);
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const fast = jsQR(ctx.getImageData(0, 0, canvas.width, canvas.height).data, canvas.width, canvas.height, { inversionAttempts: "dontInvert" });
      if (fast?.data) { handleFound(fast.data, "qr"); return; }

      // Try barcode detection on the same full-frame canvas
      const barcodeResult = decodeBarcodeFromCanvas(canvas);
      if (barcodeResult) { handleFound(barcodeResult, "barcode"); return; }

      // Fallback: center 60% crop at 400px, contrast-enhanced, attemptBoth
      const cx = vw * 0.2, cy = vh * 0.2, cw = vw * 0.6, ch = vh * 0.6;
      const s2 = Math.min(1, 400 / Math.max(cw, ch));
      canvas.width  = Math.round(cw * s2);
      canvas.height = Math.round(ch * s2);
      ctx.drawImage(video, cx, cy, cw, ch, 0, 0, canvas.width, canvas.height);
      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const d = imgData.data;
      for (let i = 0; i < d.length; i += 4) {
        const g = Math.min(255, Math.max(0, (0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2] - 128) * 1.5 + 128));
        d[i] = d[i + 1] = d[i + 2] = g;
      }
      const slow = jsQR(imgData.data, canvas.width, canvas.height, { inversionAttempts: "attemptBoth" });
      if (slow?.data) handleFound(slow.data, "qr");

      // Final barcode attempt on cropped enhanced frame
      const barcodeSlow = decodeBarcodeFromCanvas(canvas);
      if (barcodeSlow) handleFound(barcodeSlow, "barcode");
    };

    const handleFound = (data: string, type: "qr" | "barcode") => {
      const now = Date.now();
      if (data !== lastScanRef.current || now - lastScanTimeRef.current > 3000) {
        lastScanRef.current = data;
        lastScanTimeRef.current = now;
        setSuccessFlash(true);
        triggerFeedback();
        if (nudgeTimerRef.current) { clearTimeout(nudgeTimerRef.current); nudgeTimerRef.current = null; }
        setShowNudge(false);
        setTimeout(() => {
          onScan({ value: data, type });
          stopScanning();
          setSuccessFlash(false);
        }, 400);
      }
    };

    rafRef.current = requestAnimationFrame(tick);
  };

  return (
    <div className="space-y-3">
      {/* Hidden reusable canvas — never causes re-render */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Idle state — shown when not scanning */}
      {!scanning && (
        <>
          <p className="text-sm text-muted-foreground text-center">
            Scan a DatCARDVault QR label to pull up a card, or scan a product barcode for sealed inventory.
          </p>

          <button
            onClick={startScanning}
            className="w-full h-36 rounded-2xl border-2 border-dashed border-primary/40 bg-primary/5 hover:bg-primary/10 hover:border-primary/60 transition-all cursor-pointer flex flex-col items-center justify-center gap-3"
          >
            <div className="flex items-center gap-2">
              <div className="w-14 h-14 rounded-2xl bg-primary/15 flex items-center justify-center">
                <QrCode className="h-7 w-7 text-primary" />
              </div>
              <div className="w-14 h-14 rounded-2xl bg-blue-500/10 flex items-center justify-center">
                <Barcode className="h-7 w-7 text-blue-400" />
              </div>
            </div>
            <span className="font-semibold text-primary">Tap to Scan QR or Barcode</span>
          </button>
          {cameraError && (
            <CameraErrorPanel
              error={cameraError}
              onRetry={() => { setCameraError(null); startScanning(); }}
            />
          )}
        </>
      )}

      {/* Webcam — always mounted once scanning starts, hidden when idle to avoid remount flicker */}
      <div className={scanning ? "block" : "hidden"}>
        <div className={`relative rounded-2xl overflow-hidden border-2 bg-black transition-colors duration-300 ${successFlash ? "border-profit" : "border-primary/50"}`} style={{ aspectRatio: "4/3" }}>
          <Webcam
            ref={webcamRef}
            videoConstraints={{ facingMode, aspectRatio: 4 / 3, width: { ideal: 640 }, height: { ideal: 480 }, frameRate: { ideal: 30, min: 15 } }}
            className="w-full h-full object-cover"
            screenshotFormat="image/jpeg"
            onUserMediaError={(err) => {
              const name = err instanceof DOMException ? err.name : "";
              let msg: string;
              if (name === "NotAllowedError") {
                msg = "NotAllowedError: Camera permission denied.";
              } else if (name === "NotReadableError" || name === "AbortError") {
                msg = "NotReadableError: Camera is in use by another app.";
              } else if (name === "NotFoundError") {
                msg = "NotFoundError: No camera hardware detected.";
              } else {
                msg = `${name || "Unknown"}: Could not access camera.`;
              }
              setCameraError(msg);
              stopScanning();
            }}
          />
          {/* Success flash overlay */}
          <AnimatePresence>
            {successFlash && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-profit/20 pointer-events-none z-10"
              />
            )}
          </AnimatePresence>
          {/* Corner brackets */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className={`relative w-52 h-52 transition-colors duration-300 ${successFlash ? "[&_div]:border-profit" : ""}`}>
              <div className="absolute top-0 left-0 w-8 h-8 border-t-[3px] border-l-[3px] border-primary rounded-tl-md" />
              <div className="absolute top-0 right-0 w-8 h-8 border-t-[3px] border-r-[3px] border-primary rounded-tr-md" />
              <div className="absolute bottom-0 left-0 w-8 h-8 border-b-[3px] border-l-[3px] border-primary rounded-bl-md" />
              <div className="absolute bottom-0 right-0 w-8 h-8 border-b-[3px] border-r-[3px] border-primary rounded-br-md" />
              <motion.div
                className="absolute left-2 right-2 h-0.5 bg-primary/70 rounded-full"
                animate={{ top: ["8%", "88%", "8%"] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              />
            </div>
          </div>
          {/* Success checkmark */}
          <AnimatePresence>
            {successFlash && (
              <motion.div
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.5 }}
                className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none"
              >
                <div className="w-16 h-16 rounded-full bg-profit/90 flex items-center justify-center">
                  <CheckCircle className="h-9 w-9 text-white" />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          {/* Controls overlay */}
          <div className="absolute bottom-3 left-0 right-0 flex justify-center gap-2">
            <button
              onClick={() => setFacingMode(f => f === "environment" ? "user" : "environment")}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/60 text-white text-xs font-medium cursor-pointer"
            >
              <RotateCcw className="h-3 w-3" /> Flip
            </button>
            <button
              onClick={stopScanning}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-red-600/80 text-white text-xs font-medium cursor-pointer"
            >
              <X className="h-3 w-3" /> Stop
            </button>
          </div>
          {/* Scanning pulse indicator */}
          <div className="absolute top-3 left-0 right-0 flex justify-center">
            <motion.span
              animate={{ opacity: [1, 0.5, 1] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
              className="px-3 py-1 rounded-full bg-black/60 text-white text-xs flex items-center gap-1.5"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-profit animate-pulse" />
              Scanning…
            </motion.span>
          </div>
        </div>
        {/* Nudge — appears after 8 seconds with no result */}
        <AnimatePresence>
          {showNudge && (
            <motion.div
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              className="mt-2 flex items-start gap-2.5 px-3 py-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-400"
            >
              <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
              <div className="space-y-0.5">
                <p className="font-semibold">Taking a while?</p>
                <p className="text-muted-foreground">Try moving closer, improving the lighting, or holding the phone steady. Make sure the QR code is flat and not creased.</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

// ─── Session persistence key ──────────────────────────────────────────────────
const SESSION_START_KEY = "dcv_scan_session_start";

function getOrCreateSessionStart(): string {
  try {
    const stored = localStorage.getItem(SESSION_START_KEY);
    if (stored) return stored;
  } catch { /* ignore */ }
  const now = new Date().toISOString();
  try { localStorage.setItem(SESSION_START_KEY, now); } catch { /* ignore */ }
  return now;
}

// ─── Main Page ────────────────────────────────────────────────────────────────
type ScanMode = "qr" | "card";

export default function ScanPage() {
  const [mode, setMode] = useState<ScanMode>("qr");
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [queue, setQueue] = useState<QueuedScan[]>(() => {
    try { const s = localStorage.getItem("dcv_scan_queue"); return s ? (JSON.parse(s) as QueuedScan[]) : []; } catch { return []; }
  });
  const [syncing, setSyncing] = useState(false);
  const [bulkSaleOpen, setBulkSaleOpen] = useState(false);

  // Persistent session start — survives reload/reopen until user taps "New Session"
  const [sessionStart] = useState<string>(() => getOrCreateSessionStart());

  // Scanned card sheet
  const [scannedQr, setScannedQr] = useState<string | null>(null);
  const [cardSheetOpen, setCardSheetOpen] = useState(false);
  const [editOnOpen, setEditOnOpen] = useState(false);

  // Scanned barcode (sealed product) sheet
  const [scannedBarcode, setScannedBarcode] = useState<string | null>(null);
  const [barcodeSheetOpen, setBarcodeSheetOpen] = useState(false);

  // Add card from camera
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [capturedBackImage, setCapturedBackImage] = useState<string | null>(null);
  const addDialogOpenTimeRef = useRef<number>(0);
  const [form, setForm] = useState<CardFormData>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [facingMode, setFacingMode] = useState<"environment" | "user">("environment");
  const [addCardCameraError, setAddCardCameraError] = useState<string | null>(null);
  const webcamRef = useRef<Webcam>(null);
  const captureFileInputRef = useRef<HTMLInputElement>(null);
  const captureBackFileInputRef = useRef<HTMLInputElement>(null);

  const logScan = useMutation(api.scans.logScan);
  const addCard = useMutation(api.cards.addCard);
  const createLabel = useMutation(api.labels.createLabel);
  const generateUploadUrl = useMutation(api.cards.generateUploadUrl);
  const user = useQuery(api.users.getCurrentUser, {});
  const currency = user?.currency ?? "GBP";
  const scanSound = user?.scanSound ?? false;
  const scanHaptics = user?.scanHaptics ?? false;
  const soundType = (user?.scanSoundType ?? "beep") as SoundType;
  const recentScansData = useQuery(api.scans.getRecentScans, { sessionStart });

  const startNewSession = () => {
    const now = new Date().toISOString();
    try { localStorage.setItem(SESSION_START_KEY, now); } catch { /* ignore */ }
    // Clear the local offline queue too (new session = fresh start)
    setQueue([]);
    // Force a page reload so sessionStart state re-initialises
    window.location.reload();
  };

  // Look up scanned card reactively
  const scannedCard = useQuery(
    api.cards.getCardByQr,
    scannedQr ? { qrValue: scannedQr } : "skip"
  );

  // Look up scanned sealed product reactively
  const scannedSealedProduct = useQuery(
    api.sealedProducts.getByBarcode,
    scannedBarcode ? { barcode: scannedBarcode } : "skip"
  );

  // Once the scanned card resolves, patch its name into ALL matching queue entries
  useEffect(() => {
    if (scannedCard && scannedQr) {
      const name = (scannedCard as { name?: string }).name;
      if (name) {
        setQueue(prev => prev.map(q =>
          q.qrValue === scannedQr ? { ...q, cardName: q.cardName ?? name } : q
        ));
      }
    }
  }, [scannedCard, scannedQr]);

  useEffect(() => {
    const on = () => setIsOnline(true);
    const off = () => setIsOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => { window.removeEventListener("online", on); window.removeEventListener("offline", off); };
  }, []);

  useEffect(() => {
    localStorage.setItem("dcv_scan_queue", JSON.stringify(queue));
  }, [queue]);

  useEffect(() => {
    if (isOnline && queue.some(q => !q.synced)) void syncQueue();
  }, [isOnline]);

  // (Session reset is handled by startNewSession — no automatic 6am clear)

  const syncQueue = async () => {
    if (syncing) return;
    setSyncing(true);
    const unsynced = queue.filter(q => !q.synced);
    let synced = 0;
    for (const item of unsynced) {
      try {
        await logScan({ qrValue: item.qrValue, action: "scan" });
        setQueue(prev => prev.map(q => q.id === item.id ? { ...q, synced: true } : q));
        synced++;
      } catch { /* continue */ }
    }
    setSyncing(false);
  };

  const handleQrScanned = useCallback(async (result: ScanResult) => {
    if (result.type === "barcode" || !isDcvQrCode(result.value)) {
      // Sealed product barcode
      setScannedBarcode(result.value);
      setBarcodeSheetOpen(true);
      return;
    }

    // DatCARDVault QR code — existing flow unchanged
    const value = result.value;
    setScannedQr(value);
    setCardSheetOpen(true);

    // Queue + sync
    const newScan: QueuedScan = { id: `${Date.now()}-${Math.random()}`, qrValue: value, scannedAt: new Date().toISOString(), synced: false };
    setQueue(prev => [newScan, ...prev]);
    if (isOnline) {
      try {
        await logScan({ qrValue: value, action: "scan" });
        setQueue(prev => prev.map(q => q.id === newScan.id ? { ...q, synced: true } : q));
      } catch { /* queued */ }
    }
  }, [isOnline, logScan]);

  const handleCardCapture = () => {
    const img = webcamRef.current?.getScreenshot();
    if (!img) return;
    setCapturedImage(img);
    setForm(EMPTY_FORM);
    addDialogOpenTimeRef.current = Date.now();
    setShowAddDialog(true);
  };

  const handleCaptureFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = "";
    const reader = new FileReader();
    reader.onload = () => {
      setCapturedImage(reader.result as string);
      setForm(EMPTY_FORM);
      setCapturedBackImage(null);
      // Delay opening dialog to let browser settle focus after native camera returns
      setTimeout(() => {
        addDialogOpenTimeRef.current = Date.now();
        setShowAddDialog(true);
      }, 100);
    };
    reader.readAsDataURL(file);
  };

  const handleBackPhotoCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = "";
    const reader = new FileReader();
    reader.onload = () => {
      setCapturedBackImage(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSaveCard = async () => {
    if (!form.name.trim()) return;
    setSaving(true);
    try {
      let imageStorageId: Id<"_storage"> | undefined;
      let imageBackStorageId: Id<"_storage"> | undefined;
      if (capturedImage) {
        const res = await fetch(capturedImage);
        const blob = await res.blob();
        const uploadUrl = await generateUploadUrl();
        const uploadRes = await fetch(uploadUrl, { method: "POST", headers: { "Content-Type": blob.type }, body: blob });
        const { storageId } = await uploadRes.json() as { storageId: Id<"_storage"> };
        imageStorageId = storageId;
      }
      if (capturedBackImage) {
        const res = await fetch(capturedBackImage);
        const blob = await res.blob();
        const uploadUrl = await generateUploadUrl();
        const uploadRes = await fetch(uploadUrl, { method: "POST", headers: { "Content-Type": blob.type }, body: blob });
        const { storageId } = await uploadRes.json() as { storageId: Id<"_storage"> };
        imageBackStorageId = storageId;
      }
      const payload = {
        name: form.name.trim(), game: form.game, set: form.set || undefined,
        cardNumber: form.cardNumber || undefined, condition: form.condition,
        grade: form.grade || undefined, purchasePrice: form.purchasePrice ? parseFloat(form.purchasePrice) : undefined,
        marketValue: form.marketValue ? parseFloat(form.marketValue) : undefined,
        rarity: form.rarity || undefined, language: form.language || undefined,
        notes: form.notes || undefined, imageStorageId, imageBackStorageId,
      };
      const cardId = await addCard(payload);
      await createLabel({ cardId, labelData: { cardName: payload.name, game: payload.game, set: payload.set, cardNumber: payload.cardNumber, condition: payload.condition, grade: payload.grade, price: payload.marketValue, rarity: payload.rarity, language: payload.language }, currency });
      setShowAddDialog(false);
      setCapturedImage(null);
      setCapturedBackImage(null);
      setForm(EMPTY_FORM);
    } catch {
      // failed to save card
    } finally {
      setSaving(false);
    }
  };

  const pending = queue.filter(q => !q.synced).length;
  // scannedCard is undefined while loading, null if not found
  const isNotMyCard = scannedQr && scannedCard === null;

  // Recent scans JSX (rendered inline — never define as a component inside render)
  const sessionStartDate = new Date(sessionStart);
  const sessionLabel = sessionStartDate.toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
  const totalScanCount = (recentScansData?.length ?? 0) + queue.filter(q => !q.synced).length;

  const recentScansList = (
    <div className="space-y-2">
      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0">
          <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Session Scans</h2>
          <p className="text-[10px] text-muted-foreground/60 mt-0.5 truncate">Since {sessionLabel} · {totalScanCount} scan{totalScanCount !== 1 ? "s" : ""}</p>
        </div>
        <button
          onClick={startNewSession}
          className="shrink-0 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-primary hover:text-primary/80 cursor-pointer px-2.5 py-1.5 rounded-lg bg-primary/10 hover:bg-primary/20 transition-colors"
          title="Start a new session — clears scan history"
        >
          <RotateCcw className="h-3 w-3" />
          New Session
        </button>
      </div>
      {recentScansData === undefined ? (
        <div className="space-y-2">
          {[1,2,3].map(i => <div key={i} className="h-14 rounded-xl bg-secondary animate-pulse" />)}
        </div>
      ) : recentScansData.length === 0 && queue.filter(q => !q.synced).length === 0 ? (
        <div className="flex flex-col items-center justify-center py-10 gap-2 text-muted-foreground/50">
          <QrCode className="h-8 w-8" />
          <p className="text-xs text-center">No scans this session.<br />Scan a QR code to get started.</p>
        </div>
      ) : (
        <>
          {/* Unsynced local queue items first */}
          {queue.filter(q => !q.synced).map((scan) => (
            <div key={scan.id} className="relative overflow-hidden rounded-xl">
              <div className="absolute inset-0 flex items-center justify-end pr-5 bg-red-600 rounded-xl">
                <Trash2 className="h-5 w-5 text-white" />
              </div>
              <motion.div
                drag="x"
                dragConstraints={{ left: -80, right: 0 }}
                dragElastic={0.1}
                dragMomentum={false}
                onDragEnd={(_e, info) => { if (info.offset.x < -60) setQueue(prev => prev.filter(q => q.id !== scan.id)); }}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="relative"
              >
                <button className="w-full text-left cursor-pointer" onClick={() => {
                  if (isDcvQrCode(scan.qrValue)) {
                    setScannedQr(scan.qrValue);
                    setCardSheetOpen(true);
                  } else {
                    setScannedBarcode(scan.qrValue);
                    setBarcodeSheetOpen(true);
                  }
                }}>
                  <Card className="border-border hover:border-primary/40 transition-colors">
                    <CardContent className="p-3 flex items-center gap-3">
                      <XCircle className="h-4 w-4 text-amber-500 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium truncate text-foreground">{scan.cardName ?? "Pending…"}</p>
                        <p className="text-xs text-muted-foreground">{formatDate(scan.scannedAt)}</p>
                      </div>
                      <Badge className="bg-amber-600/20 text-amber-500 border-amber-700/30">Pending</Badge>
                      <span className="text-[9px] font-semibold text-muted-foreground/40 uppercase tracking-widest">Tap to view</span>
                    </CardContent>
                  </Card>
                </button>
              </motion.div>
            </div>
          ))}
          {/* Synced scans from backend */}
          {recentScansData.map((scan) => (
            <button
              key={scan.id}
              className="w-full text-left cursor-pointer"
              onClick={() => {
                if (isDcvQrCode(scan.qrValue)) {
                  setScannedQr(scan.qrValue);
                  setCardSheetOpen(true);
                } else {
                  setScannedBarcode(scan.qrValue);
                  setBarcodeSheetOpen(true);
                }
              }}
            >
              <Card className="border-border hover:border-primary/40 transition-colors">
                <CardContent className="p-3 flex items-center gap-3">
                  <CheckCircle className="h-4 w-4 text-profit shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium truncate text-foreground">{scan.cardName}</p>
                    <p className="text-xs text-muted-foreground">{formatDate(scan.scannedAt)}</p>
                  </div>
                  <Badge className="bg-profit/20 text-profit border-profit/30 capitalize">{scan.action === "scan" ? "Scanned" : scan.action}</Badge>
                  <span className="text-[9px] font-semibold text-muted-foreground/40 uppercase tracking-widest">Tap to view</span>
                </CardContent>
              </Card>
            </button>
          ))}
        </>
      )}
    </div>
  );

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-sans text-primary tracking-widest">Scan</h1>
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            className="gap-1.5 font-bold"
            onClick={() => setBulkSaleOpen(true)}
          >
            <Users className="h-4 w-4" />
            <span className="hidden sm:inline">Bulk Sale</span>
            <span className="sm:hidden">Bulk</span>
          </Button>
          <div className={`flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full border ${isOnline ? "border-profit/30 text-profit bg-profit/10" : "border-red-600/30 text-red-400 bg-red-400/10"}`}>
            {isOnline ? <Wifi className="h-3 w-3" /> : <WifiOff className="h-3 w-3" />}
            {isOnline ? "Online" : "Offline"}
          </div>
        </div>
      </div>

      {/* Bulk Sale pro tip — always visible */}
      <div className="flex gap-3 px-4 py-3 rounded-xl border border-orange-500/25 bg-orange-500/8">
        <ShoppingCart className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
        <div>
          <p className="text-[10px] font-black tracking-widest text-orange-400 uppercase mb-0.5">Pro Tip — Bulk Sale</p>
          <p className="text-xs text-muted-foreground leading-relaxed">
            Selling a customer multiple items? Use <strong className="text-foreground">Bulk Sale</strong> — scan up to 100 cards <strong className="text-foreground">and sealed products</strong> (QR labels or barcodes), set a price each, confirm the whole sale in one tap, and send a combined receipt. Find it on the Dashboard or tap <strong className="text-foreground">Bulk</strong> above.
          </p>
        </div>
      </div>

      {/* Desktop pro tip — desktop only */}
      <div className="hidden md:flex items-start gap-3 px-4 py-3 rounded-xl border border-blue-500/25 bg-blue-500/8">
        <Monitor className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
        <div>
          <p className="text-[10px] font-black tracking-widest text-blue-400 uppercase mb-0.5">Desktop Pro Tip</p>
          <p className="text-xs text-muted-foreground leading-relaxed">No camera on desktop? Open the app on your phone — both the QR scanner and the card photo camera work great on mobile. Everything syncs instantly, so anything you scan or photograph on your phone appears on desktop straight away.</p>
        </div>
      </div>

      {/* Bulk Sale dialog */}
      <Dialog open={bulkSaleOpen} onOpenChange={setBulkSaleOpen}>
        <DialogContent className="max-w-lg p-0 overflow-hidden">
          <BulkSale onClose={() => setBulkSaleOpen(false)} />
        </DialogContent>
      </Dialog>

      {/* Pending sync */}
      {pending > 0 && (
        <div className="flex items-center justify-between p-3 rounded-xl bg-amber-500/10 border border-amber-700/30">
          <div>
            <span className="text-sm text-amber-500 font-medium">{pending} scan{pending > 1 ? "s" : ""} queued offline</span>
            <p className="text-[10px] text-amber-500/70 mt-0.5">Connect to internet before 6am to sync</p>
          </div>
          <Button size="sm" variant="secondary" onClick={syncQueue} disabled={!isOnline || syncing}>
            {syncing ? "Syncing..." : "Sync Now"}
          </Button>
        </div>
      )}

      {/* Scanner + Recent Scans stacked, centered */}
      <div className="flex flex-col gap-5 items-center">
        {/* Scanner */}
        <div className="w-full max-w-md space-y-5">
          {/* Mode tabs */}
          <div className="flex gap-1 bg-secondary/60 p-1 rounded-xl">
            <button key="qr" onClick={() => setMode("qr")}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-sm font-semibold transition-all cursor-pointer ${mode === "qr" ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground hover:text-foreground"}`}>
              <QrCode className="h-4 w-4" />
              <span>Scan</span>
              <Barcode className="h-4 w-4" />
            </button>
            <button key="card" onClick={() => setMode("card")}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-semibold transition-all cursor-pointer ${mode === "card" ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground hover:text-foreground"}`}>
              <Camera className="h-4 w-4" /> Add New Card
            </button>
          </div>

          <AnimatePresence mode="wait">
            {/* QR Mode */}
            {mode === "qr" && (
              <motion.div key="qr" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
                <Card>
                  <CardContent className="p-4">
                    <QrScannerPanel onScan={handleQrScanned} scanSound={scanSound} scanHaptics={scanHaptics} soundType={soundType} />
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Add Card Mode */}
            {mode === "card" && (
              <motion.div key="card" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
                <Card>
                  <CardContent className="p-4 space-y-3">
                    <p className="text-sm text-muted-foreground text-center">
                      Take a photo of a card to add it to your inventory with an auto-generated QR label.
                    </p>
                    {"ontouchstart" in window ? (
                      /* Mobile: tap button opens native full camera */
                      <>
                        <input
                          ref={captureFileInputRef}
                          type="file"
                          accept="image/*"
                          capture="environment"
                          className="hidden"
                          onChange={handleCaptureFileChange}
                        />
                        <button
                          onClick={() => captureFileInputRef.current?.click()}
                          className="w-full h-40 rounded-2xl border-2 border-dashed border-primary/40 bg-primary/5 hover:bg-primary/10 hover:border-primary/60 transition-all cursor-pointer flex flex-col items-center justify-center gap-3"
                        >
                          <div className="w-14 h-14 rounded-2xl bg-primary/15 flex items-center justify-center">
                            <Camera className="h-8 w-8 text-primary" />
                          </div>
                          <span className="font-semibold text-primary">Tap to Take Photo</span>
                        </button>
                      </>
                    ) : (
                      /* Desktop: inline webcam, click video to capture */
                      <div className="space-y-3">
                        {addCardCameraError ? (
                          <CameraErrorPanel
                            error={addCardCameraError}
                            onRetry={() => setAddCardCameraError(null)}
                            compact
                          />
                        ) : (
                          <div
                            className="relative rounded-2xl overflow-hidden border border-border bg-black cursor-pointer group"
                            style={{ aspectRatio: "4/3" }}
                            onClick={handleCardCapture}
                            title="Click to capture"
                          >
                            <Webcam
                              ref={webcamRef}
                              videoConstraints={{ facingMode, aspectRatio: 4 / 3 }}
                              className="w-full h-full object-cover"
                              screenshotFormat="image/jpeg"
                              onUserMediaError={(err) => {
                                const name = err instanceof DOMException ? err.name : "";
                                let msg: string;
                                if (name === "NotAllowedError") {
                                  msg = "NotAllowedError: Camera permission denied.";
                                } else if (name === "NotReadableError" || name === "AbortError") {
                                  msg = "NotReadableError: Camera is in use by another app.";
                                } else if (name === "NotFoundError") {
                                  msg = "NotFoundError: No camera hardware detected.";
                                } else {
                                  msg = `${name || "Unknown"}: Could not access camera.`;
                                }
                                setAddCardCameraError(msg);
                              }}
                            />
                            {/* Card frame */}
                            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                              <div className="border-2 border-dashed border-white/60 rounded-lg shadow-[0_0_0_2000px_rgba(0,0,0,0.3)]" style={{ width: "52%", aspectRatio: "2.5/3.5" }} />
                            </div>
                            {/* Capture hint overlay */}
                            <div className="absolute inset-0 flex items-end justify-center pb-4 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                              <span className="px-3 py-1.5 rounded-full bg-black/70 text-white text-xs font-semibold flex items-center gap-1.5">
                                <Camera className="h-3.5 w-3.5" /> Click to capture
                              </span>
                            </div>
                            <div className="absolute bottom-3 left-3">
                              <button
                                onClick={e => { e.stopPropagation(); setFacingMode(f => f === "environment" ? "user" : "environment"); }}
                                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/60 text-white text-xs font-medium cursor-pointer"
                              >
                                <RotateCcw className="h-3 w-3" /> Flip
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Recent scans below scanner */}
          {recentScansList}
        </div>
      </div>

      {/* Card Action Sheet Dialog */}
      <Dialog open={cardSheetOpen} onOpenChange={o => { if (!o) { setCardSheetOpen(false); setEditOnOpen(false); } }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <div className="flex items-center justify-between gap-2 pr-6">
              <DialogTitle className="font-sans text-primary tracking-widest flex items-center gap-2">
                <ScanLine className="h-4 w-4" /> Card Scanned
              </DialogTitle>
              {scannedCard && !isNotMyCard && scannedCard.sold && (
                <Button
                  size="sm"
                  variant="secondary"
                  className="gap-1.5 h-8 text-xs font-semibold shrink-0"
                  onClick={() => {
                    // Signal to CardActionSheet to show edit view — we use a key trick via state
                    setEditOnOpen(true);
                  }}
                >
                  <Pencil className="h-3.5 w-3.5" /> Edit
                </Button>
              )}
            </div>
          </DialogHeader>
          {scannedCard === undefined && (
            <div className="py-8 flex flex-col items-center gap-3 text-muted-foreground">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="text-sm">Looking up card…</p>
            </div>
          )}
          {isNotMyCard && (
            <div className="py-6 space-y-4">
              <div className="flex flex-col items-center gap-3 text-center">
                <div className="w-14 h-14 rounded-2xl bg-amber-600/10 border border-amber-600/20 flex items-center justify-center">
                  <AlertCircle className="h-7 w-7 text-amber-500" />
                </div>
                <div>
                  <p className="font-bold text-lg">Card Not Found</p>
                  <p className="text-sm text-muted-foreground mt-1">This QR code isn&apos;t linked to any card in your vault.</p>
                </div>
              </div>
              <div className="rounded-lg bg-secondary/50 border border-border px-3 py-2">
                <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold mb-1">Scanned QR</p>
                <p className="text-xs text-foreground font-mono break-all">{scannedQr}</p>
              </div>
              <div className="rounded-lg bg-secondary/50 border border-border px-3 py-2.5 space-y-1.5">
                <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">What to try</p>
                <ul className="text-xs text-muted-foreground space-y-1">
                  <li className="flex items-start gap-2"><span className="text-amber-500 font-bold">•</span> Check the label matches a card in your Inventory</li>
                  <li className="flex items-start gap-2"><span className="text-amber-500 font-bold">•</span> Re-scan — the camera may have misread the QR</li>
                  <li className="flex items-start gap-2"><span className="text-amber-500 font-bold">•</span> The label may belong to a different vault</li>
                </ul>
              </div>
              <Button className="w-full" variant="secondary" onClick={() => setCardSheetOpen(false)}>Close & Re-scan</Button>
            </div>
          )}
          {scannedCard && !isNotMyCard && scannedCard.sold && (
            <div className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-amber-500/10 border border-amber-600/20">
              <div className="w-8 h-8 rounded-lg bg-amber-500/15 flex items-center justify-center shrink-0">
                <AlertCircle className="h-4 w-4 text-amber-500" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-xs font-bold text-amber-500">Already Sold</p>
                <p className="text-[10px] text-muted-foreground">This card has already been marked as sold{scannedCard.soldAt ? ` on ${new Date(scannedCard.soldAt).toLocaleDateString()}` : ""}.</p>
              </div>
            </div>
          )}
          {scannedCard && (
            <CardActionSheet
              key={editOnOpen ? "edit" : "actions"}
              card={scannedCard as ScannedCard}
              currency={currency}
              user={user}
              onClose={() => { setCardSheetOpen(false); setEditOnOpen(false); }}
              initialView={editOnOpen ? "edit" : "actions"}
              scanSound={scanSound}
              scanHaptics={scanHaptics}
              soundType={soundType}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Add Card Dialog */}
      <Dialog open={showAddDialog} onOpenChange={o => { if (!saving) { if (!o && Date.now() - addDialogOpenTimeRef.current < 500) return; setShowAddDialog(o); if (!o) { setCapturedImage(null); setCapturedBackImage(null); } } }}>
        <DialogContent className="max-w-lg max-h-[90dvh] overflow-y-auto" onPointerDownOutside={e => e.preventDefault()} onInteractOutside={e => e.preventDefault()} onFocusOutside={e => e.preventDefault()}>
          <DialogHeader>
            <DialogTitle className="font-sans text-primary tracking-widest flex items-center gap-2">
              <Package className="h-4 w-4" /> Add Card to Vault
            </DialogTitle>
          </DialogHeader>
          {/* Front & Back photos */}
          <div className="flex gap-3">
            {capturedImage && (
              <div className="flex-1 space-y-1">
                <p className="text-[10px] font-bold tracking-widest text-muted-foreground uppercase">Front</p>
                <div className="relative rounded-xl overflow-hidden border border-border">
                  <img src={capturedImage} alt="Front" className="w-full h-24 object-cover bg-black" />
                  <Button size="sm" variant="destructive" className="absolute top-1 right-1 h-6 w-6 p-0" onClick={() => setCapturedImage(null)}>
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            )}
            {capturedBackImage ? (
              <div className="flex-1 space-y-1">
                <p className="text-[10px] font-bold tracking-widest text-muted-foreground uppercase">Back</p>
                <div className="relative rounded-xl overflow-hidden border border-border">
                  <img src={capturedBackImage} alt="Back" className="w-full h-24 object-cover bg-black" />
                  <Button size="sm" variant="destructive" className="absolute top-1 right-1 h-6 w-6 p-0" onClick={() => setCapturedBackImage(null)}>
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex-1 space-y-1">
                <p className="text-[10px] font-bold tracking-widest text-muted-foreground uppercase">Back</p>
                <input
                  ref={captureBackFileInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                  onChange={handleBackPhotoCapture}
                />
                <button
                  onClick={() => captureBackFileInputRef.current?.click()}
                  className="w-full h-24 rounded-xl border-2 border-dashed border-muted-foreground/30 bg-secondary/50 hover:bg-secondary hover:border-primary/40 transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5"
                >
                  <Camera className="h-5 w-5 text-muted-foreground" />
                  <span className="text-[10px] font-semibold text-muted-foreground">Take Back Photo</span>
                </button>
              </div>
            )}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2 space-y-1">
              <Label>Card Name *</Label>
              <Input placeholder="e.g. Charizard" maxLength={25} value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value.slice(0, 25) }))} />
            </div>
            <div className="space-y-1">
              <Label>Game</Label>
              <Select value={form.game} onValueChange={v => setForm(f => ({ ...f, game: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{GAMES.map(g => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="col-span-2">
              <DuplicateWarning name={form.name} game={form.game} currency={currency} />
            </div>
            <div className="space-y-1">
              <Label>Condition</Label>
              <Select value={form.condition} onValueChange={v => setForm(f => ({ ...f, condition: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{CONDITIONS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Set</Label>
              <Input placeholder="e.g. Base Set" value={form.set} onChange={e => setForm(f => ({ ...f, set: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label>Grade</Label>
              <Input placeholder="e.g. PSA 10" value={form.grade} onChange={e => setForm(f => ({ ...f, grade: e.target.value }))} />
            </div>
            <div className="col-span-2 space-y-1">
              <Label>% Bought At</Label>
              <Select
                value=""
                onValueChange={pct => {
                  const mv = parseFloat(form.marketValue);
                  if (!isNaN(mv) && mv > 0) {
                    setForm(f => ({ ...f, purchasePrice: (mv * parseInt(pct) / 100).toFixed(2) }));
                  }
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder={
                    form.purchasePrice && form.marketValue && parseFloat(form.marketValue) > 0
                      ? `${Math.round((parseFloat(form.purchasePrice) / parseFloat(form.marketValue)) * 100)}% of market`
                      : "Quick fill…"
                  } />
                </SelectTrigger>
                <SelectContent>
                  {[10, 20, 30, 40, 50, 60, 70, 80, 90, 100].map(pct => (
                    <SelectItem key={pct} value={String(pct)}>
                      {pct}%
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Purchase Price ({currency})</Label>
              <Input type="number" step="0.01" placeholder="0.00" value={form.purchasePrice} onChange={e => setForm(f => ({ ...f, purchasePrice: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label>Market Value ({currency})</Label>
              <Input type="number" step="0.01" placeholder="0.00" value={form.marketValue} onChange={e => setForm(f => ({ ...f, marketValue: e.target.value }))} />
            </div>
            <div className="col-span-2 space-y-1">
              <Label>Notes</Label>
              <Textarea placeholder="Any notes..." value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} rows={2} />
            </div>
          </div>
          <Separator />
          <div className="flex items-center gap-2 p-3 rounded-xl bg-primary/10 border border-primary/20 text-xs text-primary">
            <Tag className="h-3.5 w-3.5 shrink-0" />
            A QR label will be auto-generated for this card.
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => { setShowAddDialog(false); setCapturedImage(null); setCapturedBackImage(null); }}>Cancel</Button>
            <Button onClick={handleSaveCard} disabled={saving} className="gap-2">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              {saving ? "Saving..." : "Add to Vault"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Sealed Product Sheet ── */}
      <Dialog open={barcodeSheetOpen} onOpenChange={o => { if (!o) setBarcodeSheetOpen(false); }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <div className="flex items-center gap-2 pr-6">
              <Barcode className="h-4 w-4 text-blue-400 shrink-0" />
              <DialogTitle className="text-base font-bold">Sealed Product</DialogTitle>
            </div>
          </DialogHeader>
          {scannedBarcode && (
            scannedSealedProduct === undefined ? (
              <div className="py-8 flex flex-col items-center gap-3 text-muted-foreground">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <p className="text-sm">Looking up product…</p>
              </div>
            ) : (
              <SealedProductSheet
                barcode={scannedBarcode}
                product={scannedSealedProduct}
                currency={currency}
                onClose={() => setBarcodeSheetOpen(false)}
              />
            )
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
