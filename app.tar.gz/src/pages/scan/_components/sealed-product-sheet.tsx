import { useState } from "react";
import { useMutation, useQuery, useAction } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { ShoppingCart, Plus, Loader2, Package, Pencil, CheckCircle, Mail, XCircle, AlertCircle, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import { formatCurrency } from "@/lib/utils.ts";
import { motion, AnimatePresence } from "motion/react";

const GAMES = ["Pokémon", "Magic: The Gathering", "Yu-Gi-Oh! Official", "One Piece", "Flesh and Blood", "Digimon", "Star Wars: Unlimited", "Weiss Schwarz", "Cardfight!! Vanguard", "Lorcana", "Dragon Ball Super", "Other"];
const PRODUCT_TYPES = [
  "Booster Pack", "Booster Box", "Elite Trainer Box (ETB)", "Half Booster Box",
  "Mini Tin", "Tin", "Collection Box", "Premium Collection", "Ultra Premium Collection (UPC)",
  "Bundle", "Blister Pack", "3-Pack Blister", "Build & Battle Box", "Stadium",
  "Special Set Box", "Starter Deck", "Theme Deck", "Gift Set", "Promo Pack", "Display Case", "Other",
];

type SealedProduct = {
  _id: Id<"sealedProducts">;
  name: string;
  game: string;
  type: string;
  barcode: string;
  purchasePrice?: number;
  sellPrice?: number;
  quantity: number;
  notes?: string;
  soldAt?: string;
};

type View = "actions" | "sell" | "edit" | "add" | "restock";

export default function SealedProductSheet({
  barcode,
  product,
  onClose,
  currency,
}: {
  barcode: string;
  product: SealedProduct | null;
  onClose: () => void;
  currency: string;
}) {
  const [view, setView] = useState<View>(product ? "actions" : "add");
  const [salePrice, setSalePrice] = useState(product?.sellPrice?.toString() ?? "");
  const [receiptEmail, setReceiptEmail] = useState("");
  const [selling, setSelling] = useState(false);
  const [sendingReceipt, setSendingReceipt] = useState(false);
  const [restockQty, setRestockQty] = useState("1");
  const [restocking, setRestocking] = useState(false);
  const [form, setForm] = useState({
    name: product?.name ?? "",
    game: product?.game ?? "Pokémon",
    type: product?.type ?? "Booster Pack",
    barcode: barcode,
    purchasePrice: product?.purchasePrice?.toString() ?? "",
    sellPrice: product?.sellPrice?.toString() ?? "",
    quantity: product?.quantity?.toString() ?? "1",
    notes: product?.notes ?? "",
  });
  const [saving, setSaving] = useState(false);

  const user = useQuery(api.users.getCurrentUser, {});
  const addProduct = useMutation(api.sealedProducts.addSealedProduct);
  const updateProduct = useMutation(api.sealedProducts.updateSealedProduct);
  const sellOne = useMutation(api.sealedProducts.sellOne);
  const restockProduct = useMutation(api.sealedProducts.restockProduct);
  const sendReceipt = useAction(api.emails.sendReceipt);

  const handleSell = async () => {
    if (!product) return;
    if (product.quantity <= 0) {
      toast.error("This product is out of stock");
      return;
    }
    const price = parseFloat(salePrice);
    if (!salePrice.trim()) {
      toast.error("Enter a sale price to continue");
      return;
    }
    if (isNaN(price) || price <= 0) {
      toast.error("Sale price must be greater than 0");
      return;
    }
    setSelling(true);
    const now = new Date();
    const d = now.getHours() < 6 ? new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1) : now;
    const localDate = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    try {
      await sellOne({ id: product._id, salePrice: price, localDate });
      toast.success(`Sold ${product.name} for ${formatCurrency(price, currency)}`);

      // Send receipt if email entered
      if (receiptEmail.trim()) {
        if (!user?.senderEmail) {
          toast.error("Set your sender email in Settings to send receipts");
        } else {
          setSendingReceipt(true);
          try {
            await sendReceipt({
              to: receiptEmail.trim(),
              senderEmail: user.senderEmail,
              cardName: product.name,
              game: product.game,
              condition: product.type,
              salePrice: price,
              currency,
              businessName: user?.businessName,
              instagram: user?.instagram,
              website: user?.website,
            });
            toast.success("Receipt sent!");
          } catch {
            toast.error("Sale logged but receipt failed to send");
          } finally {
            setSendingReceipt(false);
          }
        }
      }

      onClose();
    } catch {
      toast.error("Failed to record sale");
    } finally {
      setSelling(false);
    }
  };

  const handleRestock = async () => {
    if (!product) return;
    const qty = parseInt(restockQty);
    if (isNaN(qty) || qty <= 0) {
      toast.error("Enter a quantity greater than 0");
      return;
    }
    setRestocking(true);
    try {
      await restockProduct({ id: product._id, quantity: qty });
      toast.success(`Restocked ${qty} unit${qty > 1 ? "s" : ""} of ${product.name}`);
      onClose();
    } catch {
      toast.error("Failed to restock");
    } finally {
      setRestocking(false);
    }
  };

  const handleSave = async () => {
    if (!form.name.trim() || !form.barcode.trim()) return;
    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        game: form.game,
        type: form.type,
        barcode: form.barcode.trim(),
        purchasePrice: form.purchasePrice ? parseFloat(form.purchasePrice) : undefined,
        sellPrice: form.sellPrice ? parseFloat(form.sellPrice) : undefined,
        quantity: parseInt(form.quantity) || 1,
        notes: form.notes || undefined,
      };
      if (product) {
        await updateProduct({ id: product._id, ...payload });
        toast.success("Product updated");
      } else {
        await addProduct(payload);
        toast.success("Product added to sealed inventory");
      }
      onClose();
    } catch {
      toast.error("Failed to save product");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header banner */}
      <div className="rounded-xl p-4 border bg-blue-500/8 border-blue-500/20">
        <div className="flex items-start justify-between gap-2">
          <div>
            <div className="flex items-center gap-2">
              <Package className="h-4 w-4 text-blue-400 shrink-0" />
              <p className="font-bold text-lg leading-tight">{product?.name ?? "New Sealed Product"}</p>
            </div>
            {product && (
              <p className="text-sm text-muted-foreground mt-0.5">{product.game} · {product.type}</p>
            )}
            <div className="flex items-center gap-2 mt-2 flex-wrap">
              <Badge variant="secondary" className="text-xs font-mono">{barcode}</Badge>
              {product && (
                <Badge className="text-xs bg-blue-600/20 text-blue-400 border-blue-700/30">
                  {product.quantity} in stock
                </Badge>
              )}
            </div>
          </div>
          {product?.sellPrice !== undefined && (
            <p className="text-2xl font-black text-blue-400 shrink-0">{formatCurrency(product.sellPrice, currency)}</p>
          )}
        </div>
      </div>

      <AnimatePresence mode="wait">
        {/* Actions view */}
        {view === "actions" && product && (
          <motion.div key="actions" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }} className="space-y-2">
            {product.soldAt && (
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30">
                <AlertCircle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                <div className="text-xs">
                  <p className="font-bold text-amber-400">Already Sold</p>
                  <p className="text-muted-foreground">
                    Last unit sold on {new Date(product.soldAt).toLocaleDateString(undefined, { dateStyle: "medium" })}.
                    {product.quantity > 0 ? ` ${product.quantity} unit${product.quantity > 1 ? "s" : ""} still in stock.` : " No stock remaining."}
                  </p>
                </div>
              </div>
            )}
            {!product.soldAt && product.quantity <= 0 && (
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-400">
                <XCircle className="h-4 w-4 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold">Out of Stock</p>
                  <p className="text-muted-foreground">0 units remaining — restock from the Inventory page before selling.</p>
                </div>
              </div>
            )}
            <button
              onClick={() => { setSalePrice(product.sellPrice?.toString() ?? ""); setView("sell"); }}
              className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl bg-primary text-primary-foreground font-semibold cursor-pointer hover:bg-primary/90 transition-colors"
            >
              <ShoppingCart className="h-5 w-5 shrink-0" />
              <span>Sell One Unit</span>
            </button>
            <button
              onClick={() => setView("edit")}
              className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl bg-secondary text-secondary-foreground font-semibold cursor-pointer hover:bg-secondary/80 transition-colors border border-border"
            >
              <Pencil className="h-5 w-5 shrink-0" />
              <span>Edit Product</span>
            </button>
            <button
              onClick={() => { setRestockQty("1"); setView("restock"); }}
              className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl bg-secondary text-secondary-foreground font-semibold cursor-pointer hover:bg-secondary/80 transition-colors border border-border"
            >
              <RotateCcw className="h-5 w-5 shrink-0" />
              <span>Restock</span>
            </button>
          </motion.div>
        )}

        {/* Sell view */}
        {view === "sell" && product && (
          <motion.div key="sell" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }} className="space-y-4">
            <button onClick={() => setView("actions")} className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 cursor-pointer">← Back</button>
            {product.soldAt && product.quantity <= 0 && (
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs">
                <AlertCircle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-amber-400">Already Sold — No Stock Remaining</p>
                  <p className="text-muted-foreground">All units have been sold. Restock from the Inventory page before selling again.</p>
                </div>
              </div>
            )}
            {!product.soldAt && product.quantity <= 0 && (
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-400">
                <XCircle className="h-4 w-4 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold">Out of Stock</p>
                  <p className="text-muted-foreground">This product has 0 units in stock and cannot be sold. Restock it first from the Inventory page.</p>
                </div>
              </div>
            )}
            <div className="space-y-1">
              <Label className="text-sm font-semibold">Sale Price ({currency})</Label>
              <Input
                type="number" step="0.01" autoFocus
                placeholder={product.sellPrice?.toString() ?? "0.00"}
                value={salePrice}
                onChange={e => setSalePrice(e.target.value)}
                className="text-xl font-bold h-14 text-center"
                disabled={product.quantity <= 0}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-semibold flex items-center gap-1.5">
                <Mail className="h-3.5 w-3.5 text-muted-foreground" />
                Customer Email
                <span className="text-muted-foreground font-normal text-xs">(optional — sends receipt)</span>
              </Label>
              <Input
                type="email"
                placeholder="customer@example.com"
                value={receiptEmail}
                onChange={e => setReceiptEmail(e.target.value)}
                disabled={product.quantity <= 0}
              />
            </div>
            {product.quantity > 0 && (
              <div className="flex items-start gap-2 p-3 rounded-xl bg-profit/10 border border-profit/20 text-xs text-profit">
                <CheckCircle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                Sale logged to Earnings. Stock reduced by 1.
              </div>
            )}
            <Button
              onClick={handleSell}
              disabled={selling || sendingReceipt || product.quantity <= 0}
              className="w-full h-12 text-base font-bold gap-2"
            >
              {(selling || sendingReceipt) ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShoppingCart className="h-4 w-4" />}
              {selling ? "Logging sale..." : sendingReceipt ? "Sending receipt..." : product.quantity <= 0 ? "Out of Stock" : `Confirm Sale · ${salePrice ? formatCurrency(parseFloat(salePrice) || 0, currency) : "—"}`}
            </Button>
            {receiptEmail.trim() && (
              <p className="text-[10px] text-muted-foreground leading-relaxed"><span className="font-bold text-foreground">Pro tip:</span> Let the customer know their receipt might land in their <span className="font-semibold text-foreground">junk mail</span> or <span className="font-semibold text-foreground">spam</span> folder.</p>
            )}
          </motion.div>
        )}

        {/* Restock view */}
        {view === "restock" && product && (
          <motion.div key="restock" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }} className="space-y-4">
            <button onClick={() => setView("actions")} className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 cursor-pointer">← Back</button>
            <div className="space-y-1">
              <Label className="text-sm font-semibold">Units to Add</Label>
              <Input
                type="number" min="1" step="1" autoFocus
                value={restockQty}
                onChange={e => setRestockQty(e.target.value)}
                className="text-xl font-bold h-14 text-center"
                placeholder="1"
              />
              <p className="text-xs text-muted-foreground text-center">
                Current stock: {product.quantity} unit{product.quantity !== 1 ? "s" : ""}
                {restockQty && parseInt(restockQty) > 0 ? ` → ${product.quantity + (parseInt(restockQty) || 0)} after restock` : ""}
              </p>
            </div>
            <Button onClick={handleRestock} disabled={restocking} className="w-full h-12 text-base font-bold gap-2">
              {restocking ? <Loader2 className="h-4 w-4 animate-spin" /> : <RotateCcw className="h-4 w-4" />}
              {restocking ? "Restocking…" : `Add ${restockQty && parseInt(restockQty) > 0 ? parseInt(restockQty) : "—"} Unit${parseInt(restockQty) !== 1 ? "s" : ""}`}
            </Button>
          </motion.div>
        )}

        {/* Add / Edit form */}
        {(view === "add" || view === "edit") && (
          <motion.div key="form" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }} className="space-y-3">
            {view === "edit" && (
              <button onClick={() => setView("actions")} className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 cursor-pointer">← Back</button>
            )}
            {view === "add" && (
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30">
                <Package className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                <div className="text-xs">
                  <p className="font-bold text-amber-400">Barcode Not Found</p>
                  <p className="text-muted-foreground">This barcode isn&apos;t in your sealed inventory yet. Fill in the details below to add it.</p>
                </div>
              </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2 space-y-1">
                <Label>Product Name *</Label>
                <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="e.g. Prismatic Evolutions ETB" />
              </div>
              <div className="space-y-1">
                <Label>Game</Label>
                <Select value={form.game} onValueChange={v => setForm(f => ({ ...f, game: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{GAMES.map(g => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label>Type</Label>
                <Select value={form.type} onValueChange={v => setForm(f => ({ ...f, type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{PRODUCT_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label>Purchase Price</Label>
                <Input type="number" step="0.01" placeholder="0.00" value={form.purchasePrice} onChange={e => setForm(f => ({ ...f, purchasePrice: e.target.value }))} />
              </div>
              <div className="space-y-1">
                <Label>Sell Price</Label>
                <Input type="number" step="0.01" placeholder="0.00" value={form.sellPrice} onChange={e => setForm(f => ({ ...f, sellPrice: e.target.value }))} />
              </div>
              <div className="space-y-1">
                <Label>Quantity</Label>
                <Input type="number" min="0" placeholder="1" value={form.quantity} onChange={e => setForm(f => ({ ...f, quantity: e.target.value }))} />
              </div>
              <div className="space-y-1">
                <Label>Barcode</Label>
                <Input value={form.barcode} onChange={e => setForm(f => ({ ...f, barcode: e.target.value }))} />
              </div>
              <div className="col-span-2 space-y-1">
                <Label>Notes</Label>
                <Textarea placeholder="Any notes..." value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} rows={2} />
              </div>
            </div>
            <Button onClick={handleSave} disabled={saving} className="w-full gap-2">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              {saving ? "Saving..." : product ? "Save Changes" : "Add to Sealed Inventory"}
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
