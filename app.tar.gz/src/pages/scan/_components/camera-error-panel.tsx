import { useState } from "react";
import { motion } from "motion/react";
import { AlertCircle, ShieldAlert, VideoOff, MonitorSmartphone, RefreshCw, ChevronDown, ChevronUp, Plus } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";

/* ─── Error type detection ─── */
type CameraErrorType = "permission_denied" | "in_use" | "no_hardware" | "unknown";

function detectErrorType(error: string): CameraErrorType {
  const lower = error.toLowerCase();
  if (lower.includes("permission") || lower.includes("notallowed") || lower.includes("denied")) {
    return "permission_denied";
  }
  if (lower.includes("in use") || lower.includes("notreadable") || lower.includes("aborterror") || lower.includes("could not start video")) {
    return "in_use";
  }
  if (lower.includes("not found") || lower.includes("notfounderror") || lower.includes("no camera") || lower.includes("no hardware")) {
    return "no_hardware";
  }
  return "unknown";
}

/* ─── Browser detection ─── */
type BrowserType = "chrome_android" | "safari_ios" | "chrome_desktop" | "firefox" | "samsung" | "other";

function detectBrowser(): BrowserType {
  const ua = navigator.userAgent;
  const isIOS = /iPhone|iPad|iPod/.test(ua);
  const isAndroid = /Android/.test(ua);
  const isSamsung = /SamsungBrowser/.test(ua);
  const isFirefox = /Firefox/.test(ua) && !/Seamonkey/.test(ua);
  const isChrome = /Chrome/.test(ua) && !/Chromium|Edg/.test(ua);
  const isSafari = /Safari/.test(ua) && !/Chrome/.test(ua);

  if (isIOS && isSafari) return "safari_ios";
  if (isSamsung) return "samsung";
  if (isAndroid && isChrome) return "chrome_android";
  if (isFirefox) return "firefox";
  if (isChrome) return "chrome_desktop";
  return "other";
}

function getBrowserName(browser: BrowserType): string {
  switch (browser) {
    case "chrome_android": return "Chrome (Android)";
    case "safari_ios": return "Safari (iOS)";
    case "chrome_desktop": return "Chrome (Desktop)";
    case "firefox": return "Firefox";
    case "samsung": return "Samsung Internet";
    case "other": return "your browser";
  }
}

function getPermissionSteps(browser: BrowserType): string[] {
  switch (browser) {
    case "chrome_android":
      return [
        "Tap the lock icon (🔒) in the address bar",
        "Tap 'Site settings' or 'Permissions'",
        "Find 'Camera' and set to 'Allow'",
        "Come back here and tap 'Check Again'",
      ];
    case "safari_ios":
      return [
        "Open your iPhone/iPad Settings app",
        "Scroll down and tap 'Safari'",
        "Tap 'Camera' under 'Settings for Websites'",
        "Select 'Allow' or 'Ask'",
        "Come back here and tap 'Check Again'",
      ];
    case "chrome_desktop":
      return [
        "Click the lock/tune icon (🔒) in the address bar",
        "Find 'Camera' in the permissions list",
        "Change it from 'Block' to 'Allow'",
        "Come back here and tap 'Check Again'",
      ];
    case "firefox":
      return [
        "Click the lock icon (🔒) in the address bar",
        "Click 'Connection secure' → 'More information'",
        "Go to the 'Permissions' tab",
        "Find 'Use the Camera' and select 'Allow'",
        "Come back here and tap 'Check Again'",
      ];
    case "samsung":
      return [
        "Tap the menu icon (☰) in the bottom bar",
        "Tap 'Settings' → 'Sites and downloads'",
        "Tap 'Site permissions' → 'Camera'",
        "Set to 'Allow'",
        "Come back here and tap 'Check Again'",
      ];
    case "other":
      return [
        "Open your browser settings or site permissions",
        "Find the Camera permission for this site",
        "Change it from 'Block' to 'Allow'",
        "Come back here and tap 'Check Again'",
      ];
  }
}

/* ─── Error config ─── */
function getErrorConfig(type: CameraErrorType) {
  switch (type) {
    case "permission_denied":
      return {
        icon: ShieldAlert,
        title: "Camera Permission Blocked",
        description: "You've blocked camera access for this site. Follow the steps below to re-enable it.",
        color: "text-amber-500",
        bgColor: "bg-amber-500/10",
        borderColor: "border-amber-500/30",
      };
    case "in_use":
      return {
        icon: VideoOff,
        title: "Camera In Use",
        description: "Another app or browser tab is using your camera. Close it and try again.",
        color: "text-blue-400",
        bgColor: "bg-blue-500/10",
        borderColor: "border-blue-500/30",
      };
    case "no_hardware":
      return {
        icon: MonitorSmartphone,
        title: "No Camera Found",
        description: "We couldn't detect a camera on this device. Try on a phone or tablet with a camera, or check that your camera isn't disabled.",
        color: "text-red-400",
        bgColor: "bg-red-500/10",
        borderColor: "border-red-500/30",
      };
    case "unknown":
      return {
        icon: AlertCircle,
        title: "Camera Not Available",
        description: "Something went wrong while accessing your camera. This can happen if the camera was disconnected or another app grabbed it.",
        color: "text-red-400",
        bgColor: "bg-red-500/10",
        borderColor: "border-red-500/30",
      };
  }
}

/* ─── Component ─── */
type CameraErrorPanelProps = {
  error: string;
  onRetry: () => void;
  onAddManually?: () => void;
  compact?: boolean;
};

export default function CameraErrorPanel({ error, onRetry, onAddManually, compact = false }: CameraErrorPanelProps) {
  const [showSteps, setShowSteps] = useState(false);
  const [checking, setChecking] = useState(false);

  const errorType = detectErrorType(error);
  const config = getErrorConfig(errorType);
  const browser = detectBrowser();
  const browserName = getBrowserName(browser);
  const Icon = config.icon;

  const handleCheckAgain = async () => {
    setChecking(true);
    // Re-query permission state
    try {
      if (navigator.permissions) {
        const result = await navigator.permissions.query({ name: "camera" as PermissionName });
        if (result.state === "granted") {
          onRetry();
          return;
        }
        if (result.state === "prompt") {
          // Permission was reset — try again which will trigger the prompt
          onRetry();
          return;
        }
      }
    } catch {
      // permissions API not supported for camera in some browsers, just retry
    }
    // Fallback: just retry
    setTimeout(() => {
      setChecking(false);
      onRetry();
    }, 500);
  };

  if (compact) {
    return (
      <div className={`flex items-start gap-2.5 p-3 rounded-xl ${config.bgColor} border ${config.borderColor} text-xs`}>
        <Icon className={`h-4 w-4 shrink-0 mt-0.5 ${config.color}`} />
        <div className="space-y-1.5 flex-1">
          <p className={`font-bold ${config.color}`}>{config.title}</p>
          <p className="text-muted-foreground">{config.description}</p>
          <div className="flex gap-2 mt-2">
            <Button size="sm" variant="secondary" className="h-7 text-[11px] gap-1.5 cursor-pointer" onClick={handleCheckAgain} disabled={checking}>
              <RefreshCw className={`h-3 w-3 ${checking ? "animate-spin" : ""}`} />
              {checking ? "Checking…" : "Check Again"}
            </Button>
            {errorType === "permission_denied" && (
              <Button size="sm" variant="ghost" className="h-7 text-[11px] gap-1 cursor-pointer" onClick={() => setShowSteps(!showSteps)}>
                {showSteps ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                How to fix
              </Button>
            )}
          </div>
          {showSteps && errorType === "permission_denied" && (
            <div className="mt-2 pt-2 border-t border-border/50 space-y-1">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Steps for {browserName}</p>
              {getPermissionSteps(browser).map((step, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className={`text-[10px] font-black ${config.color} shrink-0 w-4`}>{i + 1}.</span>
                  <span className="text-[10px] text-muted-foreground">{step}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: [0.25, 0.1, 0.25, 1] as const }}
      className={`rounded-2xl ${config.bgColor} border ${config.borderColor} p-4 space-y-3`}
    >
      {/* Header */}
      <div className="flex items-start gap-3">
        <div className={`w-10 h-10 rounded-xl ${config.bgColor} border ${config.borderColor} flex items-center justify-center shrink-0`}>
          <Icon className={`h-5 w-5 ${config.color}`} />
        </div>
        <div className="space-y-1">
          <p className={`text-sm font-bold ${config.color}`}>{config.title}</p>
          <p className="text-xs text-muted-foreground leading-relaxed">{config.description}</p>
        </div>
      </div>

      {/* Browser-specific instructions for permission denied */}
      {errorType === "permission_denied" && (
        <div className="space-y-2">
          <button
            onClick={() => setShowSteps(!showSteps)}
            className="w-full flex items-center justify-between px-3 py-2 rounded-xl bg-background/50 border border-border/50 cursor-pointer hover:bg-background/80 transition-colors"
          >
            <span className="text-xs font-semibold text-foreground">How to re-enable camera in {browserName}</span>
            {showSteps ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
          </button>

          {showSteps && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="overflow-hidden rounded-xl bg-background/40 border border-border/50 p-3 space-y-2"
            >
              {getPermissionSteps(browser).map((step, i) => (
                <div key={i} className="flex items-start gap-2.5">
                  <div className={`w-5 h-5 rounded-md ${config.bgColor} border ${config.borderColor} flex items-center justify-center shrink-0`}>
                    <span className={`text-[10px] font-black ${config.color}`}>{i + 1}</span>
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed pt-0.5">{step}</p>
                </div>
              ))}
            </motion.div>
          )}
        </div>
      )}

      {/* In-use specific tip */}
      {errorType === "in_use" && (
        <div className="rounded-xl bg-background/40 border border-border/50 p-3 space-y-1.5">
          <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Things to try</p>
          {[
            "Close other apps using the camera (video calls, other camera apps)",
            "Close other browser tabs that might be using the camera",
            "On Android, check if any app has a camera overlay active",
          ].map((tip, i) => (
            <div key={i} className="flex items-start gap-2">
              <div className="w-1 h-1 rounded-full bg-blue-400/60 shrink-0 mt-1.5" />
              <span className="text-[10px] text-muted-foreground">{tip}</span>
            </div>
          ))}
        </div>
      )}

      {/* Action buttons */}
      <div className="flex flex-col gap-2">
        <Button
          onClick={handleCheckAgain}
          disabled={checking}
          className="w-full gap-2 cursor-pointer"
          size="sm"
        >
          <RefreshCw className={`h-4 w-4 ${checking ? "animate-spin" : ""}`} />
          {checking ? "Checking…" : "Check Again"}
        </Button>

        {onAddManually && (
          <Button
            onClick={onAddManually}
            variant="secondary"
            className="w-full gap-2 cursor-pointer"
            size="sm"
          >
            <Plus className="h-4 w-4" /> Add Card Manually
          </Button>
        )}
      </div>
    </motion.div>
  );
}
