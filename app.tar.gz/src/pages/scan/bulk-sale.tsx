import { useState, useRef, useCallback, useEffect } from "react";
import { useMutation, useAction, useQuery } from "convex/react";
import { motion, AnimatePresence } from "motion/react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { formatCurrency } from "@/lib/utils.ts";
import {
  ShoppingCart, ScanLine, Trash2, CheckCircle2,
  Mail, Loader2, Package, X, Receipt, ArrowLeft, Plus, Pencil, Check, RotateCcw, AlertCircle, Barcode,
} from "lucide-react";
import Webcam from "react-webcam";
import jsQR from "jsqr";
import { decodeBarcodeFromCanvas, isDcvQrCode } from "./_lib/barcode-decoder.ts";
import CameraErrorPanel from "./_components/camera-error-panel.tsx";

// ── Types ───────────────────────────────────────────────────────────────────

type BulkItem =
  | {
      type: "card";
      cardId: Id<"cards">;
      name: string;
      game: string;
      condition: string;
      set?: string;
      grade?: string;
      salePrice: number;
      marketValue?: number;
    }
  | {
      type: "sealed";
      productId: Id<"sealedProducts">;
      name: string;
      game: string;
      barcode: string;
      salePrice: number;
      sellPrice?: number;
    };

type ScannedCardLookup = {
  _id: Id<"cards">;
  name: string;
  game: string;
  condition: string;
  set?: string;
  grade?: string;
  marketValue?: number;
  purchasePrice?: number;
  sold: boolean;
};

type ScannedSealedLookup = {
  _id: Id<"sealedProducts">;
  name: string;
  game: string;
  barcode: string;
  sellPrice?: number;
  purchasePrice?: number;
  quantity: number;
};

type PendingItem =
  | { kind: "card"; card: ScannedCardLookup }
  | { kind: "sealed"; product: ScannedSealedLookup };

// ── Unique key per item ─────────────────────────────────────────────────────
function itemKey(item: BulkItem): string {
  return item.type === "card" ? `card:${item.cardId}` : `sealed:${item.productId}`;
}

// ── PendingAddRow ───────────────────────────────────────────────────────────
function PendingAddRow({
  pending,
  onAdd,
  onDismiss,
  currency,
}: {
  pending: PendingItem;
  onAdd: (item: BulkItem) => void;
  onDismiss: () => void;
  currency: string;
}) {
  const defaultPrice =
    pending.kind === "card"
      ? pending.card.marketValue?.toString() ?? ""
      : pending.product.sellPrice?.toString() ?? "";

  const [price, setPrice] = useState(defaultPrice);
  void currency;

  const handleAdd = () => {
    const p = parseFloat(price);
    if (isNaN(p) || p <= 0) return;
    if (pending.kind === "card") {
      const c = pending.card;
      onAdd({ type: "card", cardId: c._id, name: c.name, game: c.game, condition: c.condition, set: c.set, grade: c.grade, salePrice: p, marketValue: c.marketValue });
    } else {
      const s = pending.product;
      onAdd({ type: "sealed", productId: s._id, name: s.name, game: s.game, barcode: s.barcode, salePrice: p, sellPrice: s.sellPrice });
    }
  };

  const isSealed = pending.kind === "sealed";
  const displayName = pending.kind === "card" ? pending.card.name : pending.product.name;
  const displaySub = pending.kind === "card"
    ? `${pending.card.game}${pending.card.set ? ` · ${pending.card.set}` : ""}${pending.card.condition ? ` · ${pending.card.condition}` : ""}`
    : `${pending.product.game} · Sealed`;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.97, y: -6 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.97, y: -6 }}
      transition={{ type: "spring", stiffness: 300, damping: 28 }}
      className={`mx-4 rounded-2xl border-2 overflow-hidden ${isSealed ? "border-blue-500/50 bg-blue-500/6" : "border-primary/50 bg-primary/6"}`}
    >
      <div className="px-4 pt-3.5 pb-2 flex items-start justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${isSealed ? "bg-blue-500/15" : "bg-primary/15"}`}>
            {isSealed ? <Barcode className="h-4 w-4 text-blue-400" /> : <Package className="h-4 w-4 text-primary" />}
          </div>
          <div className="min-w-0">
            <p className="font-bold text-sm leading-tight truncate">{displayName}</p>
            <p className="text-[11px] text-muted-foreground truncate">{displaySub}</p>
          </div>
        </div>
        <button onClick={onDismiss} className="text-muted-foreground hover:text-foreground cursor-pointer mt-0.5 shrink-0">
          <X className="h-4 w-4" />
        </button>
      </div>
      <div className="px-4 pb-3.5 flex items-end gap-2">
        <div className="flex-1 space-y-1">
          <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Sale Price</Label>
          <Input
            type="number"
            step="0.01"
            placeholder="0.00"
            value={price}
            onChange={e => setPrice(e.target.value)}
            className="h-10 text-base font-bold"
            autoFocus
            onKeyDown={e => { if (e.key === "Enter") handleAdd(); }}
          />
        </div>
        <Button
          className={`h-10 px-5 gap-1.5 font-bold shrink-0 ${isSealed ? "bg-blue-500 hover:bg-blue-600 text-white" : ""}`}
          onClick={handleAdd}
        >
          <Plus className="h-4 w-4" /> Add
        </Button>
      </div>
    </motion.div>
  );
}

// ── EditablePrice ───────────────────────────────────────────────────────────
function EditablePrice({
  value,
  currency,
  onSave,
}: {
  value: number;
  currency: string;
  onSave: (v: number) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value.toFixed(2));
  const inputRef = useRef<HTMLInputElement>(null);

  const commit = () => {
    const p = parseFloat(draft);
    if (!isNaN(p) && p >= 0) { onSave(p); setEditing(false); }
    else { setDraft(value.toFixed(2)); setEditing(false); }
  };

  useEffect(() => {
    if (editing) { inputRef.current?.focus(); inputRef.current?.select(); }
  }, [editing]);

  if (editing) {
    return (
      <div className="flex items-center gap-1 shrink-0">
        <input
          ref={inputRef}
          type="number"
          step="0.01"
          min="0"
          value={draft}
          onChange={e => setDraft(e.target.value)}
          onBlur={commit}
          onKeyDown={e => {
            if (e.key === "Enter") commit();
            if (e.key === "Escape") { setDraft(value.toFixed(2)); setEditing(false); }
          }}
          className="w-20 h-8 px-2 text-sm font-black text-primary text-right rounded-lg border border-primary/50 bg-primary/8 focus:outline-none focus:ring-1 focus:ring-primary"
        />
        <button
          onMouseDown={e => { e.preventDefault(); commit(); }}
          className="w-7 h-7 flex items-center justify-center rounded-lg bg-profit/15 text-profit hover:bg-profit/25 cursor-pointer transition-colors shrink-0"
        >
          <Check className="h-3.5 w-3.5" />
        </button>
      </div>
    );
  }

  return (
    <button
      onClick={() => { setDraft(value.toFixed(2)); setEditing(true); }}
      className="flex items-center gap-1.5 group/price cursor-pointer shrink-0"
      title="Tap to edit price"
    >
      <span className="text-sm font-black text-primary group-hover/price:text-primary/70 transition-colors">
        {formatCurrency(value, currency)}
      </span>
      <Pencil className="h-3 w-3 text-muted-foreground/40 group-hover/price:text-primary/50 transition-colors" />
    </button>
  );
}

// ── Main BulkSale component ─────────────────────────────────────────────────
export default function BulkSale({ onClose }: { onClose: () => void }) {
  const user = useQuery(api.users.getCurrentUser, {});
  const currency = user?.currency ?? "GBP";

  const [items, setItems] = useState<BulkItem[]>([]);
  const [scanning, setScanning] = useState(true);
  const [pendingItem, setPendingItem] = useState<PendingItem | null>(null);

  // QR lookup
  const [pendingQr, setPendingQr] = useState("");
  // Barcode lookup
  const [pendingBarcode, setPendingBarcode] = useState("");

  const [confirming, setConfirming] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [soldAlert, setSoldAlert] = useState<{ name: string; cardId: Id<"cards"> } | null>(null);
  const [notFoundAlert, setNotFoundAlert] = useState<"qr" | "barcode" | null>(null);
  const [outOfStockAlert, setOutOfStockAlert] = useState<string | null>(null);
  const notFoundTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const soldAlertTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const outOfStockTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [sendingReceipt, setSendingReceipt] = useState(false);
  const [customerEmail, setCustomerEmail] = useState("");
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [showNudge, setShowNudge] = useState(false);
  const [successFlash, setSuccessFlash] = useState(false);
  const nudgeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const markBulkSold = useMutation(api.cards.markBulkSold);
  const markUnsold = useMutation(api.cards.markUnsold);
  const sellOne = useMutation(api.sealedProducts.sellOne);
  const sendBulkReceipt = useAction(api.emails.sendBulkReceipt);

  const convexGetCard = useQuery(
    api.cards.getCardByQr,
    pendingQr.length > 0 ? { qrValue: pendingQr } : "skip"
  );
  const convexGetSealed = useQuery(
    api.sealedProducts.getByBarcode,
    pendingBarcode.length > 0 ? { barcode: pendingBarcode } : "skip"
  );

  // QR scanner
  const webcamRef = useRef<Webcam>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number | null>(null);
  const lastScannedRef = useRef<string>("");

  const processScanned = useCallback((data: string, scanType: "qr" | "barcode") => {
    if (data === lastScannedRef.current) return;
    lastScannedRef.current = data;
    setSuccessFlash(true);
    setShowNudge(false);
    if (nudgeTimerRef.current) clearTimeout(nudgeTimerRef.current);
    nudgeTimerRef.current = setTimeout(() => setShowNudge(true), 8000);
    setTimeout(() => { setSuccessFlash(false); }, 400);
    setTimeout(() => { lastScannedRef.current = ""; }, 3000);
    if (scanType === "qr") {
      setPendingQr(data);
    } else {
      setPendingBarcode(data);
    }
  }, []);

  useEffect(() => {
    if (!scanning) {
      setShowNudge(false);
      if (nudgeTimerRef.current) { clearTimeout(nudgeTimerRef.current); nudgeTimerRef.current = null; }
      return;
    }

    if (nudgeTimerRef.current) clearTimeout(nudgeTimerRef.current);
    nudgeTimerRef.current = setTimeout(() => setShowNudge(true), 8000);

    const tick = () => {
      rafRef.current = requestAnimationFrame(tick);

      const video = webcamRef.current?.video;
      if (!video || video.readyState !== 4) return;
      const vw = video.videoWidth;
      const vh = video.videoHeight;
      if (!vw || !vh) return;

      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext("2d", { willReadFrequently: true });
      if (!ctx) return;

      const scale = Math.min(1, 400 / Math.max(vw, vh));
      canvas.width  = Math.round(vw * scale);
      canvas.height = Math.round(vh * scale);
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const fast = jsQR(ctx.getImageData(0, 0, canvas.width, canvas.height).data, canvas.width, canvas.height, { inversionAttempts: "dontInvert" });
      if (fast?.data) {
        processScanned(fast.data, isDcvQrCode(fast.data) ? "qr" : "barcode");
        return;
      }

      const barcodeResult = decodeBarcodeFromCanvas(canvas);
      if (barcodeResult) { processScanned(barcodeResult, "barcode"); return; }

      const cx = vw * 0.2, cy = vh * 0.2, cw = vw * 0.6, ch = vh * 0.6;
      const s2 = Math.min(1, 400 / Math.max(cw, ch));
      canvas.width  = Math.round(cw * s2);
      canvas.height = Math.round(ch * s2);
      ctx.drawImage(video, cx, cy, cw, ch, 0, 0, canvas.width, canvas.height);
      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const d = imgData.data;
      for (let i = 0; i < d.length; i += 4) {
        const g = Math.min(255, Math.max(0, (0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2] - 128) * 1.5 + 128));
        d[i] = d[i + 1] = d[i + 2] = g;
      }
      const slow = jsQR(imgData.data, canvas.width, canvas.height, { inversionAttempts: "attemptBoth" });
      if (slow?.data) { processScanned(slow.data, isDcvQrCode(slow.data) ? "qr" : "barcode"); return; }

      const barcodeSlow = decodeBarcodeFromCanvas(canvas);
      if (barcodeSlow) processScanned(barcodeSlow, "barcode");
    };

    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) { cancelAnimationFrame(rafRef.current); rafRef.current = null; }
      if (nudgeTimerRef.current) { clearTimeout(nudgeTimerRef.current); nudgeTimerRef.current = null; }
    };
  }, [scanning, processScanned]);

  // Handle QR result (card lookup)
  useEffect(() => {
    if (convexGetCard === undefined) return;
    if (convexGetCard === null) {
      if (pendingQr) {
        if (notFoundTimer.current) clearTimeout(notFoundTimer.current);
        setNotFoundAlert("qr");
        notFoundTimer.current = setTimeout(() => setNotFoundAlert(null), 2500);
        setPendingQr("");
        lastScannedRef.current = "";
      }
      return;
    }
    if (pendingItem) return;
    if (convexGetCard.sold) {
      if (soldAlertTimer.current) clearTimeout(soldAlertTimer.current);
      setSoldAlert({ name: convexGetCard.name, cardId: convexGetCard._id });
      soldAlertTimer.current = setTimeout(() => setSoldAlert(null), 4000);
      setPendingQr("");
      return;
    }
    if (items.some(i => i.type === "card" && i.cardId === convexGetCard._id)) {
      setPendingQr("");
      return;
    }
    setPendingItem({ kind: "card", card: convexGetCard as ScannedCardLookup });
    setPendingQr("");
  }, [convexGetCard, pendingItem, items, pendingQr]);

  // Handle barcode result (sealed product lookup)
  useEffect(() => {
    if (convexGetSealed === undefined) return;
    if (convexGetSealed === null) {
      if (pendingBarcode) {
        if (notFoundTimer.current) clearTimeout(notFoundTimer.current);
        setNotFoundAlert("barcode");
        notFoundTimer.current = setTimeout(() => setNotFoundAlert(null), 2500);
        setPendingBarcode("");
        lastScannedRef.current = "";
      }
      return;
    }
    if (pendingItem) return;
    if (convexGetSealed.quantity < 1) {
      if (outOfStockTimer.current) clearTimeout(outOfStockTimer.current);
      setOutOfStockAlert(convexGetSealed.name);
      outOfStockTimer.current = setTimeout(() => setOutOfStockAlert(null), 3000);
      setPendingBarcode("");
      return;
    }
    if (items.some(i => i.type === "sealed" && i.productId === convexGetSealed._id)) {
      setPendingBarcode("");
      return;
    }
    setPendingItem({ kind: "sealed", product: convexGetSealed as ScannedSealedLookup });
    setPendingBarcode("");
  }, [convexGetSealed, pendingItem, items, pendingBarcode]);

  const removeItem = (key: string) => setItems(prev => prev.filter(i => itemKey(i) !== key));
  const updatePrice = (key: string, newPrice: number) => {
    setItems(prev => prev.map(i => itemKey(i) === key ? { ...i, salePrice: newPrice } : i));
  };

  const total = items.reduce((s, i) => s + i.salePrice, 0);

  const handleConfirmSale = async () => {
    if (items.length === 0) return;
    setConfirming(true);
    const now = new Date();
    const d = now.getHours() < 6 ? new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1) : now;
    const localDate = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    try {
      const cardSales = items.filter((i): i is Extract<BulkItem, { type: "card" }> => i.type === "card");
      const sealedSales = items.filter((i): i is Extract<BulkItem, { type: "sealed" }> => i.type === "sealed");

      if (cardSales.length > 0) {
        await markBulkSold({
          sales: cardSales.map(i => ({ id: i.cardId, salePrice: i.salePrice })),
          localDate,
        });
      }
      for (const s of sealedSales) {
        await sellOne({ id: s.productId, salePrice: s.salePrice, localDate });
      }
      setConfirmed(true);
    } catch {
      // failed to confirm sale
    } finally {
      setConfirming(false);
    }
  };

  const handleSendReceipt = async () => {
    if (!customerEmail.trim()) return;
    if (!user?.senderEmail) return;
    setSendingReceipt(true);
    try {
      await sendBulkReceipt({
        to: customerEmail.trim(),
        senderEmail: user.senderEmail,
        currency,
        businessName: user?.businessName,
        instagram: user?.instagram,
        website: user?.website,
        items: items.map(i => ({
          cardName: i.name,
          game: i.game,
          condition: i.type === "card" ? i.condition : "Sealed",
          set: i.type === "card" ? i.set : undefined,
          grade: i.type === "card" ? i.grade : undefined,
          salePrice: i.salePrice,
        })),
      });
      onClose();
    } catch {
      // failed to send receipt
    } finally {
      setSendingReceipt(false);
    }
  };

  useEffect(() => () => {
    if (soldAlertTimer.current) clearTimeout(soldAlertTimer.current);
    if (notFoundTimer.current) clearTimeout(notFoundTimer.current);
    if (outOfStockTimer.current) clearTimeout(outOfStockTimer.current);
  }, []);

  const cardCount = items.filter(i => i.type === "card").length;
  const sealedCount = items.filter(i => i.type === "sealed").length;

  // ── Confirmed / receipt screen ───────────────────────────────────────────
  if (confirmed) {
    return (
      <div className="flex flex-col max-h-[88vh] overflow-hidden">
        <div className="flex items-center gap-3 px-5 py-4 border-b border-border shrink-0">
          <div className="w-9 h-9 rounded-xl bg-profit/15 flex items-center justify-center">
            <CheckCircle2 className="h-5 w-5 text-profit" />
          </div>
          <div>
            <h2 className="font-black text-base leading-tight">Sale Confirmed</h2>
            <p className="text-[11px] text-muted-foreground">
              {items.length} item{items.length !== 1 ? "s" : ""}
              {cardCount > 0 && sealedCount > 0 && ` (${cardCount} card${cardCount !== 1 ? "s" : ""} + ${sealedCount} sealed)`}
              {" · "}{formatCurrency(total, currency)} logged to earnings
            </p>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          <div className="rounded-2xl border border-border overflow-hidden">
            <div className="px-4 py-2.5 bg-secondary/60 border-b border-border">
              <p className="text-[10px] font-black uppercase tracking-[0.15em] text-muted-foreground">Sale Summary</p>
            </div>
            <div className="divide-y divide-border">
              {items.map(item => (
                <div key={itemKey(item)} className="flex items-center justify-between px-4 py-3">
                  <div className="flex items-center gap-2.5 min-w-0 flex-1">
                    <div className={`w-6 h-6 rounded-md flex items-center justify-center shrink-0 ${item.type === "sealed" ? "bg-blue-500/10" : "bg-secondary"}`}>
                      {item.type === "sealed"
                        ? <Barcode className="h-3.5 w-3.5 text-blue-400" />
                        : <Package className="h-3.5 w-3.5 text-muted-foreground" />
                      }
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold truncate">{item.name}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {item.type === "card" ? `${item.game}${item.condition ? ` · ${item.condition}` : ""}` : `${item.game} · Sealed`}
                      </p>
                    </div>
                  </div>
                  <p className="text-sm font-black text-primary ml-3 shrink-0">{formatCurrency(item.salePrice, currency)}</p>
                </div>
              ))}
            </div>
            <div className="flex items-center justify-between px-4 py-3 bg-primary/8 border-t border-primary/20">
              <p className="text-xs font-black uppercase tracking-widest text-primary">Total</p>
              <p className="text-xl font-black text-primary">{formatCurrency(total, currency)}</p>
            </div>
          </div>

          <div className="rounded-2xl border border-border overflow-hidden">
            <div className="px-4 py-2.5 bg-secondary/60 border-b border-border flex items-center gap-2">
              <Receipt className="h-3.5 w-3.5 text-primary" />
              <p className="text-[10px] font-black uppercase tracking-[0.15em] text-muted-foreground">Send Receipt</p>
              <span className="text-[9px] text-muted-foreground/60 ml-auto">Optional</span>
            </div>
            <div className="p-4 space-y-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold">Customer Email</Label>
                <Input type="email" placeholder="customer@example.com" value={customerEmail} onChange={e => setCustomerEmail(e.target.value)} className="h-10" />
              </div>
              <Button onClick={handleSendReceipt} disabled={sendingReceipt} className="w-full h-11 gap-2 font-bold">
                {sendingReceipt ? <Loader2 className="h-4 w-4 animate-spin" /> : <Mail className="h-4 w-4" />}
                {sendingReceipt ? "Sending…" : "Send Receipt"}
              </Button>
              <p className="text-[10px] text-muted-foreground leading-relaxed"><span className="font-bold text-primary">Pro tip:</span> Let the customer know that their receipt might land in their <span className="font-semibold text-foreground">junk mail</span> or <span className="font-semibold text-foreground">spam</span> folder.</p>
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-border shrink-0">
          <Button variant="secondary" className="w-full h-11 font-bold" onClick={onClose}>
            Done — Close
          </Button>
        </div>
      </div>
    );
  }

  // ── Scanner / cart screen ────────────────────────────────────────────────
  const capacityPct = (items.length / 100) * 100;

  return (
    <div className="flex flex-col max-h-[88vh] overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3.5 border-b border-border shrink-0 bg-card">
        <button onClick={onClose} className="cursor-pointer text-muted-foreground hover:text-foreground w-8 h-8 flex items-center justify-center rounded-lg hover:bg-secondary transition-colors">
          <ArrowLeft className="h-4 w-4" />
        </button>
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <ShoppingCart className="h-4.5 w-4.5 text-primary shrink-0" />
          <h2 className="font-black text-base tracking-wide">Bulk Sale</h2>
        </div>
        {items.length > 0 && (
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{items.length}/100</span>
            <span className="font-black text-lg text-primary">{formatCurrency(total, currency)}</span>
          </div>
        )}
      </div>

      {/* Capacity bar */}
      {items.length > 0 && (
        <div className="h-0.5 bg-border shrink-0">
          <motion.div
            className="h-full bg-primary/70"
            animate={{ width: `${capacityPct}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>
      )}

      <div className="flex-1 overflow-y-auto">
        <canvas ref={canvasRef} className="hidden" />

        {/* Camera */}
        <div className={`relative bg-black shrink-0 ${scanning && !cameraError ? "block" : "hidden"}`}>
          <Webcam
            ref={webcamRef}
            videoConstraints={{
              facingMode: "environment",
              width: { ideal: 640 },
              height: { ideal: 480 },
              frameRate: { ideal: 30, min: 15 },
            }}
            className="w-full max-h-52 object-cover opacity-90"
            screenshotFormat="image/jpeg"
            onUserMediaError={(err) => {
              const name = err instanceof DOMException ? err.name : "";
              let msg: string;
              if (name === "NotAllowedError") msg = "NotAllowedError: Camera permission denied.";
              else if (name === "NotReadableError" || name === "AbortError") msg = "NotReadableError: Camera is in use by another app.";
              else if (name === "NotFoundError") msg = "NotFoundError: No camera hardware detected.";
              else msg = `${name || "Unknown"}: Could not access camera.`;
              setCameraError(msg);
              setScanning(false);
            }}
          />
          {/* Success flash */}
          <AnimatePresence>
            {successFlash && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-profit/20 pointer-events-none z-10" />
            )}
          </AnimatePresence>
          {/* Scan frame */}
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <div className="relative w-44 h-36">
              <span className="absolute top-0 left-0 w-5 h-5 border-t-2 border-l-2 border-primary rounded-tl-md" />
              <span className="absolute top-0 right-0 w-5 h-5 border-t-2 border-r-2 border-primary rounded-tr-md" />
              <span className="absolute bottom-0 left-0 w-5 h-5 border-b-2 border-l-2 border-primary rounded-bl-md" />
              <span className="absolute bottom-0 right-0 w-5 h-5 border-b-2 border-r-2 border-primary rounded-br-md" />
              <motion.div
                className="absolute left-2 right-2 h-0.5 bg-primary/70 rounded-full"
                animate={{ top: ["15%", "85%", "15%"] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              />
            </div>
          </div>
          {/* Success checkmark */}
          <AnimatePresence>
            {successFlash && (
              <motion.div initial={{ opacity: 0, scale: 0.5 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.5 }} className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none">
                <div className="w-12 h-12 rounded-full bg-profit/90 flex items-center justify-center">
                  <CheckCircle2 className="h-7 w-7 text-white" />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          {/* Alert overlays */}
          <AnimatePresence>
            {soldAlert && (
              <motion.div
                initial={{ opacity: 0, y: -10, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -10, scale: 0.95 }}
                transition={{ type: "spring", stiffness: 350, damping: 28 }}
                className="absolute inset-x-3 top-3 flex items-center gap-3 px-4 py-3 rounded-2xl bg-red-600/95 backdrop-blur-sm border border-red-400/40 shadow-lg"
              >
                <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
                  <AlertCircle className="h-5 w-5 text-white" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-[10px] font-black text-white uppercase tracking-widest leading-tight">Already Sold</p>
                  <p className="text-[11px] text-red-100 truncate mt-0.5">{soldAlert.name}</p>
                </div>
                <button
                  onClick={async () => { try { await markUnsold({ id: soldAlert.cardId }); setSoldAlert(null); } catch { /* failed */ } }}
                  className="shrink-0 flex items-center gap-1 px-2 py-1.5 rounded-lg bg-white/20 hover:bg-white/30 transition-colors cursor-pointer"
                >
                  <RotateCcw className="h-3 w-3 text-white" />
                  <span className="text-[10px] font-bold text-white">Unsell</span>
                </button>
              </motion.div>
            )}
            {notFoundAlert && (
              <motion.div
                initial={{ opacity: 0, y: -10, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -10, scale: 0.95 }}
                transition={{ type: "spring", stiffness: 350, damping: 28 }}
                className="absolute inset-x-3 top-3 flex items-center gap-3 px-4 py-3 rounded-2xl bg-amber-600/95 backdrop-blur-sm border border-amber-400/40 shadow-lg pointer-events-none"
              >
                <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
                  <AlertCircle className="h-5 w-5 text-white" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-[10px] font-black text-white uppercase tracking-widest leading-tight">
                    {notFoundAlert === "barcode" ? "Barcode Not Found" : "Card Not Found"}
                  </p>
                  <p className="text-[11px] text-amber-100 mt-0.5">
                    {notFoundAlert === "barcode" ? "Barcode not in your sealed inventory" : "QR label not in your inventory — check and re-scan"}
                  </p>
                </div>
              </motion.div>
            )}
            {outOfStockAlert && (
              <motion.div
                initial={{ opacity: 0, y: -10, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -10, scale: 0.95 }}
                transition={{ type: "spring", stiffness: 350, damping: 28 }}
                className="absolute inset-x-3 top-3 flex items-center gap-3 px-4 py-3 rounded-2xl bg-red-600/95 backdrop-blur-sm border border-red-400/40 shadow-lg pointer-events-none"
              >
                <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
                  <AlertCircle className="h-5 w-5 text-white" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-[10px] font-black text-white uppercase tracking-widest leading-tight">Out of Stock</p>
                  <p className="text-[11px] text-red-100 truncate mt-0.5">{outOfStockAlert} has no stock remaining</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          {/* Status badges */}
          <div className="absolute bottom-3 inset-x-0 flex justify-center gap-2 pointer-events-none">
            <motion.span
              animate={{ opacity: [1, 0.5, 1] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
              className="text-[9px] font-black tracking-widest text-white/90 bg-black/60 backdrop-blur-sm px-3 py-1 rounded-full flex items-center gap-1.5"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-profit animate-pulse" />
              QR + Barcode
            </motion.span>
            {items.length > 0 && (
              <span className="text-[9px] font-black tracking-widest text-white bg-orange-500/90 backdrop-blur-sm px-3 py-1 rounded-full">
                {items.length} item{items.length !== 1 ? "s" : ""} scanned
              </span>
            )}
          </div>
        </div>

        {/* Nudge */}
        {scanning && showNudge && (
          <div className="px-4 pt-2">
            <motion.div
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-start gap-2.5 px-3 py-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-400"
            >
              <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
              <div className="space-y-0.5">
                <p className="font-semibold">Taking a while?</p>
                <p className="text-muted-foreground">Try moving closer, improving the lighting, or holding the phone steady.</p>
              </div>
            </motion.div>
          </div>
        )}

        {/* Camera error */}
        {cameraError && (
          <div className="px-4 pt-3">
            <CameraErrorPanel error={cameraError} onRetry={() => { setCameraError(null); setScanning(true); }} compact />
          </div>
        )}

        <div className="p-4 space-y-3">
          {/* Pending add row */}
          <AnimatePresence>
            {pendingItem && (
              <PendingAddRow
                key={pendingItem.kind === "card" ? pendingItem.card._id : pendingItem.product._id}
                pending={pendingItem}
                currency={currency}
                onAdd={item => { setItems(prev => [...prev, item]); setPendingItem(null); }}
                onDismiss={() => setPendingItem(null)}
              />
            )}
          </AnimatePresence>

          {/* Scanning hint */}
          {items.length === 0 && !pendingItem && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="rounded-2xl border border-dashed border-border p-8 text-center space-y-2"
            >
              <div className="w-12 h-12 rounded-2xl bg-secondary mx-auto flex items-center justify-center mb-3">
                <ScanLine className="h-6 w-6 text-muted-foreground/50" />
              </div>
              <p className="text-sm font-semibold text-muted-foreground">No items yet</p>
              <p className="text-xs text-muted-foreground/60">Scan QR labels <span className="text-foreground/50">or</span> product barcodes to add to this sale</p>
              <p className="text-[10px] text-muted-foreground/40 font-medium">Up to 100 items per sale</p>
            </motion.div>
          )}

          {/* Cart */}
          {items.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-[10px] font-black tracking-[0.2em] uppercase text-muted-foreground">Cart</p>
                <p className="text-[10px] text-muted-foreground/60 italic">Tap price to edit</p>
              </div>
              <div className="rounded-2xl border border-border overflow-hidden">
                <AnimatePresence initial={false}>
                  {items.map(item => {
                    const key = itemKey(item);
                    const isSealed = item.type === "sealed";
                    return (
                      <motion.div
                        key={key}
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.18 }}
                        className="border-b border-border last:border-0 overflow-hidden"
                      >
                        <div className="flex items-center gap-3 px-4 py-3">
                          <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${isSealed ? "bg-blue-500/10" : "bg-secondary"}`}>
                            {isSealed
                              ? <Barcode className="h-3.5 w-3.5 text-blue-400" />
                              : <Package className="h-3.5 w-3.5 text-muted-foreground" />
                            }
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-semibold truncate leading-tight">{item.name}</p>
                            <p className="text-[11px] text-muted-foreground truncate">
                              {item.type === "card"
                                ? `${item.game}${item.set ? ` · ${item.set}` : ""}`
                                : `${item.game} · Sealed`
                              }
                            </p>
                          </div>
                          <EditablePrice
                            value={item.salePrice}
                            currency={currency}
                            onSave={v => updatePrice(key, v)}
                          />
                          <button
                            onClick={() => removeItem(key)}
                            className="w-7 h-7 flex items-center justify-center rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/10 cursor-pointer transition-colors shrink-0"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>

                {/* Total row */}
                <div className="flex items-center justify-between px-4 py-3 bg-primary/8 border-t border-primary/15">
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-widest text-primary/70">
                      {items.length} item{items.length !== 1 ? "s" : ""}
                      {cardCount > 0 && sealedCount > 0 && (
                        <span className="text-muted-foreground font-normal normal-case tracking-normal ml-1.5">
                          ({cardCount} card{cardCount !== 1 ? "s" : ""} + {sealedCount} sealed)
                        </span>
                      )}
                    </p>
                    <p className="text-xs text-muted-foreground">Running total</p>
                  </div>
                  <p className="text-2xl font-black text-primary">{formatCurrency(total, currency)}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom CTA */}
      <div className="px-4 pb-4 pt-3 border-t border-border shrink-0 bg-card">
        <Button
          className="w-full h-12 text-base font-black gap-2 rounded-xl"
          disabled={items.length === 0 || confirming}
          onClick={handleConfirmSale}
        >
          {confirming
            ? <><Loader2 className="h-5 w-5 animate-spin" /> Confirming…</>
            : <><ShoppingCart className="h-5 w-5" /> Confirm Sale{items.length > 0 ? ` · ${formatCurrency(total, currency)}` : ""}</>
          }
        </Button>
      </div>
    </div>
  );
}
