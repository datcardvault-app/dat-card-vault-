import { useState, useEffect, useRef } from "react";
import { useMutation, useQuery, usePaginatedQuery, useConvexAuth, useConvex } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { toast } from "sonner";
import { ConvexError } from "convex/values";
import { User, Palette, DollarSign, Trash2, AlertTriangle, Store, Globe, AtSign, Camera, Upload, X, FileDown, Users, Copy, UserMinus, RefreshCw, LogOut, Shield, ShieldCheck, ChevronDown, Mail, Lock, Bell, Pencil, Crown, Ban, CheckCircle, Volume2, Vibrate, HeartPulse } from "lucide-react";
import { useAuth } from "@/hooks/use-auth.ts";
import { useScanFeedback } from "@/hooks/use-scan-feedback.ts";
import Papa from "papaparse";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

import { Switch } from "@/components/ui/switch.tsx";

type UploadTarget = "profile" | "logo";

export default function SettingsPage() {
  const { isAuthenticated } = useConvexAuth();
  const user = useQuery(api.users.getCurrentUserWithImages, isAuthenticated ? {} : "skip");
  // forSaleCards is fetched on-demand during CSV export (not a live subscription)
  const convex = useConvex();
  const { signout } = useAuth();
  const updateUsername = useMutation(api.users.updateUsername);
  const updateName = useMutation(api.users.updateName);
  const updateSettings = useMutation(api.users.updateSettings);
  const saveSenderEmail = useMutation(api.users.saveSenderEmail);
  const deleteAccount = useMutation(api.users.deleteAccount);
  const generateUploadUrl = useMutation(api.users.generateUploadUrl);

  const [username, setUsername] = useState("");
  const [newName, setNewName] = useState("");
  const [savingName, setSavingName] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState("");
  const [savedUsername, setSavedUsername] = useState(false);
  const [savedBranding, setSavedBranding] = useState(false);
  const [savingUsername, setSavingUsername] = useState(false);

  // Label branding fields
  const [businessName, setBusinessName] = useState("");
  const [instagram, setInstagram] = useState("");
  const [website, setWebsite] = useState("");
  const [senderEmail, setSenderEmail] = useState("");
  const [emailLocked, setEmailLocked] = useState(false);
  const [savingBranding, setSavingBranding] = useState(false);
  const [brandingInitialised, setBrandingInitialised] = useState(false);

  // Image upload state
  const [uploadingProfile, setUploadingProfile] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [showCameraDialog, setShowCameraDialog] = useState(false);
  const [cameraTarget, setCameraTarget] = useState<UploadTarget>("profile");
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const profileInputRef = useRef<HTMLInputElement>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);

  // Populate branding fields once
  useEffect(() => {
    if (user && !brandingInitialised) {
      setBusinessName(user.businessName ?? "");
      setInstagram((user.instagram ?? "").replace(/^@/, ""));
      setWebsite(user.website ?? "");
      // senderEmail is always locked to the official DatCARDVault address
      const resolvedEmail = "datcardvault@gmail.com";
      setSenderEmail(resolvedEmail);
      setEmailLocked(true);
      setBrandingInitialised(true);
    }
  }, [user, brandingInitialised]);

  // Attach stream to video element when dialog opens
  useEffect(() => {
    if (showCameraDialog && cameraStream && videoRef.current) {
      videoRef.current.srcObject = cameraStream;
    }
  }, [showCameraDialog, cameraStream]);

  // Cleanup camera on unmount
  useEffect(() => {
    return () => {
      cameraStream?.getTracks().forEach(t => t.stop());
    };
  }, [cameraStream]);

  const handleSaveUsername = async () => {
    if (!username.trim()) { toast.error("Enter a username"); return; }
    setSavingUsername(true);
    try {
      await updateUsername({ username: username.trim() });
      setUsername("");
      toast.success("Username updated!");
      setSavedUsername(true);
      setTimeout(() => setSavedUsername(false), 500);
    } catch (e) {
      if (e instanceof ConvexError) toast.error((e.data as { message: string }).message);
    } finally {
      setSavingUsername(false);
    }
  };

  const handleSaveName = async () => {
    if (!newName.trim()) { toast.error("Enter a name"); return; }
    setSavingName(true);
    try {
      await updateName({ name: newName.trim() });
      setNewName("");
      toast.success("Name updated!");
    } catch (e) {
      if (e instanceof ConvexError) toast.error((e.data as { message: string }).message);
    } finally {
      setSavingName(false);
    }
  };

  const handleSaveBranding = async () => {
    setSavingBranding(true);
    try {
      await updateSettings({
        businessName: businessName.trim() || undefined,
        instagram: instagram.trim() || undefined,
        website: website.trim() || undefined,
      });
      if (senderEmail.trim()) {
        await saveSenderEmail({ senderEmail: senderEmail.trim() });
        setEmailLocked(true);
      }
      toast.success("Branding & receipt settings saved!");
      setSavedBranding(true);
      setTimeout(() => setSavedBranding(false), 500);
    } catch { toast.error("Failed to save settings"); }
    finally { setSavingBranding(false); }
  };

  const handleThemeChange = async (mode: string) => {
    try {
      await updateSettings({ themeMode: mode });
      const html = document.documentElement;
      html.classList.remove("dark", "grey", "light");
      if (mode === "grey") {
        html.classList.add("grey");
      } else if (mode === "light") {
        // :root is the light palette — no class needed
      } else {
        html.classList.add("dark");
      }
      toast.success("Theme updated!");
    } catch { toast.error("Failed to update theme"); }
  };

  const handleCurrencyChange = async (currency: string) => {
    try {
      await updateSettings({ currency });
      toast.success("Currency updated!");
    } catch { toast.error("Failed to update currency"); }
  };

  const handleDeleteAccount = async () => {
    if (deleteConfirm !== "DELETE") { toast.error("Type DELETE to confirm"); return; }
    try {
      await deleteAccount();
      await signout();
      toast.success("Account deleted");
    } catch { toast.error("Failed to delete account"); }
  };

  const handleExportEbayCsv = async () => {
    const forSaleCards = await convex.query(api.cards.getForSaleCards, {});
    if (!forSaleCards || forSaleCards.length === 0) {
      toast.error("No for-sale cards to export");
      return;
    }
    const sym = (user?.currency ?? "GBP") === "GBP" ? "£" : "$";
    const rows = forSaleCards.map(c => ({
      "Title": [c.name, c.game, c.set, c.cardNumber ? `#${c.cardNumber}` : undefined].filter(Boolean).join(" | "),
      "Category": c.game === "Pokemon" ? "Trading Cards" : c.game === "Magic" ? "Magic: The Gathering" : c.game === "Yu-Gi-Oh" ? "Yu-Gi-Oh! Cards" : "Trading Cards",
      "Condition": c.condition,
      "Grade": c.grade ?? "",
      "Set": c.set ?? "",
      "Set Number": c.cardNumber ?? "",
      "Rarity": c.rarity ?? "",
      "Language": c.language ?? "",
      "Edition": c.edition ?? "",
      "Price": c.marketValue ? `${sym}${c.marketValue.toFixed(2)}` : "",
      "Notes": c.notes ?? "",
      "Game": c.game,
    }));

    const csv = Papa.unparse(rows, { quotes: true, header: true });
    const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `datcardvault-ebay-inventory-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    toast.success(`Exported ${rows.length} card${rows.length !== 1 ? "s" : ""} to CSV!`);
  };

  // Upload a File blob to Convex storage and save the storage ID
  const uploadFileToStorage = async (file: File, target: UploadTarget) => {
    const setUploading = target === "profile" ? setUploadingProfile : setUploadingLogo;
    setUploading(true);
    try {
      const uploadUrl = await generateUploadUrl();
      const result = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": file.type },
        body: file,
      });
      const { storageId } = await result.json() as { storageId: Id<"_storage"> };
      if (target === "profile") {
        await updateSettings({ profileImageStorageId: storageId });
        toast.success("Profile photo updated!");
      } else {
        await updateSettings({ logoStorageId: storageId });
        toast.success("Business logo updated!");
      }
    } catch {
      toast.error("Upload failed. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>, target: UploadTarget) => {
    const file = e.target.files?.[0];
    if (!file) return;
    void uploadFileToStorage(file, target);
    // Reset so same file can be re-selected
    e.target.value = "";
  };

  const openCamera = async (target: UploadTarget) => {
    setCameraTarget(target);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" } });
      setCameraStream(stream);
      setShowCameraDialog(true);
    } catch {
      toast.error("Camera not available. Please allow camera access or use file upload.");
    }
  };

  const closeCameraDialog = () => {
    cameraStream?.getTracks().forEach(t => t.stop());
    setCameraStream(null);
    setShowCameraDialog(false);
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(video, 0, 0);
    canvas.toBlob(blob => {
      if (!blob) return;
      const file = new File([blob], "photo.jpg", { type: "image/jpeg" });
      closeCameraDialog();
      void uploadFileToStorage(file, cameraTarget);
    }, "image/jpeg", 0.9);
  };

  const isAdminQuery = useQuery(api.users.isAdminUser, isAuthenticated ? {} : "skip");
  const isSuperAdminQuery = useQuery(api.users.isSuperAdminUser, isAuthenticated ? {} : "skip");
  // Latch to true once confirmed — prevents flash when Convex re-evaluates
  const [isAdminLatched, setIsAdminLatched] = useState(false);
  const [isSuperAdminLatched, setIsSuperAdminLatched] = useState(false);
  if (isAdminQuery === true && !isAdminLatched) setIsAdminLatched(true);
  if (isSuperAdminQuery === true && !isSuperAdminLatched) setIsSuperAdminLatched(true);
  const isAdmin = isAdminLatched;
  const isSuperAdmin = isSuperAdminLatched;
  const adminStats = useQuery(api.users.adminGetStats, isAuthenticated && isAdmin ? {} : "skip");
  const adminUsers = useQuery(api.users.adminGetAllUsers, isAuthenticated && isAdmin ? {} : "skip");
  const healthCheck = useQuery(api.users.adminHealthCheck, isAuthenticated && isAdmin ? {} : "skip");
  const adminGrantAdmin = useMutation(api.users.adminGrantAdmin);
  const adminDeleteUser = useMutation(api.users.adminDeleteUser);
  const adminSuspendUser = useMutation(api.users.adminSuspendUser);
  const adminSetAffiliated = useMutation(api.users.adminSetAffiliated);
  const adminSetSupporter = useMutation(api.users.adminSetSupporter);
  const [adminExpanded, setAdminExpanded] = useState(false);
  type AdminAction = { type: "suspend" | "unsuspend" | "delete" | "grant_admin" | "revoke_admin" | "grant_affiliated" | "revoke_affiliated" | "grant_supporter" | "revoke_supporter"; userId: string; name: string };
  const [adminConfirm, setAdminConfirm] = useState<AdminAction | null>(null);
  const [adminActing, setAdminActing] = useState(false);
  const displayName = user?.username ?? user?.name ?? "User";
  const daysUntilChange = (() => {
    if (!user?.usernameLastChanged) return 0;
    const last = new Date(user.usernameLastChanged).getTime();
    const diff = (Date.now() - last) / (1000 * 60 * 60 * 24);
    return Math.max(0, Math.ceil(14 - diff));
  })();

  return (
    <div className="p-4 md:p-6 max-w-2xl mx-auto space-y-5">
      <h1 className="text-3xl font-sans text-primary tracking-widest">Settings</h1>

      {/* Profile */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <User className="h-4 w-4 text-primary" /> Profile
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Avatar + photo actions */}
          <div className="flex flex-col items-center gap-3 sm:flex-row sm:items-center sm:gap-4">
            <div className="relative flex-shrink-0">
              {user?.profileImageUrl ? (
                <img
                  src={user.profileImageUrl}
                  alt="Profile"
                  className="w-20 h-20 rounded-full object-cover border-2 border-primary/40"
                />
              ) : (
                <div className="w-20 h-20 rounded-full bg-primary/20 border-2 border-primary/40 flex items-center justify-center">
                  <span className="text-3xl font-bold text-primary">{displayName[0]?.toUpperCase()}</span>
                </div>
              )}
              {uploadingProfile && (
                <div className="absolute inset-0 rounded-full bg-black/60 flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0 flex flex-col items-center sm:items-start gap-0.5">
              <p className="font-semibold truncate max-w-full">{displayName}</p>
              <div className="flex items-center gap-2 flex-wrap justify-center sm:justify-start">
                <p className="text-xs text-muted-foreground truncate">{user?.email ?? ""}</p>
                {isAdmin && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#7C3AED]/20 text-[#7C3AED] border border-[#7C3AED]/40 shrink-0">
                    <Crown className="h-2.5 w-2.5" /> OWNER
                  </span>
                )}
              </div>
              <div className="flex gap-2 mt-2 w-full sm:w-auto justify-center sm:justify-start">
                <Button
                  size="sm"
                  variant="secondary"
                  className="gap-1.5 text-xs cursor-pointer flex-1 sm:flex-none"
                  onClick={() => profileInputRef.current?.click()}
                  disabled={uploadingProfile}
                >
                  <Upload className="h-3 w-3" /> Upload Photo
                </Button>
                <Button
                  size="sm"
                  variant="secondary"
                  className="gap-1.5 text-xs cursor-pointer flex-1 sm:flex-none"
                  onClick={() => openCamera("profile")}
                  disabled={uploadingProfile}
                >
                  <Camera className="h-3 w-3" /> Take Photo
                </Button>
              </div>
            </div>
          </div>
          {/* Hidden file input */}
          <input
            ref={profileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={e => handleFileInput(e, "profile")}
          />

          <div className="space-y-2">
            <Label>Change Username</Label>
            {daysUntilChange > 0 && !isAdmin ? (
              <p className="text-sm text-muted-foreground bg-secondary p-3 rounded-lg">
                You can change your username in <span className="text-primary font-semibold">{daysUntilChange} day{daysUntilChange !== 1 ? "s" : ""}</span>
              </p>
            ) : (
              <div className="flex gap-2">
                <Input
                  placeholder="New username (3–30 chars)"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  maxLength={30}
                  onKeyDown={e => { if (e.key === "Enter") handleSaveUsername(); }}
                />
                <Button onClick={handleSaveUsername} disabled={savingUsername} className={`transition-colors ${savedUsername ? "bg-profit hover:bg-profit text-white" : ""}`}>
                  {savingUsername ? "Saving..." : "Save"}
                </Button>
              </div>
            )}
            <p className="text-xs text-muted-foreground">
              Letters, numbers, spaces, and underscores allowed. Max once per 14 days. Must follow community guidelines.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Team Mode */}
      <TeamModeCard />

      {/* Label Branding */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Store className="h-4 w-4 text-primary" /> Label Branding / Receipt Setup
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-xs text-muted-foreground">
            These details appear below the QR code on every printed label — great for buyers to find you again.
          </p>

          {/* Live label preview */}
          <div className="flex justify-center py-2">
            <div className="relative">
              <div
                style={{
                  width: "224px", height: "120px",
                  display: "flex", flexDirection: "column",
                  border: "2px dashed #cc0000",
                  borderRadius: "6px",
                  backgroundColor: "#fff",
                  overflow: "hidden",
                  boxShadow: "0 4px 20px rgba(204,0,0,0.12)",
                }}
              >
                <div style={{ display: "flex", flex: 1 }}>
                  <div style={{ width: "88px", backgroundColor: "#f7f7f7", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "space-between", borderRight: "1px solid #e0e0e0", padding: "4px 0 2px" }}>
                    <div style={{ fontSize: "4px", fontWeight: 900, color: "#cc0000", fontFamily: "Arial", letterSpacing: "0.04em", textAlign: "center", lineHeight: 1.2 }}>QR FOR VENDOR{"\n"}USE ONLY</div>
                    <div style={{ width: "60px", height: "60px", border: "2px solid #000", borderRadius: "2px", display: "grid", gridTemplateColumns: "repeat(5,1fr)", gap: "1px", padding: "4px", backgroundColor: "#fff" }}>
                      {Array.from({ length: 25 }).map((_, i) => (
                        <div key={i} style={{ backgroundColor: [0,1,3,4,5,6,10,11,15,19,20,21,23,24].includes(i) ? "#000" : "#fff" }} />
                      ))}
                    </div>
                    <div style={{ paddingBottom: "2px", textAlign: "center" }}>
                      {(businessName || user?.businessName) ? (
                        <div style={{ fontSize: "5px", fontWeight: 900, color: "#000", fontFamily: "Arial" }}>{businessName || user?.businessName}</div>
                      ) : null}
                      {(instagram || user?.instagram) ? (
                        <div style={{ fontSize: "4.5px", color: "#cc0000", fontFamily: "Arial" }}>@{(instagram || (user?.instagram ?? "")).replace(/^@/, "")}</div>
                      ) : null}
                      {(website || user?.website) ? (
                        <div style={{ fontSize: "4px", color: "#555", fontFamily: "Arial" }}>{(website || (user?.website ?? "")).replace(/^https?:\/\//, "")}</div>
                      ) : null}
                      {!businessName && !user?.businessName && !instagram && !user?.instagram && !website && !user?.website && (
                        <div style={{ fontSize: "4px", color: "#aaa", fontFamily: "Arial" }}>your info here</div>
                      )}
                    </div>
                  </div>
                  <div style={{ flex: 1, padding: "5px 7px", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
                    <div>
                      <div style={{ fontWeight: 900, fontSize: "9px", color: "#000", fontFamily: "Arial" }}>Charizard VMAX</div>
                      <div style={{ fontWeight: 700, fontSize: "7px", color: "#cc0000", fontFamily: "Arial" }}>Pokémon</div>
                      <div style={{ fontWeight: 600, fontSize: "5.5px", color: "#333", fontFamily: "Arial" }}>Darkness Ablaze #020</div>
                    </div>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: "6px", color: "#000", fontFamily: "Arial" }}>Near Mint</div>
                      <div style={{ fontWeight: 900, fontSize: "11px", color: "#cc0000", fontFamily: "Arial" }}>£74.99</div>
                    </div>
                    <div style={{ fontWeight: 500, fontSize: "4.5px", color: "#aaa", fontFamily: "Arial" }}>DatCardVault</div>
                  </div>
                </div>
              </div>
              <p className="text-[10px] text-muted-foreground text-center mt-2">Live label preview</p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label className="flex items-center gap-1.5"><Store className="h-3 w-3" /> Business Name</Label>
              <Input
                placeholder="e.g. DatPikaStore"
                value={businessName}
                onChange={e => setBusinessName(e.target.value)}
                maxLength={30}
              />
            </div>
            <div className="space-y-1.5">
              <Label className="flex items-center gap-1.5"><AtSign className="h-3 w-3" /> Instagram Handle</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">@</span>
                <Input
                  placeholder="yourhandle"
                  value={instagram}
                  onChange={e => setInstagram(e.target.value.replace(/^@/, ""))}
                  maxLength={30}
                  className="pl-7"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="flex items-center gap-1.5"><Globe className="h-3 w-3" /> Website</Label>
              <Input
                placeholder="e.g. yourstore.com"
                value={website}
                onChange={e => setWebsite(e.target.value)}
                maxLength={50}
              />
            </div>
            <div className="space-y-1.5">
              <Label className="flex items-center gap-1.5 flex-wrap leading-snug"><Mail className="h-3 w-3 text-profit shrink-0" /> Verified Receipt Sender Email — This is now automatically generated and encrypted.</Label>
              {emailLocked ? (
                <div className="flex items-center gap-2 px-3 py-2.5 rounded-md border border-profit/40 bg-profit/8">
                  <Lock className="h-3.5 w-3.5 text-profit shrink-0" />
                  <span className="flex-1 text-sm text-foreground/80 truncate">
                    {senderEmail}
                  </span>
                </div>
              ) : (
                <Input
                  type="email"
                  placeholder="Datcardvault@gmail.com"
                  value={senderEmail}
                  onChange={e => setSenderEmail(e.target.value)}
                />
              )}
              <p className="text-[10px] text-muted-foreground">
                <span className="flex items-center gap-1"><Lock className="h-3 w-3 text-profit" /> This email can not be edited.</span>
              </p>
            </div>
            <Button onClick={handleSaveBranding} disabled={savingBranding} className={`w-full transition-colors ${savedBranding ? "bg-profit hover:bg-profit text-white" : ""}`}>
              {savingBranding ? "Saving..." : "Save Branding & Receipt Settings"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Appearance */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Palette className="h-4 w-4 text-primary" /> Appearance
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Label>Theme Mode</Label>
          <div className="grid grid-cols-3 gap-3">
            {[
              { mode: "dark", label: "Dark", desc: "Black & red", preview: "bg-zinc-900 border-zinc-700" },
              { mode: "light", label: "Light", desc: "Clean white", preview: "bg-white border-zinc-200" },
              { mode: "grey", label: "Grey", desc: "Soft grey", preview: "bg-zinc-300 border-zinc-400" },
            ].map(({ mode, label, desc, preview }) => (
              <button
                key={mode}
                onClick={() => handleThemeChange(mode)}
                className={`cursor-pointer p-4 rounded-xl border-2 transition-all text-left ${
                  (user?.themeMode ?? "dark") === mode
                    ? "border-primary bg-primary/10"
                    : "border-border bg-secondary hover:bg-secondary/80"
                }`}
              >
                <div className={`w-full h-8 rounded-lg mb-2 ${preview} border [color-scheme:light]`} />
                <p className="font-semibold text-sm">{label}</p>
                <p className="text-xs text-muted-foreground">{desc}</p>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Scan Feedback */}
      <ScanFeedbackCard />

      {/* Currency */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <DollarSign className="h-4 w-4 text-primary" /> Currency
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-xs text-muted-foreground mb-3">
            Choose your currency — all prices, earnings, and labels across the app will display in this format.
          </p>
          <Select value={user?.currency ?? "GBP"} onValueChange={handleCurrencyChange}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="GBP">🇬🇧 GBP – British Pound</SelectItem>
              <SelectItem value="USD">🇺🇸 USD – US Dollar</SelectItem>
              <SelectItem value="EUR">🇪🇺 EUR – Euro</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Exports */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <FileDown className="h-4 w-4 text-primary" /> Exports
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">

          {/* PDF Logo */}
          <div className="space-y-2">
            <p className="font-semibold text-sm">Business Logo for PDF</p>
            <p className="text-xs text-muted-foreground">
              Your logo appears in the top-right of the Earnings PDF summary. Square images work best.
            </p>
            <div className="flex items-center gap-4">
              <div className="relative flex-shrink-0">
                {user?.logoUrl ? (
                  <img
                    src={user.logoUrl}
                    alt="Business logo"
                    className="w-16 h-16 rounded-xl object-contain border-2 border-primary/40 bg-secondary"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-xl bg-secondary border-2 border-dashed border-primary/30 flex items-center justify-center">
                    <Store className="h-7 w-7 text-muted-foreground" />
                  </div>
                )}
                {uploadingLogo && (
                  <div className="absolute inset-0 rounded-xl bg-black/60 flex items-center justify-center">
                    <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                  </div>
                )}
              </div>
              <div className="flex flex-col gap-2">
                <Button
                  size="sm"
                  variant="secondary"
                  className="gap-1.5 text-xs cursor-pointer"
                  onClick={() => logoInputRef.current?.click()}
                  disabled={uploadingLogo}
                >
                  <Upload className="h-3 w-3" /> Upload Logo
                </Button>
                <Button
                  size="sm"
                  variant="secondary"
                  className="gap-1.5 text-xs cursor-pointer"
                  onClick={() => openCamera("logo")}
                  disabled={uploadingLogo}
                >
                  <Camera className="h-3 w-3" /> Take Photo
                </Button>
              </div>
            </div>
            <input
              ref={logoInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={e => handleFileInput(e, "logo")}
            />
          </div>

          <div className="border-t border-border" />

          {/* eBay CSV */}
          <div className="space-y-2">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="font-semibold text-sm">eBay Bulk Upload CSV</p>
              <p className="text-xs text-muted-foreground">
                Downloads all your <span className="text-primary font-medium">for-sale</span> (unsold) cards as a CSV file — ready to upload to eBay's bulk listing tool.
              </p>
            </div>
            <Button
              size="sm"
              className="gap-1.5 shrink-0 cursor-pointer"
              onClick={handleExportEbayCsv}
            >
              <FileDown className="h-3.5 w-3.5" />
              Download CSV
            </Button>
          </div>
          <p className="text-[10px] text-muted-foreground bg-secondary rounded-lg px-3 py-2">
            Tip: Open the CSV in Excel or Google Sheets, then use eBay's <strong>Bulk Listing Tool</strong> to import. Check the Title and Price columns before uploading.
          </p>
          </div>

        </CardContent>
      </Card>

      {/* Security */}
      <SecurityCard />

      {/* Admin panel — only visible to whitelisted emails */}
      {isAdmin && (
        <Card
          className="border-2 bg-[#7C3AED]/10"
          style={{ borderColor: "#7C3AED" }}
        >
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2 text-[#7C3AED]">
              <Crown className="h-4 w-4" /> Admin Panel
              <span className="ml-auto text-[10px] font-normal px-2 py-0.5 rounded-full bg-black text-white border border-[#7C3AED]/50">
                RESTRICTED
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Stats row */}
            {adminStats && (
              <div className="grid grid-cols-5 gap-1">
                {[
                  { label: "Users", value: adminStats.totalUsers },
                  { label: "Cards", value: adminStats.totalCards },
                  { label: "Sold", value: adminStats.totalSold },
                  { label: "Labels", value: adminStats.totalLabels },
                  { label: "Prints", value: adminStats.totalPrintJobs },
                ].map(s => (
                  <div key={s.label} className="bg-secondary rounded-lg p-1.5 text-center border border-border">
                    <p className="text-sm font-black text-[#7C3AED]">{s.value}</p>
                    <p className="text-[8px] text-muted-foreground uppercase tracking-wide leading-tight">{s.label}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Health Check */}
            {healthCheck && (
              <div className="rounded-xl border border-border bg-secondary/40 p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <HeartPulse className={`h-4 w-4 ${healthCheck.overallStatus === "healthy" ? "text-profit" : "text-amber-400"}`} />
                    <span className="text-xs font-bold uppercase tracking-widest">App Health</span>
                  </div>
                  <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                    healthCheck.overallStatus === "healthy"
                      ? "bg-profit/15 text-profit border border-profit/30"
                      : "bg-amber-500/15 text-amber-400 border border-amber-500/30"
                  }`}>
                    {healthCheck.overallStatus === "healthy" ? "ALL GOOD" : "ATTENTION"}
                  </span>
                </div>
                <div className="space-y-1">
                  {healthCheck.checks.map(check => (
                    <div key={check.label} className="flex items-center justify-between py-1 border-t border-border/50">
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${
                          check.status === "healthy" ? "bg-profit" :
                          check.status === "warning" ? "bg-amber-400" : "bg-blue-400"
                        }`} />
                        <span className="text-[11px] text-foreground">{check.label}</span>
                      </div>
                      <span className="text-[10px] text-muted-foreground">{check.detail}</span>
                    </div>
                  ))}
                </div>
                <p className="text-[9px] text-muted-foreground/50 text-right">
                  Checked: {new Date(healthCheck.timestamp).toLocaleTimeString()}
                </p>
              </div>
            )}

            {/* User list toggle */}
            <button
              className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl bg-secondary border border-border cursor-pointer hover:bg-secondary/80 transition-colors"
              onClick={() => setAdminExpanded(v => !v)}
            >
              <span className="flex items-center gap-2 text-sm font-semibold">
                <Users className="h-4 w-4 text-[#7C3AED]" />
                All Users ({adminUsers?.length ?? "…"})
              </span>
              <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ${adminExpanded ? "rotate-180" : ""}`} />
            </button>

            {adminExpanded && adminUsers && (
              <div className="space-y-1.5 max-h-96 overflow-y-auto pr-1">
                {adminUsers.map(u => (
                  <div key={u._id} className={`flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3 px-3 py-2.5 rounded-xl border ${u.suspended ? "bg-red-500/5 border-red-500/30" : "bg-secondary border-border"}`}>
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 ${u.suspended ? "bg-red-400/20" : "bg-[#7C3AED]/20"}`}>
                        <span className={`text-xs font-bold ${u.suspended ? "text-red-400" : "text-[#7C3AED]"}`}>
                          {(u.name ?? u.email ?? "?")[0]?.toUpperCase()}
                        </span>
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <p className="text-xs font-semibold truncate">{u.username ?? u.name ?? "—"}</p>
                          {u.suspended && (() => {
                            const raw = u._id ?? "";
                            let hash = 0;
                            for (let i = 0; i < raw.length; i++) {
                              hash = (hash * 31 + raw.charCodeAt(i)) >>> 0;
                            }
                            const code = String(hash % 1000000).padStart(6, "0");
                            return (
                              <>
                                <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-red-400/20 text-red-400 border border-red-400/30 shrink-0">SUSPENDED</span>
                                <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-black text-white border border-white/20 shrink-0 tracking-widest">#{code}</span>
                              </>
                            );
                          })()}
                          {u.isHardcodedAdmin && (
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-[#7C3AED]/20 text-[#7C3AED] border border-[#7C3AED]/30 shrink-0 flex items-center gap-0.5"><Crown className="h-2 w-2" />OWNER</span>
                          )}
                          {u.isGrantedAdmin && !u.isHardcodedAdmin && (
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-[#7C3AED]/20 text-[#7C3AED] border border-[#7C3AED]/30 shrink-0 flex items-center gap-0.5"><Crown className="h-2 w-2" />ADMIN</span>
                          )}
                          {u.isAffiliated && (
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shrink-0">AFFILIATED</span>
                          )}
                          {u.isSupporter && (
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30 shrink-0">SUPPORTER</span>
                          )}
                        </div>
                        {u.username && u.name && (
                          <p className="text-[10px] text-muted-foreground/70 truncate">Name: {u.name}</p>
                        )}
                        <p className="text-[10px] text-muted-foreground truncate">{u.email ?? "no email"}</p>
                        <p className="text-[10px] text-muted-foreground/60">
                          {u.cardCount} cards · {u.soldCount} sold · {u.labelCount} labels · {u.printJobs} prints
                        </p>
                        {u.suspended && (() => {
                          const days = u.suspendedAt
                            ? Math.floor((Date.now() - new Date(u.suspendedAt).getTime()) / (1000 * 60 * 60 * 24))
                            : null;
                          const remaining = days !== null ? 35 - days : null;
                          return (
                            <p className="text-[10px] font-semibold text-red-400">
                              {days !== null
                                ? `Suspended ${days}d ago · auto-delete in ${remaining! > 0 ? `${remaining}d` : "0d"}`
                                : "Suspended · re-suspend to start auto-delete timer"}
                            </p>
                          );
                        })()}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0 pl-10 sm:pl-0">
                      {/* Grant/revoke admin — super admin only, hide for hardcoded admins */}
                      {isSuperAdmin && !u.isHardcodedAdmin && (
                        u.isGrantedAdmin ? (
                          <button
                            className="p-1.5 rounded-lg hover:bg-[#7C3AED]/10 text-[#7C3AED] transition-colors cursor-pointer"
                            title="Revoke admin"
                            onClick={() => setAdminConfirm({ type: "revoke_admin", userId: u._id, name: u.name ?? u.email ?? u._id })}
                          >
                            <Crown className="h-3.5 w-3.5" />
                          </button>
                        ) : (
                          <button
                            className="p-1.5 rounded-lg hover:bg-[#7C3AED]/10 text-muted-foreground transition-colors cursor-pointer"
                            title="Grant admin"
                            onClick={() => setAdminConfirm({ type: "grant_admin", userId: u._id, name: u.name ?? u.email ?? u._id })}
                          >
                            <Crown className="h-3.5 w-3.5" />
                          </button>
                        )
                      )}
                      {/* Affiliated toggle — any admin */}
                      <button
                        className={`p-1.5 rounded-lg transition-colors cursor-pointer text-[9px] font-black border ${u.isAffiliated ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/10" : "bg-secondary text-muted-foreground border-border hover:bg-emerald-500/10 hover:text-emerald-400"}`}
                        title={u.isAffiliated ? "Revoke Affiliated" : "Grant Affiliated"}
                        onClick={() => setAdminConfirm({ type: u.isAffiliated ? "revoke_affiliated" : "grant_affiliated", userId: u._id, name: u.name ?? u.email ?? u._id })}
                      >
                        AFF
                      </button>
                      {/* Supporter toggle — any admin */}
                      <button
                        className={`p-1.5 rounded-lg transition-colors cursor-pointer text-[9px] font-black border ${u.isSupporter ? "bg-amber-500/20 text-amber-400 border-amber-500/30 hover:bg-amber-500/10" : "bg-secondary text-muted-foreground border-border hover:bg-amber-500/10 hover:text-amber-400"}`}
                        title={u.isSupporter ? "Revoke Supporter" : "Grant Supporter"}
                        onClick={() => setAdminConfirm({ type: u.isSupporter ? "revoke_supporter" : "grant_supporter", userId: u._id, name: u.name ?? u.email ?? u._id })}
                      >
                        SUP
                      </button>
                      {u.suspended ? (
                        <button
                          className="p-1.5 rounded-lg hover:bg-profit/10 text-profit transition-colors cursor-pointer"
                          title="Unsuspend"
                          onClick={() => setAdminConfirm({ type: "unsuspend", userId: u._id, name: u.name ?? u.email ?? u._id })}
                        >
                          <CheckCircle className="h-3.5 w-3.5" />
                        </button>
                      ) : u.isGrantedAdmin ? (
                        <button
                          className="p-1.5 rounded-lg text-muted-foreground/30 cursor-not-allowed"
                          title="Sorry, you can't suspend an admin. Remove their admin role first."
                          disabled
                        >
                          <Ban className="h-3.5 w-3.5" />
                        </button>
                      ) : (
                        <button
                          className="p-1.5 rounded-lg hover:bg-amber-500/10 text-amber-500 transition-colors cursor-pointer"
                          title="Suspend"
                          onClick={() => setAdminConfirm({ type: "suspend", userId: u._id, name: u.name ?? u.email ?? u._id })}
                        >
                          <Ban className="h-3.5 w-3.5" />
                        </button>
                      )}
                      <button
                        className="p-1.5 rounded-lg hover:bg-red-400/10 text-red-400 transition-colors cursor-pointer"
                        title="Delete account"
                        onClick={() => setAdminConfirm({ type: "delete", userId: u._id, name: u.name ?? u.email ?? u._id })}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Admin confirm dialog */}
      <Dialog open={!!adminConfirm} onOpenChange={o => { if (!o) setAdminConfirm(null); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {adminConfirm?.type === "delete" ? (
                <><Trash2 className="h-4 w-4 text-destructive" /> Delete Account</>
              ) : adminConfirm?.type === "suspend" ? (
                <><Ban className="h-4 w-4 text-amber-500" /> Suspend Account</>
              ) : adminConfirm?.type === "unsuspend" ? (
                <><CheckCircle className="h-4 w-4 text-profit" /> Unsuspend Account</>
              ) : adminConfirm?.type === "grant_admin" ? (
                <><Crown className="h-4 w-4 text-[#7C3AED]" /> Grant Admin</>
              ) : adminConfirm?.type === "revoke_admin" ? (
                <><Crown className="h-4 w-4 text-muted-foreground" /> Revoke Admin</>
              ) : adminConfirm?.type === "grant_affiliated" ? (
                <><span className="text-emerald-400 font-black text-sm">AFF</span> Grant Affiliated</>
              ) : adminConfirm?.type === "revoke_affiliated" ? (
                <><span className="text-muted-foreground font-black text-sm">AFF</span> Revoke Affiliated</>
              ) : adminConfirm?.type === "grant_supporter" ? (
                <><span className="text-amber-400 font-black text-sm">SUP</span> Grant Supporter</>
              ) : (
                <><span className="text-muted-foreground font-black text-sm">SUP</span> Revoke Supporter</>
              )}
            </DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            {adminConfirm?.type === "delete"
              ? <>Permanently delete <span className="font-semibold text-foreground">{adminConfirm.name}</span>? This cannot be undone.</>
              : adminConfirm?.type === "suspend"
              ? <>Suspend <span className="font-semibold text-foreground">{adminConfirm.name}</span>? They will be blocked from using the app.</>
              : adminConfirm?.type === "unsuspend"
              ? <>Unsuspend <span className="font-semibold text-foreground">{adminConfirm?.name}</span>? They will regain access.</>
              : adminConfirm?.type === "grant_admin"
              ? <>Grant admin access to <span className="font-semibold text-foreground">{adminConfirm.name}</span>? They will see the Admin Panel.</>
              : adminConfirm?.type === "revoke_admin"
              ? <>Revoke admin access from <span className="font-semibold text-foreground">{adminConfirm?.name}</span>? They will lose the Admin Panel.</>
              : adminConfirm?.type === "grant_affiliated"
              ? <>Grant <span className="font-semibold text-foreground">{adminConfirm.name}</span> the <span className="text-emerald-400 font-bold">Affiliated</span> role?</>
              : adminConfirm?.type === "revoke_affiliated"
              ? <>Revoke the <span className="text-emerald-400 font-bold">Affiliated</span> role from <span className="font-semibold text-foreground">{adminConfirm.name}</span>?</>
              : adminConfirm?.type === "grant_supporter"
              ? <>Grant <span className="font-semibold text-foreground">{adminConfirm.name}</span> the <span className="text-amber-400 font-bold">Supporter</span> role?</>
              : <>Revoke the <span className="text-amber-400 font-bold">Supporter</span> role from <span className="font-semibold text-foreground">{adminConfirm?.name}</span>?</>
            }
          </p>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setAdminConfirm(null)} disabled={adminActing}>Cancel</Button>
            <Button
              variant={adminConfirm?.type === "delete" ? "destructive" : "default"}
              className={
                adminConfirm?.type === "suspend" ? "bg-amber-600 hover:bg-amber-700 text-black" :
                adminConfirm?.type === "unsuspend" ? "bg-profit hover:bg-profit" :
                adminConfirm?.type === "grant_admin" ? "bg-[#7C3AED] hover:bg-[#6D28D9] text-white" :
                adminConfirm?.type === "grant_affiliated" ? "bg-emerald-600 hover:bg-emerald-700 text-white" :
                adminConfirm?.type === "grant_supporter" ? "bg-amber-500 hover:bg-amber-600 text-black" : ""
              }
              disabled={adminActing}
              onClick={async () => {
                if (!adminConfirm) return;
                setAdminActing(true);
                try {
                  if (adminConfirm.type === "delete") {
                    await adminDeleteUser({ userId: adminConfirm.userId as Parameters<typeof adminDeleteUser>[0]["userId"] });
                    toast.success("Account deleted");
                  } else if (adminConfirm.type === "grant_admin" || adminConfirm.type === "revoke_admin") {
                    await adminGrantAdmin({ userId: adminConfirm.userId as Parameters<typeof adminGrantAdmin>[0]["userId"], grant: adminConfirm.type === "grant_admin" });
                    toast.success(adminConfirm.type === "grant_admin" ? "Admin access granted" : "Admin access revoked");
                  } else if (adminConfirm.type === "grant_affiliated" || adminConfirm.type === "revoke_affiliated") {
                    await adminSetAffiliated({ userId: adminConfirm.userId as Parameters<typeof adminSetAffiliated>[0]["userId"], value: adminConfirm.type === "grant_affiliated" });
                    toast.success(adminConfirm.type === "grant_affiliated" ? "Affiliated role granted" : "Affiliated role revoked");
                  } else if (adminConfirm.type === "grant_supporter" || adminConfirm.type === "revoke_supporter") {
                    await adminSetSupporter({ userId: adminConfirm.userId as Parameters<typeof adminSetSupporter>[0]["userId"], value: adminConfirm.type === "grant_supporter" });
                    toast.success(adminConfirm.type === "grant_supporter" ? "Supporter role granted" : "Supporter role revoked");
                  } else {
                    await adminSuspendUser({ userId: adminConfirm.userId as Parameters<typeof adminSuspendUser>[0]["userId"], suspended: adminConfirm.type === "suspend" });
                    toast.success(adminConfirm.type === "suspend" ? "Account suspended" : "Account unsuspended");
                  }
                  setAdminConfirm(null);
                } catch (e) {
                  if (e instanceof ConvexError) toast.error((e.data as { message: string }).message);
                  else toast.error("Action failed");
                } finally { setAdminActing(false); }
              }}
            >
              {adminActing ? "Working…" :
                adminConfirm?.type === "delete" ? "Delete" :
                adminConfirm?.type === "suspend" ? "Suspend" :
                adminConfirm?.type === "unsuspend" ? "Unsuspend" :
                adminConfirm?.type === "grant_admin" ? "Grant Admin" :
                adminConfirm?.type === "revoke_admin" ? "Revoke Admin" :
                adminConfirm?.type === "grant_affiliated" ? "Grant Affiliated" :
                adminConfirm?.type === "revoke_affiliated" ? "Revoke Affiliated" :
                adminConfirm?.type === "grant_supporter" ? "Grant Supporter" : "Revoke Supporter"
              }
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Danger zone */}
      <Card className="border-destructive bg-destructive/10">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2 text-destructive">
            <AlertTriangle className="h-4 w-4" /> Danger Zone
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-start justify-between gap-4">
            <div className="space-y-1">
              <p className="font-semibold text-sm text-destructive uppercase tracking-wide">DELETE ACCOUNT</p>
              <p className="text-xs text-destructive/80 leading-relaxed">
                Permanently delete your account and all its data. This cannot be undone and all data will be lost. You are welcome to make another account anytime.
              </p>
            </div>
            <Button variant="destructive" size="sm" onClick={() => setShowDeleteDialog(true)} className="gap-2 shrink-0">
              <Trash2 className="h-3 w-3" /> Delete
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Sign out */}
      <Button variant="secondary" className="w-full" onClick={() => signout()}>
        Sign Out
      </Button>

      {/* Delete confirm dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-sans text-destructive">Delete Account</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              This will permanently delete your account, all cards, labels, and scan logs. This cannot be undone.
            </p>
            <div className="space-y-1">
              <Label>Type <span className="font-bold text-destructive">DELETE</span> to confirm</Label>
              <Input
                value={deleteConfirm}
                onChange={e => setDeleteConfirm(e.target.value)}
                placeholder="DELETE"
                className="border-destructive/50"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setShowDeleteDialog(false)}>Cancel</Button>
            <Button variant="destructive" onClick={handleDeleteAccount} disabled={deleteConfirm !== "DELETE"}>
              Delete My Account
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Camera dialog */}
      <Dialog open={showCameraDialog} onOpenChange={open => { if (!open) closeCameraDialog(); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Camera className="h-4 w-4 text-primary" />
                {cameraTarget === "profile" ? "Take Profile Photo" : "Take Logo Photo"}
              </span>
              <button onClick={closeCameraDialog} className="cursor-pointer text-muted-foreground hover:text-foreground">
                <X className="h-4 w-4" />
              </button>
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="relative rounded-xl overflow-hidden bg-black aspect-square">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
            </div>
            <canvas ref={canvasRef} className="hidden" />
            <Button className="w-full gap-2" onClick={capturePhoto}>
              <Camera className="h-4 w-4" /> Capture Photo
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ─── Scan Feedback Card ────────────────────────────────────────────────────────

function ScanFeedbackCard() {
  const { isAuthenticated } = useConvexAuth();
  const user = useQuery(api.users.getCurrentUser, isAuthenticated ? {} : "skip");
  const updateSettings = useMutation(api.users.updateSettings);
  const soundType = (user?.scanSoundType ?? "beep") as import("@/hooks/use-scan-feedback.ts").SoundType;
  const { trigger: triggerBeep } = useScanFeedback(true, false, "beep");
  const { trigger: triggerChime } = useScanFeedback(true, false, "chime");
  const { trigger: triggerCash } = useScanFeedback(true, false, "cash");
  const [testing, setTesting] = useState<string | null>(null);

  const handleToggle = async (field: "scanSound" | "scanHaptics", value: boolean) => {
    try {
      await updateSettings({ [field]: value });
    } catch {
      toast.error("Failed to save setting");
    }
  };

  const handleSoundType = async (type: string) => {
    try {
      await updateSettings({ scanSoundType: type });
    } catch {
      toast.error("Failed to save setting");
    }
  };

  const handleTestSound = (type: string) => {
    if (type === "beep") triggerBeep();
    else if (type === "chime") triggerChime();
    else triggerCash();
    setTesting(type);
    setTimeout(() => setTesting(null), 700);
  };

  const soundEnabled = user?.scanSound ?? false;
  const hapticsEnabled = user?.scanHaptics ?? false;

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Bell className="h-4 w-4 text-primary" /> Scan Feedback
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-xs text-muted-foreground">
          Get an audio beep and/or vibration when a scan or sale is confirmed — ideal for busy show tables.
        </p>
        <div className="space-y-3">
          {/* Sound toggle */}
          <div className="flex items-center justify-between gap-4 px-3 py-3 rounded-xl border border-border bg-secondary/40">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-primary/15 flex items-center justify-center shrink-0">
                <Volume2 className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="text-sm font-semibold">Scan Sound</p>
                <p className="text-xs text-muted-foreground">Audio on successful scan &amp; sale</p>
              </div>
            </div>
            <Switch
              checked={soundEnabled}
              onCheckedChange={v => { void handleToggle("scanSound", v); }}
            />
          </div>

          {/* Sound type picker */}
          {soundEnabled && (
            <div className="rounded-xl border border-border bg-secondary/30 p-3 space-y-2">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Sound Style</p>
              <div className="grid grid-cols-3 gap-2">
                {([
                  { id: "beep",  label: "Beep",  desc: "Short blip" },
                  { id: "chime", label: "Chime", desc: "Two-tone rise" },
                  { id: "cash",  label: "Cash",  desc: "Register ding" },
                ] as const).map(({ id, label, desc }) => (
                  <div key={id} className="flex flex-col gap-1.5">
                    <button
                      onClick={() => { void handleSoundType(id); }}
                      className={`w-full rounded-lg border px-2 py-2 text-xs font-bold transition-all cursor-pointer ${
                        soundType === id
                          ? "border-primary bg-primary/15 text-primary"
                          : "border-border bg-secondary/40 text-muted-foreground hover:border-primary/40 hover:text-foreground"
                      }`}
                    >
                      {label}
                      <span className="block text-[10px] font-normal mt-0.5 opacity-70">{desc}</span>
                    </button>
                    <button
                      onClick={() => handleTestSound(id)}
                      className={`w-full text-[10px] font-semibold px-2 py-1 rounded-lg border transition-all cursor-pointer ${
                        testing === id
                          ? "bg-primary/20 border-primary/40 text-primary"
                          : "bg-secondary border-border text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      {testing === id ? "♪ Playing" : "▶ Test"}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Haptics toggle */}
          <div className="flex items-center justify-between gap-4 px-3 py-3 rounded-xl border border-border bg-secondary/40">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-primary/15 flex items-center justify-center shrink-0">
                <Vibrate className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="text-sm font-semibold">Haptic Feedback</p>
                <p className="text-xs text-muted-foreground">Vibrate on successful scan &amp; sale</p>
              </div>
            </div>
            <Switch
              checked={hapticsEnabled}
              onCheckedChange={v => { void handleToggle("scanHaptics", v); }}
            />
          </div>
        </div>
        <p className="text-[10px] text-muted-foreground">
          Vibration requires a mobile device that supports the Vibration API. Sound requires device audio to be unmuted.
        </p>
      </CardContent>
    </Card>
  );
}

function TeamModeCard() {
  const teamData = useQuery(api.teams.getMyTeam, {});
  const createTeam = useMutation(api.teams.createTeam);
  const joinTeam = useMutation(api.teams.joinTeam);
  const leaveTeam = useMutation(api.teams.leaveTeam);
  const removeMember = useMutation(api.teams.removeMember);
  const regenerateCode = useMutation(api.teams.regenerateCode);
  const sendNudge = useMutation(api.nudges.sendNudge);
  const cooldown = useQuery(api.nudges.myCooldownInfo, {});

  // Today's earnings per team member
  function localBusinessDay() {
    const now = new Date();
    const d = now.getHours() < 6 ? new Date(now.getTime() - 86400000) : now;
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  }
  const inTeam = teamData !== null && teamData !== undefined;
  const teamEarnings = useQuery(
    api.earnings.getTeamTodayEarnings,
    inTeam ? { dateUtc: localBusinessDay() } : "skip"
  );
  const [joinCode, setJoinCode] = useState("");
  const [teamName, setTeamName] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [loading, setLoading] = useState(false);
  const [nudging, setNudging] = useState(false);

  const isOwner = teamData?.myRole === "owner";

  // Cooldown info
  const nudgesLeft = cooldown ? Math.max(0, cooldown.limit - cooldown.used) : cooldown === undefined ? null : 2;
  const onCooldown = nudgesLeft === 0;

  // Countdown timer display
  const [cooldownSecs, setCooldownSecs] = useState<number | null>(null);
  useEffect(() => {
    if (!cooldown?.resetsAt || !onCooldown) { setCooldownSecs(null); return; }
    const tick = () => {
      const secs = Math.max(0, Math.ceil((cooldown.resetsAt! - Date.now()) / 1000));
      setCooldownSecs(secs);
    };
    tick();
    const id = setInterval(tick, 500);
    return () => clearInterval(id);
  }, [cooldown?.resetsAt, onCooldown]);

  const handleCreate = async () => {
    setLoading(true);
    try {
      await createTeam({ name: teamName.trim() || undefined });
      setShowCreate(false);
      setTeamName("");
      toast.success("Team created!");
    } catch (e) {
      if (e instanceof ConvexError) toast.error((e.data as { message: string }).message);
    } finally { setLoading(false); }
  };

  const handleJoin = async () => {
    if (!joinCode.trim()) { toast.error("Enter a join code"); return; }
    setLoading(true);
    try {
      await joinTeam({ joinCode: joinCode.trim() });
      setJoinCode("");
      toast.success("Joined team!");
    } catch (e) {
      if (e instanceof ConvexError) toast.error((e.data as { message: string }).message);
    } finally { setLoading(false); }
  };

  const handleLeave = async () => {
    setLoading(true);
    try {
      await leaveTeam({});
      toast.success(isOwner ? "Team dissolved" : "Left team");
    } catch (e) {
      if (e instanceof ConvexError) toast.error((e.data as { message: string }).message);
    } finally { setLoading(false); }
  };

  const handleRemove = async (userId: string) => {
    setLoading(true);
    try {
      await removeMember({ userId: userId as Parameters<typeof removeMember>[0]["userId"] });
      toast.success("Member removed");
    } catch (e) {
      if (e instanceof ConvexError) toast.error((e.data as { message: string }).message);
    } finally { setLoading(false); }
  };

  const handleRegenerate = async () => {
    setLoading(true);
    try {
      const code = await regenerateCode({});
      toast.success(`New code: ${code}`);
    } catch (e) {
      if (e instanceof ConvexError) toast.error((e.data as { message: string }).message);
    } finally { setLoading(false); }
  };

  const handleNudge = async () => {
    setNudging(true);
    try {
      await sendNudge({});
      toast.success("Nudge sent! 🔔");
    } catch (e) {
      if (e instanceof ConvexError) toast.error((e.data as { message: string }).message);
      else toast.error("Could not send nudge");
    } finally { setNudging(false); }
  };

  const copyCode = (code: string) => {
    void navigator.clipboard.writeText(code);
    toast.success("Join code copied!");
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Users className="h-4 w-4 text-primary" /> Team Mode
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {teamData === undefined ? (
          // Loading
          <div className="h-16 rounded-xl bg-secondary animate-pulse" />
        ) : !inTeam ? (
          // Not in a team
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Team Mode lets you share your vault with another user in real time — perfect for card shows where two people are selling from the same stock.
            </p>

            {/* Join existing team */}
            <div className="space-y-2">
              <Label>Join a team</Label>
              <div className="flex gap-2">
                <Input
                  placeholder="Enter 6-character code"
                  value={joinCode}
                  onChange={e => setJoinCode(e.target.value.toUpperCase())}
                  maxLength={6}
                  className="font-mono tracking-widest uppercase"
                />
                <Button onClick={handleJoin} disabled={loading} className="shrink-0">Join</Button>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex-1 h-px bg-border" />
              <span className="text-xs text-muted-foreground">or</span>
              <div className="flex-1 h-px bg-border" />
            </div>

            {/* Create team */}
            {!showCreate ? (
              <Button variant="secondary" className="w-full gap-2" onClick={() => setShowCreate(true)}>
                <Users className="h-4 w-4" /> Create a Team
              </Button>
            ) : (
              <div className="space-y-2">
                <Label>Team name (optional)</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="e.g. CardShow Crew"
                    value={teamName}
                    onChange={e => setTeamName(e.target.value)}
                    maxLength={30}
                  />
                  <Button onClick={handleCreate} disabled={loading} className="shrink-0">Create</Button>
                  <Button variant="secondary" onClick={() => setShowCreate(false)} className="shrink-0 px-2"><X className="h-4 w-4" /></Button>
                </div>
              </div>
            )}
          </div>
        ) : (
          // In a team
          <div className="space-y-5">

            {/* ── Team header banner ── */}
            <div className="rounded-2xl bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border border-primary/20 px-4 py-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center shrink-0">
                <Users className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold truncate text-foreground">
                  {teamData.team.name || "My Team"}
                </p>
                <p className="text-xs text-muted-foreground">
                  {teamData.members.length} member{teamData.members.length !== 1 ? "s" : ""} · {isOwner ? "You're the owner" : "You're a partner"}
                </p>
              </div>
              <span className={`text-[10px] font-bold uppercase tracking-wide px-2 py-0.5 rounded-full border ${isOwner ? "border-primary/40 text-primary bg-primary/10" : "border-muted-foreground/30 text-muted-foreground bg-muted/30"}`}>
                {isOwner ? "Owner" : "Partner"}
              </span>
            </div>

            {/* ── Invite Code (owner only) — shown at top for easy sharing ── */}
            {isOwner && (
              <div className="space-y-1.5">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Invite Code</p>
                <div className="rounded-2xl border border-primary/30 bg-primary/5 overflow-hidden">
                  <div className="px-4 py-4 flex flex-col items-center gap-1">
                    <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground">Share with your partner</p>
                    <div className="flex gap-2 mt-2">
                      {teamData.team.joinCode.split("").map((char, i) => (
                        <div key={i} className="w-9 h-11 rounded-lg bg-background border-2 border-primary/40 flex items-center justify-center shadow-sm">
                          <span className="font-mono text-xl font-black text-primary tracking-tight">{char}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="flex border-t border-primary/20">
                    <button
                      onClick={() => copyCode(teamData.team.joinCode)}
                      className="flex-1 flex items-center justify-center gap-1.5 py-3 text-xs font-semibold text-primary hover:bg-primary/10 transition-colors cursor-pointer border-r border-primary/20"
                    >
                      <Copy className="h-3.5 w-3.5" /> Copy Code
                    </button>
                    <button
                      onClick={handleRegenerate}
                      disabled={loading}
                      className="flex-1 flex items-center justify-center gap-1.5 py-3 text-xs font-semibold text-muted-foreground hover:bg-secondary transition-colors cursor-pointer disabled:opacity-50"
                    >
                      <RefreshCw className="h-3.5 w-3.5" /> New Code
                    </button>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">1 member can join with this code. Regenerate it to revoke access.</p>
              </div>
            )}

            {/* ── Member cards ── */}
            <div className="space-y-2.5">
              {teamData.members.map(m => {
                const isSelf = m.userId === teamData.myUserId;
                const memberEarnings = teamEarnings?.find(e => e.userId === m.userId);
                const initials = (m.displayName ?? "?").slice(0, 2).toUpperCase();
                return (
                  <div key={m.userId} className="rounded-2xl border border-border bg-card overflow-hidden">
                    {/* Top row */}
                    <div className="flex items-center gap-3 p-3.5">
                      {/* Avatar with online ring */}
                      <div className="relative shrink-0">
                        <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-sm font-black
                          ${m.role === "owner" ? "bg-primary/20 text-primary" : "bg-secondary text-foreground"}`}>
                          {initials}
                        </div>
                        <span className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-card
                          ${m.isOnline ? "bg-profit" : "bg-muted-foreground/40"}`} />
                      </div>
                      {/* Name / status */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <p className="text-sm font-bold truncate">{m.displayName ?? "Unknown"}</p>
                          {isSelf && (
                            <span className="text-[10px] font-semibold text-muted-foreground bg-muted px-1.5 py-0.5 rounded-full">You</span>
                          )}
                          {m.role === "owner" && (
                            <span className="text-[10px] font-bold text-primary bg-primary/10 px-1.5 py-0.5 rounded-full border border-primary/20">Owner</span>
                          )}
                        </div>
                        <p className={`text-xs mt-0.5 ${m.isOnline ? "text-profit" : "text-muted-foreground"}`}>
                          {m.isOnline ? "● Online now" : "○ Offline"}
                        </p>
                      </div>
                      {/* Today's sold badge */}
                      {memberEarnings !== undefined && (
                        <div className="text-right shrink-0">
                          <p className="text-base font-black text-profit leading-none">{memberEarnings.cardsSold}</p>
                          <p className="text-[10px] text-muted-foreground mt-0.5">sold today</p>
                        </div>
                      )}
                    </div>
                    {/* Action row — only shown when there's something to do */}
                    {(!isSelf || (isOwner && m.role !== "owner")) && (
                      <div className="flex border-t border-border">
                        {!isSelf && (
                          <button
                            onClick={handleNudge}
                            disabled={nudging || onCooldown}
                            className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 text-xs font-semibold transition-colors cursor-pointer
                              ${onCooldown
                                ? "text-muted-foreground cursor-not-allowed"
                                : "text-primary hover:bg-primary/5 active:bg-primary/10"
                              } ${isOwner && m.role !== "owner" ? "border-r border-border" : ""}`}
                            title={onCooldown ? `Cooldown — ${cooldownSecs ?? "…"}s` : "Send a nudge alert"}
                          >
                            <Bell className="h-3.5 w-3.5" />
                            {onCooldown ? `Cooldown ${cooldownSecs ?? "…"}s` : "Nudge"}
                          </button>
                        )}
                        {isOwner && m.role !== "owner" && (
                          <button
                            onClick={() => handleRemove(m.userId)}
                            disabled={loading}
                            className="flex-1 flex items-center justify-center gap-1.5 py-2.5 text-xs font-semibold text-destructive hover:bg-destructive/5 transition-colors cursor-pointer disabled:opacity-50"
                          >
                            <UserMinus className="h-3.5 w-3.5" /> Remove
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* ── Leave / dissolve ── */}
            <Button
              variant="secondary"
              className="w-full gap-2 text-destructive hover:text-destructive"
              onClick={handleLeave}
              disabled={loading}
            >
              <LogOut className="h-4 w-4" />
              {isOwner ? "Dissolve Team" : "Leave Team"}
            </Button>
            {isOwner && (
              <p className="text-xs text-muted-foreground text-center">Dissolving removes all members and deletes the team.</p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ─── Security Card ─────────────────────────────────────────────────────────────

const ACTION_LABELS: Record<string, { label: string; color: string }> = {
  username_changed:      { label: "Username changed",          color: "text-amber-500" },
  settings_saved:        { label: "Settings saved",            color: "text-blue-400" },
  team_created:          { label: "Team created",              color: "text-profit" },
  team_joined:           { label: "Team joined",               color: "text-profit" },
  team_dissolved:        { label: "Team dissolved",            color: "text-red-400" },
  team_left:             { label: "Team left",                 color: "text-orange-400" },
  earnings_recalculated: { label: "Earnings recalculated",     color: "text-purple-400" },
  earnings_restored:     { label: "Earnings snapshot restored",color: "text-purple-400" },
};

function SecurityCard() {
  const [expanded, setExpanded] = useState(false);
  // Only subscribe to full log list when the user expands the section
  const { results, status, loadMore } = usePaginatedQuery(
    api.activityLog.getMyLogs,
    expanded ? {} : "skip",
    { initialNumItems: 15 },
  );
  const recentCount = useQuery(api.activityLog.recentCount, {});

  const anomaly = (recentCount ?? 0) > 20; // >20 events in 24h → unusual

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          {anomaly ? (
            <Shield className="h-4 w-4 text-amber-500" />
          ) : (
            <ShieldCheck className="h-4 w-4 text-profit" />
          )}
          Security &amp; Activity Log
          {anomaly && (
            <span className="ml-auto text-xs font-normal px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-500">
              High activity
            </span>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Status banner */}
        <div className={`flex items-center gap-3 p-3 rounded-xl border ${anomaly ? "border-amber-500/30 bg-amber-500/5" : "border-profit/30 bg-profit/5"}`}>
          {anomaly ? (
            <Shield className="h-5 w-5 text-amber-500 shrink-0" />
          ) : (
            <ShieldCheck className="h-5 w-5 text-profit shrink-0" />
          )}
          <div>
            <p className={`text-sm font-semibold ${anomaly ? "text-amber-500" : "text-profit"}`}>
              {anomaly ? "Unusual activity detected" : "Account looks secure"}
            </p>
            <p className="text-xs text-muted-foreground">
              {recentCount ?? "—"} event{recentCount !== 1 ? "s" : ""} in the last 24 hours
              {anomaly ? " — review the log below" : ""}
            </p>
          </div>
        </div>

        {/* Protections checklist */}
        <div className="space-y-1.5">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Active protections</p>
          {[
            "All data encrypted in transit (HTTPS / TLS 1.3)",
            "Identity verified via Hercules Auth on every request",
            "Server-side auth — no user ID accepted from client",
            "Rate-limited APIs — brute-force resistant",
            "Append-only audit trail — events cannot be deleted",
            "Team vault access locked to join-code invite only",
          ].map(item => (
            <div key={item} className="flex items-start gap-2 text-sm">
              <ShieldCheck className="h-3.5 w-3.5 text-profit shrink-0 mt-0.5" />
              <span className="text-muted-foreground">{item}</span>
            </div>
          ))}
        </div>

        {/* Activity log */}
        <div className="space-y-1.5">
          <button
            className="w-full flex items-center justify-between cursor-pointer text-xs font-semibold text-muted-foreground uppercase tracking-widest py-1"
            onClick={() => setExpanded(e => !e)}
          >
            Account activity log
            <ChevronDown className={`h-3.5 w-3.5 transition-transform ${expanded ? "rotate-180" : ""}`} />
          </button>

          {expanded && (
            <div className="space-y-1.5 max-h-80 overflow-y-auto pr-1">
              {results.length === 0 ? (
                <p className="text-sm text-muted-foreground py-4 text-center">No activity recorded yet.</p>
              ) : (
                results.map(log => {
                  const meta = ACTION_LABELS[log.action] ?? { label: log.action, color: "text-foreground" };
                  return (
                    <div key={log._id} className="flex items-start gap-3 p-2.5 rounded-xl bg-secondary border border-border text-xs">
                      <div className="flex-1 min-w-0">
                        <p className={`font-semibold ${meta.color}`}>{meta.label}</p>
                        {log.detail && <p className="text-muted-foreground truncate">{log.detail}</p>}
                      </div>
                      <span className="text-muted-foreground shrink-0 tabular-nums">
                        {new Date(log.at).toLocaleString(undefined, { dateStyle: "short", timeStyle: "short" })}
                      </span>
                    </div>
                  );
                })
              )}
              {status === "CanLoadMore" && (
                <button
                  className="w-full text-xs text-primary py-2 cursor-pointer hover:underline"
                  onClick={() => loadMore(15)}
                >
                  Load more
                </button>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
