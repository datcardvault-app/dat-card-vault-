import { useQuery, useMutation, useAction, useConvexAuth } from "convex/react";
import { useStableQuery } from "@/hooks/use-stable-query.ts";
import { useNavigate } from "react-router-dom";
import { motion } from "motion/react";
import { useState, useMemo, useEffect } from "react";
import { api } from "@/convex/_generated/api.js";

type SoldItem = {
  type: "card" | "sealed";
  id: string;
  name: string;
  subtitle: string;
  salePrice?: number;
  profit?: number;
  soldAt: string;
};

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import {
  Package, DollarSign, TrendingUp, ScanLine, Plus, Tag, Clock, Zap, Users,
  Percent, ArrowRight, CheckCircle2, X, Mail, Loader2, Target,
  ShoppingCart, Settings2, Trophy, Edit2, Barcode, ShoppingBag, ChevronDown
} from "lucide-react";
import { formatCurrency } from "@/lib/utils.ts";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import type { BarProps } from "recharts";
import { CARD_GAMES, CARD_CONDITIONS } from "@/lib/constants.ts";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import BulkSale from "@/pages/scan/bulk-sale.tsx";

function localDateStr(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

/** Returns the "business day" date — before 6am rolls back to yesterday so Today's Earnings resets at 6am */
function businessDayStr() {
  const now = new Date();
  if (now.getHours() < 6) {
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    return localDateStr(yesterday);
  }
  return localDateStr(now);
}

function addDays(dateStr: string, n: number) {
  const d = new Date(dateStr + "T12:00:00Z");
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

const DASHBOARD_GREETINGS = [
  { before: "Welcome back, ", after: "!" },
  { before: "Great to see you, ", after: "!" },
  { before: "Let's get selling, ", after: "!" },
  { before: "Ready to vault, ", after: "?" },
  { before: "Good hustle, ", after: "!" },
  { before: "Hey ", after: ", let's go!" },
  { before: "Back at it, ", after: "!" },
  { before: "Time to make moves, ", after: "!" },
  { before: "The grind never stops, ", after: "!" },
  { before: "Stack it up, ", after: "!" },
  { before: "Show day energy, ", after: "!" },
  { before: "Let's bag some sales, ", after: "!" },
  { before: "Cards won't sell themselves, ", after: "!" },
  { before: "", after: " has entered the building!" },
  { before: "Another day, another Charizard, ", after: "!" },
  { before: "May the pulls be with you, ", after: "!" },
  { before: "", after: "'s vault is open for business!" },
  { before: "Plot twist: ", after: " sells out today!" },
  { before: "", after: " didn't come here to play\u2026 wait, yes you did." },
  { before: "No lowballers please, ", after: "!" },
  { before: "", after: ", the card whisperer returns!" },
  { before: "Today's forecast: 100% chance of sales, ", after: "!" },
  { before: "", after: " woke up and chose profit!" },
  { before: "The vault missed you, ", after: "!" },
  { before: "Shuffling the deck, ", after: " is in!" },
  { before: "PSA 10 energy from ", after: " today!" },
  { before: "Full art holo vibes only, ", after: "!" },
  { before: "", after: " just drew a supporter card — it's called hustle!" },
  { before: "Time to flip some cardboard, ", after: "!" },
  { before: "Topdeck incoming, ", after: "!" },
  { before: "", after: "'s ripping packs and taking names!" },
  { before: "It's giving rare holo, ", after: "!" },
  { before: "The meta just changed — ", after: " showed up!" },
  { before: "Binder full? Not for long, ", after: "!" },
  { before: "", after: " is sleeved up and ready to sell!" },
  { before: "Secret rare energy from ", after: " today!" },
  { before: "Buylisting? Never. Selling? Always, ", after: "!" },
  { before: "", after: " brought the heat to the table!" },
  { before: "First edition mindset, ", after: "!" },
  { before: "GG easy, ", after: " is here!" },
  { before: "Luffy would be proud, ", after: "!" },
  { before: "", after: " activated Ultra Instinct vendor mode!" },
  { before: "Tap all lands — ", after: " is going infinite today!" },
  { before: "", after: " just played a Pot of Greed… drew two sales!" },
  { before: "Gear 5 grind mode, ", after: "!" },
  { before: "One Piece is real… and so are ", after: "'s profits!" },
  { before: "", after: " cast Lightning Bolt on low inventory!" },
  { before: "Nakama energy from ", after: " today!" },
  { before: "Illumineer's quest: sell everything, ", after: "!" },
  { before: "", after: " just dreamborn'd a new sale!" },
  { before: "You drew the god pack, ", after: "!" },
  { before: "", after: " is the King of the Pirates… of card sales!" },
  { before: "Straw Hat hustle, ", after: "!" },
  { before: "Mono-red aggro energy from ", after: "!" },
  { before: "", after: " played Haste — straight to selling!" },
  { before: "Nami would charge 3x more, ", after: "!" },
  { before: "Lorcana lore check: ", after: " is legendary!" },
  { before: "", after: " just quested for 4 — that's sales energy!" },
  { before: "Pikachu chose you, ", after: "!" },
  { before: "", after: " used Thunderbolt — it's super effective on buyers!" },
  { before: "Nothing but net profit, ", after: "!" },
  { before: "Slam dunk sales incoming, ", after: "!" },
  { before: "", after: " is in the red zone and scoring!" },
  { before: "Hat trick of sales today, ", after: "?" },
  { before: "MVP of the vendor table, ", after: "!" },
  { before: "", after: " just hit a walk-off home run sale!" },
  { before: "Championship mindset, ", after: "!" },
  { before: "Fourth quarter closer, ", after: "!" },
  { before: "", after: " brought playoff energy to the booth!" },
  { before: "Kobe mentality on sales, ", after: "!" },
  { before: "", after: " is running a full-court press on inventory!" },
  { before: "Zoro got lost but ", after: " found the profit!" },
  { before: "", after: " used Rare Candy — evolved into top seller!" },
  { before: "Mulligan? Never. ", after: " keeps every hand!" },
  { before: "", after: " just floodgated the competition!" },
  { before: "Sanji wouldn't simp for cards, but ", after: " would!" },
  { before: "Untap, upkeep, draw sales — ", after: "'s turn!" },
  { before: "", after: " is the Hokage of the card vendor world!" },
  { before: "Sorcery speed? Nah, ", after: " sells at instant speed!" },
  { before: "Shifting into ", after: "'s Sapphire Steel era!" },
  { before: "", after: " just pulled the alt art — time to list!" },
  { before: "Gym leader energy, ", after: "!" },
  { before: "", after: " played Professor's Research — drew 7 customers!" },
  { before: "Three-pointer from half court, ", after: " drains it!" },
  { before: "No bench warmers here — ", after: " starts every game!" },
  { before: "", after: " just evolved into a Stage 2 vendor!" },
  { before: "Wano arc grind energy, ", after: "!" },
  { before: "The booth is your arena, ", after: "!" },
  { before: "", after: " summoned a Black Lotus of motivation!" },
  { before: "Touchdown on every transaction, ", after: "!" },
];

export default function Index() {
  const { isAuthenticated } = useConvexAuth();
  const skip = !isAuthenticated ? ("skip" as const) : ({});
  const stats = useStableQuery(api.cards.getInventoryStats, skip);
  const sealedStats = useStableQuery(api.sealedProducts.getSealedStats, skip);
  const user = useStableQuery(api.users.getCurrentUser, skip);
  const isAdmin = useQuery(api.users.isAdminUser, isAuthenticated ? {} : "skip");
  const recentSold = useStableQuery(api.cards.getRecentSold, isAuthenticated ? { limit: 5 } : "skip");

  // ── 7-day chart: compute a rolling 7-day window ending today (resets daily) ──
  const todayStr = businessDayStr();
  const weekDates = useMemo(() => {
    const today = new Date();
    // Always show the last 7 days ending today — oldest day drops off each new day
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(today);
      d.setDate(today.getDate() - (6 - i));
      return localDateStr(d);
    });
  }, [todayStr]);

  const weekEarnings = useStableQuery(api.earnings.getWeekEarnings, { dates: weekDates });
  const weekDeals = useStableQuery(api.buyingDeals.getWeekDeals, { dates: weekDates });
  const todayDeals = useStableQuery(api.buyingDeals.getTodayDeals, { date: todayStr });
  const navigate = useNavigate();
  const currency = user?.currency ?? "GBP";

  const [selectedSoldItem, setSelectedSoldItem] = useState<SoldItem | null>(null);
  const [bulkSaleOpen, setBulkSaleOpen] = useState(false);
  const [quickAddOpen, setQuickAddOpen] = useState(false);
  const [showChart, setShowChart] = useState(false);
  const [quickForm, setQuickForm] = useState({ name: "", game: "Pokémon" as string, condition: "Near Mint" as string, marketValue: "" });
  const [quickSaving, setQuickSaving] = useState(false);
  const addCard = useMutation(api.cards.addCard);
  const createLabel = useMutation(api.labels.createLabel);
  const logDeal = useMutation(api.buyingDeals.logDeal);
  const [dealSaving, setDealSaving] = useState(false);
  const [dealJustSaved, setDealJustSaved] = useState(false);

  // Buyer % calculator — multi-price support (up to 20)
  const [calcPrices, setCalcPrices] = useState<string[]>([""]);
  const [calcPct, setCalcPct] = useState("");
  const [calcNote, setCalcNote] = useState("");
  const [dealReceiptOpen, setDealReceiptOpen] = useState(false);
  const [dealReceiptData, setDealReceiptData] = useState<{ totalPrice: number; pay: number; keep: number; pct: number; prices: number[]; note: string } | null>(null);
  const [dealCustomerEmail, setDealCustomerEmail] = useState("");
  const [dealSendingReceipt, setDealSendingReceipt] = useState(false);

  const [greetingIndex] = useState(() => Math.floor(Math.random() * DASHBOARD_GREETINGS.length));

  const displayName = user?.username || user?.name || "Vendor";

  const sendDealReceipt = useAction(api.emails.sendDealReceipt);

  const addCalcPrice = () => {
    if (calcPrices.length < 20) setCalcPrices(prev => [...prev, ""]);
  };
  const removeCalcPrice = (idx: number) => {
    setCalcPrices(prev => prev.length <= 1 ? [""] : prev.filter((_, i) => i !== idx));
  };
  const updateCalcPrice = (idx: number, val: string) => {
    setCalcPrices(prev => prev.map((p, i) => i === idx ? val : p));
  };

  const calcTotalPrice = useMemo(() => {
    return calcPrices.reduce((sum, p) => {
      const n = parseFloat(p);
      return sum + (isNaN(n) ? 0 : n);
    }, 0);
  }, [calcPrices]);

  const calcResult = useMemo(() => {
    const pct = parseFloat(calcPct);
    if (calcTotalPrice <= 0 || isNaN(pct) || pct <= 0 || pct > 100) return null;
    const pay = (calcTotalPrice * pct) / 100;
    const keep = calcTotalPrice - pay;
    return { pay, keep, pct };
  }, [calcTotalPrice, calcPct]);

  const handleDealAccepted = async () => {
    if (!calcResult) return;
    setDealSaving(true);
    try {
      await logDeal({
        date: localDateStr(),
        cardPrice: calcTotalPrice,
        pct: calcResult.pct,
        amountPaid: calcResult.pay,
        youKeep: calcResult.keep,
        cardCount: calcPrices.filter(p => { const n = parseFloat(p); return !isNaN(n) && n > 0; }).length,
        note: calcNote.trim() || undefined,
      });
      const prices = calcPrices.map(p => parseFloat(p)).filter(n => !isNaN(n) && n > 0);
      setDealReceiptData({
        totalPrice: calcTotalPrice,
        pay: calcResult.pay,
        keep: calcResult.keep,
        pct: calcResult.pct,
        prices,
        note: calcNote.trim(),
      });
      setDealJustSaved(true);
      toast.success(`Deal logged — paid ${formatCurrency(calcResult.pay, currency)}`);
      setDealReceiptOpen(true);
      // Reset calculator
      setCalcPrices([""]);
      setCalcPct("");
      setCalcNote("");
      setTimeout(() => setDealJustSaved(false), 3000);
    } catch {
      toast.error("Failed to log deal");
    } finally {
      setDealSaving(false);
    }
  };

  // Nudge
  const teamData = useStableQuery(api.teams.getMyTeam, {});
  const sendNudge = useMutation(api.nudges.sendNudge);
  const cooldown = useQuery(api.nudges.myCooldownInfo, teamData ? {} : "skip");
  const inTeam = teamData !== null && teamData !== undefined;
  const nudgesLeft = cooldown ? Math.max(0, cooldown.limit - cooldown.used) : null;
  const onCooldown = nudgesLeft === 0;

  const handleNudge = async () => {
    try {
      await sendNudge({});
    } catch {
      // could not send nudge
    }
  };

  const handleQuickAdd = async () => {
    if (!quickForm.name.trim()) return;
    setQuickSaving(true);
    try {
      const cardId = await addCard({
        name: quickForm.name.trim(),
        game: quickForm.game,
        set: "",
        condition: quickForm.condition,
        marketValue: quickForm.marketValue ? parseFloat(quickForm.marketValue) : undefined,
      });
      // Auto-generate a label for the new card
      await createLabel({
        cardId,
        labelData: {
          cardName: quickForm.name.trim(),
          game: quickForm.game,
          condition: quickForm.condition,
          price: quickForm.marketValue ? parseFloat(quickForm.marketValue) : undefined,
        },
      });
      toast.success("Card added + label created");
      setQuickAddOpen(false);
      setQuickForm({ name: "", game: "Pokémon", condition: "Near Mint", marketValue: "" });
    } catch {
      toast.error("Failed to add card");
    } finally {
      setQuickSaving(false);
    }
  };

  const today = localDateStr();
  // Use 6am business day for "Today's Earnings" display — before 6am still shows yesterday's tally
  const todayEarnings = useStableQuery(api.earnings.getTodayEarnings, { dateUtc: businessDayStr() });

  // Event mode
  const eventActive = user?.eventActive ?? false;
  const eventStartDate = user?.eventStartDate ?? today;
  const eventDays = user?.eventDays ?? 3;
  const eventEndDate = addDays(eventStartDate, eventDays - 1);
  const daysLeft = Math.max(0, Math.ceil((new Date(eventEndDate + "T23:59:59Z").getTime() - Date.now()) / 86400000));

  const eventEarnings = useStableQuery(
    api.earnings.getEventEarnings,
    eventActive ? { startDate: eventStartDate, endDate: eventEndDate } : "skip"
  );

  // Determine what to show in the "today" slot
  const showEventTotal = eventActive && eventEarnings !== undefined;
  const earningsLabel = eventActive ? `Event Total (Day ${Math.min(eventDays, eventDays - daysLeft + 1)} of ${eventDays})` : "Today's Earnings";
  const earningsValue = eventActive
    ? (eventEarnings !== undefined ? formatCurrency(eventEarnings.totalEarned, currency) : "—")
    : (todayEarnings !== undefined ? formatCurrency(todayEarnings?.totalEarned ?? 0, currency) : "—");
  const earningsSub = eventActive
    ? (daysLeft > 0 ? `${daysLeft} day${daysLeft !== 1 ? "s" : ""} left` : "Event complete")
    : (todayEarnings ? `${todayEarnings.cardsSold} sold today` : "No sales yet today");

  const statItems = [
    {
      label: "Cards in Vault",
      value: (stats?.totalCards ?? 0) + (sealedStats?.activeProducts ?? 0),
      icon: Package,
      color: "text-primary",
      bg: "bg-primary/10",
      sub: sealedStats?.activeProducts ? `incl. ${sealedStats.activeProducts} sealed` : undefined,
    },
    {
      label: "Cards Sold",
      value: (stats?.soldCards ?? 0) + (sealedStats?.soldOutProducts ?? 0),
      icon: Tag,
      color: "text-amber-500",
      bg: "bg-amber-500/10",
      sub: (() => {
        const cards = stats?.soldCards ?? 0;
        const sealed = sealedStats?.soldOutProducts ?? 0;
        if (cards > 0 && sealed > 0) return `${cards} cards · ${sealed} sealed`;
        if (sealed > 0) return `${sealed} sealed`;
        return undefined;
      })(),
    },
    {
      label: "Inventory Value",
      value: stats !== undefined && sealedStats !== undefined
        ? formatCurrency(stats.inventoryValue + sealedStats.inventoryValue, currency)
        : "—",
      icon: TrendingUp,
      color: "text-profit",
      bg: "bg-profit/10",
      sub: sealedStats?.inventoryValue ? `+${formatCurrency(sealedStats.inventoryValue, currency)} sealed` : undefined,
    },
    {
      label: "Revenue & Profit",
      value: "—" as string | number,
      icon: DollarSign,
      color: "text-blue-400",
      bg: "bg-blue-400/10",
      profit: stats?.profit,
    },
  ];

  // ── Sale Target ──────────────────────────────────────────────────
  const setSaleTarget = useMutation(api.users.setSaleTarget);
  const [targetEditOpen, setTargetEditOpen] = useState(false);
  const [targetInput, setTargetInput] = useState("");
  const [targetSaving, setTargetSaving] = useState(false);
  const [targetSaved, setTargetSaved] = useState(false);

  const saleTarget = user?.saleTarget ?? null;
  const saleTargetSetAt = user?.saleTargetSetAt ?? null;

  // Format currency without decimals for the target widget
  const fmtTarget = (v: number) => new Intl.NumberFormat("en-GB", { style: "currency", currency, minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(v);

  // Sum earnings across all days since the target was set (no 6am reset)
  const targetProgress = useQuery(
    api.earnings.getTargetProgress,
    saleTargetSetAt ? { fromDate: saleTargetSetAt } : "skip"
  );
  const earnedSinceTarget = targetProgress?.totalEarned ?? 0;
  const cardsSoldSinceTarget = targetProgress?.cardsSold ?? 0;
  const targetPct = saleTarget && saleTarget > 0 ? Math.min(100, (earnedSinceTarget / saleTarget) * 100) : 0;
  const targetReached = saleTarget !== null && earnedSinceTarget >= saleTarget;

  const handleSaveTarget = async () => {
    const val = parseFloat(targetInput);
    if (isNaN(val) || val <= 0) {
      toast.error("Enter a valid target amount");
      return;
    }
    setTargetSaving(true);
    try {
      await setSaleTarget({ target: val });
      setTargetSaved(true);
      setTimeout(() => { setTargetSaved(false); setTargetEditOpen(false); }, 400);
    } catch {
      toast.error("Failed to save target");
    } finally {
      setTargetSaving(false);
    }
  };

  const handleClearTarget = async () => {
    await setSaleTarget({ target: undefined });
    setTargetEditOpen(false);
  };


  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-3xl font-sans font-black text-primary tracking-widest">Dashboard</h1>
          <p className="text-[10px] text-muted-foreground mt-1 leading-tight">
            {DASHBOARD_GREETINGS[greetingIndex % DASHBOARD_GREETINGS.length].before}<span className="font-bold text-primary">{displayName}</span>{DASHBOARD_GREETINGS[greetingIndex % DASHBOARD_GREETINGS.length].after}
          </p>
          {(isAdmin || user?.isAffiliated || user?.isSupporter) && (
            <div className="flex items-center gap-1.5 mt-1.5">
              {isAdmin && (
                <span className="text-[9px] font-black px-2 py-0.5 rounded-full bg-[#7C3AED]/15 text-[#9D6FFF]/80 border border-[#7C3AED]/25 tracking-wide uppercase flex items-center gap-1">
                  <svg className="w-2 h-2" viewBox="0 0 24 24" fill="currentColor"><path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5zm2 3h10v1H7v-1z"/></svg>
                  Owner
                </span>
              )}
              {user?.isAffiliated && (
                <span className="text-[9px] font-black px-2 py-0.5 rounded-full bg-emerald-900/40 text-emerald-300/70 border border-emerald-700/30 tracking-wide uppercase">Affiliated</span>
              )}
              {user?.isSupporter && (
                <span className="text-[9px] font-black px-2 py-0.5 rounded-full bg-amber-900/40 text-amber-300/70 border border-amber-700/30 tracking-wide uppercase">Supporter</span>
              )}
            </div>
          )}
        </div>
        <div className="flex items-center gap-2">
          {inTeam && (
            <Button
              variant="secondary"
              onClick={handleNudge}
              disabled={onCooldown}
              className="gap-2"
              title={onCooldown ? "Nudge cooldown active" : "Nudge your teammate"}
            >
              <span className={`text-base leading-none ${onCooldown ? "opacity-50" : "animate-[wiggle_0.4s_ease-in-out]"}`}>🫨</span>
              <span className="hidden sm:inline">
                {onCooldown ? "Cooldown…" : `Nudge${nudgesLeft !== null ? ` (${nudgesLeft})` : ""}`}
              </span>
            </Button>
          )}
          <Button onClick={() => setQuickAddOpen(true)} className="gap-2">
            <Plus className="h-4 w-4" />
            <span className="hidden sm:inline">Add Card</span>
          </Button>
        </div>
      </motion.div>

      {/* ── Today's / Event Earnings hero ── */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className={`rounded-2xl border overflow-hidden transition-all ${
          eventActive
            ? "border-primary/60 bg-primary/8"
            : "border-border bg-secondary/40"
        }`}
      >
        {/* Clickable header — navigates to earnings */}
        <div
          onClick={() => navigate("/earnings")}
          className="cursor-pointer px-5 py-4 flex items-center justify-between hover:bg-white/5 transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${eventActive ? "bg-primary/20" : "bg-primary/10"}`}>
              {eventActive
                ? <Zap className="w-5 h-5 text-primary fill-primary" />
                : <TrendingUp className="w-5 h-5 text-primary" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">{earningsLabel}</span>
                {eventActive && (
                  <span className="text-[9px] font-black tracking-widest px-1.5 py-0.5 rounded-full bg-primary text-primary-foreground">EVENT</span>
                )}
              </div>
              <div className="font-black text-foreground mt-0.5 break-all leading-tight" style={{ fontSize: "clamp(1.25rem, 6vw, 1.875rem)" }}>
                {showEventTotal || todayEarnings !== undefined
                  ? earningsValue
                  : <Skeleton className="h-8 w-24 mt-1" />}
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">{earningsSub}</div>
            </div>
          </div>
          <div className="text-right hidden sm:block">
            <div className="text-xs text-muted-foreground">Tap to view</div>
            <div className="text-xs text-primary font-semibold mt-0.5">Earnings History →</div>
          </div>
        </div>

        {/* Progress bar for event days */}
        {eventActive && eventDays > 1 && (
          <div className="px-5 pb-3">
            <div className="h-1.5 bg-muted rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-primary rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${((eventDays - daysLeft) / eventDays) * 100}%` }}
                transition={{ duration: 0.8, ease: "easeOut" }}
              />
            </div>
            <div className="flex justify-between mt-1 text-[9px] text-muted-foreground">
              <span>Day 1</span>
              <span>Day {eventDays}</span>
            </div>
          </div>
        )}

        {/* 7-Day chart — collapsible toggle strip */}
        <button
          onClick={() => setShowChart(v => !v)}
          className="w-full cursor-pointer border-t border-border/60 px-5 py-2.5 flex items-center justify-between hover:bg-white/5 transition-colors focus:outline-none focus-visible:outline-none focus-visible:ring-0 focus-visible:ring-offset-0"
        >
          <div className="flex items-center gap-2">
            <ShoppingBag className="h-3.5 w-3.5 text-profit" />
            <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">7-Day Overview</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
              <span className="flex items-center gap-1"><span className="inline-block w-2 h-2 rounded-full bg-primary" /> Sales</span>
              <span className="flex items-center gap-1"><span className="inline-block w-2 h-2 rounded-full bg-profit" /> Buys</span>
            </div>
            <ChevronDown
              className={`h-3.5 w-3.5 text-muted-foreground transition-transform duration-200 ${showChart ? "rotate-180" : ""}`}
            />
          </div>
        </button>

        {/* Chart body */}
        {showChart && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 pt-1 [&_*]:outline-none">
              {weekEarnings === undefined || weekDeals === undefined ? (
                <Skeleton className="h-[110px] w-full rounded-lg" />
              ) : (
                (() => {
                  const chartData = weekDates.map((date, i) => {
                    const dayName = new Date(date + "T12:00:00").toLocaleDateString("en-GB", { weekday: "short" });
                    const isToday = date === businessDayStr();
                    return {
                      day: dayName,
                      isToday,
                      sales: weekEarnings[i]?.totalEarned ?? 0,
                      buys: weekDeals[i]?.amountPaid ?? 0,
                    };
                  });
                  const hasData = chartData.some(d => d.sales > 0 || d.buys > 0);

                  if (!hasData) {
                    return (
                      <div className="h-[110px] flex flex-col items-center justify-center gap-1.5 text-center">
                        <ShoppingBag className="h-6 w-6 text-muted-foreground/25" />
                        <p className="text-[10px] text-muted-foreground/60">No activity in the last 7 days</p>
                      </div>
                    );
                  }

                  return (
                    <div className="[&_.recharts-surface]:!stroke-none [&_.recharts-wrapper_svg]:!stroke-none [&_.recharts-surface]:outline-none [&_.recharts-wrapper]:outline-none [&_svg]:outline-none [&_rect]:outline-none [&_.recharts-bar-rectangle]:outline-none [&_*:focus]:outline-none [&_*:active]:outline-none">
                    <ResponsiveContainer width="100%" height={110}>
                      <BarChart data={chartData} barCategoryGap="28%" barGap={3} margin={{ top: 4, right: 0, left: 0, bottom: 0 }}>
                        <CartesianGrid vertical={false} stroke="currentColor" strokeOpacity={0.1} />
                        <XAxis
                          dataKey="day"
                          tick={({ x, y, payload }: { x: string | number; y: string | number; payload: { value: string; index: number } }) => {
                            const isToday = chartData[payload.index]?.isToday;
                            return (
                              <text
                                x={Number(x)} y={Number(y) + 10}
                                textAnchor="middle"
                                fontSize={9}
                                fontWeight={isToday ? 900 : 500}
                                fill={isToday ? "var(--primary)" : "var(--muted-foreground)"}
                              >
                                {payload.value}
                              </text>
                            );
                          }}
                          axisLine={false}
                          tickLine={false}
                        />
                        <YAxis hide />
                        <Tooltip
                          cursor={{ fill: "rgba(255,255,255,0.04)", radius: 4 }}
                          content={(props: unknown) => {
                            const { active, payload, label } = props as { active?: boolean; payload?: ReadonlyArray<{ name: string; value: number }>; label?: string };
                            if (!active || !payload?.length) return null;
                            const sales = payload.find(p => p.name === "sales")?.value ?? 0;
                            const buys = payload.find(p => p.name === "buys")?.value ?? 0;
                            return (
                              <div className="rounded-lg border border-border bg-card px-3 py-2 text-xs shadow-lg">
                                <p className="font-black text-foreground mb-1 uppercase tracking-widest">{label}</p>
                                {sales > 0 && <p className="text-primary font-semibold">Sales: {formatCurrency(sales, currency)}</p>}
                                {buys > 0 && <p className="text-profit font-semibold">Buys: {formatCurrency(buys, currency)}</p>}
                                {sales === 0 && buys === 0 && <p className="text-muted-foreground">No activity</p>}
                              </div>
                            );
                          }}
                        />
                        <Bar dataKey="sales" fill="var(--primary)" maxBarSize={18} minPointSize={0}
                          shape={((props: unknown) => {
                            const p = props as { x?: number; y?: number; width?: number; height?: number; fill?: string };
                            const { x = 0, y = 0, width = 0, height = 0, fill } = p;
                            if (!height || height < 1) return <g />;
                            return <rect x={x} y={y} width={width} height={height} fill={fill} rx={3} ry={3} />;
                          }) as BarProps["shape"]}
                        />
                        <Bar dataKey="buys" fill="var(--profit)" maxBarSize={18} minPointSize={0}
                          shape={((props: unknown) => {
                            const p = props as { x?: number; y?: number; width?: number; height?: number; fill?: string };
                            const { x = 0, y = 0, width = 0, height = 0, fill } = p;
                            if (!height || height < 1) return <g />;
                            return <rect x={x} y={y} width={width} height={height} fill={fill} rx={3} ry={3} />;
                          }) as BarProps["shape"]}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                    </div>
                  );
                })()
              )}
            </div>
          </motion.div>
        )}
      </motion.div>

      {/* ── Sale Target ── */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.08 }}>
        <div
          className={`rounded-2xl border overflow-hidden transition-all ${
            targetReached
              ? "border-profit/50 bg-profit/5"
              : saleTarget
                ? "border-primary/60 bg-primary/15"
                : "border-primary/50 border-dashed bg-primary/10"
          }`}
        >
          <div className="px-5 py-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${targetReached ? "bg-profit/20" : "bg-primary/10"}`}>
                  {targetReached
                    ? <Trophy className="w-4 h-4 text-profit" />
                    : <Target className="w-4 h-4 text-primary" />}
                </div>
                <div>
                  <p className="text-xs font-black uppercase tracking-widest text-muted-foreground">Sales Target</p>
                  {saleTarget ? (
                    <p className={`text-sm font-black ${targetReached ? "text-profit" : "text-foreground"}`}>
                      {fmtTarget(earnedSinceTarget)} <span className="text-muted-foreground font-normal">of</span> {fmtTarget(saleTarget)}
                      {targetReached && <span className="ml-1.5 text-[10px] font-black tracking-widest text-profit">🎯 REACHED!</span>}
                    </p>
                  ) : (
                    <p className="text-sm text-muted-foreground">No target set</p>
                  )}
                </div>
              </div>
              <button
                onClick={() => { setTargetInput(saleTarget ? String(saleTarget) : ""); setTargetEditOpen(true); }}
                className="flex items-center gap-1.5 text-xs font-semibold text-primary hover:text-primary/80 cursor-pointer transition-colors px-3 py-1.5 rounded-lg bg-primary/10 hover:bg-primary/20"
              >
                <Edit2 className="h-3 w-3" />
                {saleTarget ? "Edit" : "Set Target"}
              </button>
            </div>

            {saleTarget ? (
              <>
                <div className="h-2.5 bg-muted rounded-full overflow-hidden">
                  <motion.div
                    className={`h-full rounded-full transition-colors ${targetReached ? "bg-profit" : "bg-primary"}`}
                    initial={{ width: 0 }}
                    animate={{ width: `${targetPct}%` }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                  />
                </div>
                <div className="flex justify-between mt-1.5">
                  <span className="text-[10px] text-muted-foreground">{targetPct.toFixed(0)}% complete</span>
                  {!targetReached && (
                    <span className="text-[10px] text-muted-foreground">
                      {fmtTarget(Math.max(0, saleTarget - earnedSinceTarget))} to go
                    </span>
                  )}
                </div>
              </>
            ) : (
              <p className="text-[11px] text-muted-foreground/70">Set a sales target — it rolls across days and won't reset until you hit it</p>
            )}
          </div>
        </div>
      </motion.div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 items-stretch">
        {statItems.map((item, i) => (
          <motion.div
            key={item.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 + 0.1 }}
            className="h-full"
          >
            <Card className="border-border h-full">
              <CardContent className="p-4 min-h-[118px] overflow-hidden">
                <div className={`inline-flex p-2 rounded-lg ${item.bg} mb-3`}>
                  <item.icon className={`h-4 w-4 ${item.color}`} />
                </div>
                {"profit" in item ? (
                  <>
                    {stats === undefined ? (
                      <Skeleton className="h-7 w-16" />
                    ) : (
                      <div className="font-bold text-foreground leading-tight break-all" style={{ fontSize: "clamp(0.875rem, 4.5vw, 1.5rem)" }}>{formatCurrency((stats.soldValue) + (sealedStats?.soldOutValue ?? 0), currency)}</div>
                    )}
                  </>
                ) : (
                  <div className="font-bold text-foreground leading-tight break-all" style={{ fontSize: "clamp(0.875rem, 4.5vw, 1.5rem)" }}>{
                    stats === undefined ? <Skeleton className="h-7 w-16" /> : item.value
                  }</div>
                )}
                <div className="text-xs text-muted-foreground mt-1 truncate">{item.label}</div>
                {"sub" in item && item.sub && (
                  <div className="text-[10px] text-muted-foreground/60 mt-0.5 truncate">{item.sub}</div>
                )}
                  {"profit" in item && stats !== undefined && (
                    <div className={`text-xs font-bold mt-0.5 truncate ${(stats.profit ?? 0) >= 0 ? "text-profit" : "text-red-400"}`}>
                      ({(stats.profit ?? 0) >= 0 ? "+" : ""}{formatCurrency(stats.profit ?? 0, currency)})
                    </div>
                  )}
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: "Scan QR Code",   icon: ScanLine, path: "/scan",      color: "bg-primary/10 hover:bg-primary/20 border-primary/20",         iconColor: "text-primary",    action: null, badge: "BARCODE" },
          { label: "Bulk Sale",      icon: Users,    path: null,          color: "bg-profit/10 hover:bg-profit/20 border-profit/25",   iconColor: "text-profit",  action: () => setBulkSaleOpen(true), badge: null },
          { label: "Print Labels",   icon: Tag,      path: "/labels",     color: "bg-card hover:bg-secondary border-border",                    iconColor: "text-primary",    action: null, badge: null },
          { label: "View Inventory", icon: Package,  path: "/inventory",  color: "bg-card hover:bg-secondary border-border",                    iconColor: "text-primary",    action: null, badge: null },
        ].map(({ label, icon: Icon, path, color, iconColor, action, badge }) => (
          <button
            key={label}
            onClick={() => action ? action() : navigate(path!)}
            className={`cursor-pointer flex flex-col items-center justify-center gap-2 p-5 rounded-xl border transition-colors ${color}`}
          >
            <Icon className={`h-6 w-6 ${iconColor}`} />
            <span className="text-sm font-semibold">{label}</span>
            {badge && (
              <span className="text-[8px] font-black tracking-widest px-1.5 py-0.5 rounded-full bg-primary/20 text-primary border border-primary/30 leading-none">
                {badge}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Bulk Sale dialog */}
      <Dialog open={bulkSaleOpen} onOpenChange={setBulkSaleOpen}>
        <DialogContent className="max-w-lg p-0 overflow-hidden">
          <BulkSale onClose={() => setBulkSaleOpen(false)} />
        </DialogContent>
      </Dialog>

      {/* Quick Add Card dialog */}
      <Dialog open={quickAddOpen} onOpenChange={setQuickAddOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Add Card</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-1">
            <div className="space-y-1.5">
              <Label>Card Name <span className="text-primary">*</span></Label>
              <Input
                placeholder="e.g. Charizard, Black Lotus"
                value={quickForm.name}
                onChange={e => setQuickForm(f => ({ ...f, name: e.target.value }))}
                onKeyDown={e => e.key === "Enter" && handleQuickAdd()}
                autoFocus
              />
            </div>
            <div className="space-y-1.5">
              <Label>Game</Label>
              <Select value={quickForm.game} onValueChange={v => setQuickForm(f => ({ ...f, game: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CARD_GAMES.map(g => (
                    <SelectItem key={g} value={g}>{g}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Condition</Label>
              <Select value={quickForm.condition} onValueChange={v => setQuickForm(f => ({ ...f, condition: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CARD_CONDITIONS.map(c => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Price (optional)</Label>
              <Input
                type="number"
                placeholder="0.00"
                value={quickForm.marketValue}
                onChange={e => setQuickForm(f => ({ ...f, marketValue: e.target.value }))}
              />
            </div>
            <p className="text-xs text-muted-foreground">You can add a photo and more details in Inventory.</p>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setQuickAddOpen(false)}>Cancel</Button>
            <Button onClick={handleQuickAdd} disabled={quickSaving || !quickForm.name.trim()}>
              {quickSaving ? "Saving…" : "Add Card"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Buyer Percentage Calculator */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}>
        <Card className="border-border overflow-hidden">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Percent className="h-4 w-4 text-primary" />
              Buyer Percentage Calculator
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Price inputs */}
            <div className="space-y-2">
              <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Card Prices ({currency})</Label>
              {calcPrices.map((price, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <Input
                    type="number"
                    step="0.01"
                    placeholder={`Card ${idx + 1} price`}
                    value={price}
                    onChange={e => updateCalcPrice(idx, e.target.value)}
                    className="h-10 text-sm font-bold flex-1"
                  />
                  {calcPrices.length > 1 && (
                    <button
                      onClick={() => removeCalcPrice(idx)}
                      className="w-8 h-8 flex items-center justify-center rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors cursor-pointer shrink-0"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              ))}
              {calcPrices.length < 20 && (
                <button
                  onClick={addCalcPrice}
                  className="flex items-center gap-1.5 text-xs font-semibold text-primary hover:text-primary/80 cursor-pointer transition-colors"
                >
                  <Plus className="h-3.5 w-3.5" />
                  Add another card price ({calcPrices.length}/20)
                </button>
              )}
              {calcPrices.length > 1 && calcTotalPrice > 0 && (
                <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-secondary/50 border border-border">
                  <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Total</span>
                  <span className="text-sm font-black">{formatCurrency(calcTotalPrice, currency)}</span>
                </div>
              )}
            </div>

            {/* Percentage input */}
            <div className="space-y-1.5">
              <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">% to Customer</Label>
              <Input
                type="number"
                step="1"
                min="1"
                max="100"
                placeholder="e.g. 70"
                value={calcPct}
                onChange={e => setCalcPct(e.target.value)}
                className="h-11 text-base font-bold"
              />
            </div>

            {/* Quick % buttons */}
            <div className="flex gap-2 flex-wrap">
              {[50, 60, 70, 75, 80].map(p => (
                <button
                  key={p}
                  onClick={() => setCalcPct(String(p))}
                  className={`px-3 py-1 rounded-full text-xs font-bold border transition-all cursor-pointer ${
                    calcPct === String(p)
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-secondary text-muted-foreground border-border hover:border-primary/40 hover:text-foreground"
                  }`}
                >
                  {p}%
                </button>
              ))}
            </div>

            {/* Result */}
            {calcResult ? (
              <motion.div
                key={`${calcResult.pay}-${calcResult.keep}`}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                className="rounded-xl border border-primary/20 bg-primary/5 overflow-hidden"
              >
                <div className="grid grid-cols-2 divide-x divide-primary/15">
                  <div className="px-4 py-3 text-center">
                    <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground mb-1">Pay Customer</p>
                    <p className="text-2xl font-black text-primary">{formatCurrency(calcResult.pay, currency)}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">{calcResult.pct}% of card value</p>
                  </div>
                  <div className="px-4 py-3 text-center">
                    <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground mb-1">You Keep</p>
                    <p className="text-2xl font-black text-profit">{formatCurrency(calcResult.keep, currency)}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">{(100 - calcResult.pct).toFixed(0)}% margin</p>
                  </div>
                </div>
                <div className="px-4 py-2 bg-primary/8 border-t border-primary/15 flex items-center justify-center gap-1.5">
                  <span className="text-xs text-muted-foreground">{calcPrices.length > 1 ? "Total" : "Card price"}</span>
                  <span className="text-xs font-bold">{formatCurrency(calcTotalPrice, currency)}</span>
                  <ArrowRight className="h-3 w-3 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">Customer gets</span>
                  <span className="text-xs font-bold text-primary">{formatCurrency(calcResult.pay, currency)}</span>
                </div>
                <div className="px-4 py-3 border-t border-primary/15 space-y-2.5">
                  <input
                    type="text"
                    value={calcNote}
                    onChange={e => setCalcNote(e.target.value)}
                    placeholder="Add a note… e.g. Charizard, PSA 9"
                    maxLength={80}
                    className="w-full h-9 rounded-lg border border-border bg-secondary/50 px-3 text-xs text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-1 focus:ring-primary/50 transition-all"
                  />
                  <Button
                    className="w-full h-11 font-black gap-2 text-sm"
                    onClick={handleDealAccepted}
                    disabled={dealSaving || dealJustSaved}
                  >
                    {dealJustSaved
                      ? <><CheckCircle2 className="h-4 w-4" /> Deal Logged!</>
                      : dealSaving
                        ? "Logging..."
                        : <><CheckCircle2 className="h-4 w-4" /> Deal Accepted</>
                    }
                  </Button>
                </div>
              </motion.div>
            ) : (
              <div className="rounded-xl border border-dashed border-border py-5 flex flex-col items-center gap-1 text-center">
                <Percent className="h-5 w-5 text-muted-foreground/40" />
                <p className="text-xs text-muted-foreground">Enter a price and % to calculate</p>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Recent cards */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Clock className="h-4 w-4 text-primary" />
              Recent Sold
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={() => navigate("/inventory")}>
              View all
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-2">
          {recentSold === undefined ? (
            Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-14 w-full" />)
          ) : recentSold.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <CheckCircle2 className="h-8 w-8 mx-auto mb-2 opacity-40" />
              <p className="text-sm">No sales yet — mark a card or product as sold!</p>
            </div>
          ) : (
            recentSold.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 border border-border cursor-pointer hover:bg-secondary transition-colors"
                onClick={() => setSelectedSoldItem(item)}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${item.type === "sealed" ? "bg-blue-500/10" : "bg-primary/10"}`}>
                    {item.type === "sealed"
                      ? <Barcode className="h-3.5 w-3.5 text-blue-400" />
                      : <Package className="h-3.5 w-3.5 text-primary" />
                    }
                  </div>
                  <div className="min-w-0">
                    <p className="font-semibold text-sm truncate">{item.name}</p>
                    <p className="text-xs text-muted-foreground">{item.subtitle}</p>
                  </div>
                </div>
                <div className="text-right shrink-0 ml-2">
                  {item.salePrice !== undefined && (
                    <p className="text-sm font-bold text-profit">{formatCurrency(item.salePrice, currency)}</p>
                  )}
                  {item.profit !== undefined && (
                    <p className={`text-xs font-semibold ${item.profit >= 0 ? "text-profit" : "text-red-400"}`}>
                      {item.profit >= 0 ? "+" : ""}{formatCurrency(item.profit, currency)}
                    </p>
                  )}
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>

      {/* Sold Item Info Dialog */}
      <Dialog open={!!selectedSoldItem} onOpenChange={o => { if (!o) setSelectedSoldItem(null); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="font-sans text-primary tracking-widest text-lg leading-tight pr-6">
              {selectedSoldItem?.name}
            </DialogTitle>
          </DialogHeader>
          {selectedSoldItem && (
            <div className="space-y-3 pt-1">
              <div className="flex flex-wrap gap-1.5">
                <Badge variant="secondary">{selectedSoldItem.type === "sealed" ? "Sealed" : "Card"}</Badge>
                <Badge className="bg-profit/20 text-profit border-profit/30">Sold</Badge>
              </div>
              <p className="text-sm text-muted-foreground">{selectedSoldItem.subtitle}</p>
              <div className="grid grid-cols-2 gap-2">
                {selectedSoldItem.salePrice !== undefined && (
                  <div className="bg-secondary/50 border border-border rounded-lg p-2.5">
                    <p className="text-[10px] font-bold tracking-widest text-muted-foreground uppercase mb-0.5">Sale Price</p>
                    <p className="text-sm font-semibold text-profit">{formatCurrency(selectedSoldItem.salePrice, currency)}</p>
                  </div>
                )}
                {selectedSoldItem.profit !== undefined && (
                  <div className="bg-secondary/50 border border-border rounded-lg p-2.5">
                    <p className="text-[10px] font-bold tracking-widest text-muted-foreground uppercase mb-0.5">Profit</p>
                    <p className={`text-sm font-semibold ${selectedSoldItem.profit >= 0 ? "text-profit" : "text-red-400"}`}>
                      {selectedSoldItem.profit >= 0 ? "+" : ""}{formatCurrency(selectedSoldItem.profit, currency)}
                    </p>
                  </div>
                )}
                <div className="bg-secondary/50 border border-border rounded-lg p-2.5 col-span-2">
                  <p className="text-[10px] font-bold tracking-widest text-muted-foreground uppercase mb-0.5">Sold At</p>
                  <p className="text-sm font-semibold">{new Date(selectedSoldItem.soldAt).toLocaleString()}</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" className="w-full gap-2 text-muted-foreground" onClick={() => { setSelectedSoldItem(null); navigate("/inventory"); }}>
                <ArrowRight className="h-4 w-4" /> View in Inventory
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Deal Receipt Dialog */}
      <Dialog open={dealReceiptOpen} onOpenChange={setDealReceiptOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <CheckCircle2 className="h-5 w-5 text-profit" />
              Deal Logged!
            </DialogTitle>
          </DialogHeader>
          {dealReceiptData && (
            <div className="space-y-4">
              {/* Deal summary */}
              <div className="rounded-xl border border-border bg-secondary/30 overflow-hidden">
                <div className="grid grid-cols-2 divide-x divide-border">
                  <div className="px-3 py-3 text-center">
                    <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground mb-1">Paid Customer</p>
                    <p className="text-xl font-black text-primary">{formatCurrency(dealReceiptData.pay, currency)}</p>
                  </div>
                  <div className="px-3 py-3 text-center">
                    <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground mb-1">You Keep</p>
                    <p className="text-xl font-black text-profit">{formatCurrency(dealReceiptData.keep, currency)}</p>
                  </div>
                </div>
                <div className="px-3 py-2 border-t border-border bg-secondary/50 flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">{dealReceiptData.prices.length} card{dealReceiptData.prices.length > 1 ? "s" : ""} · {dealReceiptData.pct}%</span>
                  <span className="font-bold">Total: {formatCurrency(dealReceiptData.totalPrice, currency)}</span>
                </div>
                {dealReceiptData.note && (
                  <div className="px-3 py-2 border-t border-border text-xs text-muted-foreground">
                    Note: {dealReceiptData.note}
                  </div>
                )}
              </div>

              {/* Send receipt to customer */}
              <div className="space-y-2">
                <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Send Receipt to Customer</p>
                <Input
                  type="email"
                  placeholder="customer@example.com"
                  value={dealCustomerEmail}
                  onChange={e => setDealCustomerEmail(e.target.value)}
                />
                <Button
                  className="w-full gap-2"
                  disabled={!dealCustomerEmail.trim() || dealSendingReceipt}
                  onClick={async () => {
                    if (!dealCustomerEmail.trim() || !dealReceiptData) return;
                    if (!user?.senderEmail) {
                      toast.error("Set your sender email in Settings first");
                      return;
                    }
                    setDealSendingReceipt(true);
                    try {
                      await sendDealReceipt({
                        to: dealCustomerEmail.trim(),
                        senderEmail: user.senderEmail,
                        totalPrice: dealReceiptData.totalPrice,
                        amountPaid: dealReceiptData.pay,
                        pct: dealReceiptData.pct,
                        prices: dealReceiptData.prices,
                        currency,
                        note: dealReceiptData.note || undefined,
                        businessName: user?.businessName,
                        instagram: user?.instagram,
                        website: user?.website,
                      });
                      toast.success("Receipt sent to customer!");
                      setDealCustomerEmail("");
                      setDealReceiptOpen(false);
                    } catch {
                      toast.error("Failed to send receipt. Check your sender email is verified.");
                    } finally {
                      setDealSendingReceipt(false);
                    }
                  }}
                >
                  {dealSendingReceipt ? <Loader2 className="h-4 w-4 animate-spin" /> : <Mail className="h-4 w-4" />}
                  {dealSendingReceipt ? "Sending..." : "Send Receipt"}
                </Button>
                <p className="text-[10px] text-muted-foreground leading-relaxed"><span className="font-bold text-primary">Pro tip:</span> Let the customer know the receipt may take a moment to arrive — and that it may land in their <span className="font-semibold text-foreground">junk mail</span> or <span className="font-semibold text-foreground">spam</span> folder.</p>
              </div>

              <Button
                variant="secondary"
                className="w-full"
                onClick={() => setDealReceiptOpen(false)}
              >
                Done
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Sale Target Edit Dialog */}
      <Dialog open={targetEditOpen} onOpenChange={setTargetEditOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Target className="h-5 w-5 text-primary" />
              Set Sales Target
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-1">
            <div className="space-y-1.5">
              <Label>Target Amount ({currency})</Label>
              <Input
                type="number"
                step="0.01"
                min="0.01"
                placeholder="e.g. 500"
                value={targetInput}
                onChange={e => setTargetInput(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleSaveTarget()}
                autoFocus
              />
              <p className="text-xs text-muted-foreground">Tracks revenue from cards sold from today onwards — rolls across days and won't reset until you hit it.</p>
            </div>
          </div>
          <DialogFooter className="gap-2">
            {saleTarget && (
              <Button variant="ghost" className="text-red-400 hover:text-red-400" onClick={handleClearTarget}>
                Clear
              </Button>
            )}
            <Button variant="ghost" onClick={() => setTargetEditOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveTarget} disabled={targetSaving} className={`transition-colors ${targetSaved ? "bg-profit hover:bg-profit text-white" : ""}`}>
              {targetSaving ? "Saving…" : "Save Target"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
