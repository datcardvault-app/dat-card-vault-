import { Coffee, Heart } from "lucide-react";
import { motion } from "motion/react";

export default function SupportPage() {
  return (
    <div className="max-w-lg mx-auto px-4 py-8 space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="rounded-2xl border-2 border-black dark:border-white/80 p-6 text-center space-y-4"
        style={{ background: "rgba(180,140,20,0.06)" }}
      >
        <div className="flex justify-center">
          <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ background: "rgba(180,140,20,0.12)", border: "2px solid black" }}>
            <Coffee className="w-8 h-8" style={{ color: "#b08c14" }} />
          </div>
        </div>

        <div className="space-y-2">
          <h1 className="text-2xl font-black tracking-wide text-foreground">
            Enjoying Dat<span className="text-primary">CARD</span>Vault?
          </h1>
          <p className="text-sm text-muted-foreground leading-relaxed max-w-sm mx-auto">
            Help keep development going and support the team with a coffee. Every contribution goes directly into making the app better for every vendor.
          </p>
          <p className="text-xs font-bold text-primary">
            Donate with the same email you use for DatCARDVault and you'll automatically receive the Supporter role. ☕
          </p>
        </div>

        <a
          href="https://www.paypal.com/donate/?hosted_button_id=Q7QAPKCV8ML44"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center justify-center gap-2.5 w-full h-12 rounded-xl font-bold text-sm transition-colors cursor-pointer text-black"
          style={{ background: "#c9a520" }}
          onMouseOver={(e) => { e.currentTarget.style.background = "#b08c14"; }}
          onMouseOut={(e) => { e.currentTarget.style.background = "#c9a520"; }}
        >
          <Coffee className="w-4 h-4" />
          Buy the Dev Team a Coffee
        </a>

        {/* QR Code */}
        <div className="flex flex-col items-center gap-2">
          <p className="text-xs text-muted-foreground">Or scan to donate</p>
          <img
            src="https://hercules-cdn.com/file_o6cuVPZu8ZwUxQVGID0pfUkq"
            alt="Buy Me a Coffee QR Code"
            className="w-48 h-48 rounded-2xl border-2 border-black dark:border-white/80"
          />
        </div>

        <p className="text-[11px] text-muted-foreground/60 flex items-center justify-center gap-1">
          <Heart className="w-3 h-3 text-primary" />
          Made with love by the DatCARDVault team
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15, duration: 0.4 }}
        className="rounded-2xl border border-border bg-secondary/30 p-5 space-y-3"
      >
        <h2 className="text-sm font-bold text-foreground">Why support us?</h2>
        <ul className="space-y-2 text-sm text-muted-foreground">
          {[
            "DatCARDVault is free to use — no subscription, no paywalls",
            "Your support helps fund new features and keeps the servers running",
            "Every coffee keeps the dev team motivated and coding",
            "You're supporting something built specifically for TCG vendors like you",
            "Receive a SUPPORT badge on your account",
          ].map((item) => (
            <li key={item} className="flex items-start gap-2">
              <span className="text-primary font-bold mt-0.5">•</span>
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </motion.div>
    </div>
  );
}
