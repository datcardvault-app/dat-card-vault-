/** Master list of card games — used by all forms (quick-add, full add, inventory, scan) */
export const CARD_GAMES = [
  "Pokémon",
  "Magic: The Gathering",
  "Yu-Gi-Oh! Official",
  "One Piece",
  "Flesh and Blood",
  "Digimon",
  "Star Wars: Unlimited",
  "Weiss Schwarz",
  "Cardfight!! Vanguard",
  "Lorcana",
  "Dragon Ball Super",
  "Other",
] as const;

export const CARD_CONDITIONS = [
  "Mint",
  "Near Mint",
  "Excellent",
  "Good",
  "Lightly Played",
  "Moderately Played",
  "Heavily Played",
  "Poor",
] as const;

/** Vault capacity limit — must match the backend enforcement in convex/cards.ts */
export const VAULT_CARD_LIMIT = 500;
